<?php
class VisaoSorteioSMS {
	static function getMsgTit($idS, $vencedor, $numPremio, $nomePremio, $vdUsu) {
		$comboUsu = new HtmlCombo('ramal1', $vdUsu, "id='comboRamais$numPremio'");
		$txtV = substr($vencedor->numero,0,3) . 'XXX' . substr($vencedor->numero,6,4) . " $vencedor->nome";
		$btns = "$txtV: " . new HtmlBtn("envSMS$numPremio", "value='Enviar SMS!' onclick='enviaSMS($idS, $numPremio)'") . " - $comboUsu " . 
				new HtmlBtn("chamar$numPremio",  "value='Contactar!'  onclick='chama($idS, $numPremio)'");
		return "<h5>$numPremio o Sorteio Conclu�do. Vencedor do $numPremio o pr�mio [ $nomePremio ] => [ $txtV ]</h5>\n$btns<br><br>";
	}
	
	function preparaTela($smarty, $nomeTela) {
		global $sessao;
		
		switch($nomeTela) {
			case 'sorteios':
				$idRoda = $sessao->getVar('idSorteioRoda');
				if(!empty($idRoda)) {
					$smarty->assign('mostraSorteio', true);
					
					$sorteio = new Sorteio($idRoda);
					$smarty->assign('sorteio', $sorteio);
					$totP = Conexao::getStr("SELECT count(id) AS total FROM sorteioparticipante WHERE idsorteio = '$sorteio->id'");
					
					if($sorteio->situacao < 3) { 
						if($sorteio->situacao == 1) {
							$smarty->assign('rodando', true);
							$msgTit = "<h5>Para participar envie um SMS com seu nome para [ $sorteio->numero ]</h5>\n";
							if($sorteio->multiplo) $msgTit .= "<h2>Envie quantos SMS quiser para aumentar as suas chances!</h2>\n";
						} else if($sorteio->situacao == 2) $msgTit = "<h5>Inscri��es encerradas. [ Aguardando Sorteio ]</h5>\n";
						$msgTit .= "<h2>1o Pr�mio: $sorteio->premio1</h2>\n";
						if(!empty($sorteio->premio2))
							$msgTit .= "<h2>2o Pr�mio: $sorteio->premio2</h2>\n";
						if(!empty($sorteio->premio3))
							$msgTit .= "<h2>3o Pr�mio: $sorteio->premio3</h2>\n";
					} else {
						$totP -= ($sorteio->situacao - 2);
						$vdUsu = Util::HtmlComboRamais(null, '-- Escolha o Ramal para contactar o vencedor --');
						$msgTit = VisaoSorteioSMS::getMsgTit($sorteio->id, new SorteioParticipante($sorteio->idvencedor1), 1, $sorteio->premio1, $vdUsu);
						if($sorteio->situacao >= 4) {
							$msgTit .= VisaoSorteioSMS::getMsgTit($sorteio->id, new SorteioParticipante($sorteio->idvencedor2), 2, $sorteio->premio2, $vdUsu);
						} else if(!empty($sorteio->premio2))
							$msgTit .= "<h5>2o Pr�mio: $sorteio->premio2</h5>\n";
						if($sorteio->situacao >= 5) {
							$msgTit .= VisaoSorteioSMS::getMsgTit($sorteio->id, new SorteioParticipante($sorteio->idvencedor3), 3, $sorteio->premio3, $vdUsu);
						} else if(!empty($sorteio->premio3))
							$msgTit .= "<h5>3o Pr�mio: $sorteio->premio3</h5>\n";
					}
					$smarty->assign('msgTit', $msgTit);
					$smarty->assign('totP', $totP);
					
					$participantes = bdFacil::todosSQL('SorteioParticipante', "SELECT * FROM sorteioparticipante WHERE idsorteio = '$sorteio->id'");
					if(Util::tem($participantes)) {
						$smarty->assign('temParts', true);
						$trs = array();
						$tr  = "<tr class='linha1'>";
						$cnt = $l = $prt = 0;
						foreach($participantes as $participante) {
							$num = substr($participante->numero,0,3) . 'XXX' . substr($participante->numero,6,4);
							list($nome) = explode(' ', $participante->nome);
							$idTD = " id='part$prt'";
							$classe = '';
							if($sorteio->situacao >= 3) {
								if($participante->id == $sorteio->idvencedor1) $classe = " class='tdSorteado'";
								if($sorteio->situacao >= 4 && $participante->id == $sorteio->idvencedor2) $classe = " class='tdSorteado2'";
								if($sorteio->situacao >= 5 && $participante->id == $sorteio->idvencedor3) $classe = " class='tdSorteado3'";
							}
							if(!empty($classe)) $idTD = '';
							else                $prt++;
							$tr .= "<td width='25%' align='center'$idTD$classe>$participante->id - $num - <b>$nome</b></td>";
							if($cnt++ == 3) {
								$trs[] = "$tr</tr>\n";
								$l = 1 - $l;
								$cls = $l ? 2 : 1;
								$tr  = "<tr class='linha$cls'>";
								$cnt = 0;
							}
						}
						if($cnt != 0) {
							for($c=$cnt;$c<4;$c++)
								$tr .= "<td width='25%'>&nbsp;</td>";
							$trs[] = "$tr</tr>\n";
						}
						$smarty->assign('parts', $trs);
					}
					if($sorteio->situacao == 1) {
						$btFinal = new HtmlBtn('encerra', 'value="Encerrar sorteio" onclick="encerrar()"');
					} else if($sorteio->situacao >= 2) {
						$numV = $sorteio->situacao - 1;
						$smarty->assign('numV', $numV);
						if($numV == 1 || ($numV == 2 && !empty($sorteio->premio2)) || ($numV == 3 && !empty($sorteio->premio3))) {
							$txt = "Sortear pr�mio $numV !!";
							$btFinal = new HtmlBtn('sorteia', "value='$txt' onclick='sortear($totP)'");
						}
					}
					$smarty->assign('btns', $btFinal . ' ' . new HtmlBtn('volta',   'value="Voltar para a lista de Sorteios" onclick="roda(0)"'));
				} else {
					$sorteios = bdFacil::todos('Sorteio');
					if(Util::tem($sorteios)) {
						$smarty->assign('temSorteios', true);
						$imgPlay = new HtmlImg("btnPlay.png");
						foreach($sorteios as $sorteio) {
							$sorteio->icoPlay = "<a href='javascript:roda($sorteio->id)'>$imgPlay</a>";
							switch($sorteio->situacao) {
								case 0: $sorteio->situacao = 'Cadastrado';   break;
								case 1: $sorteio->situacao = 'Em Andamento'; break;
								case 2: $sorteio->situacao = 'Inscricoes Encerradas'; break;
								case 3: $sorteio->situacao = (!empty($sorteio->premio2)) ? 'Sorteado 1' : 'Conclu�do'; break;
								case 4: $sorteio->situacao = (!empty($sorteio->premio3)) ? 'Sorteado 2' : 'Conclu�do'; break;
								case 5: $sorteio->situacao = 'Conclu�do';    break;
							}
							$sorteio->participantes = Conexao::getStr("SELECT count(id) AS total FROM sorteioparticipante WHERE idsorteio = '$sorteio->id'");
						}
						$smarty->assign('sorteios', $sorteios);
					}
					
					$smarty->assign('cxTxtNome',    new HtmlText('nome'));
					$smarty->assign('cxTxtNumSMS',  new HtmlText('numero'));
					$smarty->assign('chkMultiplas', new HtmlCheck('multiplo'));
					$smarty->assign('infoMultiplas',new HtmlInfo('Permitir mais de uma inscri��o por n�mero de celular'));
					$smarty->assign('cxTxtPremio1', new HtmlText('premio1', "size='60'"));
					$smarty->assign('cxTxtPremio2', new HtmlText('premio2', "size='60'"));
					$smarty->assign('cxTxtPremio3', new HtmlText('premio3', "size='60'"));
					$smarty->assign('btnOK',        new HtmlBtn('ok', 'value="Novo Sorteio" onclick="novo()"'));
				}
				break;
		}
	}
}
?>