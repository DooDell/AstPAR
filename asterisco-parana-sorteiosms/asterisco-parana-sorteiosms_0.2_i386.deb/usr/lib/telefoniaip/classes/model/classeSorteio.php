<?php
class Sorteio extends bdFacil {
	var $nome, $numero, $situacao, $multiplo;
	var $premio1, $premio2, $premio3;
	var $idvencedor1, $idvencedor2, $idvencedor3;
	
	function escreveConf() {
		// Escrever arquivo de conf
		$trataSMS = "
[khomp-sms-00-00]
exten => s,1,System(/usr/lib/telefoniaip/arquivos/scripts/trataSMSSorteio.php,$this->numero,".'${KSmsFrom},${KSmsBody}'.") 
[khomp-sms-00-01]
exten => s,1,System(/usr/lib/telefoniaip/arquivos/scripts/trataSMSSorteio.php,$this->numero,".'${KSmsFrom},${KSmsBody}'.")
[khomp-sms-00-02]
exten => s,1,System(/usr/lib/telefoniaip/arquivos/scripts/trataSMSSorteio.php,$this->numero,".'${KSmsFrom},${KSmsBody}'.")
[khomp-sms-00-03]
exten => s,1,System(/usr/lib/telefoniaip/arquivos/scripts/trataSMSSorteio.php,$this->numero,".'${KSmsFrom},${KSmsBody}'.")
";
		return Asterisk::escreveECopiaConf('trataSMSSorteio.conf', $trataSMS, 'telip', true);
	}
	
	static function limpaConf() {
		// Limpa o arquivo de conf
		return Asterisk::escreveECopiaConf('trataSMSSorteio.conf', '', 'telip', 'dialplan reload');
	}
}
?>