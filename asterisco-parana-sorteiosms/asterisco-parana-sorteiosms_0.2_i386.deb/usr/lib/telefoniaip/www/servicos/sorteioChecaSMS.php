<?php
	include(''.'/usr/lib/telefoniaip/includePrincipal.php');
	
	$idS   = $_GET['idS'];
	$atual = $_GET['atual'];
	
	$totP = Conexao::getStr("SELECT count(id) AS total FROM sorteioparticipante WHERE idsorteio = '$idS'");
	
	echo ($totP != $atual) ? 'NOVO!' : '0';
?>