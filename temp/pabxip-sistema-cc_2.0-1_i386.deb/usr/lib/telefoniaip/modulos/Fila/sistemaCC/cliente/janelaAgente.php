<?
	// TODO - Tematizar

	include('comandos.php');
	$agente = loginOK(); // Verifica se o Agente logado esta na sess�o
	
	$temTELIP = false;
	$podeDiscarPausa = true;

	// Busca os nomes das pausas no banco de dados
	$motivos = buscaMotivos();
	
	// Busca os dados das Filas (urlpopup,urlpopupfim,tipopiloto)
	$dadosFilas = buscaDadosFilaJA($agente);
	$urlAgenda  = buscaURL('Agendamento');
	$urlEmail   = buscaURL('Email');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
	<head>
		<title>.: <? echo $agente->nome; ?> :.</title>
		<link rel="Stylesheet" href="css/agente.css" type="text/css" media="screen">
		<script type="text/javascript" src="javascript/Usuario.js"></script>
		<script type="text/javascript" src="javascript/Fila.js"></script>
		<script type="text/javascript" src="javascript/popupmenu.js"></script>
	</head>
	<body>
		<form name="dados">
			<div id="divJanelaAgente">
				<div id="barra_acao_top">
					<table width="100%">
					    <tr>
					    	<td id="tdDisponivel">Login</td>
					    	<td id="tdPausa">Pausa</td>
					    	<td id="tdIndisponivel">Indispon�vel</td>
					    	<td id="tdLogoff">Sair</td>
					    </tr>
					</table>
				</div>
				<table width="100%">
				    <tr>
				    	<td><input class="msgAgente" type="text" name="mensagem" readonly="true"></td>
				    	<td class="btnMsgAgente"><input type="button" name="limpa" value="Limpar" onclick="limpaMsg()"></td>
				    </tr>
				</table>
				
				<div id="divAtendimento">
					<table id="tabelaFilas" cellspacing=0>
						<thead>
					    	<td>Fila</td>
					    	<td>Liga��es na Fila</td>
					    	<td>Tempo de Espera</td>
					    	<td class='ultimo'>Tempo M�dio de Espera </td>
					    </thead>
					</table>
				</div>
				
				<div id="barra_acao_bottom">
				  <ul>
				    <li id="tdDiscar">Discar</li>
				    <li id="tdTransferir">Transferir</li>
				    <li id="tdConferencia">Confer�ncia</li>
				    <? echo ($temTELIP) ? "<li id='tdTELIP'></li>\n" : '<li id="tdDesligar">Desligar</li>'; ?>
				  </ul>
				</div>
				<input type="text" name="caixaEntrada" size="60" onkeypress='return okpCxEntrada(event)'>
				<textarea name="mensagens" rows="4" wrap="virtual" readonly='true'></textarea>
				<table width="100%"><tr><td align="right" id="brStatus">status</td></tr></table>					
			</div>
		</form>
		<? if($temTELIP) echo "<img src='' width='0px' height='0px' id='imgTELIP'>\n"; ?>
		<script type="text/javascript">
			// Estados <
			DESLOGADO  = <? echo DESLOGADO  ?>;
			DISPONIVEL = <? echo DISPONIVEL ?>;
			CHAMANDO   = <? echo CHAMANDO   ?>;
			ATENDENDO  = <? echo ATENDENDO  ?>;
			SAINTE     = <? echo SAINTE     ?>;
			DISCANDO   = <? echo DISCANDO   ?>;
			ENTRANTE   = <? echo ENTRANTE   ?>;
			PAUSA      = <? echo PAUSA      ?>;
			INDISP     = <? echo INDISP     ?>;
			
			// AJAX
			var ajax = new XMLHttpRequest();
			var ajaxKA = new XMLHttpRequest();
			// Comet
			var comet = null;
			
			// Variaveis de Controle
			var logado      = 0;			// Flag
			var txtNumEntra = '';			// Ultimo numero recebido
			var ultimoBtn   = '';			// Ultimo bot�o clicado, para prevenir duplo clique nos botoes
			var linha       = true;			// Cor da linha da tabela de filas
			
			// Dados do usu�rio e suas filas
			var usuario  = new Usuario();	// Dados do usu�rio logado
			var filas    = new Array();		// Dados das filas do usu�rio
			var pausas   = new Array();		// Nomes das pausas
			var indisp   = new Array();		// Nomes das Indisp
			var urls     = new Array();		// URLs para popup por fila
			var urlsfim  = new Array();		// URLs para popup ao desligar por fila
			var tipofila = new Array();		// Tipo da Fila ('R' = entrada por ramal, 'M' = entrada por eMail)
			var urlEmail = '<? echo $urlEmail ?>';
			
			// "widgets"
			var cxMsg;
			var btnDisponivel, btnPausa, btnIndisponivel, btnLogoff;
			var btnDiscar, btnTransferir, btnConferencia;
			var cxTxtEntrada, cxMensagens, popupPausa, popupIndisp;
			var popup; // Janela CRM
			
			var msgs = new Array('', '', '', '');
			
			/**
			 * Interpreta os dados de retorno das req. AJAX, colocando os dados nas vari�veis 'usuario' e 'filas'
			 * Atualiza a tela em seguida
			 */
			function parseDados(str) {
				dados = str || ajax.response;
				if(dados == '_EOR_') return; // String enviada ao final de cada requisi��o (45s). Ignora-la

				// Guarda o estado anterior do agente para compara��o
				estado    = usuario.codstatus;
				filaat    = usuario.filaatual;
				uniqueid  = usuario.uniqueid;
				numentra  = usuario.numentra;
				nameentra = usuario.nameentra;
				idAlvoAgd = usuario.idalvoagd;
				espera    = usuario.canalespera;
				
				// Popula o array de (filas) e os novos dados do agente logado (usuario)
				filas  = new Array();
				linhas = dados.split("\n");
				for(l=0; l<linhas.length; l++) {
					tipoLin = linhas[l].split('{');
					if(tipoLin[0].substr(0,7) == "Agente") {
						usuario.parseLin(tipoLin[1]);
					} else if(tipoLin[0].substr(0,4) == "Fila") {
						fila = new Fila();
						fila.parseLin(tipoLin[1]);
						filas[filas.length] = fila;
					}
				}
				
				if(logado && usuario.codstatus == DESLOGADO) {
					// Deslogou
					addMsg("Deslogado");
					if(usuario.keepalive == -1)
						alert("Deslogado pelo servidor")
					else if(usuario.keepalive == -7)
						alert("Servi�o desligado")
					window.location = "logoffAg.php";
				}
				
				if(!logado) logado = (usuario.codstatus != DESLOGADO);
				if(!logado)	addMsg(" --> Por favor clique em Login");
				
				//if(usuario.numentra != txtNumEntra) {
				// Foi para Chamando
				if(estado != CHAMANDO && usuario.codstatus == CHAMANDO) {
					txtNumEntra = usuario.numentra;
					if(tipofila[usuario.filaatual] == 'M') {
						// Fila de Email
						addMsg("Atendimento Email: [" + usuario.email + "]");
					} else {
						if(usuario.numentra.length > 0) { // <
							txtFila = (usuario.filaatual.length > 0) ? " vinda da fila [" + usuario.filaatual + "]" : ''; // <
							addMsg("Chamada entrante: [" + usuario.numentra + "]" + txtFila);
							if(usuario.nameentra.length > 0) // <
								addMsg("Dados: [" + usuario.nameentra + "]");
							
							if(urls[usuario.filaatual] != undefined) {
								aux  = urls[usuario.filaatual].replace(/%NUM%/g, usuario.numentra);
								aux2 = aux.replace(/%IDAG%/g, usuario.id);
								url  = aux2.replace(/%FILA%/g, usuario.filaatual);
								popup = window.open(url, 'CRM ' + usuario.numentra, 'width=800,height=600,top=100,left=100');
								if(window.focus) {popup.focus()}
							}
						}
					}
				}
				
				// Foi para atendendo
				if(estado != ATENDENDO && usuario.codstatus == ATENDENDO) {
					addMsg('Chamada capturada. Tempo que estava em fila: ' + usuario.holdtime + ' s');
					if(tipofila[usuario.filaatual] == 'M') {
						// Fila de Email
						aux  = urlEmail.replace(/%IDAG%/g, usuario.id);
						aux2 = aux.replace(/%IDEMAIL%/g, usuario.idemail);
						url  = aux2.replace(/%EMAIL%/g, usuario.email);
						popup = window.open(url, 'Atendimento Email - ' + usuario.email, 'width=800,height=600,top=100,left=100,scrollbars=yes');
					} else {
						// Envio do UniqueID para o popup no momento do atendimento da chamada
						if(popup && popup.document && popup.document.getElementById('uniqueid'))
							popup.document.getElementById('uniqueid').value = usuario.uniqueid;
					}
				}
				
				// Saiu de atendendo
				if(estado == ATENDENDO && usuario.codstatus != ATENDENDO) {
					if(urlsfim[filaat] != undefined) {
						// Abrir, se houver, popup final da fila
						aux  = urlsfim[filaat].replace(/%NUM%/g, numentra);
						aux2 = aux.replace(/%FILA%/g, filaat);
						aux  = aux2.replace(/%IDAG%/g, usuario.id);
						aux2 = aux.replace(/%DADOS%/g, nameentra);
						url  = aux2.replace(/%UNIQUEID%/g, uniqueid);
						popup = window.open(url, 'CRM ' + numentra, 'width=400,height=400,top=100,left=100');
						popup.focus();
					}
				}

				// Chegou um novo agendamento (usuario.idalvoagd alterado)
				if(idAlvoAgd != usuario.idalvoagd && usuario.idalvoagd > 0 && urlAgendamento != '') {
					// Faz as susbtituicoes das variaveis:
					// URL exemplo: popupAgendamento.php?idagente=%IDAG%&idalvo=%IDALVO%&dadosalvo=%DADOSALVO%&filaalvo=%IDFILA%&datahora=%DTHR%&numsalvo=%NUMSALVO%&idcampanha=%IDCAMP%
					aux = urlAgendamento.replace(/%IDAG%/g, usuario.id);
					aux2= aux.replace(/%IDALVO%/g, usuario.idalvoagd);
					aux = aux2.replace(/%DADOSALVO%/g, usuario.dadosalvoagd);
					aux2= aux.replace(/%IDFILA%/g, usuario.filaalvoagd);
					aux = aux2.replace(/%DTHR%/g, usuario.dthragd);
					aux2= aux.replace(/%NUMSALVO%/g, usuario.numsalvoagd)
					url = aux2.replace(/%IDCAMP%/g, usuario.idcampagd);
					popup = window.open(url, 'Agendamento ' + usuario.idalvoagd, 'width=400,height=400,top=100,left=100');
					popup.focus();
				}
				
				// Voltou para disponivel, zerar o txtNumEntra
				if(estado != 1 && usuario.codstatus == 1) {
					txtNumEntra = '';
				}
				
				if(espera != '' && espera != undefined && usuario.canalespera == '') {
					if(!desespera) addMsg('Chamada em espera desligou');
					else           desespera = 0;
				}
				
				atualizaDadosFilas();
				atualizaDadosUsuario();
			}
			
			function atualizaDadosFilas() {
				novaTabela = document.createElement('table');
				novaTabela.setAttribute("border", "0");
				novaTabela.setAttribute("align", "center");
				novaTabela.setAttribute("width", "100%");
				novaTabela.setAttribute("id", "tabelaFilas");
				tHead = document.createElement('thead');
				col1 = document.createElement('td');
				col1.innerHTML = "Fila";
				col2 = document.createElement('td');
				col2.innerHTML = "Liga��es na Fila";
				col3 = document.createElement('td');
				col3.innerHTML = "Tempo de Espera";
				col4 = document.createElement('td');
				col4.innerHTML = "Tempo M�dio de Espera";
				col4.setAttribute("class","ultimo");
				tHead.appendChild(col1);
				tHead.appendChild(col2);
				tHead.appendChild(col3);
				tHead.appendChild(col4);
				novaTabela.appendChild(tHead);
								
				for(c=0; c<filas.length; c++) {
					novaLinha = document.createElement('tr');
					col1 = document.createElement('td');
					col1.innerHTML = filas[c].nome;
					col2 = document.createElement('td');
					col2.innerHTML = filas[c].qtdchamespera;
					col3 = document.createElement('td');
					col3.innerHTML = filas[c].tempoespera;
					col4 = document.createElement('td');
					col4.innerHTML = filas[c].tempomedioespera;
					novaLinha.appendChild(col1);
					novaLinha.appendChild(col2);
					novaLinha.appendChild(col3);
					novaLinha.appendChild(col4);
					
					if((c % 2) == 0) novaLinha.setAttribute("class", "corSim");
					else	         novaLinha.setAttribute("class", "corNao");
					novaTabela.appendChild(novaLinha);
				}
				
				// Atualizar o HTML da tabela de filas
				tabela = document.getElementById('tabelaFilas');
				tabela.parentNode.replaceChild(novaTabela, tabela);
			}
			
			function atualizaDadosUsuario() {
				if(!logado) {
					btnDisponivel.innerHTML   = 'Login';
					btnDisponivel.className   = 'botao';
					btnPausa.className        = 'botaoDesab';
					btnIndisponivel.className = 'botaoDesab';
					btnLogoff.className       = 'botao';
					btnDiscar.className       = 'botaoDesab';
					btnTransferir.className   = 'botaoDesab';
					btnConferencia.className  = 'botaoDesab';
					<? echo ($temTELIP) ? "btnTelip.className = 'botaoDesab';\n" : "btnDesligar.className = 'botaoDesab';\n"; ?>
				} else {
					emLig = (usuario.codstatus == ATENDENDO || usuario.codstatus == SAINTE || usuario.codstatus == ENTRANTE || usuario.codstatus == CHAMANDO);
					
					// Bot�o DISPONIVEL
					if(usuario.codstatus == DISPONIVEL) {
						btnDisponivel.innerHTML = 'Dispon�vel';
						btnDisponivel.className = 'botaoDisponivel';
					} else if(usuario.codstatus == CHAMANDO) {
						btnDisponivel.innerHTML = 'Chamando';
						btnDisponivel.className = 'botaoChamando';
					} else if(usuario.codstatus == ATENDENDO) {
						btnDisponivel.innerHTML = 'Atendendo';
						btnDisponivel.className = 'botaoAtendendo';
					} else if(usuario.codstatus == SAINTE) {
						btnDisponivel.innerHTML = 'Sainte';
						btnDisponivel.className = 'botaoAtendendo';
					} else if(usuario.codstatus == DISCANDO) {
						btnDisponivel.innerHTML = 'Discando';
						btnDisponivel.className = 'botaoAtendendo';
					} else if(usuario.codstatus == ENTRANTE) {
						btnDisponivel.innerHTML = 'Entrante';
						btnDisponivel.className = 'botaoAtendendo';
					} else {
						btnDisponivel.innerHTML = 'Dispon�vel';
						btnDisponivel.className = 'botao';
					}
					
					// Bot�o PAUSA
					btnPausa.className = (emLig) ? 'botaoDesab' : ((usuario.codstatus >= PAUSA && usuario.codstatus < INDISP)  ? 'botaoAtivo' : 'botao');
					btnPausa.innerHTML = (btnPausa.className == 'botaoAtivo') ? '<font size="2">Pausa</font><br>' + pausas[usuario.codstatus] : 'Pausa'; // <
					
					// Bot�o INDISPONIVEL
					btnIndisponivel.className = (emLig) ? 'botaoDesab' : ((usuario.codstatus >= INDISP) ? 'botaoAtivo' : 'botao'); // <
					btnIndisponivel.innerHTML = (btnIndisponivel.className == 'botaoAtivo') ? '<font size="2">Indispon�vel</font><br>' + indisp[usuario.codstatus] : 'Indispon�vel'; // <
					
					// Bot�o LOGOFF
					btnLogoff.className = (emLig) ? 'botaoDesab' : 'botao';

					// Bot�es DISCAR, TRANSFERIR e CONFERENCIA
					atualizaEstadoBotoes();
					
<?	if($temTELIP) { ?>
					// Bot�o TELIP
					if(emLig) {
						btnTelip.innerHTML = 'Desligar';
						btnTelip.className = 'botao';
					} else if(usuario.codstatus == CHAMANDO) {
						btnTelip.innerHTML = 'Atender';
						btnTelip.className = 'botao';
					} else {
						btnTelip.innerHTML = 'Aguarde';
						btnTelip.className = 'botaoDesab';
					}
<?	} else { ?>
					// Bot�o Desligar
					btnDesligar.className = (emLig) ? 'botao' : 'botaoDesab';
<?	} ?>
					
					// Mostrar as mensagens do banco de dados
					cxMsg.value = usuario.msg;
				}
				// Atualiza o rodap� da janela com os dados do agente
				document.getElementById('brStatus').innerHTML = "Ramal: <b><? echo $agente->ramal; ?></b> - PA: <b><? echo $agente->telefone; ?></b> - Efetuadas: <b>" +
																usuario.efetuadas + "</b> - Recebidas: <b>" + usuario.recebidas + "</b>"; // <
				
				// Redimensiona a janela
				//tamLogin = (usuario.codstatus > 0) ? 4 : 0; // <
				//tamPausa = (usuario.codstatus >= 100) ? 22 : 0; // <
				//self.resizeTo(582, 346 + tamLogin + tamPausa + (filas.length * 22));
			}
			
			/**
			 * Separado para ser usado no onKeyPress da caixa de texto
			 */
			function atualizaEstadoBotoes() {
				emLig = (usuario.codstatus == ATENDENDO || usuario.codstatus == SAINTE || usuario.codstatus == ENTRANTE || usuario.codstatus == DISCANDO || usuario.codstatus == CHAMANDO);
				
				// Bot�o DISCAR - desab se estiver em ligacao, e so habilitado caso haja texto na caixa de discagem
				podeDiscarPausa = <? echo($podeDiscarPausa ? 'INDISP' : 'PAUSA'); ?>;
				btnDiscar.className = (!logado || emLig || cxTxtEntrada.value == "" || usuario.codstatus >= podeDiscarPausa) ? 'botaoDesab' : 'botao'; // <
				
				// Bot�o TRANSFERIR - habilitado caso haja texto na caixa de discagem e estiver em liga�ao ou com chamada retida
				btnTransferir.className = (!logado || !emLig || cxTxtEntrada.value == "") ? 'botaoDesab' : 'botao';
				
				// Bot�o CONFERENCIA - habilitado caso haja texto na caixa de discagem e estiver em liga�ao
				btnConferencia.className = (!logado || !emLig || cxTxtEntrada.value == "") ? 'botaoDesab' : 'botao';
			}
			
			/**
			 * O nome do ultimo botao de status clicado fica guardado, para se o usuario clica-lo de novo possamos dar
			 * uma mensagem de 'Em processamento'. Isto s� ocorre no meio tempo em que foi solicitado
			 * mas esta ainda nao refletiu na janela do cliente. Apos ocorrer a mudan�a o botao clicado fica ativo, e assim
			 * nao pode ser clicado. Apos 2 s o nome do botao � removido da memoria, assim podendo ser clicado de novo em
			 * caso de falha na mudan�a de estado.
			 */
			function setaUltimoBtn(nomeBtn) {
				ultimoBtn = nomeBtn;
				setTimeout("limpaUltimoBtn()", 2000); // zera a var de btn clicado apos 2s
			}
			function limpaUltimoBtn() {
				ultimoBtn = '';
			}
			
			/**
			 * Fun��es dos bot�es
			 */
			function on_Disponivel_clicked() {
				if(btnDisponivel.className == 'botao') {
					if(!logado) {
						setaUltimoBtn('disponivel');
						enviaComando('login:<?echo $agente->telefone . (($agente->mobilidd) ? ':MOBILIDADE' : '') ?>');
						addMsg('Solicitado Login');
						setTimeout("testaLogin()", 500);
					} else {
						if(ultimoBtn != 'disponivel') {
							setaUltimoBtn('disponivel');
							enviaComando("mudaStatus:"+ DISPONIVEL);
							addMsg('Solicitado status de Dispon�vel');
						} else
							addMsg('Por favor aguarde. Em processamento.');
					}
				}
			}
			function on_Pausa_clicked(codP) {
				enviaComando("mudaStatus:"+ codP);
				addMsg('Solicitado status de Pausa ' + pausas[codP]);
			}
			function on_Indisponivel_clicked(codI) {
				enviaComando("mudaStatus:"+ codI);
				addMsg('Solicitado status de Indispon�vel ' + indisp[codI]);
			}
			function on_Logoff_clicked() {
				if(btnLogoff.className != 'botaoDesab') {
					if(!logado) {
						window.location = "logoffAg.php";
					} else {
						enviaComando("logoff");
						addMsg('Solicitado Logoff');
					}
				}
			}
			function on_Discar_clicked() {
				if(btnDiscar.className != 'botaoDesab') {
					addMsg('Discando para ' + cxTxtEntrada.value);
					enviaComando("disca:"+ cxTxtEntrada.value);
				}
			}
			function on_Transferir_clicked() {
				if(btnTransferir.className != 'botaoDesab') {
					var esp = '';
					if(usuario.canalespera != '') {
						esp = ' em espera';
						desespera = 1;
					}
					enviaComando("transferir:" + cxTxtEntrada.value);
					addMsg('Transferir chamada' + esp + ' para ' + cxTxtEntrada.value);
				}
			}
			function on_Conferencia_clicked() {
				if(btnConferencia.className != 'botaoDesab') {
					enviaComando("conferencia:" + cxTxtEntrada.value);
					addMsg('Entrando em confer�ncia com ' + cxTxtEntrada.value);
				}
			}
<?	if($temTELIP) { ?>
			var cntTELIP = 0;
			function enviaComandoTelip(cmd) {
				out = cmd + '-' + cntTELIP++;
				addMsg('Envia Comando TELIP: ' + out);
				imgTelip = document.getElementById('imgTELIP');
				imgTelip.src = 'http://127.0.0.1:8080/action.' + out;
			}
			function on_TELIP_clicked() {
				if(btnTelip.className != 'botaoDesab') {
					enviaComandoTelip((btnTelip.innerHTML == 'Atender') ? 'a' : 'h');
				}
			}
<?	}  else { ?>
			function on_Desligar_clicked() {
				if(btnDesligar.className != 'botaoDesab') {
					enviaComando("desligar");
					addMsg('Desligando chamada');
				}
			}
<?	} ?>

			/**
			 * Fun�ao de 'onKeyPress' da caixa de discagem, atua sobre o ENTER nesta caixa
			 */
			function okpCxEntrada(e) {
				var codTecla = e.which;
				if(codTecla == 13) { // Pressionou ENTER na caixa de discagem
					if(usuario.codstatus == 3) on_Transferir_clicked();
					else                       on_Discar_clicked();
					return false;
				} else if(codTecla < 32)
					return true;
				
				var regExpNumerico = /^[0-9*][0-9*]*$/;
				var chr = String.fromCharCode(codTecla);
				return(regExpNumerico.test(e.target.value + chr));
			}
			
			/**
			 * Adiciona uma mensagem na TEXTAREA
			 */
			function addMsg(msg) {
				agora = new Date();
				hora = agora.getHours();
				minu = agora.getMinutes();
				secs = agora.getSeconds();
				if(hora < 10) hora = '0' + hora;
				if(minu < 10) minu = '0' + minu;
				if(secs < 10) secs = '0' + secs;
				hora = hora + ":" + minu + ":" + secs;
				msg = hora + " > " + msg;
				
				for(c=1; c<4; c++)
					msgs[c - 1] = msgs[c];
				msgs[3] = msg;

				var txtAux = "";
				for(c=0; c<4; c++)
					txtAux += msgs[c] + "\n";
				
				cxMensagens.value = txtAux;
			}
			
			/**
			 * Limpa a mensagem enviada pela supervisao
			 */
			function limpaMsg() {
				enviaComando('limpaMsg');
			}
			
			/**
			 * Envia o comando de keepAlive periodicamente
			 */
			function keepAlive() {
				ajaxKA.onreadystatechange = function() {
			        if(ajaxKA.readyState==4) {
			            if(ajaxKA.responseText == 0) {
							alert("Deslogado pelo servidor (servi�o desligado)")
							window.location = "logoffAg.php";
						}
			        }
			    };
				ajaxKA.open("GET", "enviaComando.php?Comando=<?echo "$agente->id:keepAlive:$agente->ramal"?>", true);
				ajaxKA.send(null);
				setTimeout("keepAlive()", 15000);
			}
						
			/**
			 * Inicializa��o
			 */
			function init() {
				btnDisponivel   = document.getElementById('tdDisponivel');
				btnPausa        = document.getElementById('tdPausa');
				btnIndisponivel = document.getElementById('tdIndisponivel');
				btnLogoff       = document.getElementById('tdLogoff');
				btnDiscar       = document.getElementById('tdDiscar');
				btnTransferir   = document.getElementById('tdTransferir');
				btnConferencia  = document.getElementById('tdConferencia');
<?	if($temTELIP) { ?>
				btnTelip        = document.getElementById('tdTELIP');
				btnTelip.innerHTML = 'Aguarde';
<?	} else { ?>
				btnDesligar     = document.getElementById('tdDesligar');
<?	} ?>
				
				btnDisponivel.onclick   = on_Disponivel_clicked;
				btnLogoff.onclick       = on_Logoff_clicked;
				btnDiscar.onclick       = on_Discar_clicked;
				btnTransferir.onclick   = on_Transferir_clicked;
				btnConferencia.onclick  = on_Conferencia_clicked;
				<? echo ($temTELIP) ? "btnTelip.onclick        = on_TELIP_clicked;\n" : "btnDesligar.onclick        = on_Desligar_clicked;\n"; ?>
				
				popupPausa = new PopupMenu(PAUSA);
				pausas[100] = 'Supervisao';
				pausas[199] = 'Autom�tica';
<?	// Nomes das pausas buscados no banco:
	foreach($motivos as $idP => $nomeP) {
		if($idP < 200) { ?>
				pausas[<? echo $idP ?>] = '<? echo $nomeP ?>';
				popupPausa.add('<? echo $nomeP ?>', function(target) {
					on_Pausa_clicked(<? echo $idP ?>);
				});
<?		}
	} ?>
				popupPausa.setSize(170, 0);
				popupPausa.bind('tdPausa');
				
				popupIndisp = new PopupMenu(INDISP);
				indisp[200] = 'Nao Atendimento';
<?	// Nomes das Indisp buscados no banco:
	foreach($motivos as $idI => $nomeI) {
		if($idI > 200) { ?>
				indisp[<? echo $idI ?>] = '<? echo $nomeI ?>';
				popupIndisp.add('<? echo $nomeI ?>', function(target) {
					on_Indisponivel_clicked(<? echo $idI ?>);
				});
<?		}
	} ?>
				popupIndisp.setSize(170, 0);
				popupIndisp.bind('tdIndisponivel');
				
<?
	foreach($dadosFilas as $nomeFila => $fila) {
		if(!empty($fila->urlpopup))    echo "	urls['$nomeFila']     = '$fila->urlpopup';\n";
		if(!empty($fila->urlpopupfim)) echo "	urlsfim['$nomeFila']  = '$fila->urlpopupfim';\n";
		echo "	tipofila['$nomeFila'] = '$fila->tipopiloto';\n";
	}
?>
				urlAgendamento = '<?echo $urlAgenda?>';
				
				cxTxtEntrada         = document.dados.caixaEntrada;
				cxTxtEntrada.onkeyup = atualizaEstadoBotoes;
				
				cxMensagens = document.dados.mensagens;
				cxMsg       = document.dados.mensagem;
				
				// Busca os dados inciais
				ajax.open("GET", "buscaDados.php", false);
				ajax.send(null);
				parseDados(ajax.responseText);
				
				// Caso F5
				if(usuario.codstatus > 0) {  // <
					logado = true;
					initComet();
					setTimeout("keepAlive()", 6000);
				}
			}
			init();
			
			
			/**
			 * Inicializa o http 'persistente' (Comet)
			 */
			function initComet() {
				comet = new XMLHttpRequest();
				comet.multipart = true;
				comet.open("GET","cometAgente.php", true);
				comet.onload = handleContent;
				comet.send(null);
				
				setTimeout("initComet()", 45200);// Reinicializa a conex�o Comet a cada 45s
			}
			function handleContent(event) {
				parseDados(event.target.responseText);
			}
			
			/**
			 * Envia um comando a ser executado pelo controle do CallCenter
			 */
			function enviaComando(cmd) {
				ajax.open("GET", "enviaComando.php?Comando=<?echo $agente->id?>:" + cmd, true);
				ajax.send(null);
			}
			
			/**
			 * Fun��o pr�-comet. S� inicializa o comet depois que o agente foi logado
			 */
			function testaLogin() {
				ajax.open("GET", "buscaStatusAgente.php", false);
				ajax.send(null);
				testaLoginCB(ajax.responseText);
			}
			function testaLoginCB(estado) {
				if(estado > 0) {  // <
					addMsg('Login efetuado');
					usuario.codstatus = 1;
					logado = true;
					initComet();
					setTimeout("keepAlive()", 6000);
				} else
					setTimeout("testaLogin()", 500);
			}
		</script>
	</body>
</html>
