<?php
	include('comandos.php');
	$agente = loginOK();
	$totfilas = count(explode(',', $agente->idsfilas)); 
	$tam = 320 + ($totfilas * 20);
 ?>
<script type="text/javascript">
	popup = window.open('janelaAgente.php','agente ' + '<?$agente->nome?>','width=582,height=<?echo $tam?>,scrolling=auto,top=100,left=100,scrollbar=no,resizable=no,minimize=no,maximize=no');
	if (window.focus) {popup.focus()}
	window.location = 'login.php';
</script>