<?
	session_name('popupEmail');
	include(''.'/usr/lib/telefoniaip/modulos/Fila/sistemaCC/cliente/comandos.php');
	
	$idAg    = $_REQUEST['idagente'];
	$idEmail = $_REQUEST['idemail'];
	$email   = $_REQUEST['email'];
	
	$corpo = file_get_contents("/var/spool/asterisk/tmp/EMAIL-$idEmail");
?>
<html>
	<head>
		<title>.: Email - <? echo $email ?> :.</title>
	</head>
	<body>
		<h2>.: Atendimento Email - [<? echo $email ?>] :.</h2>

		<? echo quoted_printable_decode($corpo); ?>

		Resposta:<br>
		<textarea name="resposta" rows="20" cols="80" wrap="off"></textarea>
	</body>
</html>
