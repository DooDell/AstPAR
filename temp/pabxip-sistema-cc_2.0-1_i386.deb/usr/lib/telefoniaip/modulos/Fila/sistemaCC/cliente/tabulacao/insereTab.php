<?
	session_name('popupTabulacao');
	include(''.'/usr/lib/telefoniaip/modulos/Fila/sistemaCC/cliente/comandos.php');
	
	$idag     = $_REQUEST['idag'];
	$nomeFila = $_REQUEST['fila'];
	$uniqueid = $_REQUEST['uid'];
	$item     = $_REQUEST['item'];
	
	insereTabulacao($nomeFila, $idag, $uniqueid, $item);
?>
OK
<script type="text/javascript">
	function fecha() {
		window.close();
	}
	setTimeout("fecha()", 250);
</script>