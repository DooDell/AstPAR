<?php
class Logger
{
	private $arqLoga, $rst, $mais;
	public  $emTela, $nivel;
	
	public function Logger($nivel, $emTela=true, $RST=false) {
		$this->nivel  = $nivel;
		$this->emTela = $emTela;
		$this->rst    = $RST;
		$this->mais   = '';
		
		$this->descNivLog = array();
		$this->descNivLog[LOG_CRITICO] = "\033[31;1mLOG_CRITCO\033[0m";
		$this->descNivLog[LOG_AVISO]   = "\033[35;1mLOG_AVISOS\033[0m";
		$this->descNivLog[LOG_NORMAL]  = "\033[37;1mLOG_NORMAL\033[0m";
		$this->descNivLog[LOG_DEBUG0]  = "\033[33;1mLOG_DEBUG0\033[0m";
		$this->descNivLog[LOG_DEBUG1]  = "\033[32;1mLOG_DEBUG1\033[0m";
		$this->descNivLog[LOG_DEBUG2]  = "\033[34;1mLOG_DEBUG2\033[0m";
		$this->descNivLog[LOG_DEBUG3]  = "\033[36;1mLOG_DEBUG3\033[0m";
	}
	
	function setMais($mais) {
		$this->mais = $mais;
	}
	
	function loga($nivelDebug, $texto)
	{
		if($nivelDebug <= $this->nivel) {
			$data = date("d/m/y");
			$hora = date("H:i:s");
			
			if(!is_resource($this->arqLoga)) {
				$this->arqLoga = fopen("/var/log/controleCallCenter.log", "a");
				if(!$this->arqLoga) {
					echo("Erro ao abrir arquivo de log [/var/log/controleCallCenter.log]. Saindo!\n");
					exit(1);
				}
				$enes = (!$this->rst) ? "\n" : '';
				$reab = ($this->rst) ? "RE" : '';
				fprintf($this->arqLoga, "$enes=== controleCC Ver:".VERSAO." - Arquivo de LOG $reab aberto dia [$data] ===$enes\n");
				if($this->emTela)
					echo("\n\n=== controleCC Ver:".VERSAO." - Arquivo de LOG aberto dia [$data] ===\n\n");
			}
			
			$nivLog = $this->descNivLog[$nivelDebug];
			$texto = str_replace("%", "%%", $texto);
			switch($nivelDebug) {
				case LOG_CRITICO: $add = '!!!>>> '; break;
				case LOG_AVISO:   $add = '>>> ';    break;
				default:          $add = '';        break;
			}
			$ut = ($this->nivel > LOG_NORMAL) ? '['.microtime(true).']' : '';
			$msg = "[$data $hora][$nivLog]$ut$this->mais > $add$texto\n";
			fprintf($this->arqLoga, $msg);
			if($this->emTela)  echo($msg);
		}
	}
	
	function fecha()
	{
		if(is_resource($this->arqLoga)) {
			$this->loga(LOG_NORMAL, "Fechando arquivo de log.");
			fclose($this->arqLoga);
		}
	}
}
?>