<?php
define('TEMPO_MAX_PROCESSA', 0.5);
define('TEMPO_CRITICO', 0.05); // Tempo para colocar em vermelho a MSG de debug com o tempo de execu��o de cada MSG

class MsgQueue {
	function MsgQueue($idMQ) {
		$this->idMQ  = $idMQ;
		$this->mq_id = msg_get_queue($idMQ);
	}
	
	function processa($inicio=false) {
		$tipo = $msgRecv = $errCode = null;
		
		// Receber as msgs de sistema, tipo 100, primeiro
		$inicioProcessa = microtime(true); // Marcar o inicio para limitar/debugar o tempo de execu��o
		while(msg_receive($this->mq_id, 100, $tipo, 256, $msgRecv, false, MSG_IPC_NOWAIT, $errCode) === true) {
			$ehPing = $this->trataTipo100($msgRecv, $inicio);
			
			$mt = microtime(true);
			if(!$ehPing) {
				$tempo = $mt - $inicioProcessa;
				if($tempo > TEMPO_CRITICO) $tempo = "[\033[31;1m$tempo\033[0m]"; // Deixa em vermelho tempo muito grandes
				ControleCC::loga(LOG_DEBUG0, "Tempo de execucao da MSG [\033[32;1m$msgRecv\033[0m][100]: $tempo");
			}
			
			if($mt > ($inicioProcessa + TEMPO_MAX_PROCESSA)) {
				$dadosMsgQ = msg_stat_queue($this->mq_id);
				$falta = $dadosMsgQ['msg_qnum'];
				ControleCC::loga(LOG_AVISO, "MsgQueue - Tempo de execucao tipo 100 estourado - faltaram $falta msgs, deixando para proxima passada");
				break;
			}
		}
		
		$inicioProcessa = microtime(true); // Marcar o inicio para limitar/debugar o tempo de execu��o
		while(msg_receive($this->mq_id, 0, $tipo, 256, $msgRecv, false, MSG_IPC_NOWAIT, $errCode) === true) {
			$ehPing = false;
			if($tipo == 100)
				$ehPing =$this->trataTipo100($msgRecv, $inicio);
			else {
				$params = explode(":", $msgRecv);
				$tsCmd  = array_shift($params);
				$codUsu = array_shift($params);
				if($inicio && (time() > ($tsCmd + 10))) {
					ControleCC::loga(LOG_AVISO, "Mensagem [\033[35;1m$msgRecv\033[0m] IGNORADA. Muito antiga (> 10s)");
					continue;
				}
				$acao = $params[0];
				if($tipo == 10) {
					// Mensagens de opera��o - Supervisores
					$supervisor = ControleCC::$memAgs->get('id', $codUsu);
					if(is_a($supervisor, 'Agente')) {
						$nomeSup = $supervisor->getNome();
		
						ControleCC::loga(($acao == 'keepAlive') ? LOG_DEBUG3 : LOG_DEBUG0, "Mensagem de Operacao-Supervisor recebida de $nomeSup - MSG: [\033[34;1m$msgRecv\033[0m]");
						switch($acao) {
							case 'keepAlive':
								if($supervisor->codstatus > 0) {
									ControleCC::loga(LOG_DEBUG2, "keepAlive de supervidor: $nomeSup");
									$supervisor->keepAlive();
								} else
									ControleCC::loga(LOG_AVISO, "keepAlive de Supervisor Deslogado!!! $nomeSup");
								break;
							
							case 'loginSup':
								$telefone = $params[1];
								
								if(($sucesso = $supervisor->mudaEstado(SUPLOGADO, array('telefone' => $telefone, 'tempologin' => '_AGORA_','numSai' => '','numEntra' => '','msg' => ''))) === true) {
									ControleCC::loga(LOG_NORMAL, "Login do Supervisor $nomeSup no telefone [$telefone] efetuado");
									ControleCC::logaEvento(EVENTO_LOGINSUP, $supervisor->id, $supervisor->ramal, $telefone);
									// Setar a flag de supervisor logado
									shmop_write(ControleCC::$memLogin, '2', $supervisor->ramal);
								} else
									ControleCC::loga(LOG_CRITICO, "Erro ao mudar estado do supervidor $nomeSup - msg [$sucesso]");
								break;
							
							case 'enviaMsg': // Broadcast
								$idAg = $params[1];
								$msg  = $params[2];
								
								$ag = ControleCC::$memAgs->get('id', $idAg);
								if(is_a($ag, 'Agente')) {
									$ag->msg = $msg;
									$sucesso = $ag->atualiza();
									if($sucesso !== true) {
										$nomeAgente = $ag->getNome();
										ControleCC::loga(LOG_CRITICO, "Erro ao enviar mensagem para $nomeAgente - Msg [$sucesso]");
									}
								} else
									ControleCC::loga(LOG_CRITICO, "Comando enviaMsg - Erro ao buscar dados do agente ID($idAg)");
								break;
		
							case 'mudaStatus':
								$idAg    = $params[1];
								$stsNovo = $params[2];
								
								$ag = ControleCC::$memAgs->get('id', $idAg);
								if(is_a($ag, 'Agente')) {
									$atzAg = false;
									$nomeAgente = $ag->getNome();
									
									$paused = ($stsNovo != DISPONIVEL);
									$sucesso = $ag->pausa($paused);
									if($sucesso === true) {
										$sucesso = $ag->mudaEstado($stsNovo, array('codstatusbase' => $stsNovo));
										if($sucesso === true) ControleCC::loga(LOG_NORMAL, "Status de $nomeAgente alterado com sucesso para [$ag->codstatus] pelo Supervisor $nomeSup");
										else {
											// Des-mudar o estado
											$sucesso = $ag->pausa(!$paused);
											ControleCC::loga(LOG_CRITICO, "AG: Erro ao alterar codStatus de $nomeAgente pelo Supervisor $nomeSup - Msg [$sucesso]");
											$ag->msg = "Erro ao supevisor alterar estado.";
											$atzAg = true;
										}
									} else {
										ControleCC::loga(LOG_CRITICO, "AG: Erro ao pausar/despausar $nomeAgente pelo Supervisor $nomeSup - Msg [$sucesso]");
										$ag->msg = "Erro ao supervisor alterar estado de pausa";
										$atzAg = true;
									}
									if($atzAg)
										$ag->atualiza();
								} else
									ControleCC::loga(LOG_CRITICO, "Comando enviaMsg - Erro ao buscar dados do agente ID($idAg) pelo Supervisor $nomeSup");
								break;
												
							case 'pausaStatusBase':
								$idAg = $params[1];
								
								$ag = ControleCC::$memAgs->get('id', $idAg);
								if(is_a($ag, 'Agente')) {
									$nomeAgente = $ag->getNome();
									
									$ag->codstatusbase = PAUSA;
									$sucesso = $ag->atualiza();
									if($sucesso === true) ControleCC::loga(LOG_NORMAL, "Status BASE de $nomeAgente alterado com sucesso para [PAUSA SUPERVISAO] pelo Supervisor $nomeSup");
									else                  ControleCC::loga(LOG_CRITICO, "Erro ao alterar codStatusBase de $nomeAgente pelo Supervisor $nomeSup - Msg [$sucesso]");
								} else
									ControleCC::loga(LOG_CRITICO, "Comando enviaMsg - Erro ao buscar dados do agente ID($idAg) pelo Supervisor $nomeSup");
								break;
							
							case 'desloga':
								$idAg = $params[1];
								
								$ag = ControleCC::$memAgs->get('id', $idAg);
								if(is_a($ag, 'Agente')) {
									$nomeAgente = $ag->getNome();
									
									$sucesso = $ag->desloga(-3);
									if($sucesso === true) ControleCC::loga(LOG_NORMAL, "Agente $nomeAgente deslogado pelo Supervisor $nomeSup");
									else                  ControleCC::loga(LOG_CRITICO, "Erro ao deslogar $nomeAgente pelo Supervisor $nomeSup - Msg [$sucesso]");
								} else
									ControleCC::loga(LOG_CRITICO, "Comando enviaMsg - Erro ao buscar dados do agente ID($idAg) pelo Supervisor $nomeSup");
								break;
							
							case 'entraChamada':
							case 'escutaChamada':
							case 'sussurraChamada':
								$idAg   = $params[1];
								$telSup = $params[2];
								
								$ag = ControleCC::$memAgs->get('id', $idAg);
								if(is_a($ag, 'Agente')) {
									$nomeAgente = $ag->getNome();
									
									$entra = ($acao == 'entraChamada') ? 'B' : (($acao == 'sussurraChamada') ? 'w' : '');
									$evento= ($acao == 'entraChamada') ? EVENTO_ENTRACH : (($acao == 'sussuraChamada') ? EVENTO_SUSSURRACH : EVENTO_ESCUTACH);
									$sucesso = ControleCC::$comandosAst->enviaComando('Originate', array(
												'Channel'     => "Local/$telSup@irrestrito-user",
												'Priority'    => 0,
												'Variable'    => 'RAMAL_CC='.$supervisor->ramal,
												'Application' => 'ChanSpy',
												'Data'        => "$ag->telefone|v(2)q$entra",
												'Timeout'     => 30000,
												'Async'       => 1
											));
									if($sucesso) {
										$txt = ($acao == 'entraChamada') ? 'entrou na' : (($acao == 'sussurraChamada') ? 'sussurrando na' : 'escutando a');
										ControleCC::loga(LOG_NORMAL, "Supervisor $nomeSup $txt chamada do agente $nomeAgente no ramal $telSup");
										ControleCC::logaEvento($evento, $codUsu, $telSup, $idAg, $ag->telefone);
									} else
										ControleCC::loga(LOG_AVISO, "Erro ao $nomeSup entrar na chamade de $nomeAgente");
								} else
									ControleCC::loga(LOG_CRITICO, "Comando enviaMsg - Erro ao buscar dados do agente ID($idAg) pelo Supervisor $nomeSup");
								break;
		
							case 'logoff':
								$err = $supervisor->desloga(-5);
								if($err !== true) ControleCC::loga(LOG_AVISO, $err);
								break;
								
								
							
							
							// A��es do Supervisor como agente
							case 'loginSupAg':
								if($supervisor->codstatus == 10) {
									// PARAM1 = Telefone  |   $params[2];	// PARAM2 = OPCIONAL = Mobilidade
									$supervisor->login($params[1], (isset($params[2]) ? $params[2] : null), true);
								} else
									ControleCC::loga(LOG_AVISO, "Imposs�vel logar $nomeSup - codtatus != 10 ($supervisor->codstatus)");
								break;
							
							case 'logoffSupAg':
								$err = $supervisor->desloga();
								if($err !== true) ControleCC::loga(LOG_AVISO, $err);
								break;
							
							case 'mudaStatusAg':
								$stsNovo  = $params[1];
								$podeMudar = true;
								
								// Consistencia. Este comando s� muda para DISPONIVEL, PAUSA ou INDISP
								if($stsNovo != DISPONIVEL && $stsNovo < PAUSA) {
									$supervisor->msg = "Imposs�vel mudar para o status $stsNovo";
									$podeMudar = false;
								}
								
								// S� � poss�vel pausar vindo de DISPONIVEL
								if($stsNovo >= PAUSA && $supervisor->codstatus != DISPONIVEL) {
									$tipo = ($stsNovo >= INDISP) ? 'indisponibilizar' : 'pausar';
									$supervisor->msg = "Impossivel $tipo se nao estiver disponivel";
									$podeMudar = false;
								}
								
								if($podeMudar) {
									$paused = ($stsNovo != DISPONIVEL);
									$sucesso = $supervisor->pausa($paused);
									
									if($sucesso === true) {
										$sucesso = $supervisor->mudaEstado($stsNovo, array('codstatusbase' => $stsNovo));
										if($sucesso === true) ControleCC::loga(LOG_NORMAL, "Status do supervisor $nomeSup alterado com sucesso para [$supervisor->codstatus]");
										else {
											// Des-mudar o estado
											$sucesso = $supervisor->pausa(!$paused);
											ControleCC::loga(LOG_CRITICO, "AG: Erro ao alterar codStatus do supervisor $nomeSup - Msg [$sucesso]");
											$supervisor->msg = "Erro ao alterar estado. Tente novamente";
											$podeMudar = false;
										}
									} else {
										ControleCC::loga(LOG_CRITICO, "AG: Erro ao pausar/despausar supervisor $nomeSup - Msg [$sucesso]");
										$supervisor->msg = "Erro ao alterar estado. Tente novamente";
										$podeMudar = false;
									}
								}
								if(!$podeMudar)
									$supervisor->atualiza();
								break;
							
							case 'disca':
								$num = $params[1];
								$this->disca($supervisor, $num);
								break;
							case 'transferir':
								$num = $params[1];
								$this->transfere($supervisor, $num);
								break;
							case 'conferencia':
								$num = $params[1];
								$this->conferencia($supervisor, $num);
								break;
							case 'desligar':
								$this->desligaChamada($supervisor);
								break;
							case 'limpaMsg':
								$this->limpaMsg($supervisor);
								break;
																												
							default:
								ControleCC::loga(LOG_CRITICO, "Mensagem de Operacao-Supervisor \033[35;1mRECUSADA\033[0m - Acao nao reconhecida - msg: [$msgRecv]");
						}
					} else
						ControleCC::loga(LOG_CRITICO, "Mensagem de Operacao-Supervisor \033[35;1mRECUSADA\033[0m - ID do supervisor invalido - msg: [$msgRecv]");
				} else if($tipo == 1) {
					// Mensagens de opera��o - Agentes
					$agente = ControleCC::$memAgs->get('id', $codUsu);
					if(is_a($agente, 'Agente')) {
						$nomeAgente = $agente->getNome();
							
						ControleCC::loga(($acao == 'keepAlive') ? LOG_DEBUG3 : LOG_DEBUG0, "Mensagem de Operacao-Agente recebida de $nomeAgente - MSG: [\033[35;1m$msgRecv\033[0m]");
						switch($acao) {
							case 'keepAlive':
								if($agente->codstatus > 0) {
									ControleCC::loga(LOG_DEBUG2, "keepAlive de $nomeAgente");
									$agente->keepAlive();
								} else
									ControleCC::loga(LOG_AVISO, "keepAlive de Agente Deslogado!!! $nomeAgente");
								break;
								
							case 'login':
								if($agente->codstatus == 0) {
									// PARAM1 = Telefone  |   $params[2];	// PARAM2 = OPCIONAL = Mobilidade
									$agente->login($params[1], (isset($params[2]) ? $params[2] : null));
								} else
									ControleCC::loga(LOG_AVISO, "Imposs�vel logar $nomeAgente - codtatus > 0 ($agente->codstatus)");
								break;
							
							case 'logoff':
								// func desloga j� da esta MSG - ControleCC::loga(LOG_NORMAL, ">>>> Efetuar logoff de" . $agente->getNome());
								$err = $agente->desloga();
								if($err !== true) ControleCC::loga(LOG_AVISO, $err);
								break;
							
							case 'mudaStatus':
								$stsNovo   = $params[1];
								$podeMudar = true;

								if($stsNovo == 'TABULACAO') {
									$stsNovo = DISPONIVEL;
									if($agente->codstatus != PAUSA_AUTO) {
										ControleCC::loga(LOG_AVISO, "Despausa por tabulacao de $nomeAgente cancelada. Nao estava em PAUSA AUTOMATICA");
										$podeMudar = false;
									}
								} else if($stsNovo == 'NAOTABULADO') {
									$stsNovo = INDISP;
									if($agente->codstatus != PAUSA_AUTO) {
										ControleCC::loga(LOG_AVISO, "Indisponivel por NAO tabulacao de $nomeAgente cancelada. Nao estava em PAUSA AUTOMATICA");
										$podeMudar = false;
									}
								} else if($stsNovo != DISPONIVEL && $stsNovo < PAUSA) {
									// Consistencia. Este comando s� muda para DISPONIVEL, PAUSA ou INDISP
									$agente->msg = "Imposs�vel mudar para o status $stsNovo";
									$podeMudar = false;
								}
								
								/*
								// TODO - parametrizar
								// S� � poss�vel pausar vindo de DISPONIVEL
								if($stsNovo >= PAUSA && $agente->codstatus != DISPONIVEL) {
									$tipo = ($stsNovo >= INDISP) ? 'indisponibilizar' : 'pausar';
									$agente->msg = "Impossivel $tipo se nao estiver disponivel";
									$podeMudar = false;
								}
								*/
								// Verifica se esta indo para pausa/indisp
								if($podeMudar && $agente->codstatus < PAUSA && $stsNovo >= PAUSA) {
									// Se esta indo para pausa, verificar se pode devido aos limites de pausa por fila
									// Busca todos os agentes que ESTAO EM PAUSA
									$agentesEmPausa = ControleCC::$memAgs->getObjs('codstatus', PAUSA-1, '>');
									if(count($agentesEmPausa) > 0) {
										// Filas do agente solicitando pausa
										$filasAg = ControleCC::$memFilas->getObjs('id', explode(',', $agente->idsfilas));
										$idsFilasComLimite = array();
										foreach($filasAg as $fa)
											if($fa->maxagspausa > 0) {
												$fa->agsEmPausa = 0;
												$idsFilasComLimite[] = $fa->id;
											}
										if(count($idsFilasComLimite) > 0) {
											foreach($agentesEmPausa as $ag) {
												$idsFilasAgTeste = explode(',', $ag->idsfilas);
												if(count(array_intersect($idsFilasComLimite, $idsFilasAgTeste)) > 0) {
													// O agente sendo testado esta em alguma fila que o agente solicitante tambem esta
													// Incrementar o numero de agentes pausados para as filas do agente em teste:
													foreach($idsFilasAgTeste as $idfat) {
														if($filasAg[$idfat]->maxagspausa > 0) {	// maxagspausa = 0 => sem limite
															$filasAg[$idfat]->agsEmPausa++;
															if($filasAg[$idfat]->agsEmPausa >= $filasAg[$idfat]->maxagspausa) {
																// Achou um limite
																$nomeF = $filasAg[$idfat]->name;
																ControleCC::loga(LOG_AVISO, "Muito usuarios pausados na fila ($nomeF), impedindo pausa de $nomeAgente");
																$agente->msg = "Muitos agentes em pausa no momento na fila [$nomeF]";
																$podeMudar = false;
																break 2;
															}
														}
													}
												}
											}
										}
									}
								}
								
								if($podeMudar) {
									$paused = ($stsNovo != DISPONIVEL);
									$sucesso = $agente->pausa($paused);
									
									if($sucesso === true) {
										$sucesso = $agente->mudaEstado($stsNovo, array('codstatusbase' => $stsNovo));
										if($sucesso === true) ControleCC::loga(LOG_NORMAL, "Status de $nomeAgente alterado com sucesso para [$agente->codstatus]");
										else {
											// Des-mudar o estado
											$estIgual = ($sucesso == 'Estados iguais');
											if(!$estIgual) $agente->pausa(!$paused);
											ControleCC::loga(($estIgual ? LOG_AVISO : LOG_CRITICO), "AG: Erro ao alterar codStatus de $nomeAgente - Msg [$sucesso]");
											$agente->msg = "Erro ao alterar estado. Tente novamente";
											$podeMudar = false;
										}
									} else {
										ControleCC::loga(LOG_CRITICO, "AG: Erro ao pausar/despausar $nomeAgente - Msg [$sucesso]");
										$agente->msg = "Erro ao alterar estado. Tente novamente";
										$podeMudar = false;
									}
								}
								if(!$podeMudar)
									$agente->atualiza();
								break;
							
							case 'disca':
								$num = $params[1];
								$this->disca($agente, $num);
								break;
							case 'transferir':
								$num = $params[1];
								$this->transfere($agente, $num);
								break;
							case 'conferencia':
								$num = $params[1];
								$this->conferencia($agente, $num);
								break;
							case 'desligar':
								$this->desligaChamada($agente);
								break;
							case 'limpaMsg':
								$this->limpaMsg($agente);
								break;
																						
							default:
								ControleCC::loga(LOG_CRITICO, "Mensagem de Operacao-Agente \033[35;1mRECUSADA\033[0m - Acao nao reconhecida - msg: [$msgRecv]");
						}
					} else
						ControleCC::loga(LOG_CRITICO, "Mensagem de Operacao-Agente \033[35;1mRECUSADA\033[0m - ID do Agente inv�lido - msg: [$msgRecv]");
				} else {
					ControleCC::loga(LOG_CRITICO, "MSG: [$msgRecv] - Tipo: [$tipo] - TIPO DESCONHECIDO");
				}
				
				$mt = microtime(true);
				if($acao != 'keepAlive' && !$ehPing) {
					$tempo = $mt - $inicioProcessa;
					if($tempo > TEMPO_CRITICO) $tempo = "[\033[31;1m$tempo\033[0m]"; // Deixa em vermelho tempo muito grandes
					ControleCC::loga(LOG_DEBUG0, "Tempo de execucao da MSG [\033[32;1m$msgRecv\033[0m][100]: $tempo");
				}
				if($mt > ($inicioProcessa + TEMPO_MAX_PROCESSA)) {
					$dadosMsgQ = msg_stat_queue($this->mq_id);
					$falta = $dadosMsgQ['msg_qnum'];
					ControleCC::loga(LOG_AVISO, "MsgQueue - Tempo de execucao estourado - faltaram $falta msgs, deixando para proxima passada");
					break;
				}
			}
		}
	}
	
	function trataTipo100($msgRecv, $inicio=false) {
		$ehPing = false;
		
		$params = explode(":", $msgRecv);
		$tsCmd  = array_shift($params);
		$codUsu = array_shift($params);
		if($codUsu != 'ADM') {
			ControleCC::loga(LOG_CRITICO, "Mensagem de Sistema \033[35;1mRECUSADA\033[0m - usuario nao 'ADM' - msg: [$msgRecv]");
			return false;
		}
		if($inicio && (time() > ($tsCmd + 10))) {
			ControleCC::loga(LOG_AVISO, "Mensagem [\033[35;1m$msgRecv\033[0m] IGNORADA. Muito antiga (> 10s)");
			return false;
		}
		$acao = $params[0];
		// Mensagens de Controle do sistema
		ControleCC::loga(($acao != 'PING' ? LOG_DEBUG0 : LOG_DEBUG2), "Mensagem de Sistema recebida - MSG: [\033[35;1m$msgRecv\033[0m]");
		switch($acao) {
			case 'PING':
				file_put_contents('/etc/asterisk/telip/cc/PING', $params[1]);
				$ehPing = true;
				break;
			
			case 'refresh':			// A��o para atualizar os dados de Agentes / Filas na SHMEM
				$tipo = $params[1];	// Tipo = 'TUDO', 'Agente', 'Fila'
				$id   = $params[2]; // ID do Agente ou da Fila - 0 = todos
				switch($tipo) {
					case 'TUDO':
						if(ControleCC::$memAgs->refresh() === true)
							Agente::setaAltFlagPorID();
						ControleCC::$memFilas->refresh();
						break;
					case 'Agente':
						if(ControleCC::$memAgs->refresh($id) === true)
							Agente::syncFilas2($id);
						break;
					case 'Fila':
						ControleCC::$memFilas->refresh($id);
						break;
				}
				ControleCC::atualizaNomesFilas();
				ControleCC::atualizaTelAgentes();
				break;
				
			case 'delete':
				$tipo = $params[1];	// Tipo = 'Agente' ou 'Fila'
				$id   = $params[2]; // ID do Agente ou da Fila
				switch($tipo) {
					case 'Agente':
						$ag = ControleCC::$memAgs->get('id', $id);
						if(is_a($ag, 'Agente')) {
							if($ag->codstatus > 0)
								$ag->desloga(-6);
							ControleCC::$memAgs->delete($id);
						}
						break;
					
					case 'Fila':
						ControleCC::$memFilas->delete($id);
						break;
				}
				ControleCC::atualizaNomesFilas();
				ControleCC::atualizaTelAgentes();
				break;
			
			case 'LOGOFFALL':
				foreach(ControleCC::$memAgs->getObjs('codstatus', 0, '>') as $ag)
					$ag->desloga(-7);
				break;
			
			case 'SAIA':
				if($inicio) {
					ControleCC::loga(LOG_AVISO, "Pedido de saida antigo IGNORADO");
				} else {
					ControleCC::loga(LOG_AVISO, "Pedido de saida! Saindo!");
					ControleCC::$loopPrincipal = 0;
				}
				break;
			
			case 'RST':
				ControleCC::loga(LOG_AVISO, "RST!");
				ControleCC::$loopPrincipal = 33;
				break;
			
			case 'NIVELLOG':
				$nivel = $params[1];
				ControleCC::$logger->nivel = $nivel;
				file_put_contents('/etc/asterisk/telip/cc/NIVELLOG', $nivel);
				ControleCC::loga(LOG_AVISO, "Nivel de log alterado para [$nivel]");
				break;
			
			case 'addCallBack':
				$idFila = $params[1];
				$cid    = $params[2];
				$uid    = $params[3];
				
				$fila = ControleCC::$memFilas->get('id', $idFila);
				if(is_a($fila, 'FilaCC')) {
					// Colocar chamada na fila de callbacks desta fila
					$fila->addCallBack($cid, $uid);
				} else
					ControleCC::loga(LOG_AVISO, "Erro ao buscar fila ID($idFila) para adicionar callback para $cid");
				break;
			
			/**
			 * addPopupAgenda
			 * mensagem enviada pelo script modulos/Discador/discador/agendamentos.php (CRON (1/1min))
			 * Dispara a altera��o para ativar o popup de Chamada Agendada na tela do Agente
			 *   quandou houver chamada agendada para o minuto corrente
			 */
			case 'addPopupAgenda':
				$idAg      = $params[1];
				$idAlvo    = $params[2];
				$dadosAlvo = $params[3];
				$idFila    = $params[4];
				$dataHora  = $params[5];
				$nums      = $params[6];
				$idCampanha= $params[7];
				
				$agente = ControleCC::$memAgs->get('id', $idAg);
				if(is_a($agente, 'Agente')) {
					$nomeAgente = $agente->getNome();
					// Altera idalvoagd que � monitorado via JavaScript em janelaAgente.php->parseDados()
					$agente->idalvoagd    = $idAlvo;
					$agente->dadosalvoagd = $dadosAlvo;
					$agente->filaalvoagd  = $idFila;
					$agente->dthragd      = $dataHora;
					$agente->numsalvoagd  = $nums;
					$agente->idcampagd    = $idCampanha;
					$sucesso = $agente->atualiza();
					if($sucesso === true) ControleCC::loga(LOG_NORMAL,  "Agendamento para alvo[$idAlvo]($dadosAlvo,$idFila,$dataHora,$nums,$idCampanha) enviado para $nomeAgente");
					else                  ControleCC::loga(LOG_CRITICO, "Erro ao enviar agendamento para $nomeAgente - Msg [$sucesso]");
				}
				break;
			
			case 'atzTemposAgs':
				$tIni = microtime(true);
				foreach(file(BASE_DIR.'controleCC-Tempos-agentes.dat', FILE_IGNORE_NEW_LINES) as $linAg) {
					list($idAg,$ramal,$nome,$tel,$recebidas,$efetuadas,$tta,$tma,$abandonadas,$tempologado,$atendidas,$tratadas) = explode('|', $linAg);
					$agente = ControleCC::$memAgs->get('id', $idAg);
					if(is_a($agente, 'Agente')) {
						$agente->recebidas   = $recebidas;
						$agente->efetuadas   = $efetuadas;
						$agente->tta         = $tta;
						$agente->tma         = $tma;
						$agente->abandonadas = $abandonadas;
						$agente->tempologado = $tempologado;
						$agente->atendidas   = $atendidas;
						$agente->tratadas    = $tratadas;
						if(($sucesso = $agente->atualiza()) !== true)
							ControleCC::loga(LOG_CRITICO, "Erro ao atualizar dados de $nomeAgente - Msg [$sucesso]");
					}
				}
				ControleCC::setaFlagAltSups();
				ControleCC::loga(LOG_DEBUG1, 'Setados tempos dos Agentes. Tempo: ' . (microtime(true) - $tIni));
				break;
			
			case 'atzTemposFilas':
				$tIni = microtime(true);
				foreach(file(BASE_DIR.'controleCC-Tempos-filas.dat', FILE_IGNORE_NEW_LINES) as $linFila) {
					list($idFila,$name,$qtdchamatendida,$tempototalatend,$qtdchamaband,$tempototalabandono,$tempomaxabandono) = explode('|', $linFila);
					$fila = ControleCC::$memFilas->get('id', $idFila);
					if(is_a($fila, 'FilaCC')) {
						$fila->qtdchamatendida    = $qtdchamatendida;
						$fila->tempototalatend    = $tempototalatend;
						$fila->qtdchamaband       = $qtdchamaband;
						$fila->tempototalabandono = $tempototalabandono;
						$fila->tempomaxabandono   = $tempomaxabandono;
						if(($sucesso = $fila->atualizaShMem()) !== true)
							ControleCC::loga(LOG_CRITICO, "Erro ao atualizar dados da fila $name - Msg [$sucesso]");
					}
				}
				ControleCC::setaFlagAltSups();
				ControleCC::loga(LOG_DEBUG1, 'Setados tempos das Filas. Tempo: ' . (microtime(true) - $tIni));
				break;
			
			default:
				ControleCC::loga(LOG_CRITICO, "Mensagem de Sistema \033[35;1mRECUSADA\033[0m - Acao nao reconhecida - msg: [$msgRecv]");
		}
		
		return $ehPing;
	}
	
	function disca($agente, $num) {
		$nomeAgente = $agente->getNome();
		if($agente->codstatus > 0) {
			$sucesso = ControleCC::$comandosAst->enviaComando('Originate', array(
					'Channel'  => $agente->telefone,
					'Context'  => $agente->contexto,
					'Exten'    => $num,
					'Priority' => 1,
					'Callerid' => "$agente->nome <$agente->ramal>",
					'Timeout'  => 30000,
					'Variable' => "RAMAL_CC=$agente->ramal",
					'Async'    => 1
				));
			if($sucesso === true) {
				$agente->mudaEstado(DISCANDO);
				ControleCC::loga(LOG_NORMAL,  "Chamada de $nomeAgente para $num efetuada com sucesso");
			} else
				ControleCC::loga(LOG_AVISO, "Falha ao efetuar discagem de $nomeAgente para $num - msg [".substr($sucesso,0,-1)."]");
		} else
			ControleCC::loga(LOG_AVISO, "Comando disca de agente $nomeAgente deslogado");
	}
	
	function transfere($agente, $num) {
		$nomeAgente = $agente->getNome();
		if(!empty($agente->link) && strlen($agente->link) > 6) {
			$sucesso = ControleCC::$comandosAst->enviaComando('Redirect', array(
						'Channel'  => $agente->link,
						'Context'  => 'irrestrito-user',
						'Exten'    => $num,
						'Priority' => "1"
					));
			if($sucesso === true) {
				ControleCC::logaEvento(EVENTO_TRANSFERE, $agente->id, $agente->telefone, $agente->numentra, $num);
				ControleCC::loga(LOG_NORMAL, "Chamada de $nomeAgente transferida para $num");
			} else
				ControleCC::loga(LOG_CRITICO, "Erro ao transferir chamada de $nomeAgente para $num - msg [$sucesso]");
		} else
			ControleCC::loga(LOG_CRITICO, "Erro ao transferir chamada de $nomeAgente - Impossivel achar canal - Nao esta em chamada?");
	}
	
	function conferencia($agente, $num) {
		$nomeAgente = $agente->getNome();
		$sucesso = ControleCC::$comandosAst->enviaComando('Originate', array(
					'Channel'     => "Local/$num@todos",
					'Priority'    => 0,
					'Variable'    => "RAMAL_CC=$agente->ramal",
					'Application' => 'ChanSpy',
					'Data'        => "$agente->telefone|v(2)B",
					'Timeout'     => 30000,
					'Async'       => 1
				));
		if($sucesso === true) {
			ControleCC::logaEvento(EVENTO_CONFERENCIA, $agente->id, $agente->telefone, $agente->numentra, $num);
			ControleCC::loga(LOG_NORMAL, "Agente $nomeAgente, telefone $agente->numentra colocados em conferencia com $num");
		} else
			ControleCC::loga(LOG_AVISO, "Erro ao iniciar conferencia do Agente $nomeAgente, telefone $agente->numentra com $num");
	}
	
	function desligaChamada($agente) {
		$nomeAgente = $agente->getNome();
		if($agente->channel != '' && strlen($agente->channel) > 6) {
			$sucesso = ControleCC::$comandosAst->enviaComando('Hangup', array('Channel'  => $agente->channel));
			if($sucesso === true) ControleCC::loga(LOG_NORMAL, "Chamada de $nomeAgente desligada");
			else {
				ControleCC::loga(LOG_NORMAL, "Falha ao desligar chamada de $nomeAgente. [$sucesso] Nao estava em chamada? Forcando mudanca de estado");
				$agente->mudaEstado(DISPONIVEL);
			}
		} else
			ControleCC::loga(LOG_NORMAL, "Falha ao buscar canal de $nomeAgente. Nao estava em chamada?");
	}
	
	function limpaMsg($agente) {
		$nomeAgente = $agente->getNome();
		ControleCC::loga(LOG_DEBUG1, "Agente $nomeAgente limpou a mensagem [$agente->msg]");
		$agente->msg = '';
		$agente->atualiza();
	}
	
	function shut($apaga=false) {
		if($apaga) msg_remove_queue($this->mq_id);
	}
}
?>