<?php
	include('comandos.php');
	
	$agente = loginOK();
	$agente->telefone = $_REQUEST['telefone'];
	$agente->mobilidd = true;
	$_SESSION['agenteLogado'] = $agente;
	
	header("location:popupagente.php");
?>
