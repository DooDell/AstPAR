<?php
/*
Content-type: multipart/x-mixed-replace; boundary="abracadabra"--abracadabraContent-type: text/html&lt;h1&gt;This is the first page...&lt;/h1&gt;--abracadabraContent-type: text/plain

And this is the last.

--abracadabra--
*/
    $delimiter = "kanduske123kadunske";
    header('Content-type: multipart/x-mixed-replace;boundary="'.$delimiter.'"');

    $header   = "Content-type: text/html\n\n";
    $boundary = "--{$delimiter}\n\n";
    $footer   = "--{$delimiter}--\n\n";

    if (ob_get_level() == 0) ob_start();
    
    $content = '';
    $timeout = time() + 10;
    while(time() < $timeout) {
    	$aux = $content;
        $content = file_get_contents('/tmp/TESTE');
        if($aux != $content) {
        	echo "$header loop $i: $content\n$boundary";
        	ob_flush();
        	flush();
        	$i++;
        }
		usleep(250000);
    }

    echo $header . "_FIM_". $footer;
    ob_end_flush();
?>