<?php
class Totais {
	var $total, $deslogado, $logado, $disponivel, $atendimento, $sainte, $entrante, $empausa, $indisponivel, $supervisor, $agora;
	
	function Totais($arrayAgs) {
		//$this->deslogado = $this->disponivel = $this->atendimento = $this->sainte = $this->entrante = $this->empausa = $this->indisponivel = $this->supervisor = 0;
		$this->total = is_array($arrayAgs) ? count($arrayAgs) : 0;
		if($this->total > 0) {
			foreach($arrayAgs as $ag) {
				if($ag->codstatus > DESLOGADO && $ag->codstatus != SUPLOGADO) $this->logado++; 
				switch($ag->codstatus) {
					case DESLOGADO:  $this->deslogado++;   break;
					case DISPONIVEL: $this->disponivel++;  break;
					case CHAMANDO:
					case ATENDENDO:  $this->atendimento++; break;
					case SAINTE:     $this->sainte++;      break;
					case ENTRANTE:   $this->entrante++;    break;
					case SUPLOGADO:  $this->supervisor++;  break;
					default:
						if($ag->codstatus >= 200) $this->indisponivel++;
						else                      $this->empausa++;
				}
			}
		}
		$this->agora = date('H:i:s');
	}
	
	function __toString() {
		$ret = get_class($this) . '{';
		foreach(get_object_vars($this) as $c => $v)
			$ret .= "$c=$v|";
		return $ret;
	}
}
?>