<?php
	include('comandos.php');
	$ramalSup = $_SESSION['agenteLogado']->ramal;
	
	$mem = new SharedMem(ID_SHMEM_AGS, 'Agente');
	
	if(!empty($ramalSup)) {
		$memFlags = @shmop_open(ID_SHMEM_FLAGS, 'w', 0, 0);
		if ($memFlags) {
			// Busca todos os ramais de Agentes e IDs de filas
			$rf = buscaRamaisEFilas();
			$ramaisAgs = $rf['ramais'];
			$idsFilas  = $rf['filas'];
			
			// Inicializa��o do Comet
		    $delimiter = 'kanduskeS123kadunskeS';
		    header('Content-type: multipart/x-mixed-replace;boundary="'.$delimiter.'"');
		    $header   = "Content-type: text/html\n\n";
		    $boundary = "--{$delimiter}\n\n";
		    $footer   = "--{$delimiter}--\n\n";
		    if (ob_get_level() == 0) ob_start();
	    	
	    	$sts = 10;		// Status do supervisor
	    	$ini = true;	// Flag para buscar os dados iniciais
	    	
	    	$agora = time();
		    $timeout = $agora + 45; // 45s por requisi��o
		    $refresh = $agora + 5; // 5s para refresh
		    while($sts > 0 && $agora < $timeout) {
		    	if($ini || (shmop_read($memFlags, $ramalSup, 1) == '1') || $agora > $refresh) {		// Verifica a mem�ria de flags de altera��o
		    		$refresh = $agora + 5; // 5s para refresh
		    		shmop_write($memFlags, '0', $ramalSup);			// Zera a flag
		    		$ini = false;
					echo $header;
					foreach(buscaDadosSup($ramaisAgs, $idsFilas) as $obj) {
						if(is_a($obj, 'Agente'))
							$obj->tempostatus = $agora - $obj->tempostatus;
						echo "$obj\n";
					}
		        	echo $boundary;
		        	ob_flush();
		        	flush();
		       	}
		       	
				sleep(1);
				$agora = time();
				
				$agente = $mem->get('ramal', $ramalSup);
				$sts = $agente->codstatus;
		    }
		    shmop_close($memFlags);
		    echo $header . '_EOR_' . $footer;
		    ob_end_flush();
		} else
			echo "Erro ao abrir SHMEM\n";
	} else
		echo "Nao logado\n";
?>