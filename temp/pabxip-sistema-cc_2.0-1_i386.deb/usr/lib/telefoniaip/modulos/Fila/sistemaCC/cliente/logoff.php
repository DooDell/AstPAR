<?php
	session_start();
	unset($_SESSION['agenteLogado']);
	header("location:login.php");
?>
