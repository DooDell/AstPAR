#!/usr/bin/php -c /usr/lib/telefoniaip/arquivos/config/php.ini
<?php
ini_set('max_execution_time', '0');
ini_set('max_input_time',     '0');
set_time_limit(0);

include(''.'/usr/lib/telefoniaip/modulos/Fila/sistemaCC/includePrincipal.php');
include(''.'/usr/lib/telefoniaip/modulos/Fila/sistemaCC/logger.php');

// Parse da linha de comando
$tipo = (isset($argv[1]) && $argv[1] == 'FILAS') ? 'FILAS' : 'AGS'; // Padrao = FILAS

// Calcular!
calculaTempos($tipo);

function calculaTempos($tipo) {
	$mais = " [\033[35;1mcalcT\033[0m]";
	$conn = new Conexao();

	$hoje = date('Y-m-d');   // para SQL
	$tIni = microtime(true); // Para calcular os tempos de execu��o
	if($tipo == 'AGS') {
		// Busca todos os agentes
		$agentes = array();
		$conn->executa('SELECT id,ramal FROM usuario WHERE funcionalidades & '.FUNC_AGENTE.' = '.FUNC_AGENTE);
		while($conn->temMaisDados()) {
			$agente = (object)$conn->data;
			$agente->tta = $agente->tma = $agente->recebidas = $agente->efetuadas = $agente->atendidas = $agente->abandonadas = $agente->tratadas = $agente->tempologado = 0;
			$agentes[$agente->ramal] = $agente;
		}
		
		loga(LOG_DEBUG1, "Calculando {tta,tma,recebidas,efetuadas} dos Agentes com base em cc_historico", $mais);
		// Calculo de recebidas e tta por agente
		$conn->executa("SELECT campo1 as ramal, COUNT(id) as recebidas, SUM(INT4(campo3)) as tta FROM cc_historico WHERE tipoevento = 17 AND data = '$hoje' GROUP BY campo1");
		while($conn->temMaisDados()) {
			$ramal = $conn->data['ramal'];
			if(isset($agentes[$ramal])) {
				$rec = $conn->data['recebidas'];
				$tta = $conn->data['tta'];
				$agentes[$ramal]->recebidas = $rec;
				$agentes[$ramal]->tta       = $tta;
				$agentes[$ramal]->tma       = ($rec > 0) ? ceil($tta / $rec) : 0;
			}
		}
		// Calculo de efetuadas por agente
		$conn->executa("SELECT campo1 as ramal, COUNT(id) as efetuadas FROM cc_historico WHERE tipoevento = 9 AND data = '$hoje' GROUP BY campo1");
		while($conn->temMaisDados()) {
			$ramal = $conn->data['ramal'];
			if(isset($agentes[$ramal]))
				$agentes[$ramal]->efetuadas = $conn->data['efetuadas'];
		}
		
		// Gravar os dados calculados em arquivo
		$txtOut = '';
		foreach($agentes as $agente)
			$txtOut .= "$agente->id|$agente->ramal|$agente->nome|$agente->telefone|$agente->recebidas|$agente->efetuadas|$agente->tta|$agente->tma|$agente->abandonadas|$agente->tempologado|$agente->atendidas|$agente->tratadas\n";
		file_put_contents(BASE_DIR.'controleCC-Tempos-agentes.dat', $txtOut);
		
		// Sinalizar para o controle atualizar os dados do arquivo na memoria
		$msg_err = null;
		$mq_id = msg_get_queue(ID_MSG_QUEUE);
		if (!msg_send ($mq_id, 100, time() . ':ADM:atzTemposAgs', false, false, $msg_err))
			loga(LOG_CRITICO, "Erro [$msg_err] ao enviar comando", $mais);
		
		// Logar o tempo de execu��o
		loga(LOG_DEBUG0, 'Calculado tempos dos Agentes. Tempo: ' . (microtime(true) - $tIni), $mais);
	} else {
		// Busca todas as filas
		$filas = array();
		$conn->executa('SELECT id,name FROM fila');
		while($conn->temMaisDados()) {
			$fila = (object)$conn->data;
			$fila->qtdchamatendida = $fila->tempototalatend = $fila->qtdchamaband = $fila->tempototalabandono = $fila->tempomaxabandono = 0;
			$filas[strtolower($fila->name)] = $fila;
		}
		
		loga(LOG_DEBUG1, "Calculando {qtdchamatendida,tempototalatend,qtdchamaband,tempototalabandono,tempomaxabandono} das Filas com base em cc_historico", $mais);
		// calcular qtdchamatendida e tempototalatend por fila
		$conn->executa("SELECT LOWER(campo5) as nomefila, COUNT(id) as qtdchamatendida, SUM(INT4(campo3)) as tempototalatend FROM cc_historico WHERE tipoevento = 17 AND data = '$hoje' GROUP BY LOWER(campo5)");
		while($conn->temMaisDados()) {
			$nomeFila = substr($conn->data['nomefila'], 1, -1);
			$filas[$nomeFila]->qtdchamatendida = $conn->data['qtdchamatendida'];
			$filas[$nomeFila]->tempototalatend = $conn->data['tempototalatend'];
		}
		loga(LOG_DEBUG1, 'Calculado tempos das Filas. SQL2 - Tempo: ' . (microtime(true) - $tIni), $mais);
		// calcular qtdchamaband, tempomaximo de abandono e tempo total de abandono
		$conn->executa("SELECT LOWER(campo5) as nomefila, COUNT(id) as qtdchamaband, SUM(INT4(campo1)) as ttaband, MAX(INT4(campo1)) as tmaxaband FROM cc_historico WHERE tipoevento = 18 AND data = '$hoje' GROUP BY LOWER(campo5)");
		while($conn->temMaisDados()) {
			$nomeFila = substr($conn->data['nomefila'], 1, -1);
			$filas[$nomeFila]->qtdchamaband       = $conn->data['qtdchamaband'];
			$filas[$nomeFila]->tempototalabandono = $conn->data['ttaband'];
			$filas[$nomeFila]->tempomaxabandono   = $conn->data['tmaxaband'];
		}
		
		// Gravar os dados calculados em arquivo
		$txtOut = '';
		foreach($filas as $fila)
			$txtOut .= "$fila->id|$fila->name|$fila->qtdchamatendida|$fila->tempototalatend|$fila->qtdchamaband|$fila->tempototalabandono|$fila->tempomaxabandono\n";
		file_put_contents(BASE_DIR.'controleCC-Tempos-filas.dat', $txtOut);
		
		// Sinalizar para o controle atualizar os dados do arquivo na memoria
		$msg_err = null;
		$mq_id = msg_get_queue(ID_MSG_QUEUE);
		if (!msg_send ($mq_id, 100, time() . ':ADM:atzTemposFilas', false, false, $msg_err))
			loga(LOG_CRITICO, "Erro [$msg_err] ao enviar comando", $mais);
		
		loga(LOG_DEBUG0, 'Calculado tempos das Filas. Tempo: ' . (microtime(true) - $tIni), $mais);
	}
}
?>