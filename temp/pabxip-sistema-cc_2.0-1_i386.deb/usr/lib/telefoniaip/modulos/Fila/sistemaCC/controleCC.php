<?php
ini_set('max_execution_time', '0');
ini_set('max_input_time',     '0');
set_time_limit(0);
include('includePrincipal.php');

class ControleCC {
	/** �reas de mem�ria compartilhada */
	public static $memLogin, $memFlags, $memAgs, $memFilas;
	/** Array com os telefones dos agentes e os nomes das filas */
	public static $telAgentes, $nomesFilas;
	/** Vari�veis de controle */
	public static $loopPrincipal, $conf, $logger, $connAst, $eventos, $nomeEventos;
	public static $comandosAst, $agsEmFilas, $params, $pingRET, $temQueueSync;
	
	// Variaveis locais
	var $comandos;
	
	/**
	 * Inicializa��o do Sistema
	 */
	function ControleCC($emTela) {
		ControleCC::$loopPrincipal = 1;
		ControleCC::$pingRET = 'PING';
		ControleCC::$agsEmFilas = array();
		
		$nivelLog = file_get_contents('/etc/asterisk/telip/cc/NIVELLOG');
		ControleCC::$logger = new Logger($nivelLog, $emTela);
		
		ControleCC::$conf = new Conf();
		$err = ControleCC::$conf->init();
		if(!$err)
			ControleCC::loga(LOG_AVISO, "Arquivo de configuracao [".ControleCC::$conf->arq."] nao encontrado. Assumindo valores padrao");
		
		ControleCC::loga(LOG_NORMAL, "Conectando com o banco Asterisk");
		ControleCC::$connAst = new Conexao();
		if(!ControleCC::$connAst->loginOK) {
			ControleCC::loga(LOG_CRITICO, "Problemas ao conectar no banco do Asterisk!");
			$this->shut(9);
		}
		
		ControleCC::loga(LOG_NORMAL, "Buscando parametros");
		ControleCC::$params = array();
		ControleCC::$connAst->executa("SELECT valor FROM parametro WHERE nomeparam = 'DDDLocal'");
		if(ControleCC::$connAst->temMaisDados())
			ControleCC::$params['DDDLocal'] = ControleCC::$connAst->data['valor'];
		
		ControleCC::loga(LOG_NORMAL, "Buscando nomes dos eventos");
		ControleCC::$nomeEventos = array();
		ControleCC::$connAst->executa("SELECT id,nome FROM cc_tipoevento");
		while(ControleCC::$connAst->temMaisDados())
			ControleCC::$nomeEventos[ControleCC::$connAst->data['id']] = ControleCC::$connAst->data['nome'];
		
		ControleCC::loga(LOG_NORMAL, "Inicializando memoria compartilhada de flags de alteracoes");
		ControleCC::$memFlags = @shmop_open(ID_SHMEM_FLAGS, 'c', 0666, 10000);
		if (!ControleCC::$memFlags) {
			ControleCC::loga(LOG_CRITICO, "Problemas inicializar memoria compartilhada!");
			$this->shut(11);
		}
		// Inicializar os slots
		shmop_write(ControleCC::$memFlags, str_repeat('0000000000', 1000), 0);
		
		ControleCC::loga(LOG_NORMAL, "Inicializando memoria compartilhada de Agentes");
		ControleCC::$memAgs = new SharedMem(ID_SHMEM_AGS, 'Agente', ControleCC::$connAst,
			'SELECT id,nome,login,ramal,senha,funcionalidades,contexto,idsfilas,nomesfilas FROM usuario WHERE funcionalidades & '.FUNC_AGENTE.' = '.FUNC_AGENTE, 'ESCRITA');
		ControleCC::loga(LOG_NORMAL, "Inicializando memoria compartilhada de Filas");
		ControleCC::$memFilas = new SharedMem(ID_SHMEM_FILAS, 'FilaCC', ControleCC::$connAst,
			'SELECT id,flags,name,tipopiloto,ramal,maxagspausa,urlpopup,urlpopupfim,indispna,callback,callbackdisp,callbackmin,callbackmax,callbackstriplocal,callbackaddlocal,callbackaddddd FROM fila', 'ESCRITA');
		
		ControleCC::loga(LOG_NORMAL, "Inicializando memoria compartilhada de flags de agentes logados");
		ControleCC::$memLogin = @shmop_open(ID_SHMEM_LOGIN, 'c', 0666, 10000);
		if (!ControleCC::$memLogin) {
			ControleCC::loga(LOG_CRITICO, "Problemas inicializar memoria compartilhada de flags de agentes logados!");
			$this->shut(12);
		}
		$this->atualizaFlagsLogados(true);
		
		// Buscar a lista de telefones de agentes
		ControleCC::atualizaTelAgentes();
		// Buscar a lista de nomes de filas
		ControleCC::atualizaNomesFilas();
		
		// Inicializar as conex�es com o AMI
		$this->initAMI();
		
		ControleCC::loga(LOG_NORMAL, "Inicializando fila de mensagens para comandos");
		$this->comandos = new MsgQueue(ID_MSG_QUEUE);
		// L� a fila de comandos, ignorando poss�veis SAIA e comandos antigos (> 10s) que estejam l�
		$this->comandos->processa(true);
		
		// Marca a hora de inicio do controleCC
		file_put_contents('/etc/controleCC.uptime', time());
	}
	
	function initAMI() {
		if(is_a(ControleCC::$eventos, 'EventosAMI'))
			ControleCC::$eventos->shut();
		ControleCC::$eventos = null;
		ControleCC::loga(LOG_NORMAL, "Inicializando processador de eventos Asterisk");
		ControleCC::$eventos = new EventosAMI(array('hostAMI' => ControleCC::$conf->ami->host,
													'userAMI' => ControleCC::$conf->ami->user,
													'passAMI' => ControleCC::$conf->ami->pass));
		if(ControleCC::$eventos->loginOK !== true) {
			ControleCC::loga(LOG_CRITICO, "Falha ao logar no AMI!");
			$this->shut(13);
		}

		if(is_a(ControleCC::$comandosAst, 'ComandosAMI'))
			ControleCC::$eventos->shut();
		ControleCC::$comandosAst = null;			
		ControleCC::loga(LOG_NORMAL, "Inicializando processador de comandos Asterisk");
		ControleCC::$comandosAst = new ComandosAMI(array('hostAMI'    => ControleCC::$conf->ami->host,
														 'userAMI'    => ControleCC::$conf->ami->user,
														 'passAMI'    => ControleCC::$conf->ami->pass,
														 'eventosAMI' => 'off'));
		if(ControleCC::$comandosAst->loginOK !== true) {
			ControleCC::loga(LOG_CRITICO, "Falha ao logar no AMI(2)!");
			$this->shut(14);
		}
		
		// Verificar se existe o comando QueueSync
		$sucesso = ControleCC::$comandosAst->enviaComando('ListCommands');
		$aux  = ControleCC::$comandosAst->getPacotesUltCmd();
		$aux2 = $aux->getAtr('QueueSync');
		ControleCC::$temQueueSync = !empty($aux2);
		if(!ControleCC::$temQueueSync) {
			ControleCC::loga(LOG_CRITICO, "Versao do asterisk sem patch GSD(QueueSync)");
			//$this->shut(15);
		}
	}

	/**
	 * Loop Principal
	 */
	function run() {
		$resetPeriodico = true;
		$tipo = $timer5s = $timer5m = 0;
		
		ControleCC::loga(LOG_NORMAL, "Loop Principal");
		
		// Calculo inicial
		$this->calculaTempos('FILAS');

		while($resetPeriodico) {
			while(ControleCC::$loopPrincipal === 1) {
				// Trata os eventos recebidos, se houver
				ControleCC::$eventos->processa(0.02);
				
				// Processa os comandos da fila de mensagens
				$this->comandos->processa();
				
				$agora = time();
				if($agora > $timer5s) { // A��es de 5 em 5 segundos
					$this->checaKeepAlive();
					
					// Atualiza os dados das filas e processa a fila de callbacks
					$this->atualizaFilas();
	
					// Ajusta o timer para daqui 5s
					$timer5s = $agora + 5;
				}
				if($agora > $timer5m) { // A��es de 5 em 5 minutos
					// Atualizar a lista de telefones de agentes
					ControleCC::atualizaTelAgentes();
					
					// CalculaTempos de Agentes e Tipos de 10 em 10 Minutos, intercalando-os de 5 em 5
					$this->calculaTempos(((!$tipo) ? 'AGS' : 'FILAS'));
					$tipo = 1 - $tipo;
					$timer5m = $agora + 300;
				}
			}
			
			$resetPeriodico = file_exists('/etc/asterisk/telip/EH_RESTART');
			if($resetPeriodico) {
				// Reabrir conex�o perdida com o AMI:
				$this->initAMI();
				unlink('/etc/asterisk/telip/EH_RESTART');
				// Restaurar o valor OK de ControleCC::$loopPrincipal
				ControleCC::$loopPrincipal = 1;
			}
		}
		
		// Deslogar todos se nao for um restart
		if(ControleCC::$loopPrincipal != 33) {
			ControleCC::loga(LOG_NORMAL, "Deslogando todos os agentes");
			foreach(ControleCC::$memAgs->getObjs('codstatus', 0, '>') as $ag)
				$ag->desloga(-7);
		}
		
		return ControleCC::$loopPrincipal;
	}
	
	/**
	 * Desligamento do Sistema
	 */
	function shut($ret=0) {
		if(is_a(ControleCC::$eventos, 'EventosAMI')) {
			ControleCC::loga(LOG_NORMAL, "Desconectando processador de eventos Asterisk");
			ControleCC::$eventos->shut();
		}
		if(is_a(ControleCC::$comandosAst, 'ComandosAMI')) {
			ControleCC::loga(LOG_NORMAL, "Desconectando processador de comandos Asterisk");
			ControleCC::$comandosAst->shut();
		}
		
		if(is_a(ControleCC::$connAst, 'Conexao')) {
			ControleCC::loga(LOG_NORMAL, "Desconectando do banco Asterisk.");
			ControleCC::$connAst->fecha(true);
		}
		
		ControleCC::loga(LOG_NORMAL, "Fechando memoria compartilhada");
		ControleCC::$memAgs->shut(($ret != 33));
		ControleCC::$memFilas->shut(($ret != 33));
		shmop_delete(ControleCC::$memLogin);
		shmop_delete(ControleCC::$memFlags);
		
		if(is_a($this->comandos, 'MsgQueue')) {
			ControleCC::loga(LOG_NORMAL, "Fechando fila de mensagens para comandos");
			$this->comandos->shut(($ret != 33));
		}
		
	    ControleCC::$logger->fecha();
	    exit($ret);
	}
	
	// **************************************************************
	// -------------------- Fun��es Diversas ------------------------
	// **************************************************************
	static function atualizaTelAgentes() {
		ControleCC::$telAgentes = array();
		foreach(ControleCC::$memAgs->getObjs() as $ag) {
			if($ag->codstatus > DESLOGADO && $ag->codstatus != SUPLOGADO)
				ControleCC::$telAgentes[$ag->telefone] = $ag->telefone;
		}
	}
	static function atualizaNomesFilas() {
		ControleCC::$nomesFilas = array();
		foreach(ControleCC::$memFilas->getObjs() as $fila)
			ControleCC::$nomesFilas[$fila->id] = $fila->name;
	}
	static function escreveArquivoTMA($agentes) {
		$txtOut = '';
		foreach($agentes as $ag) {
			if(!empty($ag->telefone) && $ag->tma > 0)
				$txtOut .= "$ag->nome|$ag->telefone|$ag->tma\n";
		}
		file_put_contents('/tmp/controleCC-TMA-agentes.dat', $txtOut);
	}
	
	function atualizaFlagsLogados($completo=false) {
		$ramaisAtz = array();
		foreach(ControleCC::$memAgs->getObjs() as $ag) {
			$logado = ($ag->codstatus > 0) ? '1' : '0';
			shmop_write(ControleCC::$memLogin, $logado, $ag->ramal);
			$ramaisAtz[] = $ag->ramal;
		}
		if($completo) {
			for($c=0; $c<10000; $c++)
				if(!in_array($c, $ramaisAtz))
					shmop_write(ControleCC::$memLogin, '0', $c);
		}
	}
	
	static function setaFlagAltSups() {
		$supervisores = ControleCC::$memAgs->getObjs('funcionalidades', FUNC_SUPERVISOR, '&');
		foreach($supervisores as $sup)
			shmop_write(ControleCC::$memFlags, '1', $sup->ramal);
	}
	
	/**
	 * Envia o comando para buscar os dados atuais das filas
	 */
	function atualizaFilas() {
		$c=0;
		$filaAgs = array();
		foreach(ControleCC::$memAgs->getObjs() as $ag) {
			if(is_a($ag, 'Agente')) {
				$idx = $c + ($ag->codstatus == 1 ? 200000 : (($ag->codstatus > 0 && $ag->codstatus != 10) ? 100000 : 0));
				$filaAgs[$idx] = explode(',', $ag->idsfilas);
				$c++;
			}
		}
		
		foreach(ControleCC::$memFilas->getObjs() as $fila) {
			if(is_a($fila, 'FilaCC')) {
				$fila->totag = $fila->totaglog = 0;
				$disps = 0;
				foreach($filaAgs as $logado => $idsfilas) {
					if(in_array($fila->id, $idsfilas)) {
						$fila->totag++;
						if($logado >= 100000) $fila->totaglog++;
						if($logado >= 200000) $disps++;
					}
				}
				
				// Verificar a fila de callback
				if($fila->callback && $disps > $fila->callbackdisp) $fila->processaCallBack($disps);
				
				$fila->atualizaShMem();
			}
		}
		
		ControleCC::setaFlagAltSups();
		ControleCC::loga(LOG_DEBUG3, "Checando status das filas no Asterisk [QueueStatus]");
		ControleCC::$eventos->enviaQueueStatus();
	}
	
	/**
	 * Verifica se os agentes est�o "vivos"
	 */
	function checaKeepAlive() {
		$fim = microtime(true) + 1.5; // Max 1.5s de execu�ao por vez
		// Tempo de KA = MAX_KEEPALIVE * 5
		ControleCC::loga(LOG_DEBUG2, "Checando keepAlive dos Agentes");
		$agentes = ControleCC::$memAgs->getObjs();
		foreach($agentes as $ag) {
			if(microtime(true) > $fim) return;
			if($ag->codstatus > 0) {
				$ag->keepalive++;
				if($ag->keepalive > ControleCC::$conf->kaAtivo) $ag->desloga(-1);
				else                                            $ag->atualizaShMem();
			} else if($ag->telefone != '') {
				ControleCC::loga(LOG_AVISO, "Agente ".$ag->getNome()." deslogado com telefone setado. Zerando telefone");
				$ag->telefone = '';
				$ag->atualizaShMem();
			}
		}
	}
	
	function calculaTempos($tipo) {
		exec(BASE_DIR."calculaTempos.php $tipo >> /var/log/controleCallCenter.log &");
	}
	
	// -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
	// -   Utilit�rios
	// -*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-*-
	/**
	 * Loga os eventos na base de dados
	 */
	static function logaEvento($tipoEvento, $c1="", $c2="", $c3="", $c4="", $c5="") {
		$data = date("Y-m-d");
		$hora = date("H:i:s");
		$params = "'$c1', '$c2', '$c3', '$c4', '$c5'";
		$err = ControleCC::$connAst->executa("INSERT INTO cc_historico(tipoEvento, datahora, data, hora, campo1, campo2, campo3, campo4, campo5) " .
												"VALUES($tipoEvento, '$data $hora', '$data', '$hora', $params)", false);
		if($err === true) {
			$nomeEv = "\033[30;1m$tipoEvento - " . ControleCC::$nomeEventos[$tipoEvento] . "\033[0m";
			ControleCC::loga(LOG_DEBUG1, "Evento [$nomeEv] logado. Params($params)");
		}
		return $err;
	}
	
	/**
	 * Fun��o auxiliar para simplicar o log
	 */
	static function loga($nivel, $msg) {
		ControleCC::$logger->loga($nivel, $msg);
	}
}

$daemon = new ControleCC(isset($argv[1]) && $argv[1] == 'FG');
$codRet = $daemon->run();
$daemon->shut($codRet);
?>