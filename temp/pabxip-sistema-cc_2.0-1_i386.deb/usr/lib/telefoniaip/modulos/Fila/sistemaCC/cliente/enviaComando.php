<?php
	define('ID_MSG_QUEUE',   0xf0f0);
	define('ID_SHMEM_LOGIN', 0xf0f4);
	
	if(($mq_id = msg_get_queue(ID_MSG_QUEUE))) {
		$msg = '1';
		
		// Verificar o tipo da mensagem baseado na URL de origem
		// Se estamos vindo de uma pagina que contenha 'agente'     no nome o comando enviado ser� do tipo 1
		// Se estamos vindo de uma pagina que contenha 'supervisor' no nome o comando enviado ser� do tipo 10
		// caso contrario enviamos comandos do tipo 0 (que provavelmente ser� ignorado pelo controle e dada uma msg de erro)
		$tipo = stristr($_SERVER['HTTP_REFERER'], 'agente') ? 1 : 10;
	
		// Se o comando for 'keepAlive', verificar se o agente em questoa est� logado na memoria de flags de agentes logados (0xf0f4)
		list($idAg,$ka,$ramal) = explode(':', $_REQUEST['Comando']);
		if($ka === 'keepAlive')
			$msg = (($shmMsgs = @shmop_open(ID_SHMEM_LOGIN, 'a', 0, 0))) ? shmop_read($shmMsgs, $ramal, 1) : '30';
		
		// Tenta enviar o comando
		echo (msg_send($mq_id, $tipo, time() . ':' . $_REQUEST['Comando'], false, false, $msg_err)) ? $msg : '10';
	} else
		echo '20';
	
	// Devolve os seguintes c�digos para o cliente
	//  0 - Agente deslogado (0 vem da mem�ria de flags de agentes logados)
	//  1 - Comandos OK
	// 10 - Erro ao enviar comando (msg_send)
	// 20 - Erro ao enviar comando (msg_get_queue)
	// 30 - Erro ao buscar estado do agente (keepAlive)
?>