<?
	$var = $_GET['var'];
	$content = $var . ' ' . md5(mt_rand(0, 9999));
	file_put_contents('/tmp/TESTE', $content);
?>