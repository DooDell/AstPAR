/*
 * Copyright (C) 2008-2009 Teluu Inc. (http://www.teluu.com)
 * Copyright (C) 2003-2008 Benny Prijono <benny@prijono.org>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <pjsua-lib/pjsua.h>
#include "http.h"

#define THIS_FILE       "TELIP"

#define SIP_DOMAIN      "vm"
#define SIP_USER        "1201"
#define SIP_PASSWD      "d7bba346"
#define SIP_REALM       "asterisk"

/* Ringtones		    US	       UK  */
#define RINGBACK_FREQ1	    440	    /* 400 */
#define RINGBACK_FREQ2	    480	    /* 450 */
#define RINGBACK_ON	    	2000    /* 400 */
#define RINGBACK_OFF	    4000    /* 200 */
#define RINGBACK_CNT	    1	    /* 2   */
#define RINGBACK_INTERVAL   4000    /* 2000 */

#define RING_FREQ1	    800
#define RING_FREQ2	    640
#define RING_ON		    200
#define RING_OFF	    100
#define RING_CNT	    3
#define RING_INTERVAL	3000

pj_pool_t *pool;
static pjsua_call_id current_call = PJSUA_INVALID_ID;

pj_bool_t     ring_on;
int           ring_slot;
pjmedia_port *ring_port;

pj_bool_t     ringback_on;
int           ringback_slot;
pjmedia_port *ringback_port;

pjsua_acc_id  acc_id;
pj_bool_t     sip_cfg;

static void ring_stop()
{
    if (ring_on) {
		ring_on = PJ_FALSE;
		pjsua_conf_disconnect(ring_slot, 0);
		pjmedia_tonegen_rewind(ring_port);
    }
}

static void ring_start()
{
    if (ring_on)
    	return;

    ring_on = PJ_TRUE;
	pjsua_conf_connect(ring_slot, 0);
}

/* Callback called by the library upon receiving incoming call */
static void on_incoming_call(pjsua_acc_id acc_id, pjsua_call_id call_id,
                             pjsip_rx_data *rdata)
{
    pjsua_call_info call_info;

    PJ_UNUSED_ARG(acc_id);
    PJ_UNUSED_ARG(rdata);

    pjsua_call_get_info(call_id, &call_info);

    /* Start ringback */
    ring_start();

    if (current_call == PJSUA_INVALID_ID)
    	current_call = call_id;

    PJ_LOG(3,(THIS_FILE, "Incoming call from %.*s!!",
                         (int)call_info.remote_info.slen,
                         call_info.remote_info.ptr));
}

/* Callback called by the library when call's state has changed */
static void on_call_state(pjsua_call_id call_id, pjsip_event *e)
{
	pjsua_call_info call_info;

	PJ_UNUSED_ARG(e);

	pjsua_call_get_info(call_id, &call_info);
	PJ_LOG(3,(THIS_FILE, "Call %d state=%.*s", call_id,
						 (int)call_info.state_text.slen,
						 call_info.state_text.ptr));

	if (call_info.state == PJSIP_INV_STATE_DISCONNECTED) {
		/* Stop all ringback for this call */
		ring_stop();

		current_call = PJSUA_INVALID_ID;
	} else {
		if (current_call==PJSUA_INVALID_ID)
			current_call = call_id;
	}
}

/* Callback called by the library when call's media state has changed */
static void on_call_media_state(pjsua_call_id call_id)
{
    pjsua_call_info ci;

    pjsua_call_get_info(call_id, &ci);

    /* Stop ringback */
    ring_stop();

    if (ci.media_status == PJSUA_CALL_MEDIA_ACTIVE) {
        // When media is active, connect call to sound device.
        pjsua_conf_connect(ci.conf_slot, 0);
        pjsua_conf_connect(0, ci.conf_slot);
    }
}

/* Display error and exit application */
static void error_exit(const char *title, pj_status_t status)
{
    pjsua_perror(THIS_FILE, title, status);
    pjsua_destroy();
    exit(1);
}

/*
 * main()
 *
 * argv[1] may contain URL to call.
 */
int main(int argc, char *argv[])
{
	char act, num[64], strDial[128];
	int listenfd;
	pjsua_acc_id acc_id;
    pj_status_t status;

    /* Create pjsua first! */
    status = pjsua_create();
    if (status != PJ_SUCCESS) error_exit("Error in pjsua_create()", status);

    /* Init pjsua */
    {
        pjsua_config cfg;
        pjsua_logging_config log_cfg;

        pjsua_config_default(&cfg);
        cfg.cb.on_incoming_call = &on_incoming_call;
        cfg.cb.on_call_media_state = &on_call_media_state;
        cfg.cb.on_call_state = &on_call_state;

        pjsua_logging_config_default(&log_cfg);
        log_cfg.console_level = 4;

        status = pjsua_init(&cfg, &log_cfg, NULL);
        if (status != PJ_SUCCESS) error_exit("Error in pjsua_init()", status);
    }

    /* Add UDP transport. */
    {
        pjsua_transport_config cfg;

        pjsua_transport_config_default(&cfg);
        cfg.port = 5060;
        status = pjsua_transport_create(PJSIP_TRANSPORT_UDP, &cfg, NULL);
        if (status != PJ_SUCCESS) error_exit("Error creating transport", status);
    }

    /* Initialization is done, now start pjsua */
    status = pjsua_start();
    if (status != PJ_SUCCESS) error_exit("Error starting pjsua", status);

    /* Register to SIP server by creating SIP account. */
    {
		pjsua_acc_config cfg;
		pj_status_t status;

		pjsua_acc_config_default(&cfg);
		cfg.id = pj_str("sip:" SIP_USER "@" SIP_DOMAIN);
		cfg.reg_uri = pj_str("sip:" SIP_DOMAIN);
		cfg.cred_count = 1;
		cfg.cred_info[0].realm = pj_str(SIP_REALM);
		cfg.cred_info[0].scheme = pj_str("digest");
		cfg.cred_info[0].username = pj_str(SIP_USER);
		cfg.cred_info[0].data_type = PJSIP_CRED_DATA_PLAIN_PASSWD;
		cfg.cred_info[0].data = pj_str(SIP_PASSWD);

		status = pjsua_acc_add(&cfg, PJ_TRUE, &acc_id);
		if (status != PJ_SUCCESS) error_exit("Error adding account", status);
    }

    /* Create ring and ringback tones */
    pool = pjsua_pool_create("pjsua-app", 1000, 1000);

    pjsua_media_config media_cfg;
	unsigned i, samples_per_frame;
	pjmedia_tone_desc tone[RING_CNT+RINGBACK_CNT];
	pj_str_t name;

	pjsua_media_config_default(&media_cfg);

	samples_per_frame = media_cfg.audio_frame_ptime * media_cfg.clock_rate * media_cfg.channel_count / 1000;

	/* Ringback tone (call is ringing) */
	name = pj_str("ringback");
	status = pjmedia_tonegen_create2(pool, &name,
					 media_cfg.clock_rate,
					 media_cfg.channel_count,
					 samples_per_frame,
					 16, PJMEDIA_TONEGEN_LOOP,
					 &ringback_port);
	if (status != PJ_SUCCESS)
		error_exit("Error1", status);

	pj_bzero(&tone, sizeof(tone));
	for (i=0; i<RINGBACK_CNT; ++i) {
	    tone[i].freq1 = RINGBACK_FREQ1;
	    tone[i].freq2 = RINGBACK_FREQ2;
	    tone[i].on_msec = RINGBACK_ON;
	    tone[i].off_msec = RINGBACK_OFF;
	}
	tone[RINGBACK_CNT-1].off_msec = RINGBACK_INTERVAL;
	pjmedia_tonegen_play(ringback_port, RINGBACK_CNT, tone, PJMEDIA_TONEGEN_LOOP);


	status = pjsua_conf_add_port(pool, ringback_port, &ringback_slot);
	if (status != PJ_SUCCESS)
		error_exit("Error2", status);

	/* Ring (to alert incoming call) */
	name = pj_str("ring");
	status = pjmedia_tonegen_create2(pool, &name,
					 media_cfg.clock_rate,
					 media_cfg.channel_count,
					 samples_per_frame,
					 16, PJMEDIA_TONEGEN_LOOP,
					 &ring_port);
	if (status != PJ_SUCCESS)
		error_exit("Error3", status);

	for (i=0; i<RING_CNT; ++i) {
	    tone[i].freq1 = RING_FREQ1;
	    tone[i].freq2 = RING_FREQ2;
	    tone[i].on_msec = RING_ON;
	    tone[i].off_msec = RING_OFF;
	}
	tone[RING_CNT-1].off_msec = RING_INTERVAL;

	pjmedia_tonegen_play(ring_port, RING_CNT, tone, PJMEDIA_TONEGEN_LOOP);

	status = pjsua_conf_add_port(pool, ring_port, &ring_slot);
	if (status != PJ_SUCCESS)
		error_exit("Error4", status);

	sip_cfg = PJ_FALSE;

    /* Init the HTTP controller */
    listenfd = initHttp();

    /* Wait until receive action "q" to quit. */
    for (;;) {
        puts("Waiting action");
        act = getAction(listenfd, num);

        if (act == 'q')
            break;

        if (act == 'h') {
        	puts(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Hangup");
            pjsua_call_hangup_all();
        }

        if (act == 'a') {
        	if (current_call != PJSUA_INVALID_ID) {
        		puts(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Answer");
        		pjsua_call_answer(current_call, 200, NULL, NULL);
        	} else
        		puts(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> Could not Answer");
        }

        if (act == 'd') {
        	sprintf(strDial, "sip:%s@%s", num, SIP_DOMAIN);
        	pj_str_t uri = pj_str(strDial);
        	status = pjsua_call_make_call(acc_id, &uri, 0, NULL, NULL, NULL);
        	if (status != PJ_SUCCESS) error_exit("Error making call", status);
        }

        if (act == 'r') {
        	pjsua_acc_set_registration(acc_id, 1);
        }

        if (act == 'u') {
        	pjsua_acc_set_registration(acc_id, 0);
		}
    }

    shutHttp(listenfd);

    /* Destroy pjsua */
    pjsua_destroy();

    return 0;
}
