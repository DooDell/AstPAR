
int initHttp();
int shutHttp(int);
char getAction(int, char *);
void loga(int, char *, char *);
