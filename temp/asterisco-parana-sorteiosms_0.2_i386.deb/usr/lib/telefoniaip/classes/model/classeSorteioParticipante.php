<?php
class SorteioParticipante extends bdFacil {
	var $idsorteio, $nome, $numero;
}
?>