<?php
class ControleSorteioSMS extends Controle {
	static function enviaSMS($canal, $numero, $msg) {
		return true;
	}
	
	function executaAcao($nomeAcao, $params) {
		global $sessao;
		$err = false;

		switch($nomeAcao) {
			case 'novo':
				$sorteio = new Sorteio('doRequest');
				$sorteio->situacao = 0;
				$sorteio->multiplo = (Util::pegaAtributoDoRequest('multiplo') == 'on') ? 1 : 0;
				if(($err = $sorteio->salvar()) === true)
					$err = 'Sorteio adicionado com sucesso';
				break;
			
			case 'roda':
				$id = $params['id'];
				if($id != '0') {
					$sorteio = new Sorteio($id);
					$emAndamento = false;
					foreach(bdFacil::todos('Sorteio') as $sortAux) {
						if($sortAux->id != $id && $sortAux->numero == $sorteio->numero) {
							// Achamos um sorteio com o mesmo n�mero, verificar se esta em andamento
							$emAndamento = (($sortAux->situacao > 0  && $sortAux->situacao < 4) ||
											($sortAux->situacao == 3 && !empty($sortAux->premio2)) ||
											($sortAux->situacao == 4 && !empty($sortAux->premio3)));
							if($emAndamento) break;
						}
					}
					if(!$emAndamento) {
						$sessao->setVar('idSorteioRoda', $id);
						if(Conexao::getStr("SELECT situacao FROM sorteio WHERE id = '$id'") == '0') {
							if(($err = Conexao::sql("UPDATE sorteio SET situacao = '1' WHERE id = '$id'")) == true) {
								$err = $sorteio->escreveConf();
								if($err === true)
									$err = 'Sorteio ativado!';
							}
						} else
							$err = '';
					} else
						$err = 'J� existe um sorteio em andamento com este mesmo n�mero!';
				} else {
					$sessao->setVar('idSorteioRoda', 0);
					$err = '';
				}
				break;
			
			case 'encerra':
				$id = $sessao->getVar('idSorteioRoda');
				if($id > 0) {
					if(($err = Conexao::sql("UPDATE sorteio SET situacao = '2' WHERE id = '$id'")) == true) {
						$err = Sorteio::limpaConf();
						if($err === true)
							$err = 'Sorteio encerrado!';
					}
				} else
					$err = 'Sorteio inv�lido';
				break;
			
			case 'sorteia':
				$idSorteio = $sessao->getVar('idSorteioRoda');
				if($idSorteio > 0) {
					$idV  = trim($params['idV']);
					$numV = $params['numV'];
					$sit  = $numV + 2;
					if(($err = Conexao::sql("UPDATE sorteio SET situacao = '$sit', idvencedor$numV = '$idV' WHERE id = '$idSorteio'")) == true)
						$err = 'Sorteio conclu�do!';
				} else
					$err = 'Sorteio inv�lido';
				break;
			
			case 'enviaSMS':
				$idSorteio = $params['idS'];
				$numVenc   = $params['numV'];
				
				$sorteio = new Sorteio($idSorteio);
				$aux = "premio$numVenc";
				$descPremio = $sorteio->$aux;
				$aux = "idvencedor$numVenc";
				$idV = $sorteio->$aux;
				$vencedor = new SorteioParticipante($idV);
				
				$msg = "Parabens $vencedor->nome! " .
						"Voce eh o vencedor do ".$numVenc."o premio do sorteio $sorteio->nome: $descPremio. " .
						"Em breve voce sera contactado.";
				$err = ControleSorteioSMS::enviaSMS('B0C0', $vencedor->numero, $msg);
				if($err === true)
					$err = "SMS enviado para $vencedor->nome";
				break;
			
			case 'chamaV':
				$idSorteio = $params['idS'];
				$numVenc = $params['numV'];
				$ramal   = $params['ramal'];
				
				$sorteio = new Sorteio($idSorteio);
				$aux = "idvencedor$numVenc";
				$vencedor = new SorteioParticipante($sorteio->$aux);
				$err = Asterisk::c2c("Local/$ramal@ramais-internos", $vencedor->numero);
				if($err === true)
					$err = "Chamando $vencedor->nome";
				break;
		}
		
		return $err;
	}
}
?>