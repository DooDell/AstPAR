#!/usr/bin/php -q
<?php
	include(''.'/usr/lib/telefoniaip/includePrincipal.php');
	list($d,$de,$para) = $argv;
	
	// Buscar lista de sorteios
	$sorts = array();
	
	$conn = new Conexao();
	$conn->executa("SELECT id,nome FROM sorteio");
	while($conn->temMaisDados()) 
		$sorts[$conn->data['id']] = $conn->data['nome'];
	
	if(count($sorts) < 2) {
		echo "Existem menos de 2 sorteios cadastrados! Impossivel importar dados!!\n\n";
		exit(10);
	}
	
	if(empty($de) || empty($para)) {
		echo "Listando campanhas:\n";
		foreach($sorts as $id => $nome)
			echo "  $id -> $nome \n";
		echo "\nUSO: importaNumerosSorteio ID_SORTEIO_ORIGEM ID_SORTEIO_DESTINO\n\n";
	} else {
		if($de == $para) {
			echo "ID_SORTEIO_ORIGEM nao pode ser igual a ID_SORTEIO_DESTINO!\n\n";
			exit(1);
		}
		if(!in_array($de, array_keys($sorts))) {
			echo "ID_SORTEIO_ORIGEM invalido. Digite apenas 'importaNumerosSorteio' para obter uma lista\n\n";
			exit(2);
		}
		if(!in_array($para, array_keys($sorts))) {
			echo "ID_SORTEIO_DESTINO invalido. Digite apenas 'importaNumerosSorteio' para obter uma lista\n\n";
			exit(3);
		}

		$nomeDE   = $sorts[$de];
		$nomePARA = $sorts[$para];
		echo "\nImportando participantes do sorteio [$nomeDE] para o sorteio [$nomePARA]\n\n";
		
		$imports = 0;
		$connUpd = new Conexao();
		$conn->executa("SELECT * FROM sorteioparticipante WHERE idsorteio = '$de'");
		while($conn->temMaisDados()) {
			$nome   = $conn->data['nome'];
			$numero = $conn->data['numero'];
			$sql = "INSERT INTO sorteioparticipante(idsorteio, nome, numero) VALUES('$para', '$nome', '$numero')";
			if($connUpd->executa($sql) === true) $imports++;
		}
		$connUpd->fecha(true);
		echo "Importacao concluida. $imports participantes transferidos.\n\n";
	}
	$conn->fecha(true);
?>