#!/usr/bin/php -q
<?php
	/**
	 * Colocar no dialplan:
	 * [khomp-sms-DD-CC]
	 * exten => s,1,System(/usr/lib/telefoniaip/arquivos/scripts/trataSMSSorteio.php,NUMERODOCHIP,${KSmsFrom},${KSmsBody}) 
	 */
	 
	include(''.'/usr/lib/telefoniaip/includePrincipal.php');
	
	// Pega os parametros passados
	list($d,$numChip,$numOrig,$corpo) = $argv;
	
	// Nao aceita o SMS se nao houver origem/destino
	if(empty($numChip) || empty($numOrig)) exit(1);
	// Se o corpo do SMS estiver vazio assume 'VAZIO!'
	if(empty($corpo)) $corpo = 'VAZIO!';
	// Se nao pega somente a primeira palavra
	else list($corpo) = explode(' ', $corpo);
	
	list($ids,$mult) = explode('-', Conexao::getStr("SELECT id||'-'||multiplo FROM sorteio WHERE situacao = '1' AND numero = '$numChip'"));
	// Nao aceita o SMS se este numero de Chip nao estiver cadastrado
	if(empty($ids)) exit(10);
	
	if(!$mult && Conexao::getStr("SELECT COUNT(id) FROM sorteioparticipante WHERE idsorteio = '$ids' AND numero = '$numOrig'") > 0)
		exit(20);
	
	Conexao::sql("INSERT INTO sorteioparticipante(idsorteio,nome,numero) VALUES('$ids','$corpo','$numOrig')");
?>