
CREATE TABLE sorteio (
    id serial NOT NULL,
    nome character varying(64),
    numero character(10),
    multiplo integer,
    situacao integer,
    premio1 character varying(128),
    premio2 character varying(128),
    premio3 character varying(128),
    idvencedor1 integer,
    idvencedor2 integer,
    idvencedor3 integer
);
ALTER TABLE public.sorteio OWNER TO sa_asterisk;

CREATE TABLE sorteioparticipante (
    id serial NOT NULL,
    idsorteio integer,
    nome character varying(64),
    numero character(16)
);
ALTER TABLE public.sorteioparticipante OWNER TO sa_asterisk;

