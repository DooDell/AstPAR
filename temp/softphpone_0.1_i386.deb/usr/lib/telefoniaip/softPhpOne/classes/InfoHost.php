<?php
class InfoHost {
	public $host, $port;
	public $user, $pass;
	
	public function InfoHost($host='localhost', $user='user', $pass='pass', $port=5060) {
		$this->host = $host;
		$this->user = $user;
		$this->pass = $pass;
		$this->port = $port;
	}
}
?>
