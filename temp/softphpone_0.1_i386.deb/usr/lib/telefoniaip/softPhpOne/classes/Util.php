<?php
class Util
{
	static function tiraAspas($str) {
		return str_replace('"', '', $str);
	}
}
?>