<?php
class SipRtp
{
	private $socket = null, $ip, $porta;
	
	public function SipRtp($ip, $porta) {
		$this->ip    = $ip;
		$this->porta = $porta;
	}
 
    public function escuta() {
		if(($this->SOCKET = socket_create(AF_INET, SOCK_DGRAM, SOL_UDP)) < 0) {
			$this->debugMsg("Impossivel criar socket");
			return false;
		}
		
		if(!@socket_bind($this->SOCKET, "0.0.0.0", $this->porta)) {
			$err = socket_last_error();
			$this->debugMsg("Impossivel abrir porta $this->porta : " . socket_strerror($err));
			return false;
		}
			
        if ($this->SOCKET == false) {
			$this->debugMsg("Impossivel conectar ao Servidor SIP [$conf->host] [$err] : " . socket_strerror($err));
			return false;
		}
		
		$snd = fopen('/dev/dsp', 'wb');
		//$snd = fopen('out.wav', 'wb');
		$buff = "";
		for($c=0; $c<300; $c++) {
			socket_recvfrom($this->SOCKET, $buff, 512, 0, $this->ip, $this->porta);
			fwrite($snd, substr($buff, 8)); // Cortar o Header UDP
			//usleep(1000);
		}
		fclose($snd);
		
       	socket_close($this->SOCKET);
    }
}
?>