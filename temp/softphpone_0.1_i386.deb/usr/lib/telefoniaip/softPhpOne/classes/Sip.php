<?php
class Sip
{
	private $socket = null, $DEBUG = true, $conectado = false;
	private $conf = null, $dadosLocais;
	
	public function Sip($conf, $dadosLocais) {
		$this->conf        = $conf;
		$this->dadosLocais = $dadosLocais;
	}

	public function debugMsg($msg)
	{
		if($this->DEBUG)
			echo "SIP> " .date("H:i:s"). " -- debug: $msg \n";
    }
 
    public function conecta() {
    	$conf = $this->conf;
    	if(!is_a($conf, "InfoHost")) {
    		$this->debugMsg("Parametro inv�lido para SIP->login");
    		return false;
    	}
 
		if(($this->SOCKET = socket_create(AF_INET, SOCK_DGRAM, SOL_UDP)) < 0) {
			$this->debugMsg("Impossivel criar socket");
			return false;
		}

		if(!@socket_connect($this->SOCKET, $conf->host, $conf->port)) {
			$err = socket_last_error();
			$this->debugMsg("Impossivel conectar ao Servidor SIP [$conf->host] [$err] : " . socket_strerror($err));
			return false;
		}
			
        if ($this->SOCKET == false) {
			$this->debugMsg("Impossivel conectar ao Servidor SIP [$conf->host] [$err] : " . socket_strerror($err));
			return false;
		}
		$this->conectado = true;
	}
 
    public function desconecta()
    {
    	if($this->conectado) {
        	socket_close($this->SOCKET);
        	$this->conectado = false;
    	}
    }
    
    public function envia($pacote)
    {
    	if(!is_a($pacote, 'PacoteSip')) return false;
        socket_write($this->SOCKET, $pacote . "");
        return $this->recebe();
    }
    
    function recebe($timeout = 0.3) {
    	$rbuff = "";
    	while($this->temDadosNoSocket($timeout))
			$rbuff .= socket_read($this->SOCKET, 2048);
		if(!empty($rbuff)) return PacoteSip::parse($rbuff);
		else               return "";
	}
	
	function temDadosNoSocket($timeout = 0.1) {
		$read = array($this->SOCKET);
		return socket_select($read, $write = NULL, $except = NULL, floor($timeout), ceil($timeout*1000000));
	}
	
	function ACK($pacote) {
		$inv = $this->criaPacote('ACK', $pacote);
		$this->debugMsg($inv);
		
		$recv = $this->envia($inv);
		$this->debugMsg($recv);
		return $recv;
	}
	
	function efetuaLogin($dadosLogin) {
		$register = $this->criaPacote('REGISTER', $dadosLogin);
		$this->debugMsg($register);
		
		$recv = $this->envia($register);
		$this->debugMsg($recv);
		
		$aux =& $recv;
		while($aux) {
			$cod = $aux->getCod();
			if($cod == 401) {
				$wwwAuth = $aux->getAtr('WWW-Authenticate');
				if(!empty($wwwAuth)) {
					$this->ACK($aux);
					
					list($algoritimo,$dominio,$nonce) = explode(',', $wwwAuth);
					list($d,$algoritimo) = explode('=', $algoritimo);
					list($d,$dominio) = explode('=', $dominio);
					list($d,$nonce) = explode('=', $nonce);
					$algoritimo = Util::tiraAspas($algoritimo);
					$dominio = Util::tiraAspas($dominio);
					$nonce = Util::tiraAspas($nonce);
					// Calcular o digest com nonce:
					$host = $dadosLogin['host'];
					$user = $dadosLogin['user'];
					$pass = $dadosLogin['pass'];
					$uri  = "sip:$user@$host";
    				$HA1 = MD5("$user:$dominio:$pass");
					$HA2 = MD5("REGISTER:$uri");
					$digest = MD5("$HA1:$nonce:$HA2");
					$dadosLogin['digest']  = $digest;
					$dadosLogin['dominio'] = $dominio;
					$dadosLogin['nonce']   = $nonce;
					$dadosLogin['uri']     = $uri;
					return $this->efetuaLogin($dadosLogin);
				}
			} else if($cod == 200) {
				$this->dadosLocais['HostREG'] = $dadosLogin['host'];
				$this->dadosLocais['UserREG'] = $dadosLogin['user'];
				$this->dadosLocais['PassREG'] = $dadosLogin['pass'];
				return $aux;
			}
			$aux = $aux->prox;
		}
		return "Erro!";
	}
	
	function invite($dadosInvite) {
		$inv = $this->criaPacote('INVITE', $dadosInvite);
		$this->debugMsg($inv);
		
		$recv = $this->envia($inv);
		$this->debugMsg($recv);
		
		$aux =& $recv;
		while($aux) {
			$cod = $aux->getCod();
			if($cod == 407) {
				$proxyAuth = $aux->getAtr('Proxy-Authenticate');
				if(!empty($proxyAuth)) {
					$this->ACK($aux);
					
					list($algoritimo,$dominio,$nonce) = explode(',', $proxyAuth);
					list($d,$algoritimo) = explode('=', $algoritimo);
					list($d,$dominio) = explode('=', $dominio);
					list($d,$nonce) = explode('=', $nonce);
					$algoritimo = Util::tiraAspas($algoritimo);
					$dominio = Util::tiraAspas($dominio);
					$nonce = Util::tiraAspas($nonce);
					// Calcular o digest com nonce:
					$host = $this->dadosLocais['HostREG'];
					$user = $this->dadosLocais['UserREG'];
					$pass = $this->dadosLocais['PassREG'];
					$num  = $dadosInvite['num'];
					$uri  = "sip:$num@$host";
    				$HA1 = MD5("$user:$dominio:$pass");
					$HA2 = MD5("INVITE:$uri");
					$digest = MD5("$HA1:$nonce:$HA2");
					$dadosInvite['digest']  = $digest;
					$dadosInvite['dominio'] = $dominio;
					$dadosInvite['nonce']   = $nonce;
					$dadosInvite['uri']     = $uri;
					return $this->invite($dadosInvite);
				}
			} else if($cod == 200) {
				return $aux;
			}
			$aux = $aux->prox;
		}
		return "Erro!";
	}
	
	function criaPacote($metodo, $dados) {
		$conf = $this->conf;
		$meuIP         = $this->dadosLocais['IPLocal'];
		$minhaPorta    = $this->dadosLocais['PortaLocal'];
		$minhaPortaRTP = $this->dadosLocais['PortaRTPLocal'];
		$meuHostname   = $this->dadosLocais['HostName'];
		$host          = $conf->host;
		switch($metodo) {
			case 'REGISTER':
				$user = $dados['user'];
				if(!isset($host) || !isset($user))
					return "REGISTER precisa de um [host] e um [user]";
				
				$sipID       = "<sip:$user@$host>";
				$ret = new PacoteSip("REGISTER sip:$host SIP/2.0");
				$ret->setAtr('CSeq', PacoteSip::getCSeq('REGISTER'));
				$ret->setAtr('Via', "SIP/2.0/UDP $meuIP:$minhaPorta;branch=z9hG4bK12f6b92c-3976-dd11-8462-001b24e72cfd;rport");
				$ret->setAtr('User-Agent', 'softPhpone/0.0.2');
				if(!empty($dados['digest'])) {
					$digest  = $dados['digest'];
					$dominio = $dados['dominio'];
					$nonce   = $dados['nonce'];
					$uri     = $dados['uri'];
					$ret->setAtr('Authorization', "Digest username=\"$user\", realm=\"$dominio\", nonce=\"$nonce\", uri=\"$uri\", algorithm=md5, response=\"$digest\"");
				}
				$ret->setAtr('From', "$sipID;tag=4ce9b92c-3976-dd11-8462-001b24e72cfd");
				$ret->setAtr('Call-ID', "225fb42c-3976-dd11-8462-001b24e72cfd@$meuHostname");
				$ret->setAtr('To', $sipID);
				$ret->setAtr('Contact', "<sip:$user@$host:$minhaPorta;transport=udp>");
				$ret->setAtr('Allow', 'INVITE,ACK,OPTIONS,BYE,CANCEL,NOTIFY,REFER,MESSAGE');
				$ret->setAtr('Expires', 3600);
				$ret->setAtr('Content-Length', 0);
				$ret->setAtr('Max-Forwards', 70);
				break;
			
			case 'INVITE':
				$num  = $dados['num'];
				if(!isset($num))
					return "INVITE precisa de um [num]";
					
				$host = $this->dadosLocais['HostREG'];
				$user = $this->dadosLocais['UserREG'];
				$callerid = (!empty($dados['callerid'])) ? '"'.$dados['callerid'].'"' : "";
				
				$ret = new PacoteSip("INVITE sip:$num@$host SIP/2.0");
				$ret->setSdp('v', '0');
				$ret->setSdp('o', "- 1220461292 1220461292 IN IP4 $meuIP");
				$ret->setSdp('s', 'Opal SIP Session');
				$ret->setSdp('c', "IN IP4 $meuIP");
				$ret->setSdp('t', '0 0');
				$ret->setSdp('m', "audio $minhaPortaRTP RTP/AVP 8 0");
				$ret->setSdp('a1', 'rtpmap:8 PCMA/8000');
				$ret->setSdp('a2', 'rtpmap:0 PCMU/8000');
				
				$ret->setAtr('CSeq', PacoteSip::getCSeq('INVITE'));
				$ret->setAtr('Via', "SIP/2.0/UDP $meuIP:$minhaPorta;branch=z9hG4bK12f6b92c-3976-dd11-8462-001b24e72cfd;rport");
				$ret->setAtr('User-Agent', 'softPhpone/0.0.2');
				$ret->setAtr('From', "$callerid<sip:$user@$host>;tag=4ce9b92c-3976-dd11-8462-001b24e72cfd");
				$ret->setAtr('Call-ID', "42c388a0-4778-dd11-8b0f-000fead33327@$meuHostname");
				$ret->setAtr('To', "<sip:$num@$host>");
				$ret->setAtr('Contact', "<sip:$user@$host:$minhaPorta;transport=udp>");
				if(!empty($dados['digest'])) {
					$digest  = $dados['digest'];
					$dominio = $dados['dominio'];
					$nonce   = $dados['nonce'];
					$uri     = $dados['uri'];
					$ret->setAtr('Proxy-Authorization', "Digest username=\"$user\", realm=\"$dominio\", nonce=\"$nonce\", uri=\"$uri\", algorithm=md5, response=\"$digest\"");
				}
				$ret->setAtr('Allow', 'INVITE,ACK,OPTIONS,BYE,CANCEL,NOTIFY,REFER,MESSAGE');
				$ret->setAtr('Content-Type', 'application/sdp');
				$ret->setAtr('Content-Length', NULL);
				$ret->setAtr('Max-Forwards', 70);
				break;
			
			case 'ACK':
				if(!is_a($dados, 'PacoteSip'))
					return "ACK precisa de um PacoteSip a ser 'ACKado'";

				list($num,$d) = explode('@', $dados->getAtr('To'));
				list($d,$num) = explode(':', $num);
				$host = $this->dadosLocais['HostREG'];
				
				$ret = new PacoteSip("ACK sip:$num@$host SIP/2.0");
				$ret->setAtr('CSeq', PacoteSip::getCSeq('ACK'));
				$ret->setAtr('Via', "SIP/2.0/UDP $meuIP:$minhaPorta;branch=z9hG4bK12f6b92c-3976-dd11-8462-001b24e72cfd;rport");
				$ret->setAtr('From', "<sip:$user@$host>;tag=4ce9b92c-3976-dd11-8462-001b24e72cfd");
				$ret->setAtr('Call-ID', "225fb42c-3976-dd11-8462-001b24e72cfd@$meuHostname");
				$ret->setAtr('To', "<sip:$num@$host>");
				$ret->setAtr('Allow', 'INVITE,ACK,OPTIONS,BYE,CANCEL,NOTIFY,REFER,MESSAGE');
				$ret->setAtr('Content-Length', 0);
				$ret->setAtr('Max-Forwards', 70);
				break;
		}
		return $ret;
	}
}
?>