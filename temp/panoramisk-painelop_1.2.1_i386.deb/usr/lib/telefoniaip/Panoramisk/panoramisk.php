#!/usr/bin/php -c/etc/php5/php-gtk.ini
<?php
if( !class_exists('gtk')) {
	die("Erro. PHP-GTK2 não instalado.\r\n");
}

include("classes/model/classeUsuario.php");
include("classes/control/classeAMI.php");
include("classes/control/classePacoteAMI.php");
include("classes/control/classeUtil.php");
include("classes/view/janelaPreferencias.php");
include("classes/view/janelaConferencias.php");
include("classes/view/janelaPainelOp.php");
include("classes/view/janelaLogin.php");
include("classes/view/classeLista.php");
$conf = null;

$painelOp = new PainelOp();
Gtk::main();
?>
