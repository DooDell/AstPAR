<?php
define('PROGRAMA', 'Panoramisk');

class AMI
{
	private $SOCKET = null, $DEBUG, $actID = 1000;
	public $conectado = false, $pacoteLogin = null;

	public function AMI($conf) {
		$this->DEBUG = true;
		$this->eventos = (isset($conf['eventosAMI']) && $conf['eventosAMI'] == 'off') ? false : true;
		
		$tents = 0;
		$pacote = null;
		$maxTents = (isset($conf['tentativasConnAMI']) && $conf['tentativasConnAMI'] > 0) ? $conf['tentativasConnAMI'] : 4;
		$testeConexao = false;
		while($tents++ < 4) {
			$this->pacoteLogin = $this->login($conf);
			if($this->pacoteLogin !== false){
				$testeConexao = true;
				break;			
			}
			sleep(1);
		}
		if(!$testeConexao)Util::alerta('Falha na comunicação com o AMI. Verifique os dados para autenticação!');
	}
	
	public function debugMsg($msg) {
		Util::alerta($msg);
	}
	
	private function login($conf) {
		if(!isset($conf['userAMI']) || !isset($conf['passAMI']) ||!isset($conf['hostAMI'])) {			
			$this->debugMsg('Faltam parametros para o login no AMI');
			return false;
		}
		
		if(($this->SOCKET = socket_create(AF_INET, SOCK_STREAM, SOL_TCP)) < 0) {
			$this->debugMsg('Impossivel criar socket');
			return false;
		}

		$portaAMI = (isset($conf['portAMI']) && is_numeric($conf['portAMI'])) ? $conf['portAMI'] : 5038;
		if(!@socket_connect($this->SOCKET, $conf['hostAMI'], $portaAMI)) {
			$this->debugMsg('Impossivel conectar ao Asterisk AMI');
			return false;
		}
			
        if ($this->SOCKET == false) {
			$this->debugMsg("Impossivel conectar ao asterisk manager");
			return false;
		}
		
		// Espera chegarem dados no socket
        while(!$this->temDadosNoSocket()) {}
        
        // Le todos os dados iniciais enviados pelo Asterisk para o buffer
        $buffer = $this->recebeBuffer();
        
        if ($buffer === false || !stristr($buffer, 'Asterisk Call Manager')) {
			$this->debugMsg('String de identificacao do AMI nao encontrada');
			$this->logoff();
            return false;
        }
        
		$pacote = $this->enviaComando('Login', array(
				'Username' => $conf['userAMI'],
				'Secret'   => $conf['passAMI'],
				'Events'   => ($this->eventos  ? 'On' : 'Off')
			));
			
        if (!AMI::comandoOK($pacote)) {			
			$this->logoff();
            return false;
        }
		        
		$this->conectado = true;
		//$this->debugMsg('Conexao com o AMI bem sucedida.');
		
		return $pacote;
	}
	
	public function logoff() {
		$ret = true;
		if(is_resource($this->SOCKET)) {
			if($this->conectado)
				$ret = $this->enviaComando('Logoff');
			@socket_shutdown($this->SOCKET, 2);
			@socket_close($this->SOCKET);
		}
		return $ret;
	}
	
	static function comandoOK($pacote, $actID="") {
		$aux =& $pacote;
		while($aux) {
			if((empty($actID) || $pacote->getAtr('ActionID') == $actID) && 
					$pacote->getAtr('Response') == 'Success') {
				return true;
			}
			$aux = $aux->prox;
		}
		return false;
	}
	
	public function enviaComando($acao, $params = array(), $debug=false) {
		$cmd = "Action: $acao\r\n";
		foreach($params as $chave => $valor)
			$cmd .= "$chave: $valor\r\n";
		$cmd .= 'ActionID: ' .$this->actID++. "\r\n\r\n";
		if($debug) echo "\n\n$cmd\n\n";
		socket_write($this->SOCKET, $cmd);
		if($acao != 'Logoff') $pacote = $this->recebeEventos((($acao == 'Login') ? 0.8 : 0.2));
		else                  $pacote = new PacoteAMI();
		return $pacote;
    }

	/**
	 * Retorna true ou a mensagem de erro (Message), baseado no atributo Response
	 */
	static function verificaStatus($pacote) {
		return ($pacote->getAtr('Response') == 'Success' ? true : $pacote->getAtr('Message'));
	}
	
    function recebeEventos($timeout = 0.1) {
    	$rbuff = $this->recebeBuffer($timeout);
    	return PacoteAMI::parse($rbuff);
	}
	
	function recebeBuffer($timeout = 0.1) {
    	$rbuff = '';
    	while($this->temDadosNoSocket($timeout)) {
    		$sockData = socket_read($this->SOCKET, 2048);
    		if(strlen($rbuff)==0 && strlen($sockData)==0) return false;
			$rbuff .= $sockData;
    	}
		return $rbuff;
	}
	
	function temDadosNoSocket($timeout = 0.1) {
		$read = array($this->SOCKET);
		socket_select($read, $write = null, $except = null, floor($timeout), ceil($timeout*1000000));
		return (count($read) > 0);
	}
}
?>