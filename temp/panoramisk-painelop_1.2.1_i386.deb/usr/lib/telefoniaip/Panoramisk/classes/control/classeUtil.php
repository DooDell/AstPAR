<?php

class Conf {
	private $arq;
	public $astHost, $astPort, $astUser, $astPass;
	public $bdHost,  $bdPort,  $bdUser,  $bdPass, $bdDB;
	
	public function __construct($arq = "panoramisk.conf") {
	
		$this->arq = exec("echo /etc/$arq");
		
		if(!$this->ler()) {
			$this->astHost = "";
			$this->astPort = "";
			$this->astUser = "";
			$this->astPass = "";
			$this->bdHost = "";
			$this->bdPort = "";
			$this->bdUser = "";
			$this->bdPass = "";
			$this->bdDB   = "";
			$this->salvar();
		}
		
	}
	
	
	function salvar() {
		$txt = 
			'// Arquivo de configuracao do Painel Telefonico [panoramisk.conf]
			$astHost = "' .$this->astHost. '";
			$astPort = ' .$this->astPort. ';
			$astUser = "' .$this->astUser. '";
			$astPass = "' .$this->astPass. '";
			$bdHost = "' .$this->bdHost. '";
			$bdPort = ' .$this->bdPort. ';
			$bdUser = "' .$this->bdUser. '";
			$bdPass = "' .$this->bdPass. '";
			$bdDB   = "' .$this->bdDB. '";
			';		
		
		file_put_contents($this->arq, $txt);
				
	}
	
	function ler() {
		if(!file_exists($this->arq)) return false;
		$txt = file_get_contents($this->arq);
	
		if(strstr($txt, "// Arquivo de configuracao do Painel Telefonico [panoramisk.conf]")) {
			$astHost = $astPort = $astUser = $astPass = null;
			$bdHost = $bdPort = $bdUser = $bdPass = $bdDB = null;
			eval($txt);
			$this->astHost = $astHost;
			$this->astPort = $astPort;
			$this->astUser = $astUser;
			$this->astPass = $astPass;
			$this->bdHost  = $bdHost;
			$this->bdPort  = $bdPort;
			$this->bdUser  = $bdUser;
			$this->bdPass  = $bdPass;
			$this->bdDB    = $bdDB;						
			return true;
		}
	}
}

class Util
{
	static function getDadosHttp($params) {
		global $conf;
		$hostHttp = "$conf->astHost/telefoniaip";
		$baseUrl  = "http://$hostHttp/servicos/voip.php?magic=1333\\&acao=";
		exec("wget -q -O /tmp/http.out $baseUrl$params");
		$ret = file('/tmp/http.out', FILE_IGNORE_NEW_LINES);
		unlink("/tmp/http.out");
		return $ret;
	}
	
	static function getUsuarios($sohTelefonistas=false) {
		$tipo = $sohTelefonistas ? 'listaTelefonistas' : 'listaUsuarios';
		$ret = array();
		foreach(Util::getDadosHttp($tipo) as $lin) {
			list($ramal, $nome, $nomeguerra) = explode('|', $lin);
			$aux = new Usuario();
			$aux->ramal      = $ramal;
			$aux->nome       = $nome;
			$aux->nomeguerra = $nomeguerra;
			$ret[$aux->nome] = $aux;
		}
		return $ret;
	}
	
	static function getAutorizacao($ramal, $hashSenha) {
		$authOK = Util::getDadosHttp("authUsuario\\&ramal=$ramal\\&senha=$hashSenha");				
		return ($authOK[0] == 'Resposta:1');
	}
	
	static function getPilotoTelefonista() {
		$aux = Util::getDadosHttp('getPilotoTel');
		list($d, $piloto) = explode(':', $aux[0]);				
		return $piloto;
	}
	
	static function getRamalSVCNoturno() {
		$aux = Util::getDadosHttp('getRamalSVCNot');
		list($d, $ramal) = explode(':', $aux[0]);				
		return $ramal;
	}
	
	static function pegaSipDoPacote($pacote, $tipo='Channel') {
		list($sip, $d) = explode("-", $pacote->getAtr($tipo));
		return $sip;
	}
	
	static function pegaChannelDoPacote($pacote, $tipo='Channel') {		
		return $pacote->getAtr($tipo);
	}
	
	static function tiraEspacosDuplicados($str) {
		$ret = "";
		foreach(explode(" ", $str) as $pal) {
			if(!empty($pal)) {
				if(!empty($ret)) $ret .= " ";
				$ret .= $pal;
			}
		}
		return $ret;
	}
	static function mudaCorDeFundo($widget, $cor) {
	 	$widget->modify_bg(Gtk::STATE_NORMAL,GdkColor::parse($cor));
	 	$widget->modify_bg(Gtk::STATE_ACTIVE,GdkColor::parse($cor));
	 	$widget->modify_bg(Gtk::STATE_PRELIGHT,GdkColor::parse($cor)); 
	 }
		
	static function setup_radio($radio_button_grp, $button_label, $button_value) {
	    $radio = new GtkRadioButton($radio_button_grp, $button_label);
	    $radio->connect('toggled', "on_toggle", $button_value);
	    return $radio;
	}
	
	static function alerta($msg) { // note 1
		$dialog = new GtkDialog("Alerta", null, Gtk::DIALOG_MODAL);
		$dialog->set_position(Gtk::WIN_POS_CENTER_ALWAYS);
		$top_area = $dialog->vbox;
		$top_area->pack_start($hbox = new GtkHBox());
		$stock = GtkImage::new_from_stock(Gtk::STOCK_DIALOG_WARNING, Gtk::ICON_SIZE_DIALOG);
		$hbox->pack_start($stock, 0, 0);
		$hbox->pack_start(new GtkLabel($msg));
		$dialog->add_button(Gtk::STOCK_OK, Gtk::RESPONSE_OK);
		$dialog->set_has_separator(false);
		$dialog->show_all();
		$dialog->run();
		$dialog->destroy();
	}
}
?>
