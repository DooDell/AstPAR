<?php
class Usuario {
	var $id, $ramal, $telAtual, $nome, $tipo, $nomeguerra, $idccusto;
	
	function __toString() {
		return "Usuário [" .$this->nome. "]: Ramal [" .$this->ramal. "] - " .
				"telAtual: [" .$this->telAtual. "] - tipo: [" .$this->tipo. "]";
	}
}
?>
