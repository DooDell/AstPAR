<?php
class JanelaPref extends GtkWindow
{
	public $mostra, $ehInicio;
	private $cxAstHost, $cxAstPort, $cxAstUser, $cxAstPass, $emLigacao;
	private $cxBdHost, $cxBdPort, $cxBdUser, $cxBdPass, $cxBdDb;
	
	function __construct($parent = null) {
		global $conf;
		
		parent::__construct();
		$this->connect_simple('delete-event', array($this, 'fecha'));
		$this->mostra = false;
		$this->ehInicio = false;
		$this->emLigacao = false;
		
		$this->set_title("Preferencias");
		$this->set_position(Gtk::WIN_POS_CENTER);
		$this->set_default_size(500, 300);
		$this->set_border_width(8);
		$this->set_icon(GdkPixbuf::new_from_file("gfx/telefonista.png"));
		
		$linhas = new GtkVBox();
		
		$frame = new GtkFrame("Hosts dos Servidores");
		$tabela = new GtkTable();
		$tabela->attach(new GtkLabel("Asterisk:"), 0, 1, 0, 1);
		$this->cxAstHost = new GtkEntry($conf->astHost);
		$tabela->attach($this->cxAstHost, 1, 2, 0, 1);
		$tabela->attach(new GtkLabel("Banco de Dados:"), 0, 1, 1, 2);
		$this->cxBdHost = new GtkEntry($conf->bdHost);
		$tabela->attach($this->cxBdHost, 1, 2, 1, 2);
		$frame->add($tabela);
		$linhas->pack_start($frame, false, false, 10);
		
		$frame = new GtkFrame("Conta do AMI");
		$tabela = new GtkTable();
		$tabela->attach(new GtkLabel("Usuario:"), 0, 1, 0, 1);
		$this->cxAstUser = new GtkEntry($conf->astUser);
		$tabela->attach($this->cxAstUser, 1, 2, 0, 1);
		$tabela->attach(new GtkLabel("Senha:"), 0, 1, 1, 2);
		$this->cxAstPass = new GtkEntry($conf->astPass);
		$this->cxAstPass->set_visibility(false);
		$tabela->attach($this->cxAstPass, 1, 2, 1, 2);
		$frame->add($tabela);
		$linhas->pack_start($frame, false, false, 10);
		
		$frame = new GtkFrame("Conta do BD");
		$tabela = new GtkTable();
		$tabela->attach(new GtkLabel("Usuario:"), 0, 1, 0, 1);
		$this->cxBdUser = new GtkEntry($conf->bdUser);
		$tabela->attach($this->cxBdUser, 1, 2, 0, 1);
		$tabela->attach(new GtkLabel("Senha:"), 0, 1, 1, 2);
		$this->cxBdPass = new GtkEntry($conf->bdPass);
		$this->cxBdPass->set_visibility(false);
		$tabela->attach($this->cxBdPass, 1, 2, 1, 2);
		$tabela->attach(new GtkLabel("BD:"), 0, 1, 2, 3);
		$this->cxBdDb = new GtkEntry($conf->bdDB);
		$tabela->attach($this->cxBdDb, 1, 2, 2, 3);
		$frame->add($tabela);
		$linhas->pack_start($frame, false, false, 10);
		
		$caixaBotoes = new GtkHButtonBox();
		$caixaBotoes->set_border_width(5);
		$caixaBotoes->set_layout(Gtk::BUTTONBOX_SPREAD);
		$caixaBotoes->set_spacing(20);
		$btnOK = new GtkButton("OK");
		$btnOK->connect("clicked", array($this, "on_OK_clicked"));
		$caixaBotoes->add($btnOK);
		$btnCancel = new GtkButton("Cancelar");
		$btnCancel->connect("clicked", array($this, "on_Cancelar_clicked"));
		$caixaBotoes->add($btnCancel);
		$linhas->pack_start($caixaBotoes, false, false);
		
		$this->add($linhas);
	}
	
	function on_Cancelar_clicked($btn) {
		$this->hide_all();
		return true;
	}
	
	function on_OK_clicked($btn) {
		global $conf;
		$conf->astHost = $this->cxAstHost->get_text();
		$conf->astPort = 5038; //$this->cxAstPort->get_text();
		$conf->astUser = $this->cxAstUser->get_text();
		$conf->astPass = $this->cxAstPass->get_text();
		$conf->bdHost  = $this->cxBdHost->get_text();
		$conf->bdPort  = 3306; //$this->cxBdPort->get_text();
		$conf->bdUser  = $this->cxBdUser->get_text();
		$conf->bdPass  = $this->cxBdPass->get_text();
		$conf->bdDB    = $this->cxBdDb->get_text();
		$conf->salvar();
		$this->ehInicio = false;
		$this->hide_all();
		return true;
	}
		
	function toggleMostra() {
		if(($this->mostra = !$this->mostra)) $this->show_all();
		else                                 $this->hide_all();
	}
	
	function fecha() {
		$this->hide_all();
		return true;
	}
}
?>