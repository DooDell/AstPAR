<?php
define('CONTEXTO', 'todos');
define('TEMPO_ALERTA', 2);

class PainelOp extends GtkWindow
{
	private $rangeConf, $idTimerCE, $svc_noturno,$chanChamada, $AMI, $usuarios,$prefixoLocal;
	private $telefonistaBuffer,$retencaoBuffer,$ramalServicoNoturno,$listaCallersTelefonista,$tempBuffer,$linkCanais,$bufferTransfSIP;
	private $canal1Ast, $canalTransfSIP, $canal2Ast ;
	private $emLigacao, $emTransfAsterisk; //Booleanos, FLAGs usadas na Ativa��o e Desativa��o das posi��es de Reten��o	
	public $nomeOp, $ramalOp, $telOp, $senhaOp,$canalOp, $pilotoOp;
	// Widgets
	private $splashWin;
	private $btnDisca, $btnTransfere,$btnPlayback, $btnConf,$btnNoturno,$btnLimpar;
	private $cxSaida, $cxEntrada, $cxProcuraR, $cxProcuraN, $lbTotalOcupados ,$listaOcupados;
	private $btnRetencao1,$btnRetencao2,$btnRetencao3,$btnRetencao4,$btnRetencao5,$btnRetencao6,$btnRetencao7,$btnRetencao8,$btnStyleDefault,$tableRetencao;
	private $filaTelefonista,$listaUsuarios, $janelasConf, $janelaLogin;

	public function __construct($parent = null) {

		parent::__construct();
		$this->splashScreen();
		global $conf;
		$this->bufferTransfSIP = array();
		$this->telefonistaBuffer = array();
		$this->tempBuffer = array();
		$this->retencaoBuffer = array();
		$this->retencaoBuffer[1]['time']=0;
		$this->retencaoBuffer[2]['time']=0;
		$this->retencaoBuffer[3]['time']=0;
		$this->retencaoBuffer[4]['time']=0;
		$this->retencaoBuffer[5]['time']=0;
		$this->retencaoBuffer[6]['time']=0;
		$this->retencaoBuffer[7]['time']=0;
		$this->retencaoBuffer[8]['time']=0;
		$conf = new Conf();
		$this->timeAlerta = time();
		$this->idTimerCE = 0;
		Gtk::timeout_add(1000, array($this, "posSplash"));
	}

	public function posSplash() {
		$this->splashWin->destroy();
		$this->login();
	}

	public function login() {
		$this->janelaLogin = new JanelaLogin();
		$this->janelaLogin->connect('hide', array($this, 'init'));
		$this->janelaLogin->show_all();
	}

	public function init() {
		$this->connect_simple('destroy', array($this, 'sair'), true);
		$this->set_title("Panoramisk : Painel Telef�nico");
		$this->set_position(Gtk::WIN_POS_CENTER);
		$this->set_default_size(500, 500);
		$this->set_border_width(8);
		$this->set_icon(GdkPixbuf::new_from_file("gfx/telefonista.png"));

		$this->buscaUsuarios();
		$this->initTelefonista();

		if($this->initAMI() === false)
		$this->sair();

		$this->add($this->criaInterface());
		$this->initDados();

		$this->idTimerCE = Gtk::timeout_add(1000, array($this, 'checaEventos'));
		$this->desativarSvcNoturno();
		$this->show_all();
	}

	function splashScreen() {
		$this->splashWin = new GtkWindow( gtk::WINDOW_POPUP );
		$this->splashWin->set_position( gtk::WIN_POS_CENTER );
		$this->splashWin->realize();

		$pixbuf = GdkPixbuf::new_from_file("gfx/splash.png");
		list($pixmap, $mask) = $pixbuf->render_pixmap_and_mask(255);
		$splashImg = gtkImage::new_from_pixmap($pixmap, $mask);
		$splashImg->show();

		$this->splashWin->shape_combine_mask($mask, 0, 0);

		$fix = new GtkFixed();
		$fix->put( $splashImg, 0, 0 );
		$this->splashWin->add($fix);
		$this->splashWin->show_all();
	}

	function initAMI() {
		global $conf;
		$configAMI = array('hostAMI' => $conf->astHost,
							'userAMI' => $this->ramalOp, //Conex�o AMI realizado com os dados da telefonista logada!
							'passAMI' => $this->senhaOp);

		$this->AMI = new AMI($configAMI);
		if($this->AMI->pacoteLogin === false)	return false;
		//$this->checaEventos($this->AMI->pacoteLogin);
		return true;
	}

	function shutAMI() {
		if(is_a($this->AMI, "AMI"))
		$this->AMI->logoff();
		if($this->idTimerCE)
		Gtk::timeout_remove($this->idTimerCE);
	}

	/*
	 * Obtem as informa��es atualizadas do PABX para posterior apresenta��o 
	 * e/ou recupera��o das funcionalidades a serem realizadas pela telefonista
	 */
	function initDados() {
		//Chama m�todos de atualiza��o dos dados
		$this->carregaCanaisOcupados();
		$this->carregaUsuarios();
		$this->carregaFilaTelefonista();
		$this->carregaCanaisRetidos();

	}

	function criaInterface() {
		$this->ramalServicoNoturno = Util::getRamalSVCNoturno();//Verifica ativa��o so servi�o noturno pelo Ramal salvo no banco e nao pela FLAG svcnot_ativo

		$box = new GtkHBox();//Janela principal, onde agrupar� todos os outros elementos gr�ficos

		$vbox = new GtkVBox();//�rea mais a esquerda que agrupa os frames de Fun��es, Reten��o e Fila

		// ------FRAME FUN��ES Linha 1 - cxTexto + 3 bot�es ---------
		$hboxFunc = new GtkHBox();

		$this->cxSaida = new GtkEntry();
		$this->cxSaida->modify_font(new PangoFontDescription("Arial Bold 12"));
		$this->cxSaida->connect('changed', array($this, 'on_CxDisca_changed'));
		$hboxFunc->pack_start($this->cxSaida,false);

		$this->btnLimpar1 = new GtkButton("Limpar");
		$this->btnLimpar1->connect('clicked', array($this, 'on_Limpar_CxDisca'));
		$this->btnLimpar1->set_size_request(70,30);
		$this->btnLimpar1->set_sensitive(false);
		$hboxFunc->pack_start($this->btnLimpar1,false);

		$this->btnDisca = new GtkButton("Disca");
		$this->btnDisca->set_image(GtkImage::new_from_file("gfx/disca.png"));
		$this->btnDisca->connect('clicked', array($this, 'on_Disca_clicked'));
		$this->btnDisca->set_size_request(70,30);
		$this->btnDisca->set_sensitive(false);
		$hboxFunc->pack_start($this->btnDisca,false);

		$this->btnTransfere = new GtkButton("Transfere");
		$this->btnTransfere->set_image(GtkImage::new_from_file("gfx/transfere.png"));
		$this->btnTransfere->connect('clicked', array($this, 'on_Transfere_clicked'));
		$this->btnTransfere->set_size_request(90,30);
		$this->btnTransfere->set_sensitive(false);
		$hboxFunc->pack_start($this->btnTransfere,false);

		$frameFuncao = new GtkFrame(" Fun��es: ");
		$frameFuncao->add($hboxFunc);
		// add linha 1
		$vbox->pack_start($frameFuncao,false,false);
		// ---------------- EO linha 1 -----------------


		// ------FRAME RETEN��O  Linha 2 - Bot�es de Reten��o ---------

		$frameRetencao = new GtkFrame();
		$frameRetencao->set_label(" Reten��o: ");

		$this->tableRetencao = new GtkTable();
		$this->tableRetencao->set_homogeneous(true);
		$this->tableRetencao->set_col_spacing(0, 50);//set_col_spacing(int column, int spacing);

		// Linha 1 com 2 colunas
		$this->btnRetencao1 = new GtkButton("Reter");
		$this->btnRetencao1->set_size_request(130,30);
		$this->btnRetencao1->connect('clicked', array($this, 'on_Retencao_clicked'));
		$this->tableRetencao->attach($this->btnRetencao1, 0, 1, 0, 1, Gtk::FILL, Gtk::SHRINK);

		$this->btnRetencao2 = new GtkButton("Reter");
		$this->btnRetencao2->set_size_request(130,30);
		$this->btnRetencao2->connect('clicked', array($this, 'on_Retencao_clicked'));
		$this->tableRetencao->attach($this->btnRetencao2 , 1, 2, 0, 1, Gtk::FILL, Gtk::SHRINK);

		//Linha 2 com 2 colunas
		$this->btnRetencao3 = new GtkButton("Reter");
		$this->btnRetencao3->set_size_request(130,30);
		$this->btnRetencao3->connect('clicked', array($this, 'on_Retencao_clicked'));
		$this->tableRetencao->attach($this->btnRetencao3, 0, 1, 1, 2, Gtk::FILL, Gtk::SHRINK);
			
		$this->btnRetencao4 = new GtkButton("Reter");
		$this->btnRetencao4->set_size_request(130,30);
		$this->btnRetencao4->connect('clicked', array($this, 'on_Retencao_clicked'));
		$this->tableRetencao->attach($this->btnRetencao4 , 1, 2, 1, 2, Gtk::FILL, Gtk::SHRINK);

		//Linha 3 com 2 colunas
		$this->btnRetencao5 = new GtkButton("Reter");
		$this->btnRetencao5->set_size_request(130,30);
		$this->btnRetencao5->connect('clicked', array($this, 'on_Retencao_clicked'));
		$this->tableRetencao->attach($this->btnRetencao5, 0, 1, 2, 3, Gtk::FILL, Gtk::SHRINK);
			
		$this->btnRetencao6 = new GtkButton("Reter");
		$this->btnRetencao6->set_size_request(130,30);
		$this->btnRetencao6->connect('clicked', array($this, 'on_Retencao_clicked'));
		$this->tableRetencao->attach($this->btnRetencao6 , 1, 2, 2, 3, Gtk::FILL, Gtk::SHRINK);

		//Linha 4 com 2 colunas
		$this->btnRetencao7 = new GtkButton("Reter");
		$this->btnRetencao7->set_size_request(130,30);
		$this->btnRetencao7->connect('clicked', array($this, 'on_Retencao_clicked'));
		$this->tableRetencao->attach($this->btnRetencao7, 0, 1, 3, 4, Gtk::FILL, Gtk::SHRINK);
			
		$this->btnRetencao8 = new GtkButton("Reter");
		$this->btnRetencao8->set_size_request(130,30);
		$this->btnRetencao8->connect('clicked', array($this, 'on_Retencao_clicked'));
		$this->tableRetencao->attach($this->btnRetencao8 , 1, 2, 3, 4, Gtk::FILL, Gtk::SHRINK);

		$frameRetencao->add($this->tableRetencao);
		$vbox->pack_start($frameRetencao,false,false);
			
		// ------FRAME FILA Linha 3 - Lista chamadas entrantes na Fila Telefonista
		$frameFila = new GtkFrame();
		$frameFila->set_label(" Fila: ");
		$this->lbTotalFila = new GtkLabel();
		$this->lbTotalFila->set_markup("Fila Telefonista : <b>".count($this->filaTelefonista)."</b>");

		$tipoColunas = new GtkListStore(GObject::TYPE_STRING, GObject::TYPE_STRING);
		$this->filaTelefonista = new Lista("Nome,N�mero", $tipoColunas);
		$this->filaTelefonista->connect('row-activated', array($this, 'on_CapturaDaFila_doubleclicked'));

		$scrolwnd = new GtkScrolledWindow();
		$scrolwnd->set_policy( Gtk::POLICY_AUTOMATIC, Gtk::POLICY_AUTOMATIC);
		$scrolwnd->add($this->filaTelefonista);
		$frameFila->add($scrolwnd);
		$vbox->pack_start($frameFila);
			
		$box->pack_start($vbox);

		// --- Coluna 2 : FRAME RAMAIS ---
		$jpVbox = new GtkVBox();

		//Linha 1 --- PROCURA NOME / RAMAL + Bot�o Limpar 
		$hboxPesquisa= new GtkHBox();

		$alignment = new GtkAlignment(0.5, 0.5, 0, 0);
		$lbProcuraNome = new GtkLabel("Procura Nome :");
		$lbProcuraNome->set_justify(Gtk::JUSTIFY_LEFT);
		$alignment->add($lbProcuraNome);
		$alignment->set_padding(0,0,15,0);

		$hboxPesquisa->pack_start($alignment);

		$this->cxProcuraN = new GtkEntry();
		$this->cxProcuraN->modify_font(new PangoFontDescription("Arial 12"));
		$this->cxProcuraN->connect('changed', array($this, 'on_CxProcuraN_changed'));
		$this->cxProcuraN->set_size_request(200,30);
		$hboxPesquisa->pack_start($this->cxProcuraN);


		$alignment = new GtkAlignment(0.5, 0.5, 0, 0);
		$lbProcuraRamal = new GtkLabel("Procura Ramal :");
		$lbProcuraRamal->set_justify(Gtk::JUSTIFY_LEFT);
		$alignment->add($lbProcuraRamal);
		$alignment->set_padding(0,0,15,0);

		$hboxPesquisa->pack_start($alignment);

		$this->cxProcuraR = new GtkEntry("", 4);
		$this->cxProcuraR->modify_font(new PangoFontDescription("Arial 12"));
		$this->cxProcuraR->connect('changed', array($this, 'on_CxProcuraR_changed'));
		$this->cxProcuraR->set_size_request(70,30);
		$hboxPesquisa->pack_start($this->cxProcuraR);
			
		$alignment = new GtkAlignment(); // note 3
		$this->btnLimpar2 = new GtkButton("Limpar");
		$this->btnLimpar2->connect('clicked', array($this, 'on_Limpar_cxProcura'));
		$alignment->add($this->btnLimpar2);
		$this->btnLimpar2->set_size_request(70,30);

		$hboxPesquisa->pack_start($alignment);

		//$title->set_justify(Gtk::JUSTIFY_CENTER);
		//$alignment = new GtkAlignment(0.5, 0, 0, 0);

		$jpVbox->pack_start($hboxPesquisa,false, false);
			
		$frameRamal= new GtkFrame(" Ramais : ");

		//Linha 2 ---LISTA RAMAIS DO PABX ASTERISK
		$tipoColunas   = new GtkListStore(GObject::TYPE_STRING, GObject::TYPE_STRING);
		$this->listaUsuarios = new Lista("Status&P,Ramal,Usu�rio,Nome de Guerra", $tipoColunas);

		$this->listaUsuarios->connect('cursor-changed', array($this, 'on_LinhaProcura_clicked'));
		//Linha abaixo comentada para evitar Discar e Transferir com Double Click, for�ando o click nos bot�es :Disca / Transfere
		//$this->listaUsuarios->connect('row-activated', array($this, 'on_LinhaProcura_dclicked'));
		$this->listaUsuarios->connect('end-selection', array($this, 'on_Limpar_CxDisca'));
		$scrolwnd = new GtkScrolledWindow();
		$scrolwnd->set_policy( Gtk::POLICY_AUTOMATIC, Gtk::POLICY_AUTOMATIC);
		$scrolwnd->add($this->listaUsuarios);
		$jpVbox->pack_start($scrolwnd);
		$frameRamal->add($jpVbox);

		//Linha 3 ---FRAME SERVI�O NOTURNO + Identifica��o Telefonista
		$frameIdentificacao = new GtkFrame("Servi�o Noturno : ");

		$telPrefHBox = new GtkHBox();
		$this->barraTelefonista = new GtkLabel();
		$this->barraTelefonista->set_markup("Telefonista: $this->nomeOp");

		if(!empty($this->ramalServicoNoturno)){
			$this->btnNoturno = new GtkButton();
			$this->btnNoturno->set_size_request(200,35);
			if($this->svc_noturno == 0){
				$this->btnNoturno->set_label("Ativar Servi�o Noturno");
				$this->btnNoturno->set_image(GtkImage::new_from_file("gfx/noturno.png"));
			} else {
				$this->btnNoturno->set_label("Desativar Servi�o Noturno");
				$this->btnNoturno->set_image(GtkImage::new_from_file("gfx/noturno_des.png"));
			}
			$this->btnNoturno->connect('clicked', array($this, 'on_Notuno_clicked'));

		}else{
			$this->btnNoturno = new GtkLabel();
			$this->btnNoturno->set_markup("Servi�o Noturno n�o Configurado no PABX");
		}
		$telPrefHBox->pack_start($this->btnNoturno, false, false);
		$telPrefHBox->pack_start(new GtkVSeparator(), true, false, 20);
		$telPrefHBox->pack_start($this->barraTelefonista, false, false);
		$frameIdentificacao->add($telPrefHBox);

		// -------------------------------------------------
		$v = new GtkVBox();
		$v->pack_start($frameRamal);
		$v->pack_start($frameIdentificacao,false,false);
		$box->pack_start(new GtkVSeparator(), true, false, 20);
		$box->pack_start($v);

		// -------------------

		$b = new GtkVBox();
		// ------ Cabe�alho - Logo Celepar + Logo Linux --------
		$hboxLogos = new GtkHBox();

		$hboxLogos->pack_start(GtkImage::new_from_file("gfx/logoProjeto.png"), true,true,20);
		$hboxLogos->pack_start(GtkImage::new_from_file("gfx/logoCelepar.png"), true,true,20);
		$hboxLogos->pack_start(GtkImage::new_from_file("gfx/logoLinux.png"),true,true,20);

		$eventbox = new GtkEventBox();
		$eventbox->modify_bg(Gtk::STATE_NORMAL, GdkColor::parse('#222266'));
		$eventbox->add($hboxLogos);
		$b->pack_start($eventbox, false, true, 8);

		$b->pack_start($box);
		return $b;
	}

	function enviaComando($cmd, $params=array(), $debug=false) {
		$pacote = $this->AMI->enviaComando($cmd, $params, $debug);
		$this->checaEventos($pacote);
		return $pacote;
	}

	function on_Limpar_CxDisca(){
		$this->cxSaida->set_text("");
		$this->btnDisca->set_sensitive(false);
		$this->btnTransfere->set_sensitive(false);
	}

	function on_Limpar_cxProcura(){
		$this->cxProcuraN->set_text("");
		$this->cxProcuraR->set_text("");
	}

	/*
	 * Ativa ou desativa o servi�o noturno no PABX e atualiza as informa��es na tela 
	 */
	function on_Notuno_clicked($btn) {
		if($this->svc_noturno==1){
			$this->svc_noturno = 0;
			$btn->set_label("Ativar Servi�o Noturno");
			//Sai do estado Desativado
			$btn->set_image(GtkImage::new_from_file("gfx/noturno.png"));
		}else{
			//Ativa servi�o noturno
			$this->svc_noturno = 1;
			$btn->set_label("Desativar Servi�o Noturno");
			$btn->set_image(GtkImage::new_from_file("gfx/noturno_des.png"));
		}
		$this->enviaComando("DBPut", array(
								"Family" => "plano",
								"Key" => "svcnot_ativo",
								"Val" => $this->svc_noturno
		));
	}

	function getStatusSvcNoturno() {
		$pacote = $this->enviaComando("DBGet", array(
								"Family" => "plano",
								"Key" => "svcnot_ativo"
								));
								$aux =& $pacote;
								while($aux){
									if($aux->getAtr('Event') == "DBGetResponse"){
										$this->svc_noturno = $aux->getAtr('Val');
										break;
									}
									$aux = $aux->prox;
								}
	}

	function desativarSvcNoturno() {
		$this->svc_noturno = 0;
		$this->enviaComando("DBPut", array(
								"Family" => "plano",
								"Key" => "svcnot_ativo",
								"Val" => $this->svc_noturno
		));

	}

	function on_Disca_clicked() {
		if(!$this->emLigacao){
			$this->enviaComando("Originate", array(
								"Channel" => $this->telOp,
								"Context" => CONTEXTO,
								"Exten" => $this->cxSaida->get_text(),
								"Priority" => "1",
								"Callerid" => "$this->pilotoOp TELEFONISTA", //N�o identificar o ramal original da telefonista 
								"Timeout" => "15000"
								));
		}
	}
	function desativaRetencao(){
		for($c=1;$c<=8;$c++){
			$botao = "btnRetencao$c";
				$this->$botao->set_sensitive(false);
		}

	}
	function ativaRetencao(){
		for($c=1;$c<=8;$c++){
			$botao = "btnRetencao$c";
				$this->$botao->set_sensitive(true);
		}

	}

	/* Fun��o de Reten��o/Captura das Chamadas no Buffer de Chamadas Retidas ->retencaoBuffer */
	function on_Retencao_clicked($btn) {
		     if($btn === $this->btnRetencao1) {$pos=1;}
		else if($btn === $this->btnRetencao2) {$pos=2;}
		else if($btn === $this->btnRetencao3) {$pos=3;}
		else if($btn === $this->btnRetencao4) {$pos=4;}
		else if($btn === $this->btnRetencao5) {$pos=5;}
		else if($btn === $this->btnRetencao6) {$pos=6;}
		else if($btn === $this->btnRetencao7) {$pos=7;}
		else if($btn === $this->btnRetencao8) {$pos=8;}

		$estado = $btn->get_label();
		if($estado == 'Reter') {
			// Reter chamada atual
			$canalLinkOp = $this->procuraLinkDaOp();

			$numChamada = isset($this->tempBuffer[$canalLinkOp]) ? $this->tempBuffer[$canalLinkOp] : $this->procuraCallerIdDaOp($canalLinkOp);
			if(!empty($canalLinkOp) ){	//&& $numChamada>9999
				$this->retencaoBuffer[$pos]['channel'] = "$canalLinkOp|$numChamada";
				$this->retencaoBuffer[$pos]['time'] =time();
				$this->enviaComando("Redirect", array(
									"Channel" => $canalLinkOp,
									"Context" => 'agentes',
									"Exten" => '***123',
									"Priority" => '1'
									));
									$btn->set_label("$numChamada");
			}
		} else {
			// Capturar chamada retida
			list($canalRetido) = explode("|", $this->retencaoBuffer[$pos]['channel']);
			$this->retencaoBuffer[$pos]['time']=0;
			$this->enviaComando("Redirect", array(
								"Channel" => $canalRetido,
								"Context" => 'ramais-internos',
								"Exten" => $this->ramalOp,
								"Priority" => '1'
								));
								unset($this->retencaoBuffer[$pos]['channel']);
								$bt = new GtkButton();
								$btn->modify_bg(Gtk::STATE_NORMAL,$bt->get_style()->bg[Gtk::STATE_NORMAL]);
								$btn->modify_bg(Gtk::STATE_ACTIVE,$bt->get_style()->bg[Gtk::STATE_ACTIVE]);
								$btn->modify_bg(Gtk::STATE_PRELIGHT,$bt->get_style()->bg[Gtk::STATE_PRELIGHT]);
								$btn->set_label('Reter');
		}

	}

	/*
	 * Obtem o numero originador da chamada e redireciona para o numero de destino da transfer�ncia
	 */
	function on_Transfere_clicked() {
		$chanLinkOP = $this->procuraLinkDaOp();
		$this->enviaComando("Redirect", array(
								"Channel" => $chanLinkOP,
								"Context" => CONTEXTO,
								"Exten" => $this->cxSaida->get_text(),
								"Priority" => "1"								
								));
		unset($this->tempBuffer[$chanLinkOP]);
	}
	
	function on_CapturaDaFila_doubleclicked($treeview, $path, $column){
		$store = $treeview->get_model();
		$iter = $store->get_iter($path);
		$numero = $store->get_value($iter, 1);
		$canalFila = array_search($numero,$this->telefonistaBuffer);
		$canalLinkOp = $this->procuraLinkDaOp();
		$this->tempBuffer[$canalFila]=$numero;

		if(empty($canalLinkOp)){
			$this->enviaComando("Redirect", array(
									"Channel" => $canalFila,
									"Context" => 'ramais-internos',
									"Exten" => $this->ramalOp,
									"Priority" => '1'
									));
									$this->filaTelefonista->delLinha('N�mero',$numero);
									$this->limpaCanalBufferTelefonista($canalFila);
		}
		//Se a chamada entrante na Fila foi ocorr�ncia de uma tranferencia pelo Asterisk (#9#) DESATIVO RETENCAO para essa chamada
		if((stristr($canalFila,'Local/9@')) || (stristr($canalFila,"Local/$this->pilotoOp@"))){
			$this->desativaRetencao();
			$this->setaEmTransfAst(true);
		}		
	}
	
	function on_LinhaProcura_dclicked($treeview, $path, $column) {
		$store = $treeview->get_model();
		$iter = $store->get_iter($path);
		$ramal = $store->get_value($iter, 1);
		$this->cxSaida->set_text($ramal);
		if($column) {
			if($this->emLigacao) $this->on_Transfere_clicked();
			else $this->on_Disca_clicked();
		}
	}

	function on_LinhaProcura_clicked($treeview) {
		list($path, $col) = $treeview->get_cursor();
		//$this->on_LinhaProcura_dclicked($treeview, $path, null);
		
		$store = $treeview->get_model();
		$iter = $store->get_iter($path);
		$ramal = $store->get_value($iter, 1);
		$this->cxSaida->set_text($ramal);
		//if($column) {
			//if($this->emLigacao) $this->on_Transfere_clicked();
			//else $this->on_Disca_clicked();
		//}
	}

	function on_CxProcuraR_changed($gtkEntry) {
		$txt = $gtkEntry->get_text();
		if(strlen($txt) == 4 && is_numeric($txt)) {
			$store = $this->listaUsuarios->get_model();
			foreach ($store as $row) {
				$iter = $row->iter;
				if($store->get_value($iter, 1) == $txt) {
					$this->listaUsuarios->set_cursor($store->get_path($iter));
					break;
				}
			}
		}

	}

	function on_CxDisca_changed($gtkEntry) {
		if(strlen($gtkEntry->get_text()) ){ 
			$this->btnLimpar1->set_sensitive(true);
		}
		if(!$this->emLigacao)
			$this->btnDisca->set_sensitive(true);
		if($this->emLigacao && !$this->emTransfAsterisk){
			$this->btnTransfere->set_sensitive(true);
		}
	}

	function on_CxProcuraN_changed($gtkEntry) {
		$txt = $gtkEntry->get_text();
		if(strlen($txt)>2) {
			// Desligar o sort
			$this->listaUsuarios->setOrdena(false);

			$todos = false;
			$movidos = array();
			while(!$todos) {
				$store = $this->listaUsuarios->get_model(); //Devolve uma lista de GtkListStore
				$todos = true;
				foreach($store as $row) {
					$iter = $row->iter;
					$nome = $store->get_value($iter, 2);
					$guerra = $store->get_value($iter, 3);
					if(!in_array($nome, $movidos) && (stristr($nome, $txt) || stristr($guerra, $txt))) {
						$movidos[] = $nome;
						$store->move_after($iter, null);
						$todos = false;
						break;
					}
				}
			}
			$this->listaUsuarios->setOrdena(true);
		}
	}

	function sair($voltaParaLogin) {
		$this->shutAMI();
		if($voltaParaLogin) $this->janelaLogin->reseta();
		else gtk::main_quit();
	}

	function setaEmLigacao($emLig) {
		$this->btnTransfere->set_sensitive($emLig);
		$this->emLigacao = $emLig;
	}
	
	function setaEmTransfAst($emTransf=true) {
		$this->btnTransfere->set_sensitive(false);
		$this->btnDisca->set_sensitive(false);	
		$this->emTransfAsterisk = $emTransf;
		$this->emLigacao = true;
	}

	function buscaUsuarios() {
		$this->usuarios = array();
		foreach(Util::getUsuarios() as $usu)
		$this->usuarios[$usu->ramal] = $usu;
	}

	/*
	 * Carrega a lista de usu�rios do PABX com o Status do Ramais : LIVRE ou OCUPADO
	 */
	function carregaUsuarios($busca=false) {
		if($busca) $this->buscaUsuarios();
		$this->listaUsuarios->limpa();
		foreach($this->usuarios as $usu) {
			if($usu->ramal != $this->ramalOp) {
				if(array_search($usu->ramal,$this->listaOcupados)){
					$this->listaUsuarios->addLinha("ocupado.png,$usu->ramal,$usu->nome,$usu->nomeguerra");
				}else {
					$this->listaUsuarios->addLinha("livre.png,$usu->ramal,$usu->nome,$usu->nomeguerra");
				}
			}
		}
	}

	function initTelefonista() {
		$this->emLigacao	= false;
		$this->nomeOp		= $this->janelaLogin->getSelLogin();
		$this->senhaOp		= $this->janelaLogin->getSenha();
		$this->pilotoOp		= Util::getPilotoTelefonista();
		foreach($this->usuarios as $usu) {
			if($usu->nome == $this->nomeOp) {
				$this->ramalOp = $usu->ramal;
				$this->telOp   = "SIP/$usu->ramal";
				return true;
			}
		}
		return false;
	}

	function setLabel($btn,$num){
		$aux = array();
		$cont = 0;
		for($c=1;$c<=8;$c++){
			if(!empty($this->retencaoBuffer[$c]['channel'])){
				$cont ++;
			}
		}
		$btn->set_label("$cont  - $num");
	}

	/*
	 * Fun��o para recuperar as chamadas retidas, no caso acidental de fechamento da janela principal, 
	 * sem encerramento do programa!
	 */
	function carregaCanaisRetidos() {
		$canalRetido = null;
		for($c=1;$c<=8;$c++){
			if(isset($this->retencaoBuffer[$c]['channel'])){
				list($canalRetido,$numChamada) = explode("|", $this->retencaoBuffer[$c]['channel']);
				$botao = "btnRetencao$c";
				$this->$botao->set_label($numChamada);
			}
		}
	}

	/*
	 * Fun��o para recuperar os canais ocupados e atualizar na tela a coluna Status da lista de usuarios
	 */
	function carregaCanaisOcupados() {
		// Buscar dados atuais dos canais ocupados pelo AMI
		$listaCanais = $this->enviaComando("Command", array("command"=>"core show channels concise"));
		$linhas = explode("\n", $listaCanais->dados);
		$totLin = count($linhas);
		$this->listaOcupados = array();
		for($c=0; $c<$totLin - 1; $c++) {
			list($ramalSip, $d,$d,$d,$status) = explode("!", $linhas[$c]);
			list($d,$ramal) = explode("/",$ramalSip);
			list($ramal) = explode("-",$ramal);
			if(is_numeric($ramal) && $ramal > 999 && $ramal != $this->ramalOp && $status=="Up") {
				$usu = $this->getUsuarioPorRamal($ramal);
				$this->listaOcupados[$ramal]=$ramal;
			}
		}
	}

	/*
	 * Fun��o para recuperar as chamadas entrantes na fila Telefonista
	 */
	function carregaFilaTelefonista() {
		$this->telefonistaBuffer = array();
		$this->filaTelefonista->limpa();
		// Este comando ir� gerar v�rios eventos do tipo QueueEntry,
		// com informa�oes das chamadas na fila da telefonista, que ser�o tratados pela fun��o 'checaEventos'
		$this->enviaComando("QueueStatus", array("Queue" => "telefonista", 'Member' => '--NenhuM--'));

	}

	/*
	 * Fun��o para inserir recuperar as chamadas entrantes na fila Telefonista
	 */
	function exibirChamadaNaFila($nomeFila='Externo', $numFila=null, $canalFila=null) {
		//Verifica se � um ramal do PABX da Celepar par exibir na Fila o Nome de Guerra
		$nomeFila='Externo';
		if(array_key_exists($numFila,$this->usuarios)){
			$usu = $this->usuarios[$numFila];
			$nomeFila = $usu->nomeguerra;
		}
		//Verifica exist�ncia de canal, como �ndice, no Buffer na Telefonista para evitar duplicidade
		if(!array_key_exists($canalFila,$this->telefonistaBuffer)){
			$this->telefonistaBuffer[$canalFila] = $numFila;
			$this->filaTelefonista->addLinha("$nomeFila,$numFila");
		}
		
	}
	/**
	 * Func�o para obter o Status do canal originalmente em transfer�ncia pelo Asterisk (#9#)
	 * para entrada dos dados na Fila Telefonista (CallerID, CallerIdName)
	 */
	function obterStatusCanal($canal, $transfAst = false){
		$statusCanal = $canal;
		if($transfAst){
			$this->canal1Ast = str_ireplace(',2',',1',$canal);	//CANAL 1 DO ASTERISK ex:  Local/9@liberado15-f6ef,1
			$this->canal2Ast = $canal;							//CANAL 2 DO ASTERISK ex:  Local/9@liberado15-f6ef,2
			$statusCanal = $this->canal1Ast;
		}
		//Obt�m dados do canal original que efetuou a transf.
		$this->enviaComando("Status",array("Channel" => $statusCanal));
	}

	/**
	 * Func�o para tratamento das chamadas em Transfer�ncia pelo Asterisk (#9#)
	 */
	function verCanalTransferencia($aux){
		//Resposta ao comando Status Channel [Local/9] ou [Local/6000]
		$canal 		= $aux->getAtr('Channel');
		$cidNum 	= $aux->getAtr('CallerID');
		$cidNome 	= $aux->getAtr('CallerIDName');
		$link		= $aux->getAtr('Link');
		
		if($canal == $this->canal1Ast){
			$this->canalTransfSIP = $link;
			$this->bufferTransfSIP[$link] = $this->canal2Ast;
			$this->obterStatusCanal($link);	// Pedindo segundo pacote STATUS para obter dados do CANAL SIP como CallerIdNum
		}
		if($canal == $this->canalTransfSIP && $link == $this->canal1Ast){	//Se CANAL SIP est� LINKADO com CANAL 1 DO ASTERISK
			//Apresentar dados na fila Telefonista
			if(!isset($this->telefonistaBuffer[$this->canal2Ast])){
				$this->exibirChamadaNaFila($cidNome, $cidNum,$this->canal2Ast);
			}
		}
	}

	/*
	 * Obtem do buffer de chamadas entrantes na fila Telefonista o n�mero originador da chamada atrav�s do canal
	 */
	function getCanalBufferTelefonista($canal) {
		if(isset($this->telefonistaBuffer[$canal])) return $this->telefonistaBuffer[$canal];
		return null;
	}

	/*
	 * Exclui do buffer de chamadas retidas o n�mero originador da chamada atrav�s do canal
	 */
	function limpaCanalBufferTelefonista($canal) {
		if(isset($this->telefonistaBuffer[$canal])) unset($this->telefonistaBuffer[$canal]);
	}

	function getUsuarioPorRamal($ramal) {
		if(!is_array($this->usuarios)) return null;
		if(isset($this->usuarios[$ramal])) return $this->usuarios[$ramal];
		return null;
	}

	function procuraLinkDaOp($canal='') {
		if(!empty($canal)){
			$pacote = $this->enviaComando("Status",array("Channel" => $canal));
		}
		else
			$pacote = $this->enviaComando("Status");
		$aux =& $pacote;
		while($aux) {
			if($aux->getAtr('Event') == "Status" && stristr($aux->getAtr('Channel'), $this->telOp))
			 	return $aux->getAtr('Link');
			$aux = $aux->prox;
		}
		return null;
	}

	function procuraCallerIdDaOp($canal="") {
		if(!empty($canal)) {
			//$pacote = $this->enviaComando("Status");
			$pacote = $this->enviaComando("Status",array("Channel" => $canal));
			$aux =& $pacote;
			while($aux) {
				if($aux->getAtr('Event') == "Status" && stristr($aux->getAtr('Channel'),$canal))
				return $aux->getAtr('CallerIDNum');
				$aux = $aux->prox;
			}
		}
		return "N�o Identificado";
	}

	function atualizaDadosInterface() {
		$this->carregaCanaisOcupados();
		$this->carregaUsuarios();
		$this->carregaFilaTelefonista();
		$this->getStatusSvcNoturno();
		$this->carregaCanaisRetidos();
	}

	function checaEventos($pacote=null) {
		if(!$pacote) $pacote = $this->AMI->recebeEventos(0.1);
		$aux =& $pacote;
		while($aux) {
			$evento = $aux->getAtr('Event');
			switch(strtolower($evento)) {
				case "newchannel":
					$sip = Util::pegaSipDoPacote($aux);
					list($d, $ramal) = explode("/", $sip);
					if ($sip != $this->telOp && is_numeric($ramal) && $ramal > 999) {
						if (isset($this->usuarios[$ramal])){
							$this->listaUsuarios->setLinha("Ramal", $ramal, "Status", "ocupado.png");
						}
					}
					break;

				case "hangup":
					$sip = Util::pegaSipDoPacote($aux);
					$chanHangup = $aux->getAtr('Channel');

					if($sip == $this->telOp)
						$this->setaEmLigacao(false);
					$sip = Util::pegaSipDoPacote($aux);
					$ramal = null;
					list($d, $ramal) = explode("/", $sip);

					if(isset($this->usuarios[$ramal])){
						$this->listaUsuarios->setLinha('Ramal', $ramal, "Status", "livre.png");
						//Quando a chamada for consequencia de uma transferencia pelo telefone (SIEMENS),
						// a mesma ser� identificada exclusivamente pelo RAMAL e N�O pelo CANAL
						$canalEmEspera = array_search($ramal,$this->telefonistaBuffer);
						if($canalEmEspera) $this->limpaCanalBufferTelefonista($canalEmEspera);
					}
					$bt = new GtkButton();
					for($c=1;$c<=8;$c++){
						$botao = "btnRetencao$c";
						if(isset($this->retencaoBuffer[$c]['channel'])){
							$auxCanal = $this->retencaoBuffer[$c]['channel'];
							if(stristr($auxCanal,$chanHangup)){
								$this->$botao->modify_bg(Gtk::STATE_NORMAL,$bt->get_style()->bg[Gtk::STATE_NORMAL]);
								$this->$botao->modify_bg(Gtk::STATE_ACTIVE,$bt->get_style()->bg[Gtk::STATE_ACTIVE]);
								$this->$botao->modify_bg(Gtk::STATE_PRELIGHT,$bt->get_style()->bg[Gtk::STATE_PRELIGHT]);
								$this->$botao->set_label('Reter');
								unset($this->retencaoBuffer[$c]);
								unset($this->tempBuffer[$chanHangup]);
								$this->retencaoBuffer[$c]['time']=0;
							}
						}
					}

					//	Verifica se a chamada foi realizada pelo Asterisk (#9#) e desativa a Reten��o
					//  do canal que originou a transfer�ncia porque nesse caso,
					// 	Reter implica em Redirecionar paro o contexto ***123 e o Asterisk completa automaticamente a chamada com a Telefonista
					if(array_key_exists($chanHangup, $this->bufferTransfSIP)) {
						$this->ativaRetencao();
						$this->limpaCanalBufferTelefonista($chanHangup);
						unset($this->tempBuffer[$chanHangup]);
						unset($this->bufferTransfSIP[$chanHangup]);
					}
					if(stristr($chanHangup,$this->telOp))
						$this->ativaRetencao();
					if(isset($this->telefonistaBuffer[$chanHangup]))
						$this->limpaCanalBufferTelefonista($chanHangup);

					break;

				case "unlink":
					$canal1 = $aux->getAtr('Channel1');
					$canal2 = $aux->getAtr('Channel2');
					if((stristr($canal2,'Local/9@')) || (stristr($canal2,"Local/$this->pilotoOp@"))) {
						$cidNum = $aux->getAtr('CallerID1');
						$this->filaTelefonista->delLinha("N�mero",$cidNum);
						$this->tempBuffer[$canal1] = $cidNum;
						break;
					}
				case "link":
					$canal2 = $aux->getAtr('Channel2');
					if((!stristr($canal2,'Local/9@')) && (!stristr($canal2,"Local/$this->pilotoOp@"))) {
						break;
					}

				case "rename":
					$old = $aux->getAtr('Oldname');	//Canal que redirecionou
					$new = $aux->getAtr('Newname'); //Canal para o qual foi redirecionado
					if(strstr($old, '<') || strstr($new, '<'))
					break;
						
				case "join":
				case "leave":
					$this->carregaFilaTelefonista();
					break;

				case "dial":
					$sip = Util::pegaSipDoPacote($aux, 'Destination');
					if($sip == $this->telOp) {  // Telefonista recebendo
						$num = $aux->getAtr('CallerID');
						$cidName = $aux->getAtr('CallerIDName');
						$cidName = (!empty($cidName) && !strstr($cidName, "nknown")) ? " - $cidName" : "Externo";
						$txt = $num . $cidName;
						if(array_key_exists($num, $this->usuarios)) {
							// Se a liga��o vem de ramal interno pega o nome do usu�rio
							$usu = $this->getUsuarioPorRamal($num);
							$txt = "$usu->ramal - $usu->nome";
						}
						$this->setaEmLigacao(true);
					} else {
						$sip = Util::pegaSipDoPacote($aux, 'Source');
						if(stristr($sip, $this->telOp)) // Telefonista ligando
						$this->setaEmLigacao(true);
					}
					break;

				case "newstate":
					$sip = Util::pegaSipDoPacote($aux);
					if($sip == $this->telOp) {
						$estado = $aux->getAtr('State');
						switch($estado) {
							case "Ringing": $cor = "ff0000"; break;
							case "Up":      $cor = "0000ff"; break;
							default:        $cor = "000000";
						}
					}
					break;

				case "channelreload":
					$this->atualizaDadosInterface();
					break;

				case "shutdown":
					Util::alerta("Asterisk desligou. Saindo!");
					$this->sair(false);
					break;

					// Eventos de retorno do QueueStatus
				case 'queueentry':
					$canal = $aux->getAtr('Channel');
					$cidNum  = $aux->getAtr('CallerID');
					$cidNome = $aux->getAtr('CallerIDName');

					//Buscar um canal com identifica��o Local/9 ou Local/6000 que s�o canais de transfer�ncia pelo Asterisk
					if((stristr($canal,'Local/9@')) || (stristr($canal,"Local/$this->pilotoOp@"))){
						$this->obterStatusCanal($canal, true);
					} else {
						$this->exibirChamadaNaFila($cidNome, $cidNum, $canal);
					}
					break;

				case 'status':
					//Resposta ao comando Status Channel [Local/9] ou [Local/6000]
					$this->verCanalTransferencia($aux);
					break;

			}//Fechando o switch
			$aux = $aux->prox;
		} //Fechando o While

		$agora = time();
		if((count($this->telefonistaBuffer) > 0) && !$this->emLigacao && $agora > $this->timeAlerta) {
			system("play sound/alertNewCall.wav 2> /dev/null");
			$this->timeAlerta = $agora + TEMPO_ALERTA;
		}
			
		//Verifica o tempo de cada posi��o de Reten��o e mostra alerta de cores conforme o tempo de espera,
		// se > 30s = amarelo ou > 60s = vermelho
		$intervalo = array();
		for($c=1; $c<=8; $c++){
			$botao = "btnRetencao$c";
			$intervalo[$c] = time() - $this->retencaoBuffer[$c]['time'];
			if ($this->retencaoBuffer[$c]['time'] > 0){
				if($intervalo[$c]>=30 &&  $intervalo[$c]<60)
				Util::mudaCorDeFundo($this->$botao,"#fdee73");
				elseif($intervalo[$c]>=60)
				Util::mudaCorDeFundo($this->$botao, "#ee4848");
			}
		}
		return true;
	}
}
?>