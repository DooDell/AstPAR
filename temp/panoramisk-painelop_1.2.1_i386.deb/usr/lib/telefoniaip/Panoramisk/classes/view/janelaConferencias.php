<?php
class JanelaConferencias extends GtkWindow
{
	private $listaUsuarios, $listaMudo, $pbCxSom, $pbCxSomMute, $numSala;
	
	function __construct($numSala) {
		parent::__construct();
		$this->connect_simple('delete-event', array($this, 'fecha'));
		
		$this->numSala = $numSala;
		
		$this->listaMudo = array();
		$this->pbCxSom     = GdkPixbuf::new_from_file("gfx/cxSom.png");
		$this->pbCxSomMute = GdkPixbuf::new_from_file("gfx/cxSomMute.png");
		
		$this->set_title("Sala de Conferencia [$numSala]");
		$this->set_position(Gtk::WIN_POS_CENTER);
		$this->set_default_size(500, 300);
		$this->set_border_width(8);
		$this->set_icon(GdkPixbuf::new_from_file("gfx/telefonista.png"));
		
		$linhas = new GtkVBox();
		
		$col1 = new GtkHBox();
		$btnFecha = new GtkButton("Encerrar Sala");
		$btnFecha->connect("clicked", array($this, "on_Encerra_clicked"));
		$col1->pack_start($btnFecha);
		$col1->pack_start(new GtkLabel(".: Sala de Conferencia $numSala :."));
		$btnLock = new GtkButton("Bloquear Sala");
		$btnLock->connect("clicked", array($this, "on_Lock_clicked"));
		$col1->pack_start($btnLock);
		$linhas->pack_start($col1, false);
		
		$this->listaUsuarios = new Lista("Mute&P Kick&P Ramal Nome");
		
		$pbRenderer = $this->listaUsuarios->get_column(0)->get_cell_renderers();
		$this->listaUsuarios->get_column(0)->set_cell_data_func($pbRenderer[0], array($this, "format_Mute_pixbuf")); 
		
		$this->listaUsuarios->connect('row-activated', array($this, 'on_Mute_dclicked'));
		$linhas->pack_start($this->listaUsuarios);
		
		$this->add($linhas);
	}
	
	function format_Mute_pixbuf($column, $cell, $store, $iter) {
		list($numUsu, $d) = explode(" - ", $store->get_value($iter, 3));
		if($this->listaMudo[$numUsu]) $cell->set_property('pixbuf', $this->pbCxSomMute);
		else                          $cell->set_property('pixbuf', $this->pbCxSom);
	}
	
	function on_Encerra_clicked($btn) {
		global $painelOp;
		$painelOp->enviaComando("Command", array(
				"command" => "meetme kick $this->numSala all"
			));
		$this->hide_all();
	}
	
	function on_Lock_clicked($btn) {
		global $painelOp;
		if($btn->get_label() == "Fechar Sala") {
			$btn->set_label("Abrir Sala");
			$painelOp->enviaComando("Command", array(
					"command" => "meetme lock $this->numSala"
				));
		} else {
			$btn->set_label("Fechar Sala");
			$painelOp->enviaComando("Command", array(
					"command" => "meetme unlock $this->numSala"
				));
		}
	}
	
	function on_Mute_dclicked($treeview, $path, $column) {
		if($column->get_title() == "Mute") {
			global $painelOp;
			$store = $this->listaUsuarios->get_model();
			$iter = $store->get_iter($path);
			list($numUsu, $d) = explode(" - ", $store->get_value($iter, 3));
			$this->listaMudo[$numUsu] = !$this->listaMudo[$numUsu];
			if($this->listaMudo[$numUsu]) {
				$painelOp->enviaComando("Command", array(
						"command" => "meetme mute $this->numSala $numUsu"
					));
			} else {
				$painelOp->enviaComando("Command", array(
						"command" => "meetme unmute $this->numSala $numUsu"
					));				
			}
		} else if($column->get_title() == "Kick") {
			global $painelOp;
			$store = $this->listaUsuarios->get_model();
			$iter = $store->get_iter($path);
			list($numUsu, $d) = explode(" - ", $store->get_value($iter, 3));
			$painelOp->enviaComando("Command", array(
					"command" => "meetme kick $this->numSala $numUsu"
				));
		}
	}
	
	function addUsuario($usu, $num) {
		if(!is_a($usu, "Usuario")) return;
		$iter = $this->listaUsuarios->addLinha("gfx/cxSom.png,gfx/kick.png,$usu->ramal,$num - $usu->nome");
		$this->listaMudo[$num] = false;
	}
	
	function delUsuario($usu) {
		if(!is_a($usu, "Usuario")) return;
		$this->listaUsuarios->delLinha("Ramal", $usu->ramal);
	}
	
	function contaUsuarios() {
		return $this->listaUsuarios->total();
	}
	
	function fecha() {
		$this->hide_all();
		return true;
	}
}

?>
