#!/bin/bash 

#------------------------------------------------------------------
# MODULO - UCARP.SH - 
#
# DATA DE MODIFICAO:
# DESCRI�AO DA ALTERACAO:
#------------------------------------------------------------------

grava_log()
{
    echo -e "$(date '+%F %T') $MODULO - $MSG" >> $ARQ_LOG
}

#------------------------------------------------------------------
# MODULO PRINCIPAL
#------------------------------------------------------------------


MODULO="T.SH"
ARQ_LOG="/var/log/cluster.log"
LOCALHOST=$(uname -n)

HOST_MASTER="Master"
HOST_SLAVE="Slave"
IP_VIRTUAL="192.168.254.237"
IP_HOSTMASTER="192.168.254.235"
IP_HOSTSLAVE="192.168.254.236"

UCARP="/usr/local/sbin/ucarp"
VID="50"
PWD="PWD50"
INTERFACE="eth0"
UP="/aplic/scripts/ucarp/up.sh"
DOWN="/aplic/scripts/ucarp/down.sh"

#-------------------------------------------------------
#   O NOH MASTER NAO PODE ENTRAR DIRETAMENTE, EH 
#   NECESSARIO VERIFICAR SE O NOH SLAVE ESTA PRESENTE E 
#   E SE ESTIVER, SERAH NECESSARIO SINCRONIZAR O DISCO ENTRE
#   O MASTER E O SLAVE
#
#-------------------------------------------------------
#        Verifica o estado atual de cada NO
#-------------------------------------------------------

MSG="VERIFICANDO SINCRONIZACAO DO DISCO ...";grava_log
if [ $LOCALHOST == $HOST_MASTER ]
then
       while true
       do
            if [ -f /proc/drbd ]
            then
                  break
            fi
            MSG="AGUARDANDO DRBD ......";grava_log
	    sleep 1
       done

       while true 
       do
           ping -c 1 $IP_HOSTSLAVE > /dev/null
           if [ $? -eq 0 ]
           then
                   STATE=$(drbdadm dstate all | cut -d \/ -f 1)   #Estado Local
                   STATE2=$(drbdadm dstate all | cut -d \/ -f 2)  #Estado Remoto
                   STATE3=$(drbdadm cstate all )  #Estado da conexao
                   STATE4=$(drbdadm state all | cut -d \/ -f 1)   #Estado Local
                   STATE5=$(drbdadm state all | cut -d \/ -f 2)  #Estado Remoto
		   if [ $STATE =  "UpToDate" -a $STATE2 = "UpToDate" -a $STATE3 = "Connected" ]
                   then
		         break
		   else
                         MSG="SINCRONIZANDO OS DISCOS ... $(cat /proc/drbd)";grava_log
                         MSG="ESPERANDO SITUACAO IDEAL UPDATE/UPDATE/CONNECTED";grava_log
		         sleep 1
		   fi
	   else
	           break
	   fi
       done
fi   

