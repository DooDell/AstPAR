#!/bin/bash

#--------------------------------------------------------------------------
#
#  MODULO: CHECK_DRBD.SH
#
#  OBJETIVO: RESOLVER PROBLEMAS DE SPLIT BRAIN. ESTA SITUACAO OCORRE QUANDO
#            EXISTEM DOIS NOHS PRIMARIOS
#
#            O CONTEUDO DE UM DOS DOIS SERA DESPREZADO
#
#--------------------------------------------------------------------------

grava_log()
{
    echo -e "$(date '+%F %T') $MODULO - $MSG" >> $ARQ_LOG
}



#-----------------------------------------------------
#        FUNCAO PRINCIPAL
#-----------------------------------------------------

MODULO="CHECK_DRBD.SH"
ARQ_LOG="/var/log/cluster.log"
SCRIPT_DRBD="/aplic/scripts/drbd/drbd.sh"
LOCALHOST=$(uname -n)
HOSTMASTER="Master"
HOSTSLAVE="Slave"
IP_VIRTUAL="192.168.254.237"
IP_HOSTMASTER="192.168.254.235"
IP_HOSTSLAVE="192.168.254.236"

if [ $LOCALHOST = $HOSTMASTER ]
then
       IP=$IP_HOSTSLAVE
else
       IP=$IP_HOSTMASTER
fi


while true 
do
      drbdadm state all > /dev/null

      if [ $? -ne 0 ]
      then
            drbdadm up all > /dev/null
      fi

      ip addr show | grep -v grep | grep $IP_VIRTUAL > /dev/null

      IFCONFIG=$?

      if [ $IFCONFIG -eq 0 ] #Interface Virtual esta presente neste noh
      then
            #---------------------------------------------------
            #   Verifica o estado atual (Primary/Secondary)
            #   do noh
            #---------------------------------------------------

            MSG="Verificando Situacao do MASTER";grava_log
            CSTATE=$(drbdadm cstate all)
            STATE=$( drbdadm state all | cut -d \/ -f 1)

	    #---------------------------------------------------
	    #   SE O ESTADO DA CONEXAO ESTA EM STANDALONE
	    #   ENTAO DEVEMOS TRATAR O SPLIT BRAIN
	    #---------------------------------------------------

            if [ $CSTATE = "StandAlone" ]
            then
                   MSG="FAZENDO TRATAMENTO SPLIT BRAIN NO MASTER";grava_log
                   ping -c 1 -w 1 $IP > /dev/null
		   if  [ $? -eq 0 ] 
		   then
                          MSG="Entrando em modo Secondary";grava_log
                          $SCRIPT_DRBD secondary
                          drbdadm connect all
                          sleep 2
                          MSG="Entrando em modo Primary";grava_log
                          $SCRIPT_DRBD primary
                          sleep 2
	           fi

		   if [ $STATE = "Secondary" ]
		   then 
                          MSG="Entrando em modo Primary";grava_log
                          $SCRIPT_DRBD primary
                          sleep 2
	           fi
             fi

             #-------------------------------------------------------
	     #    AVISO DE SINCRONIZACAO DE DISCOS
	     #-------------------------------------------------------

             if  [ $CSTATE = "SyncTarget" -o $CSTATE = "SyncSource" ]
             then           
                      MSG="Sincronizacao de disco";grava_log
             fi
 
      else #endereco 10.15.151.50 nao esta no HOST

             MSG="Verificando Situacao do SLAVE";grava_log
             CSTATE=$(drbdadm cstate all)  #Connetec/WaitForConnection/StandAlone
             STATE=$( drbdadm state all | cut -d \/ -f 1)

             #---------------------------------------------------
	     #   SE O ESTADO DA CONEXAO ESTA EM STANDALONE
	     #   ENTAO DEVEMOS TRATAR O SPLIT BRAIN
	     #---------------------------------------------------

             if [ $CSTATE = "StandAlone" ]
             then
                   MSG="FAZENDO TRATAMENTO SPLIT BRAIN NO SLAVE";grava_log
                   MSG="Entrando em modo Secondary";grava_log
                   $SCRIPT_DRBD secondary
                   drbdadm -- --discard-my-data connect all
		   sleep 5
             fi

      fi
      sleep 15
done

