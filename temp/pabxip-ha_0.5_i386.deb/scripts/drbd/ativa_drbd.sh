#!/bin/bash 

#------------------------------------------------------------------
# MODULO - ATIVA_DRBD.SH
#
# OBJETIVO: ATIVA SERVICO DRBD NA MAQUINA LOCAL
#
# DATA DE MODIFICAO:
# DESCRICAO DA ALTERACAO:
#------------------------------------------------------------------

#==================================================================
#   FUNCAO - GRAVA_LOG
#
#   OBJETIVO - GRAVACAO DE LOG NO ARQUIVO /VAR/LOG/CLUSTER.LOG
#==================================================================
grava_log()
{
    echo -e "$(date '+%F %T') $MODULO - $MSG" >> $ARQ_LOG
}


#======================================
#        Inicio do modulo principal
#======================================

LOCALHOST=$(uname -n)
MODULO="ATIVA_DRBD.SH"
ARQ_LOG="/var/log/cluster.log"
DRBD_SH="/aplic/scripts/drbd/drbd.sh"
HOST_MASTER="Master"
HOST_SLAVE="Slave"
IP_VIRTUAL="192.168.254.237"
IP_HOSTMASTER="192.168.254.235"
IP_HOSTSLAVE="192.168.254.236"

#---------------------------------------------------
#     Verifica se modulo DRBD esta carregado
#---------------------------------------------------

while true
do
    MSG="Verificando modulos do  DRBD";grava_log
    lsmod | grep -v grep | grep drbd > /dev/null
    if [ $? -eq	 0 ]
    then
          MSG="Modul DRBD esta Carregado";grava_log
          break
    else
          MSG="Aguardando carga do modulo DRBD";grava_log
	  sleep 2
    fi
done

#---------------------------------------------------
#     Verifica DRBD foi ativado
#---------------------------------------------------

while true
do
    MSG="Verificando se DRBD esta Ativo";grava_log
    if [ -f /proc/drbd ]
    then
           cat /proc/drbd | grep -v grep | grep 'ds:' > /dev/null
           if [ $? -eq 0 ]
	   then
                 MSG="DRBD esta Ativo";grava_log
                 break
           fi
           MSG="Aguardando Ativacao do DRBD";grava_log
	   sleep 10
    else
          MSG="ARQUIVO /PROC/NAO FOI ENCONTRADO, ENCERRANDO SCRIPT ..";grava_log
	  exit 1
    fi
done

#---------------------------------------------------
#     Ativa DRBD como Secundario
#---------------------------------------------------

STATE4=$(drbdadm state all | cut -d \/ -f 1)   #Estado Local

if [ $STATE4 != "Primary" ]
then
        $DRBD_SH secondary
fi

#----------------------------------------------------
#      LOOPING ETERNO DE VERIFICAO
#----------------------------------------------------

while true
do
       MSG="--------------------------------------------";grava_log
       MSG="       INICIO DE BLOCO DE VERIFICACAO       ";grava_log
       MSG="--------------------------------------------";grava_log
       #-------------------------------------------------#
       #   Verifica se interface virtual esta presente   #
       #-------------------------------------------------#

       ip addr | grep -v grep | grep $IP_VIRTUAL > /dev/null

       if [ $? -eq 0 ]
       then
               MSG="Interface Virtual esta presente neste noh  ..";grava_log
               #--------------------------#
	       #   Verifica endereco IP   #
	       #--------------------------#
	       if [ $LOCALHOST == $HOST_MASTER ]
	       then
                     IP=$IP_HOSTSLAVE
	       else
                     IP=$IP_HOSTMASTER
	       fi

               STATE=$(drbdadm dstate all | cut -d \/ -f 1)   #Estado Local
               STATE2=$(drbdadm dstate all | cut -d \/ -f 2)  #Estado Remoto
               STATE3=$(drbdadm cstate all )  #Estado da conexao
               STATE4=$(drbdadm state all | cut -d \/ -f 1)   #Estado Local
               STATE5=$(drbdadm state all | cut -d \/ -f 2)  #Estado Remoto

	       #--------------------------#
	       # Verifica se o noh remoto #
	       # esta respondendo         #
	       #--------------------------#
	       ping -c 1 -w 1 $IP > /dev/null

               if [ $? -eq 0 ]
	       then
                      MSG="Noh Remoto esta respondendo ping ..";grava_log

		      #---------------------------#
		      # Verifica se o estado      #
		      # da conexao de rede local  #  
		      # eh connected              #
		      #---------------------------#
		      if [ $STATE3 = "Connected" ]
		      then
                             MSG="Noh Local esta CONNECTED ..";grava_log
		             #--------------------------#
			     # Verifica se o estado do  #
			     # noh local eh Secondary   #
			     #--------------------------#
		             if [ $STATE4 = "Secondary" ]
		             then
                                   MSG="Noh Local esta como SECONDARY ..";grava_log
                                   #---------------------------------#
                                   # Verifica se o estado do noh     #
				   # remoto eh Secondary             #
				   #---------------------------------#
                                   if [ $STATE5 = "Secondary" ]
				   then
                                         MSG="Noh Remoto esta como SECONDARY ..";grava_log
				         #------------------------------------#
					 # Verifica se o estado do disco      #
					 # local eh UpToDate                  #
					 #------------------------------------#
					 if [ $STATE = "UpToDate" ]
					 then
                                               MSG="Disco Local eh UPTODATE ..";grava_log
					       #--------------------------------------#
					       # Verifica se o estado do disco remoto #
					       # eth UpToDate                         #
					       #--------------------------------------#
					       if [ $STATE2 = "UpToDate" ]
					       then
                                                     MSG="Disco remoto eh UPTODATE ..";grava_log
                                                     MSG="Entrando em modo PRIMARY ..";grava_log
						     $DRBD_SH primary
					       else #Aqui o noh remoto nao eh UpToDate
                                                     MSG="Disk remoto NAO EH UPTODATE..";grava_log
                                                     MSG="Sincronizando Disco .. $STATE2";grava_log
					       fi
					 else #Aqui o noh local nao eh UpToDate
                                               MSG="Disk Local NAH EH UPTODATE ..";grava_log
                                               MSG="Sincronizando Disco ..$STATE";grava_log
					 fi
			           else #Aqui o noh remoto nao eh secondary
                                         MSG="Noh remoto EH PRIMARY ..";grava_log
				   fi
			     else #Aqui o noh local nao eh secondary
                                   MSG="Noh local EH PRIMARY ..";grava_log
			     fi
                      else #Aqui o noh local nao esta connected
                             MSG="No Local NAO ESTA CONNECTED .. $STATE3";grava_log
		      fi
	       else #Aqui nao fez Ping com o noh remoto
                      MSG="Nao fez Ping com o noh remoto ..";grava_log
		      if [ $STATE4 != "Primary" ]
		      then
                              MSG="Entrando em modo PRIMARY SEM CONEXAO COM REMOTO..";grava_log
			      $DRBD_SH primary
		      else
		              
                              MSG="Mas nao tem problema, SOU PRIMARY ..";grava_log
		      fi
	       fi
       else # Aqui a interface nao esta presente neste noh      

               MSG="A interface Virtual nao esta presente neste Noh ..";grava_log
               #--------------------------#
	       #   Verifica endereco IP   #
	       #--------------------------#
	       if [ $LOCALHOST == $HOST_MASTER ]
	       then
                     IP=$IP_HOSTSLAVE
	       else
                     IP=$IP_HOSTMASTER
	       fi

               STATE=$(drbdadm dstate all | cut -d \/ -f 1)   #Estado Local
               STATE2=$(drbdadm dstate all | cut -d \/ -f 2)  #Estado Remoto
               STATE3=$(drbdadm cstate all )  #Estado da conexao
               STATE4=$(drbdadm state all | cut -d \/ -f 1)   #Estado Local
               STATE5=$(drbdadm state all | cut -d \/ -f 2)  #Estado Remoto

	       #--------------------------#
	       # Verifica se o noh remoto #
	       # esta respondendo         #
	       #--------------------------#
	       ping -c 1 -w 1 $IP > /dev/null

               if [ $? -eq 0 ]
	       then
                      MSG="Noh Remoto esta respondendo ping ..";grava_log

		      #---------------------------#
		      # Verifica se o estado      #
		      # da conexao de rede local  #  
		      # eh connected              #
		      #---------------------------#
		      if [ $STATE3 = "Connected" ]
		      then
                             MSG="Noh Local esta CONNECTED ..";grava_log
		             #--------------------------#
			     # Verifica se o estado do  #
			     # noh local eh Secondary   #
			     #--------------------------#
		             if [ $STATE4 = "Secondary" ]
		             then
                                   MSG="Noh Local esta como SECONDARY ..";grava_log
                                   #---------------------------------#
                                   # Verifica se o estado do noh     #
				   # remoto eh Secondary             #
				   #---------------------------------#
                                   if [ $STATE5 = "Secondary" ]
				   then
                                         MSG="Noh Remoto esta como SECONDARY ..";grava_log
				         #------------------------------------#
					 # Verifica se o estado do disco      #
					 # local eh UpToDate                  #
					 #------------------------------------#
					 if [ $STATE = "UpToDate" ]
					 then
                                               MSG="Disco Local eh UPTODATE ..";grava_log
					       #--------------------------------------#
					       # Verifica se o estado do disco remoto #
					       # eth UpToDate                         #
					       #--------------------------------------#
					       if [ $STATE2 = "UpToDate" ]
					       then
                                                     MSG="Disco remoto eh UPTODATE ..";grava_log
                                                     MSG="ESPERANDO MASTER ENTRAR ..";grava_log
					       else #Aqui o noh remoto nao eh UpToDate
                                                     MSG="Disk remoto NAO EH UPTODATE..";grava_log
                                                     MSG="Sincronizando Disco .. $STATE2";grava_log
					       fi
					 else #Aqui o noh local nao eh UpToDate
                                               MSG="Disk Local NAH EH UPTODATE ..";grava_log
                                               MSG="Sincronizando Disco ..$STATE";grava_log
					 fi
			           else #Aqui o noh remoto nao eh secondary
                                         MSG="Noh remoto EH PRIMARY ..";grava_log
				   fi
			     else #Aqui o noh local nao eh secondary
                                   MSG="Noh local EH PRIMARY ..";grava_log
                                   MSG="Noh local entrando em SECONDARY ..";grava_log
			           $DRBD_SH secondary
			     fi
                      else #Aqui o noh local nao esta connected
                             MSG="No Local NAO ESTA CONNECTED ..$STATE3";grava_log
		      fi
	       else #Aqui nao fez Ping com o noh remoto
                      MSG="Nao fez Ping com o noh remoto ..";grava_log
		      if [ $STATE4 != "Primary" ]
		      then
                              MSG="Entrando em modo PRIMARY SEM CONEXAO COM REMOTO";grava_log
			      $DRBD_SH primary
		      else
		              
                              MSG="Mas nao tem problema, SOU PRIMARY ..";grava_log
		      fi
	      fi
       fi

       MSG="--------------------------------------------";grava_log
       MSG="         FINAL DO BLOCO DE VERIFICACAO      ";grava_log
       MSG="--------------------------------------------";grava_log
       sleep 5
done

