#!/bin/bash

./down.sh
killall -9 ucarp
../drbd/drbd.sh stop

