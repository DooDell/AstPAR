#!/bin/bash -x
#------------------------------------------------------------------
# ucarp.sh
# Script de inicalizacao do uCARP
#------------------------------------------------------------------

MODULO="UCARP.SH"
source /usr/lib/telefoniaip/modulos/Ferramentas/telipHA/clusterConfig.sh

UP="/usr/lib/telefoniaip/modulos/Ferramentas/telipHA/ucarp/up.sh"
DOWN="/usr/lib/telefoniaip/modulos/Ferramentas/telipHA/ucarp/down.sh"

start()
{
	MSG="INICIANDO EXECUCAO DO MODULO UCARP.SH";grava_log
	
	#--------------------------------------------------------------
	#     ESTE PROCEDIMENTO DEVE SER EXECUTADO PARA VERIFICAR SE 
	#     PLACA DE REDE JA ESTA CONFIGURADA.
	#     SE A PLACA DE REDE N�O ESTIVER DISPONIVEL, OCORRERA UM
	#     ERRO COM A INICIALIZACAO DO UCARP
	#---------------------------------------------------------------
	while true; do
		MSG="PROCURANDO O IP $IP_LOCAL NA INTERFACE $INTERFACE";grava_log
		ifconfig $INTERFACE | grep $IP_LOCAL > /dev/null
		if [ $? -eq 0 ]; then
			break
		fi
		sleep 1
	done
	
	MSG="VERIFICANDO HOSTNAME E ENDERECAMENTO IP";grava_log
	if [ $LOCALHOST == $HOST_MASTER ]; then
		PREFERENCE="-P"
		PESO="1" 
	else
		PREFERENCE=" "
		PESO="3"
	fi

	MSG="EXECUTANDO UCARP ";grava_log

	#----------------------------------------------------
	#    PARAMETROS DO UCARP
	#---------------------------------------------------
	#    i - Interface de escuta de multicast
	#    s - Endereco IP real da interface
	#    v - Identificacao de grupo
	#    p - Senha de autenticacao de grupo
	#    a - Endereco IP Virtual
	#    u - Script a ser executado em modo UP
	#    d - Script a ser executado em modo DOWN
	#    B - Execucao em modo Background
	#    b - Intervalo de envio de mensagem keepalive
	#    r - Tempo de espera para considerar "morto" um noh do cluster
	#    k - Preferencia para assumir o papel de MASTER
	#        Quanto menor o valor melhor a preferencia
	#----------------------------------------------------
	$UCARP -i $INTERFACE $PREFERENCE -s $IP_LOCAL -v $VID -p $PWD -a $IP_VIRTUAL -u $UP -d $DOWN -B -b $INTERVALO_PING -r $MAX_NO_PING -k $PESO
}

stop()
{
	. $DOWN
	killall -9 ucarp
}

case "$1" in
	start) start
		;;
	stop)  stop
		;;
	*)     MSG="Parametro Invalido (uso: start/stop)";grava_log
		;;
esac

