#!/bin/bash

MODULO="INSTALL.SH"
source /usr/lib/telefoniaip/modulos/Ferramentas/telipHA/clusterConfig.sh

instala()
{
	MSG="Iniciando verificacao de instalacao";grava_log
	
	lsmod | grep -v grep | grep drbd > /dev/null
	if [ $? -eq 1 ]; then
		/sbin/modprobe drbd > /dev/null
		lsmod | grep -v grep | grep drbd > /dev/null
		if [ $? -eq 1 ]
		then
			MSG="ERRO DE CARGA DO MODULO DRBD. O pacote [pabxip-ha] esta instalado??";grava_log
			exit 1
		else
			MSG="Modulo DRBD Carregado com Sucesso";grava_log
		fi
	else
		MSG="Modulos do DRBD jah estao carregados";grava_log
	fi
	
	if [ ! -x $UCARP ]; then
		MSG="IMPOSSIVEL ACHAR BINARIO DO UCARP. O pacote [pabxip-ha] esta instalado??";grava_log
		exit 2
	fi
	
	MSG="Verificando links DRBD";grava_log
	# /etc/asterisk                -> /drbd0/etc/asterisk
	# /var/lib/postgresql/8.1/main -> /drbd0/var/lib/postgresql/8.1/main
			
	if [ $LOCALHOST = $HOST_MASTER ]; then
		MSG="Somos MASTER.";grava_log
	else
		MSG="Somos SLAVE.";grava_log
	fi
}

desinstala()
{
	
}

case "$1" in
	install)   instala
	;;

	uninstall) desinstala
	;;

	*)    MSG="Parametro Invalido (uso: install/uninstall)";grava_log
	;;
esac
