#------------------------------------------------------------------
# clusterConfig.sh
#------------------------------------------------------------------

ARQ_LOG="/var/log/telipHA.log"   # Arquivo para logar as mensagens do cluster

#------------------------------------------------------------------
# Configuracoes de rede
#------------------------------------------------------------------
HOST_MASTER="PABX"              # Hostnames \
HOST_SLAVE="OBELIX"             # \ Devem ser iguais aos de (uname -n)
IP_VIRTUAL="192.168.0.60:eth0"  # Formato: "IP_1:IFACE_1 IP2:IFACE_2 ..."
IP_HOSTMASTER="192.168.0.61"    # IPs fixos \
IP_HOSTSLAVE="192.168.0.62"     # \
GW="192.168.0.1"                # Utilizado para "ativar" a rede (ping)
REDE="/24"                      # Classe da rede

#------------------------------------------------------------------
# Configuracoes do DRBD
#------------------------------------------------------------------
DRBD_ATIVO=0
DRBD_MAX_TIMEOUT=180
DRBD_DEV=/dev/drbd0
DRBD_MOUNT=/drbd0

#------------------------------------------------------------------
# Configuracoes do uCARP
#------------------------------------------------------------------
UCARP_INTERVALO_PING=1  # Intervalo de tempo entre os "PINGs" do uCarp
UCARP_MAX_NO_PING=2     # Numero de "PINGs" perdidos para decretar o MASTER como "morto"
UCARP_VID="237"         # Identificacao de grupo
UCARP_PWD="PWD237"      # Senha de autenticacao de grupo
UCARP="/usr/lib/telefoniaip/modulos/Ferramentas/telipHA/ucarp/bin/ucarp"

#--------------------------------------------
# N�o mexer abaixo
#--------------------------------------------
LOCALHOST=$(uname -n)

if [ $LOCALHOST = $HOST_MASTER ]; then
      IP_LOCAL=$IP_HOSTMASTER
else
      IP_LOCAL=$IP_HOSTSLAVE
fi

#--------------------------------------------
# Funcao auxiliar
# $MODULO � definido no script de cada m�dulo
#--------------------------------------------
grava_log () {
    echo -e "$(date '+%F %T') $MODULO - $MSG" >> $ARQ_LOG
}
