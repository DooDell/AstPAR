#!/bin/bash -x

#------------------------------------------------------------------
# ucarp.sh
#
# AUTHOR: AIRTON KUADA / Gabriel Ortiz
# DATA: 08/04/2008
#
# Script de inicalizacao do uCARP
#------------------------------------------------------------------

MODULO="UCARP.SH"
. /aplic/scripts/ucarp/ucarpConfig.sh

#--------------------------------------------------------------
#     ESTE PROCEDIMENTO DEVE SER EXECUTADO PARA VERIFICAR SE 
#     PLACA DE REDE JA ESTA CONFIGURADA.
#     SE A PLACA DE REDE N�O ESTIVER DISPONIVEL, OCORRERA UM
#     ERRO COM A INICIALIZACAO DO UCARP
#---------------------------------------------------------------

MSG="INICIANDO EXECUCAO DO MODULO UCARP.SH";grava_log

if [ $LOCALHOST == $HOST_MASTER ]; then
      IP=$IP_HOSTMASTER
else
      IP=$IP_HOSTSLAVE
fi

while true; do
      ifconfig $INTERFACE | grep $IP > /dev/null
      if [ $? -eq 0 ]; then
           break
      fi
done

MSG="VERIFICANDO HOSTNAME E ENDERECAMENTO IP";grava_log

if [ $LOCALHOST == $HOST_MASTER ]; then
       IP_LOCAL=$IP_HOSTMASTER
       PREFERENCE="-P"
       PESO="1" 
else
       IP_LOCAL=$IP_HOSTSLAVE
       PREFERENCE=" "
       PESO="3"
fi

MSG="EXECUTANDO UCARP ";grava_log

$UCARP -i $INTERFACE $PREFERENCE -s $IP_LOCAL -v $VID -p $PWD -a $IP_VIRTUAL -u $UP -d $DOWN -B -b $INTERVALO_PING -r $MAX_NO_PING -k $PESO

