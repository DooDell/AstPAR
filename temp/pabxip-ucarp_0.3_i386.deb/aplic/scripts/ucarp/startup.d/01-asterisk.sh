#!/bin/bash

/usr/sbin/safe_asterisk
sleep 2

