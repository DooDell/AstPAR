#!/bin/bash

/usr/local/bin/sipsak -s sip:9@127.0.0.1 > /dev/null
if [ $? -eq 0 ]; then
	MSG="UP: Asterisk foi inicializado com Sucesso";grava_log
else
	MSG="UP: PROBLEMAS NA INICIALIZACAO DO Asterisk";grava_log
fi

