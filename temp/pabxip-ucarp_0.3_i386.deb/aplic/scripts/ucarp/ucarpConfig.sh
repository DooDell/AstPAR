#------------------------------------------------------------------
# ucarpConfig.sh
#------------------------------------------------------------------

#------------------------------------------------------------------
# Configuracoes do uCARP
#------------------------------------------------------------------
HOST_MASTER="PABX"
HOST_SLAVE="OBELIX"
IP_VIRTUAL="192.168.0.18"
IP_HOSTMASTER="192.168.0.6"
IP_HOSTSLAVE="192.168.0.8"
GW="192.168.0.1"
REDE="/24"
VID="237"
PWD="PWD237"
INTERFACE="eth0"

# Intervalo de tempo entre os "PINGs" do uCarp
INTERVALO_PING=1
# Numero de "PINGs" perdidos para decretar o MASTER como "morto"
MAX_NO_PING=2

#--------------------------------------------
# Provavelmente nao e necessario mexer aqui
#--------------------------------------------
UP="/aplic/scripts/ucarp/up.sh"
DOWN="/aplic/scripts/ucarp/down.sh"
UCARP="/aplic/scripts/ucarp/bin/ucarp"
LOCALHOST=$(uname -n | tr 'a-z' 'A-Z')

#--------------------------------------------
# Funcao auxiliar
#--------------------------------------------
ARQ_LOG="/var/log/cluster.log"
grava_log () {
    echo -e "$(date '+%F %T') $MODULO - $MSG" >> $ARQ_LOG
}

