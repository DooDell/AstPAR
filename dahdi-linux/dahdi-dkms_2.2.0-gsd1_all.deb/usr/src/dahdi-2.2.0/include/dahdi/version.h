/*
 * version.h 
 * Automatically generated
 */
#define DAHDI_VERSION "2.2.0-rc5"

