#include <stdlib.h>
#include <stdint.h>
#include <string.h>

#define kmalloc(a,b) malloc((a))
#define kzalloc(a,b) calloc(1,(a))
#define kcalloc(a,b,c) calloc((a),(b))
#define kfree(a) free((a))
#define GFP_KERNEL
#define EXPORT_SYMBOL_GPL(a)
#define MODULE_LICENSE(a)
#define MODULE_AUTHOR(a)
#define MODULE_DESCRIPTION(a)
#define MODULE_VERSION(a)

/* FIXME: get rid of this typedef? */
typedef struct oslec_state echo_can_state_t;
