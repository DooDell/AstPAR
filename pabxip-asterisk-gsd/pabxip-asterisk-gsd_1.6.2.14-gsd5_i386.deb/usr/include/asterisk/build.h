/*
 * build.h 
 * Automatically generated
 */
#define BUILD_HOSTNAME "scelepar00190"
#define BUILD_KERNEL "2.6.26-2-686"
#define BUILD_MACHINE "i686"
#define BUILD_OS "Linux"
#define BUILD_DATE "2011-08-18 14:38:44 UTC"
#define BUILD_USER "root"

