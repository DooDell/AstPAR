/*
 * version.h 
 * Automatically generated
 */
#define ASTERISK_VERSION "1.6.2.14-gsd5"
#define ASTERISK_VERSION_NUM 10602

