<?php
class Lista extends GtkTreeView
{
	private $colunas;
	
	// Ex.: new Lista("Img&P Ramal Nome"); : Img = Imagem, Ramal e Nome = String(default)
	function __construct($colunas, $bgRowArray=NULL, $bgColorArray=NULL) {
		$tipoColunas = null;
		$c=0;
		$strGtkListStore = "\$tipoColunas = new GtkListStore(";
		foreach(explode(",", $colunas) as $col) {
			if($c) $strGtkListStore .= ",";
			$strGtkListStore .= "GObject::TYPE_STRING";
			$c++;
		}
		eval($strGtkListStore.");");
		parent::__construct($tipoColunas);

		$this->colunas = $colunas;
		$this->bgCol = $bgRowArray;
		$this->bgCor = $bgColorArray;
		$c = 0;
		foreach(explode(",", $colunas) as $col) {
			$tipo = "S";
			$column = null;
			if(strstr($col, "&")) list($col, $tipo) = explode("&", $col);
	        if ($tipo == 'P') {
	            $cell_renderer = new GtkCellRendererPixbuf(); 
	            $column = new GtkTreeViewColumn($col);
	            $column->pack_start($cell_renderer); 
	            $column->set_cell_data_func($cell_renderer, array($this, 'setaImagem'), $c); 
	        } else {
	            $cell_renderer = new GtkCellRendererText();
	            $column = new GtkTreeViewColumn($col, $cell_renderer, 'text', $c);
	            $column->set_expand(1);
	            $column->set_cell_data_func($cell_renderer, array($this, 'setaBg'), $c); 
	        }
			$column->set_sort_column_id($c++);
	        $this->append_column($column);
		}
	}
	
	
	function setaImagem($column, $cell, $model, $iter, $col_num) {
		$gfx = $model->get_value($iter, $col_num);
		$pixbuf = GdkPixbuf::new_from_file('gfx/' . $gfx);
		$cell->set_property('pixbuf', $pixbuf);
	}
	
	function setLinha($nomeColunaProcura, $valorProcura, $nomeColunaSet, $valorSet) {
		$store = $this->get_model();
		$posColunaProcura = -1;
		$posColunaSet     = -1;
		
		$c = 0;
		foreach(explode(",", $this->colunas) as $col) {
			if(strstr($col, "&")) list($col, $t) = explode("&", $col);
			if($col == $nomeColunaProcura)
				$posColunaProcura = $c;
			if($col == $nomeColunaSet)
				$posColunaSet = $c;
			$c++;
		}
		
		if($posColunaProcura >= 0)
			foreach ($store as $row) {
				$iter = $row->iter;
				if($store->get_value($iter, $posColunaProcura) == $valorProcura) {
					$store->set($iter, $posColunaSet, $valorSet);
					break;
				}
			}
	}
	
	function addLinha($txt) {
		$store = $this->get_model();
		$iter  = $store->append();
		$col = 0;
		foreach(explode(",", $txt) as $t) {
			$store->set($iter, $col, $t);
			$col++;
		}
		return $iter;
	}
	
	function delLinha($nomeColuna, $valor) {
		$store = $this->get_model();
		$posColuna = -1;
		
		$c = 0;
		foreach(explode(",", $this->colunas) as $col) {
			if(strstr($col, "&")) list($col, $t) = explode("&", $col);
			if($col == $nomeColuna) {
				$posColuna = $c;
				break;
			}
			$c++;
		}
		
		if($posColuna >= 0)
			foreach ($store as $row) {
				$iter = $row->iter;
				if($store->get_value($iter, $posColuna) == $valor) {
					$store->remove($iter);
					break;
				}
			}
	}
	
	function setaBG($column, $cell, $model, $iter, $col_num) {
		$txt = $model->get_value($iter, $col_num);
		$cell->set_property('text', $txt);
		if(is_array($this->bgCol) && is_array($this->bgCor) && in_array($col_num, $this->bgCol) && in_array($txt, array_keys($this->bgCor))) {
			$row_color = $this->bgCor[$txt];
    		$cell->set_property('cell-background', $row_color);
		}
	}	
	
	function limpa() {
		if ($this->get_model())
			$this->get_model()->clear();
	}
	
	function total() {
		return count($this->get_model());
	}
	
	function setOrdena($ordenado) {
		$c = 0;
		foreach($this->get_columns() as $col) {
			$id = $ordenado	?	$c++	:	-1;
			$col->set_sort_column_id($id);
		}
	}
}
?>