<?php
define('CONTEXTO', 'todos');

class PainelOp extends GtkWindow
{
	private $rangeConf, $idTimerCE, $svc_noturno,$chanChamada, $AMI, $usuarios,$prefixoLocal;
	private $telefonistaBuffer,$retencaoBuffer,$ramalServicoNoturno,$listaCallersTelefonista,$tempBuffer,$linkCanais,$cont;
	public $nomeOp, $ramalOp, $telOp, $senhaOp;

	// Widgets
	private $splashWin;
	private $btnDisca, $btnTransfere,$btnPlayback, $btnConf,$btnNoturno,$btnLimpar;
	private $cxSaida, $cxEntrada, $cxProcuraR, $cxProcuraN, $lbTotalOcupados ,$listaOcupados;
	private $btnRetencao1,$btnRetencao2,$btnRetencao3,$btnRetencao4,$btnRetencao5,$btnRetencao6,$btnRetencao7,$btnRetencao8,$btnStyleDefault,$tableRetencao;
	private $filaTelefonista,$listaUsuarios, $janelasConf, $janelaLogin;
		
	public function __construct($parent = null) {

		parent::__construct();
		$this->splashScreen();
		global $conf;
		$this->telefonistaBuffer = array();
		$this->tempBuffer = array();
		$this->retencaoBuffer = array();			
		$this->retencaoBuffer[1]['time']=0;
		$this->retencaoBuffer[2]['time']=0;
		$this->retencaoBuffer[3]['time']=0;
		$this->retencaoBuffer[4]['time']=0;
		$this->retencaoBuffer[5]['time']=0;
		$this->retencaoBuffer[6]['time']=0;
		$this->retencaoBuffer[7]['time']=0;
		$this->retencaoBuffer[8]['time']=0;
		$conf = new Conf();
		$this->timeAlerta = time();
		$this->idTimerCE = 0;
		Gtk::timeout_add(1000, array($this, "posSplash"));
	}

	public function posSplash() {
		$this->splashWin->destroy();
		$this->login();
	}

	public function login() {
		$this->janelaLogin = new JanelaLogin();
		$this->janelaLogin->connect('hide', array($this, 'init'));
		$this->janelaLogin->show_all();
	}

	public function init() {
		$this->connect_simple('destroy', array($this, 'sair'), true);
		$this->set_title("Panoramisk : Painel Telefônico");
		$this->set_position(Gtk::WIN_POS_CENTER);
		$this->set_default_size(500, 500);
		$this->set_border_width(8);
		$this->set_icon(GdkPixbuf::new_from_file("gfx/telefonista.png"));
		
		$this->buscaUsuarios();
		$this->initTelefonista();

		if($this->initAMI() === false)
			$this->sair();

		$this->add($this->criaInterface());
		$this->initDados();
		
		$this->idTimerCE = Gtk::timeout_add(1000, array($this, 'checaEventos'));
		$this->desativarSvcNoturno();
		$this->show_all();
	}

	function splashScreen() {
		$this->splashWin = new GtkWindow( gtk::WINDOW_POPUP );
		$this->splashWin->set_position( gtk::WIN_POS_CENTER );
		$this->splashWin->realize();

		$pixbuf = GdkPixbuf::new_from_file("gfx/splash.png");
		list($pixmap, $mask) = $pixbuf->render_pixmap_and_mask(255);
		$splashImg = gtkImage::new_from_pixmap($pixmap, $mask);
		$splashImg->show();

		$this->splashWin->shape_combine_mask($mask, 0, 0);

		$fix = new GtkFixed();
		$fix->put( $splashImg, 0, 0 );
		$this->splashWin->add($fix);
		$this->splashWin->show_all();
	}

	function initAMI() {
		global $conf;		
		$configAMI = array('hostAMI' => $conf->astHost,
							'userAMI' => $this->ramalOp, //Conexão AMI realizado com os dados da telefonista logada!
							'passAMI' => $this->senhaOp);
				
		$this->AMI = new AMI($configAMI);
		if($this->AMI->pacoteLogin === false)	return false;
		//$this->checaEventos($this->AMI->pacoteLogin);
		return true;
	}

	function shutAMI() {
		if(is_a($this->AMI, "AMI"))
		$this->AMI->logoff();
		if($this->idTimerCE)
		Gtk::timeout_remove($this->idTimerCE);
	}
	
	/*
	 * Obtem as informações atualizadas do PABX para posterior apresentação 
	 * e/ou recuperação das funcionalidades a serem realizadas pela telefonista
	 */
	function initDados() {
		//Chama métodos de atualização dos dados
		$this->carregaCanaisOcupados();
		$this->carregaUsuarios();
		$this->carregaFilaTelefonista();
		$this->carregaCanaisRetidos();
		
	}

	function criaInterface() {
		$this->ramalServicoNoturno = Util::getRamalSVCNoturno();//Verifica ativação so serviço noturno pelo Ramal salvo no banco e nao pela FLAG svcnot_ativo
		
		$box = new GtkHBox();//Janela principal, onde agrupará todos os outros elementos gráficos

		$vbox = new GtkVBox();//Área mais a esquerda que agrupa os frames de Funções, Retenção e Fila

		// ------FRAME FUNÇÕES Linha 1 - cxTexto + 3 botões ---------
		$hboxFunc = new GtkHBox();

		$this->cxSaida = new GtkEntry();
		$this->cxSaida->modify_font(new PangoFontDescription("Arial Bold 12"));
		$this->cxSaida->connect('changed', array($this, 'on_CxDisca_changed'));
		$hboxFunc->pack_start($this->cxSaida,false);

		$btnLimpa = new GtkButton("Limpar");
		$btnLimpa->connect('clicked', array($this, 'on_Limpar_CxDisca'));
		$btnLimpa->set_size_request(50,30);
		$btnLimpa->set_sensitive(true);
		$hboxFunc->pack_start($btnLimpa,false);

		$this->btnDisca = new GtkButton("Disca");
		$this->btnDisca->set_image(GtkImage::new_from_file("gfx/disca.png"));
		$this->btnDisca->connect('clicked', array($this, 'on_Disca_clicked'));
		$this->btnDisca->set_size_request(60,30);
		$this->btnDisca->set_sensitive(false);
		$hboxFunc->pack_start($this->btnDisca,false);

		$this->btnTransfere = new GtkButton("Transfere");
		$this->btnTransfere->set_image(GtkImage::new_from_file("gfx/transfere.png"));
		$this->btnTransfere->connect('clicked', array($this, 'on_Transfere_clicked'));
		$this->btnTransfere->set_size_request(80,30);
		$this->btnTransfere->set_sensitive(false);
		$hboxFunc->pack_start($this->btnTransfere,false);

		$frameFuncao = new GtkFrame(" Funções: ");
		$frameFuncao->add($hboxFunc);
		// add linha 1
		$vbox->pack_start($frameFuncao,false,false);
		// ---------------- EO linha 1 -----------------

		
		// ------FRAME RETENÇÃO  Linha 2 - Botões de Retenção ---------

		$frameRetencao = new GtkFrame();
		$frameRetencao->set_label(" Retenção: ");

		$this->tableRetencao = new GtkTable();
		$this->tableRetencao->set_homogeneous(true);
		$this->tableRetencao->set_col_spacing(0, 50);//set_col_spacing(int column, int spacing);

		// Linha 1 com 2 colunas
		$this->btnRetencao1 = new GtkButton("Reter");
		$this->btnRetencao1->set_size_request(130,30);
		$this->btnRetencao1->connect('clicked', array($this, 'on_Retencao_clicked'));
		$this->tableRetencao->attach($this->btnRetencao1, 0, 1, 0, 1, Gtk::FILL, Gtk::SHRINK);

		$this->btnRetencao2 = new GtkButton("Reter");
		$this->btnRetencao2->set_size_request(130,30);
		$this->btnRetencao2->connect('clicked', array($this, 'on_Retencao_clicked'));
		$this->tableRetencao->attach($this->btnRetencao2 , 1, 2, 0, 1, Gtk::FILL, Gtk::SHRINK);

		//Linha 2 com 2 colunas
		$this->btnRetencao3 = new GtkButton("Reter");
		$this->btnRetencao3->set_size_request(130,30);
		$this->btnRetencao3->connect('clicked', array($this, 'on_Retencao_clicked'));
		$this->tableRetencao->attach($this->btnRetencao3, 0, 1, 1, 2, Gtk::FILL, Gtk::SHRINK);
			
		$this->btnRetencao4 = new GtkButton("Reter");
		$this->btnRetencao4->set_size_request(130,30);
		$this->btnRetencao4->connect('clicked', array($this, 'on_Retencao_clicked'));
		$this->tableRetencao->attach($this->btnRetencao4 , 1, 2, 1, 2, Gtk::FILL, Gtk::SHRINK);

		//Linha 3 com 2 colunas
		$this->btnRetencao5 = new GtkButton("Reter");
		$this->btnRetencao5->set_size_request(130,30);
		$this->btnRetencao5->connect('clicked', array($this, 'on_Retencao_clicked'));
		$this->tableRetencao->attach($this->btnRetencao5, 0, 1, 2, 3, Gtk::FILL, Gtk::SHRINK);
			
		$this->btnRetencao6 = new GtkButton("Reter");
		$this->btnRetencao6->set_size_request(130,30);
		$this->btnRetencao6->connect('clicked', array($this, 'on_Retencao_clicked'));
		$this->tableRetencao->attach($this->btnRetencao6 , 1, 2, 2, 3, Gtk::FILL, Gtk::SHRINK);

		//Linha 4 com 2 colunas
		$this->btnRetencao7 = new GtkButton("Reter");
		$this->btnRetencao7->set_size_request(130,30);
		$this->btnRetencao7->connect('clicked', array($this, 'on_Retencao_clicked'));
		$this->tableRetencao->attach($this->btnRetencao7, 0, 1, 3, 4, Gtk::FILL, Gtk::SHRINK);
			
		$this->btnRetencao8 = new GtkButton("Reter");
		$this->btnRetencao8->set_size_request(130,30);
		$this->btnRetencao8->connect('clicked', array($this, 'on_Retencao_clicked'));
		$this->tableRetencao->attach($this->btnRetencao8 , 1, 2, 3, 4, Gtk::FILL, Gtk::SHRINK);

		$frameRetencao->add($this->tableRetencao);
		$vbox->pack_start($frameRetencao,false,false);
			
		// ------FRAME FILA Linha 3 - Lista chamadas entrantes na Fila Telefonista
		$frameFila = new GtkFrame();
		$frameFila->set_label(" Fila: ");
		$this->lbTotalFila = new GtkLabel();
		$this->lbTotalFila->set_markup("Fila Telefonista : <b>".count($this->filaTelefonista)."</b>");

		$tipoColunas = new GtkListStore(GObject::TYPE_STRING, GObject::TYPE_STRING);
		$this->filaTelefonista = new Lista("Nome,Número", $tipoColunas);
		$this->filaTelefonista->connect('row-activated', array($this, 'on_CapturaDaFila_doubleclicked'));

		$scrolwnd = new GtkScrolledWindow();
		$scrolwnd->set_policy( Gtk::POLICY_AUTOMATIC, Gtk::POLICY_AUTOMATIC);
		$scrolwnd->add($this->filaTelefonista);
		$frameFila->add($scrolwnd);
		$vbox->pack_start($frameFila);
			
		$box->pack_start($vbox);

		// --- Coluna 2 : FRAME RAMAIS ---
		$jpVbox = new GtkVBox();

		//Linha 1 --- PROCURA NOME / RAMAL + Botão Limpar 
		$hboxPesquisa= new GtkHBox();

		$alignment = new GtkAlignment(0.5, 0.5, 0, 0);
		$lbProcuraNome = new GtkLabel("Procura Nome :");
		$lbProcuraNome->set_justify(Gtk::JUSTIFY_LEFT);
		$alignment->add($lbProcuraNome);
		$alignment->set_padding(0,0,15,0);

		$hboxPesquisa->pack_start($alignment);

		$this->cxProcuraN = new GtkEntry();
		$this->cxProcuraN->modify_font(new PangoFontDescription("Arial 12"));
		$this->cxProcuraN->connect('changed', array($this, 'on_CxProcuraN_changed'));
		$this->cxProcuraN->set_size_request(200,30);
		$hboxPesquisa->pack_start($this->cxProcuraN);


		$alignment = new GtkAlignment(0.5, 0.5, 0, 0);
		$lbProcuraRamal = new GtkLabel("Procura Ramal :");
		$lbProcuraRamal->set_justify(Gtk::JUSTIFY_LEFT);
		$alignment->add($lbProcuraRamal);
		$alignment->set_padding(0,0,15,0);

		$hboxPesquisa->pack_start($alignment);

		$this->cxProcuraR = new GtkEntry("", 4);
		$this->cxProcuraR->modify_font(new PangoFontDescription("Arial 12"));
		$this->cxProcuraR->connect('changed', array($this, 'on_CxProcuraR_changed'));
		$this->cxProcuraR->set_size_request(70,30);
		$hboxPesquisa->pack_start($this->cxProcuraR);
			
		$alignment = new GtkAlignment(); // note 3
		$this->btnLimpar = new GtkButton("Limpar");
		$this->btnLimpar->connect('clicked', array($this, 'on_Limpar_clicked'));
		$alignment->add($this->btnLimpar);
		$this->btnLimpar->set_size_request(70,30);

		$hboxPesquisa->pack_start($alignment);

		//$title->set_justify(Gtk::JUSTIFY_CENTER);
		//$alignment = new GtkAlignment(0.5, 0, 0, 0);

		$jpVbox->pack_start($hboxPesquisa,false, false);
			
		$frameRamal= new GtkFrame(" Ramais : ");
		
		//Linha 2 ---LISTA RAMAIS DO PABX ASTERISK
		$tipoColunas   = new GtkListStore(GObject::TYPE_STRING, GObject::TYPE_STRING);
		$this->listaUsuarios = new Lista("Status&P,Ramal,Usuário,Nome de Guerra", $tipoColunas);

		$this->listaUsuarios->connect('cursor-changed', array($this, 'on_LinhaProcura_clicked'));
		$this->listaUsuarios->connect('row-activated', array($this, 'on_LinhaProcura_dclicked'));
		//$this->listaUsuarios->connect('end-selection', array($this, 'on_Limpa_CxDisca'));
		$scrolwnd = new GtkScrolledWindow();
		$scrolwnd->set_policy( Gtk::POLICY_AUTOMATIC, Gtk::POLICY_AUTOMATIC);
		$scrolwnd->add($this->listaUsuarios);
		$jpVbox->pack_start($scrolwnd);
		$frameRamal->add($jpVbox);

		//Linha 3 ---FRAME SERVIÇO NOTURNO + Identificação Telefonista
		$frameIdentificacao = new GtkFrame("Serviço Noturno : ");

		$telPrefHBox = new GtkHBox();
		$this->barraTelefonista = new GtkLabel();
		$this->barraTelefonista->set_markup("Telefonista: $this->nomeOp");

		if(!empty($this->ramalServicoNoturno)){
			$this->btnNoturno = new GtkButton();
			$this->btnNoturno->set_size_request(200,35);
			if($this->svc_noturno == 0){
				$this->btnNoturno->set_label("Ativar Serviço Noturno");
				$this->btnNoturno->set_image(GtkImage::new_from_file("gfx/noturno.png"));
			} else {
				$this->btnNoturno->set_label("Desativar Serviço Noturno");
				$this->btnNoturno->set_image(GtkImage::new_from_file("gfx/noturno_des.png"));
			}
			$this->btnNoturno->connect('clicked', array($this, 'on_Notuno_clicked'));

		}else{
			$this->btnNoturno = new GtkLabel();
			$this->btnNoturno->set_markup("Serviço Noturno não Configurado no PABX");
		}
		$telPrefHBox->pack_start($this->btnNoturno, false, false);
		$telPrefHBox->pack_start(new GtkVSeparator(), true, false, 20);
		$telPrefHBox->pack_start($this->barraTelefonista, false, false);
		$frameIdentificacao->add($telPrefHBox);

		// -------------------------------------------------
		$v = new GtkVBox();
		$v->pack_start($frameRamal);
		$v->pack_start($frameIdentificacao,false,false);
		$box->pack_start(new GtkVSeparator(), true, false, 20);
		$box->pack_start($v);

		// -------------------

		$b = new GtkVBox();
		// ------ Cabeçalho - Logo Celepar + Logo Linux --------
		$hboxLogos = new GtkHBox();

		$hboxLogos->pack_start(GtkImage::new_from_file("gfx/logoProjeto.png"), true,true,20);
		$hboxLogos->pack_start(GtkImage::new_from_file("gfx/logoCelepar.png"), true,true,20);
		$hboxLogos->pack_start(GtkImage::new_from_file("gfx/logoLinux.png"),true,true,20);

		$eventbox = new GtkEventBox();
		$eventbox->modify_bg(Gtk::STATE_NORMAL, GdkColor::parse('#222266'));
		$eventbox->add($hboxLogos);
		$b->pack_start($eventbox, false, true, 8);

		$b->pack_start($box);
		return $b;
	}
		
	function enviaComando($cmd, $params=array(), $debug=false) {
		$pacote = $this->AMI->enviaComando($cmd, $params, $debug);
		$this->checaEventos($pacote);
		return $pacote;
	}

	function on_Limpar_CxDisca(){
		$this->cxSaida->set_text("");
	}

	function on_Limpar_clicked(){
		$this->cxProcuraN->set_text("");
		$this->cxProcuraR->set_text("");
	}

	/*
	 * Ativa ou desativa o serviço noturno no PABX e atualiza as informações na tela 
	 */
	function on_Notuno_clicked($btn) {
		if($this->svc_noturno==1){
			$this->svc_noturno = 0;
			$btn->set_label("Ativar Serviço Noturno");
			//Sai do estado Desativado
			$btn->set_image(GtkImage::new_from_file("gfx/noturno.png"));
		}else{
			//Ativa serviço noturno
			$this->svc_noturno = 1;
			$btn->set_label("Desativar Serviço Noturno");
			$btn->set_image(GtkImage::new_from_file("gfx/noturno_des.png"));
		}
		$this->enviaComando("DBPut", array(
								"Family" => "plano",
								"Key" => "svcnot_ativo",
								"Val" => $this->svc_noturno
		));
	}

	function getStatusSvcNoturno() {
		$pacote = $this->enviaComando("DBGet", array(
								"Family" => "plano",
								"Key" => "svcnot_ativo"
								));
								$aux =& $pacote;
								while($aux){
									if($aux->getAtr('Event') == "DBGetResponse"){
										$this->svc_noturno = $aux->getAtr('Val');
										break;
									}
									$aux = $aux->prox;
								}
	}

	function desativarSvcNoturno() {
		$this->svc_noturno = 0;
		$this->enviaComando("DBPut", array(
								"Family" => "plano",
								"Key" => "svcnot_ativo",
								"Val" => $this->svc_noturno
		));

	}

	function on_Disca_clicked() {
		$this->enviaComando("Originate", array(
								"Channel" => $this->telOp,
								"Context" => CONTEXTO,
								"Exten" => $this->cxSaida->get_text(),
								"Priority" => "1",
								"Callerid" => "6000 TELEFONISTA", //Não identificar o ramal original da telefonista 
								"Timeout" => "15000"
								));
	}
	/* Função de Retenção/Captura das Chamadas no Buffer de Chamadas Retidas ->retencaoBuffer */
	function on_Retencao_clicked($btn) {
			 if($btn === $this->btnRetencao1) {$pos=1;}
		else if($btn === $this->btnRetencao2) {$pos=2;}
		else if($btn === $this->btnRetencao3) {$pos=3;}
		else if($btn === $this->btnRetencao4) {$pos=4;}
		else if($btn === $this->btnRetencao5) {$pos=5;}
		else if($btn === $this->btnRetencao6) {$pos=6;}
		else if($btn === $this->btnRetencao7) {$pos=7;}
		else if($btn === $this->btnRetencao8) {$pos=8;}

		$estado = $btn->get_label();
		if($estado == 'Reter') {
			// Reter chamada atual
			$canalOp = $this->procuraLinkDaOp();
			$numChamada = isset($this->tempBuffer[$canalOp]) ? $this->tempBuffer[$canalOp] : $this->procuraLinkDaOp();
			if(!empty($canalOp) ){	//&& $numChamada>9999
				$this->retencaoBuffer[$pos]['channel'] = "$canalOp|$numChamada";
				$this->retencaoBuffer[$pos]['time'] =time();
				$this->enviaComando("Redirect", array(
									"Channel" => $canalOp,
									"Context" => 'agentes',
									"Exten" => '***123',
									"Priority" => '1'
									));
									$btn->set_label("$numChamada");
			}
		} else {
			// Capturar chamada retida
			list($canalRetido) = explode("|", $this->retencaoBuffer[$pos]['channel']);
			$this->retencaoBuffer[$pos]['time']=0;
			$this->enviaComando("Redirect", array(
								"Channel" => $canalRetido,
								"Context" => 'ramais-internos',
								"Exten" => $this->ramalOp,
								"Priority" => '1'
								));
								unset($this->retencaoBuffer[$pos]['channel']);
								$bt = new GtkButton();
								$btn->modify_bg(Gtk::STATE_NORMAL,$bt->get_style()->bg[Gtk::STATE_NORMAL]);
								$btn->modify_bg(Gtk::STATE_ACTIVE,$bt->get_style()->bg[Gtk::STATE_ACTIVE]);
								$btn->modify_bg(Gtk::STATE_PRELIGHT,$bt->get_style()->bg[Gtk::STATE_PRELIGHT]);
								$btn->set_label('Reter');
		}

	}

	/*
	 * Obtem o numero originador da chamada e redireciona para o numero de destino da transferência
	 */
	function on_Transfere_clicked() {

		$chanOP = $this->procuraLinkDaOp();
		$this->enviaComando("Redirect", array(
								"Channel" => $chanOP,
								"Context" => CONTEXTO,
								"Exten" => $this->cxSaida->get_text(),
								"Priority" => "1"								
								));

		unset($this->tempBuffer[$chanOP]);
	}

	function on_LinhaProcura_dclicked($treeview, $path, $column) {
		$store = $treeview->get_model();
		$iter = $store->get_iter($path);
		$ramal = $store->get_value($iter, 1);
		$this->cxSaida->set_text($ramal);
		if($column) {
			if($this->emLigacao) $this->on_Transfere_clicked();
			else $this->on_Disca_clicked();
		}
	}

	function on_CapturaDaFila_doubleclicked($treeview, $path, $column){
		$store = $treeview->get_model();
		$iter = $store->get_iter($path);
		$numero = $store->get_value($iter, 1);
		$canalFila = array_search($numero,$this->telefonistaBuffer);
		$canalOp = $this->procuraLinkDaOp();
		$this->tempBuffer[$canalFila]=$numero;

		if(empty($canalOp)){
			$this->enviaComando("Redirect", array(
									"Channel" => $canalFila,
									"Context" => 'ramais-internos',
									"Exten" => $this->ramalOp,
									"Priority" => '1'
									));
			$this->filaTelefonista->delLinha('Número',$numero);
			$this->limpaCanalBufferTelefonista($canalFila);
		}
	}

	function on_LinhaProcura_clicked($treeview) {
		list($path, $col) = $treeview->get_cursor();
		$this->on_LinhaProcura_dclicked($treeview, $path, null);
	}

	function on_CxProcuraR_changed($gtkEntry) {
		$txt = $gtkEntry->get_text();
		if(strlen($txt) == 4 && is_numeric($txt)) {
			$store = $this->listaUsuarios->get_model();
			foreach ($store as $row) {
				$iter = $row->iter;
				if($store->get_value($iter, 1) == $txt) {
					$this->listaUsuarios->set_cursor($store->get_path($iter));
					break;
				}
			}
		}

	}

	function on_CxDisca_changed($gtkEntry) {
		if(strlen($gtkEntry->get_text())) $this->btnDisca->set_sensitive(true);
		else                              $this->btnDisca->set_sensitive(false);
	}

	function on_CxProcuraN_changed($gtkEntry) {
		$txt = $gtkEntry->get_text();
		if(strlen($txt)>2) {
			// Desligar o sort
			$this->listaUsuarios->setOrdena(false);
				
			$todos = false;
			$movidos = array();
			while(!$todos) {
				$store = $this->listaUsuarios->get_model(); //Devolve uma lista de GtkListStore
				$todos = true;
				foreach($store as $row) {
					$iter = $row->iter;
					$nome = $store->get_value($iter, 2);
					$guerra = $store->get_value($iter, 3);
					if(!in_array($nome, $movidos) && (stristr($nome, $txt) || stristr($guerra, $txt))) {
						$movidos[] = $nome;
						$store->move_after($iter, null);
						$todos = false;
						break;
					}
				}
			}
			$this->listaUsuarios->setOrdena(true);
		}
	}

	function sair($voltaParaLogin) {
		$this->shutAMI();		
		if($voltaParaLogin) $this->janelaLogin->reseta();
		else gtk::main_quit();
	}

	function setaEmLigacao($emLig) {
		$this->btnTransfere->set_sensitive($emLig);
		$this->emLigacao = $emLig;
	}
	
	function buscaUsuarios() {
		$this->usuarios = array();
		foreach(Util::getUsuarios() as $usu)
			$this->usuarios[$usu->ramal] = $usu;	
	}

	/*
	 * Carrega a lista de usuários do PABX com o Status do Ramais : LIVRE ou OCUPADO
	 */
	function carregaUsuarios($busca=false) {
		if($busca) $this->buscaUsuarios();
		$this->listaUsuarios->limpa();		
		foreach($this->usuarios as $usu) {
			if($usu->ramal != $this->ramalOp) {
				if(array_search($usu->ramal,$this->listaOcupados)){
					$this->listaUsuarios->addLinha("ocupado.png,$usu->ramal,$usu->nome,$usu->nomeguerra");
				}else {
					$this->listaUsuarios->addLinha("livre.png,$usu->ramal,$usu->nome,$usu->nomeguerra");
				}
			}
		}
	}

	function initTelefonista() {
		$this->emLigacao = false;
		$this->nomeOp    = $this->janelaLogin->getSelLogin();
		$this->senhaOp   = $this->janelaLogin->getSenha();
		foreach($this->usuarios as $usu) {
			if($usu->nome == $this->nomeOp) {
				$this->ramalOp = $usu->ramal;
				$this->telOp   = "SIP/$usu->ramal";
				return true;
			}
		}
		return false;
	}

	function setLabel($btn,$num){
		$aux = array();
		$cont = 0;
		for($c=1;$c<=8;$c++){
			if(!empty($this->retencaoBuffer[$c]['channel'])){
				$cont ++;
			}
		}
		$btn->set_label("$cont  - $num");
	}
	
	/*
	 * Função para recuperar as chamadas retidas, no caso acidental de fechamento da janela principal, 
	 * sem encerramento do programa!
	 */
	function carregaCanaisRetidos() {
		$canalRetido = null;
		for($c=1;$c<=8;$c++){
			if(isset($this->retencaoBuffer[$c]['channel'])){
				list($canalRetido,$numChamada) = explode("|", $this->retencaoBuffer[$c]['channel']);
				$botao = "btnRetencao$c";
				$this->$botao->set_label($numChamada);
			}
		}
	}
	
	/*
	 * Função para recuperar os canais ocupados e atualizar na tela a coluna Status da lista de usuarios
	 */ 
	function carregaCanaisOcupados() {
		// Buscar dados atuais dos canais ocupados pelo AMI
		$listaCanais = $this->enviaComando("Command", array("command"=>"core show channels concise"));
		$linhas = explode("\n", $listaCanais->dados);		
		$totLin = count($linhas);
		$this->listaOcupados = array();
		for($c=0; $c<$totLin - 1; $c++) {
			list($ramalSip, $d,$d,$d,$status) = explode("!", $linhas[$c]);
			list($d,$ramal) = explode("/",$ramalSip);
			list($ramal) = explode("-",$ramal);
			if(is_numeric($ramal) && $ramal > 999 && $ramal != $this->ramalOp && $status=="Up") {
				$usu = $this->getUsuarioPorRamal($ramal);
				$this->listaOcupados[$ramal]=$ramal;		
			}
		}
	}
	
	/*
	 * Função para recuperar as chamadas entrantes na fila Telefonista
	 */
	function carregaFilaTelefonista() {
		$this->telefonistaBuffer = array();
		$this->filaTelefonista->limpa();
		// Este comando irá gerar vários eventos do tipo QueueEntry,
		// com informaçoes das chamadas na fila da telefonista, que serão tratados pela função 'checaEventos'
		$this->enviaComando("QueueStatus", array("Queue" => "telefonista", 'Member' => '--NenhuM--'));
		
	}
	
	/*
	 * Obtem do buffer de chamadas entrantes na fila Telefonista o número originador da chamada através do canal
	 */
	function getCanalBufferTelefonista($canal) {
		if(isset($this->telefonistaBuffer[$canal])) return $this->telefonistaBuffer[$canal];
		return null;
	}
	
	/*
	 * Exclui do buffer de chamadas retidas o número originador da chamada através do canal
	 */
	function limpaCanalBufferTelefonista($canal) {
		if(isset($this->telefonistaBuffer[$canal])) unset($this->telefonistaBuffer[$canal]);
	}

	function getUsuarioPorRamal($ramal) {
		if(!is_array($this->usuarios)) return null;
		if(isset($this->usuarios[$ramal])) return $this->usuarios[$ramal];
		return null;
	}
	function procuraLinkDaOp() {
		$pacote = $this->enviaComando("Status");
		$aux =& $pacote;
		while($aux) {
			if($aux->getAtr('Event') == "Status" && stristr($aux->getAtr('Channel'), $this->telOp))
			return $aux->getAtr('Link');
			$aux = $aux->prox;
		}
		return null;
	}
	
	function procuraCallerIdDaOp($canal="") {
		if(!empty($canal)) {		
			$pacote = $this->enviaComando("Status");
			$aux =& $pacote;
			while($aux) {
				if($aux->getAtr('Event') == "Status" && stristr($aux->getAtr('Link'),$canal) && stristr($aux->getAtr('Link'),$canal))
				return $aux->getAtr('CallerID');
				$aux = $aux->prox;
			}
		}
		return "Não Identificado";
	}

	function atualizaDadosInterface() {
		$this->carregaCanaisOcupados();
		$this->carregaUsuarios();
		$this->carregaFilaTelefonista();
		$this->getStatusSvcNoturno();		
		$this->carregaCanaisRetidos();
	}

	function checaEventos($pacote=null) {
		if(!$pacote) $pacote = $this->AMI->recebeEventos(0.1);
		$aux =& $pacote;
		while($aux) {
			$evento = $aux->getAtr('Event');
			switch(strtolower($evento)) {
				case "newchannel":
					$sip = Util::pegaSipDoPacote($aux);					
					list($d, $ramal) = explode("/", $sip);					
					if ($sip != $this->telOp && is_numeric($ramal) && $ramal > 999) {						
						if (isset($this->usuarios[$ramal])){
							$this->listaUsuarios->setLinha("Ramal", $ramal, "Status", "ocupado.png");
						}
					}
					break;

				case "hangup":
					$sip = Util::pegaSipDoPacote($aux);
					$chanHangup = $aux->getAtr('Channel');
					if($sip == $this->telOp)	
						$this->setaEmLigacao(false);
					$sip = Util::pegaSipDoPacote($aux);
					$ramal = null;
					list($d, $ramal) = explode("/", $sip);
						
					if(isset($this->usuarios[$ramal])){
						$this->listaUsuarios->setLinha('Ramal', $ramal, "Status", "livre.png");						
						//$this->filaTelefonista->delLinha("Número",$ramal);
						//Quando a chamada for consequencia de uma transferencia pelo telefone (SIEMENS),
						// a mesma será identificada exclusivamente pelo RAMAL e NÃO pelo CANAL
						$canalEmEspera = array_search($ramal,$this->telefonistaBuffer);
						if($canalEmEspera) $this->limpaCanalBufferTelefonista($canalEmEspera);
					}
					$bt = new GtkButton();
					for($c=1;$c<=8;$c++){
						$botao = "btnRetencao$c";
						if(isset($this->retencaoBuffer[$c]['channel'])){
							$auxCanal = $this->retencaoBuffer[$c]['channel'];
							if(stristr($auxCanal,$chanHangup)){
								$this->$botao->modify_bg(Gtk::STATE_NORMAL,$bt->get_style()->bg[Gtk::STATE_NORMAL]);
								$this->$botao->modify_bg(Gtk::STATE_ACTIVE,$bt->get_style()->bg[Gtk::STATE_ACTIVE]);
								$this->$botao->modify_bg(Gtk::STATE_PRELIGHT,$bt->get_style()->bg[Gtk::STATE_PRELIGHT]);
								$this->$botao->set_label('Reter');
								unset($this->retencaoBuffer[$c]);
								unset($this->tempBuffer[$chanHangup]);
								$this->retencaoBuffer[$c]['time']=0;
							}
						}
					}

					if(!empty($chanHangup) && isset($this->telefonistaBuffer[$chanHangup])){
						$this->limpaCanalBufferTelefonista($chanHangup);
					}
					break;

				case "rename":
					$old = $aux->getAtr('Oldname');	//Canal que redirecionou
					$new = $aux->getAtr('Newname'); //Canal para o qual foi redirecionado
					if(strstr($old, '<') || strstr($new, '<'))
						break;
								
				case "join":
				case "leave":
					$this->carregaFilaTelefonista();
					break;

				case "dial":
					$sip = Util::pegaSipDoPacote($aux, 'Destination');
					if($sip == $this->telOp) {  // Telefonista recebendo
						$num = $aux->getAtr('CallerID');
						$cidName = $aux->getAtr('CallerIDName');
						$cidName = (!empty($cidName) && !strstr($cidName, "nknown")) ? " - $cidName" : "Externo";
						$txt = $num . $cidName;
						if(array_key_exists($num, $this->usuarios)) {
							// Se a ligação vem de ramal interno pega o nome do usuário
							$usu = $this->getUsuarioPorRamal($num);
							$txt = "$usu->ramal - $usu->nome";
						}
						$this->setaEmLigacao(true);
					} else {
						$sip = Util::pegaSipDoPacote($aux, 'Source');
						if(stristr($sip, $this->telOp)) // Telefonista ligando
						$this->setaEmLigacao(true);
					}
					break;

				case "newstate":
					$sip = Util::pegaSipDoPacote($aux);
					if($sip == $this->telOp) {
						$estado = $aux->getAtr('State');
						switch($estado) {
							case "Ringing": $cor = "ff0000"; break;
							case "Up":      $cor = "0000ff"; break;
							default:        $cor = "000000";
						}
					}
					break;
				
				case "channelreload":
					$this->atualizaDadosInterface();
					break;
						
				case "shutdown":
					Util::alerta("Asterisk desligou. Saindo!");
					$this->sair(false);
					break;
				
				// Eventos de retorno do QueueStatus
				case 'queueentry':
					$canal   = $aux->getAtr('Channel');
					$cidNum  = $aux->getAtr('CallerID');
					$cidNome = $aux->getAtr('CallerIDName');
					
					$this->telefonistaBuffer[$canal] = $cidNum;
					$this->filaTelefonista->addLinha("$cidNome,$cidNum");
					break;
			}

			$aux = $aux->prox;
		}
		if ((count($this->telefonistaBuffer)> 0) && (!$this->emLigacao)){
			if ((time() - $this->timeAlerta) > 4){
				system("play sound/alertNewCall.wav 2> /dev/null");
				$this->timeAlerta = time();
			}
		}else{
			$this->timeAlerta = time();
		}
			
		//Verifica o tempo de cada posição de Retenção e mostra alerta de cores conforme o tempo de espera,
		// se > 30s = amarelo ou > 60s = vermelho		
		$intervalo = array();
		for($c=1; $c<=8; $c++){
			$botao = "btnRetencao$c";
			$intervalo[$c] = time() - $this->retencaoBuffer[$c]['time'];			
			if ($this->retencaoBuffer[$c]['time'] > 0){
				if($intervalo[$c]>=30 &&  $intervalo[$c]<60) 
					Util::mudaCorDeFundo($this->$botao,"#fdee73");
				elseif($intervalo[$c]>=60)
					Util::mudaCorDeFundo($this->$botao, "#ee4848");
			}
		}
		return true;
	}
}
?>
