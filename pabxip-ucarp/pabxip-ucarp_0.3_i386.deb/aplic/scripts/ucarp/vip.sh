#!/bin/bash 

#----------------------------------------------------------------------
# vip.sh
#
# AUTOR: AIRTON KUADA / Gabriel Ortiz
# DATA:  18/08/2009
# 
# Utilizado para "subir" e "descer" os n�s do cluster HA
#----------------------------------------------------------------------

MODULO="VIP.SH"
. /aplic/scripts/ucarp/ucarpConfig.sh

up()
{
    #--------- Adiciona endere�o IP Virtual como PRINCIPAL na INTERFACE  ---------
    MSG="UP: Adicionando endereco VIRTUAL na interface $INTERFACE";grava_log
    ip addr add $IP_VIRTUAL$REDE dev eth0

    ping -c 1 -I $IP_VIRTUAL $GW > /dev/null
    MSG="UP: PING com gateway realizado";grava_log

    #-----------------------------------------------------
    #    INICIALIZACAO DOS SERVICOS
    #-----------------------------------------------------
	if [ -d ./startup.d ]; then
	    MSG="UP: Inicializando Servicos";grava_log
		for script in ./startup.d/*.sh; do
		    if [ -x ${script} ]; then
			    MSG="UP: Invocando ${script}";grava_log
				source ${script}
			fi
		done
	fi
}


down()
{
    #--------- Removendo endere�o IP Virtual como PRINCIPAL na INTERFACE  ---------
    MSG="DOWN: Removendo Endereco IP na $INTERFACE";grava_log
    ip addr | grep -v grep | grep $IP_VIRTUAL$REDE > /dev/null
    if [ $? -eq 0 ]; then
    	ip addr del $IP_VIRTUAL$REDE dev eth0
    fi

    #-----------------------------------------------------
    #    ENCERRANDO OS SERVICOS
    #-----------------------------------------------------
    if [ -d ./shutdown.d ]; then
	    MSG="DOWN: Encerrando Servicos";grava_log
		for script in ./shutdown.d/*.sh; do
		    if [ -x ${script} ]; then
			    MSG="DOWN: Invocando ${script}";grava_log
				source ${script}
			fi
		done
	fi
}

case "$1" in
    up) up
    ;;
    
    down) down
    ;;
    
    *) MSG="Parametro Invalido";grava_log
    ;;
esac

