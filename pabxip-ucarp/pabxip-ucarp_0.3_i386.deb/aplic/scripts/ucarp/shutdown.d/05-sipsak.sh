#!/bin/bash

/usr/local/bin/sipsak -s sip:9@127.0.0.1 > /dev/null
if [ $? -eq 0 ]; then
	/usr/sbin/asterisk -rx 'stop now' > /dev/null
fi

