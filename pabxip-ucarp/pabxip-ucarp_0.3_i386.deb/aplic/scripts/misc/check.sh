#!/bin/bash 

GW="10.15.151.1"
GW2="10.15.151.32"

while true
do
    ping -c 5 $GW > /dev/null
    ping -c 5 $GW2 > /dev/null
    sleep 3

done

