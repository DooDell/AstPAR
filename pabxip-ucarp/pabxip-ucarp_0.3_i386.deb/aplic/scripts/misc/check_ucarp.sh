#!/bin/bash 

grava_log()
{
    echo -e "$(date '+%F %T') $MODULO - $MSG" >> $ARQ_LOG
}


#-----------------------------------------------------
#        FUNCAO PRINCIPAL
#-----------------------------------------------------
MODULO="CHECK_UCARP.SH"
ARQ_LOG="/var/log/cluster.log"
SCRIPT_DRBD="/aplic/scripts/drbd/drbd.sh"
LOCALHOST=$(uname -n)
HOST_MASTER="scelepar00200"
HOST_SLAVE="scelepar00201"
IP_VIRTUAL="10.15.151.45"
GW="10.15.151.1"

while true 
do
      ip addr show | grep -v grep | grep $IP_VIRTUAL > /dev/null

      IFCONFIG=$?

      #-----------------------------------------------
      #    Verifica se a interface esta estavel
      #----------------------------------------------

      if [ $IFCONFIG -eq 0 ]   # MASTER/PRIMARY
      then
            MSG="A interface MASTER esta presente neste HOST";grava_log
            CONT1=0 #contabiliza interface up
            CONT2=0 #contabiliza interface down

	    #----------------------------------------------------
	    #      CONTABILIZA QUEDAS DA INTERFACE VIRTUAL
	    #---------------------------------------------------

            MSG="CONTABILIZANDO QUEDAS NA INTERFACE";grava_log

	    while [ $CONT1 -lt 10 -a $CONT2 -lt 10 ]
	    do
	          sleep 2
                  ip addr show | grep -v grep | grep $IP_VIRTUAL > /dev/null
		  if [ $? -eq 0 ]
		  then
		      CONT1=$(expr $CONT1 + 1)
		  else
		      CONT2=$(expr $CONT2 + 1)
		  fi
	    done

	    #----------------------------------------------------
	    #      SE VERIFICOU-SE QUEDA NA INTERFACE VIRTUAL
	    #      ENTAO O TESTE DEVE SER REINICIADO
	    #----------------------------------------------------

            if [ $CONT2 -ne 0 ] #contabilizou queda na interface 
	    then
                   MSG="OCORRENDO OSCILACAO NA INTERFACE MASTER, REINICIANDO UCARP";grava_log
		   killall ucarp
		   /aplic/scripts/ucarp/ucarp.sh
                   sleep 10
                   continue
	    fi

            MSG="INTERFACE MASTER ESTAVEL ...";grava_log

	    #$SCRIPT_DRBD primary
      else
            MSG="A interface MASTER NAO esta presente neste HOST";grava_log
	    #$SCRIPT_DRBD secondary
            sleep 15
      fi
done

