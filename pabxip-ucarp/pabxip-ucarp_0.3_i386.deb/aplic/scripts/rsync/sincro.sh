#!/bin/bash 

MODULO="SINCRO.SH"
. /aplic/scripts/ucarp/ucarpConfig.sh

LISTA=/usr/lib/telefoniaip/arquivos/config/arquivosSistema.txt
LISTA_CC=/usr/lib/telefoniaip/arquivos/config/arquivosSistemaCC.txt

MSG="SINCRONIZANDO ARQUIVOS ...";grava_log
while true
do
	#---------------- Verifica se o host possui o endereco virtual --------------
	ip addr | grep -v grep | grep $IP_VIRTUAL > /dev/null
	if [ $? -ne 0 ]; then
		# Host nao eh master
		if  [ $LOCALHOST = $HOSTMASTER ]; then
			IP_ORIGEM="$IP_HOSTSLAVE" 
		else
			IP_ORIGEM="$IP_HOSTMASTER"
		fi
 
		#---------- Verifica se o Asterisk Remoto esta executando -------------------
		/usr/local/bin/sipsak -s sip:9@$IP_ORIGEM > /dev/null

		if [ $? -eq 0 ]; then
			# Asterisk remoto esta respondendo
			MSG="SINCRONIZANDO ARQUIVOS ...";grava_log
			for ARQ in `cat $LISTA | grep -v "#"`; do
				PATH_DESTINO=`dirname $ARQ`
				rsync -Cravzp root@$IP_ORIGEM:$ARQ $PATH_DESTINO
			done
			if [ -f $LISTA_CC ] ; then
				MSG="SINCRONIZANDO ARQUIVOS CC ...";grava_log
				for ARQ in `cat $LISTA_CC | grep -v "#"`; do
					PATH_DESTINO=`dirname $ARQ`
					rsync -Cravzp root@$IP_ORIGEM:$ARQ $PATH_DESTINO
				done
			fi
		else
			MSG="ASTERISK FORA DE OPERACAO NO HOST $IP_ORIGEM ...";grava_log
		fi
	else
		# localhost eh MASTER, entao nao faz nada
		MSG="NAO FAZENDO NADA, HOST EH MASTER ...";grava_log
	fi
	sleep 60
done
exit

#------------------------------------------------------------------#
# Opcoes do rsync                                                  #
#------------------------------------------------------------------#
#      -C = ignorar arquivos identicos                             #
#      -r = recursivo                                              #
#      -a = archive                                                #
#      -v = verbose                                                #
#      -z = compress                                               #
#      -p = preserve permissions                                   #
#      --delete = exclui o arquivo do backup caso a origem         #
#                tenha excluido tambem.                            #
#      --exclude = exclui arquivos do backup. ex. --exclude='x*'   #
#                  um exclude para cada mascara a ser considerada  #
#                                                                  #
#------------------------------------------------------------------#

