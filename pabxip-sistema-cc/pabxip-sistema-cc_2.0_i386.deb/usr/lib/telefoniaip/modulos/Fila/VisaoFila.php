<?php
class VisaoFila {
	function preparaTela($smarty, $nomeTela) {
		global $sessao;
		
		$smarty->assign('temMenuLateral', true);
		$icones = array();
		$moduloAtivo = $sessao->moduloAtivo;
		$funcaoAtiva = $moduloAtivo->funcaoAtiva;
		foreach($moduloAtivo->funcoes as $funcaoIcone) {
			if(($funcaoIcone->nome!="editFila" || $funcaoAtiva->nome=="editFila") &&
					!($funcaoIcone->nome=="addFila" && $funcaoAtiva->nome=="editFila") &&
				($funcaoIcone->nome!="editPA" || $funcaoAtiva->nome=="editPA") &&
					!($funcaoIcone->nome=="addPA" && $funcaoAtiva->nome=="editPA")) {
				$icones[] = $funcaoIcone->getIcone(($funcaoIcone == $funcaoAtiva));
			}
		}
		$smarty->assign('iconesFuncoes', $icones);
		
		switch($nomeTela) {
			case 'fila':
				// Mostra somente as filas dos centros de custo do usuario logado
				$filas = $sessao->usuario->getMinhasFilas();
				if(is_array($filas) && count($filas) > 0) {
					$smarty->assign('temFilas', true);					
					$gfxEdit = new HtmlImg("btnEdit.png");					
					$gfxDel  = new HtmlImg("btnDelete.png");
					$gfxDelDesab = new HtmlImg("btnDeleteDesab.png");
					$gfxEditDesab = new HtmlImg("btnEditDesab.png");
					if ($sessao->ehAdmin() || in_array('excluirFila',$sessao->permissoes))
							$acessoDel = true;
					else $acessoDel = false;
					if ($sessao->ehAdmin() || in_array('editFila',$sessao->permissoes))
							$acessoEdit = true;
					else $acessoEdit = false;
										
					foreach($filas as $fila) {						
						if($acessoEdit)	$fila->btnEdit = "<a href='javascript:edit($fila->id)'>$gfxEdit</a>";
						else $fila->btnEdit = $gfxEditDesab;
						if ($acessoDel)	$fila->btnDel  = "<a href='javascript:del($fila->id,\"$fila->name\")'>$gfxDel</a>";
						else $fila->btnDel = "$gfxDelDesab";
						$fila->membros = '-';//$fila->totMembros();
						$fila->temmembros = $fila->membros > 0 ? true : false;
						$fila->gravacao = ($fila->monitor_format == "wav49") ? "<font color='red'>Ligada!</font>" : "Desligada";
						$fila->estrategia  = $fila->getDescEstrategia();
						$fila->weight = 11 - $fila->weight;
					}
					$smarty->assign('filas', $filas);
				}
			
				if(!empty($sessao->msg)) {
					echo "<div class='msg'>$sessao->msg</div>";
					$sessao->msg = "";
				}
				break;
			
			case 'addFila':
			case 'editFila':
				$id = 0;
				$edit = ($nomeTela == 'editFila');
				if($edit) {
					$id = $sessao->getVar('fila');
					$btnCap = "Salvar Altera��es";
					$btnAct = "edit";
					$smarty->assign('editParams', "id=" . $id);
				} else {
					$btnCap = "Adicionar";
					$btnAct = "nova";
				}
				$smarty->assign('btnCap', $btnCap);
				$smarty->assign('btnAct', $btnAct);
				
				$fila = new Fila($id);
				$comboEstrategia = array(
						'leastrecent' => "Ocioso a mais tempo",
						'rrmemory'    => "C�clico",
						'roundrobin'  => "Prioriza o Topo",
						'fewestcalls' => "Menor n�mero de chamadas",
						'ringall'     => "Tocar todos",
						'random'      => "Aleat�rio"
					);
				
				$comboEspera = array(
						'yes'  => "Sempre",
						'no'   => "N�o avisar",
						'once' => "Apenas na primeira vez"
					);
				
				$comboGrupoMOH = array('default' => 'Padr�o');
				foreach(bdFacil::todos('GrupoMoh') as $moh)
					$comboGrupoMOH[Util::limpaNomeParaContexto($moh->nome)] = $moh->nome;
			
				$comboAnuncio = array(0 => "Nenhum");
				$pasta = "arquivos/asterisk/anuncios/";
				$pastaBase = Arquivos::getBaseDir() . $pasta;
				$arqs = Arquivos::lista($pasta, false);
				foreach($arqs as $file) {
					if(substr($file, 0, 8) == 'anuncio_') {
						$cortaPrefixo = substr($file, 8);
						$arqAst = substr($file, 0, strlen($file) - 4); // Remover a extens�o
						$comboAnuncio["anuncios/$arqAst"] = $cortaPrefixo;
					}
				}
				
				$comboPrior = Array();
				for($c=1;$c<=10;$c++)
					$comboPrior[11-$c] = $c;
				
				$smarty->assign('hiddenAddOUEdit', new HtmlHidden("addOUedit", "value='$btnAct'"));
				if($edit) {
					$smarty->assign('hiddenID', new HtmlHidden('id', "value='$id'"));
					$smarty->assign('hiddenFilaAtual', new HtmlHidden('filaatual',"value='$fila->name'"));
				}
				
				// Geral
				$smarty->assign('cxTxtName', $fila->htmlText("name", 20, "maxlength=128 onkeypress='return soAlphaNum(event)'"));
				$smarty->assign('comboEstrategia', $fila->htmlComboArray("strategy", $comboEstrategia));
				$smarty->assign('comboPrioridade', $fila->htmlComboArray("weight", $comboPrior));
				$smarty->assign('infoPrioridade', new HtmlInfo('1 = Alta, 10 = Baixa'));
				$smarty->assign('cxTxtRamal', $fila->htmlText("ramal", 10, "maxlength='32'"));
				$smarty->assign('infoRamal',  new HtmlInfo('Para multiplos pilotos separe-os por v�rgula'));
				$smarty->assign('cxTxtNivelServico', $fila->htmlText("servicelevel", 4, "maxlength='4'"));
				$smarty->assign('infoNivelServico',  new HtmlInfo('NS = % das chamadas antendidas antes do tempo definido'));
				$smarty->assign('cxTxtRetry', $fila->htmlText("retry", 4, "maxlength='4'"));
				$smarty->assign('infoRetry',  new HtmlInfo('Tempo entre as checagens de agentes disponiveis'));
				
				// Op��es da fila
				$smarty->assign('comboMOH', $fila->htmlComboArray("musiconhold", $comboGrupoMOH));
				$smarty->assign('cxTxtTempoEmFila', $fila->htmlText("timeoutfila", 2, "onkeypress='return soNum(event)' maxlength=4"));
				$smarty->assign('infoTempoEmFila', new HtmlInfo('0 = sem limite'));
				$smarty->assign('cxTxtTamanhoFila', $fila->htmlText("maxlen", 2, "onkeypress='return soNum(event)' maxlength=2"));
				$smarty->assign('infoTamanhoFila', new HtmlInfo('0 = sem limite'));
				
				// Op��es do Agente
				$smarty->assign('cxTxtTempoToque', $fila->htmlText("timeout", 2, "onkeypress='return soNum(event)' maxlength=3"));
				$smarty->assign('cxTxtTempoEntreChamadas', $fila->htmlText("wrapuptime", 2, "onkeypress='return soNum(event)' maxlength=3"));
				$smarty->assign('checkPausaAutomatica', new HtmlCheck("pausaAutomatica", "onchange='enDisab2()' " . ($fila->flags & FLAG_FILA_PAUSA_AUTO ? 'checked' : '')));
				$smarty->assign('cxTxtMaxAgPausa', $fila->htmlText("maxagspausa", 2, "onkeypress='return soNum(event)' maxlength=3"));
				$smarty->assign('infoMaxAgsPausa',  new HtmlInfo('N�mero m�ximo de Agentes em Pausa. 0 = sem limite'));

				// Op��es
				$smarty->assign('checkGravacao', $fila->htmlCheck("monitor_format"));
				$smarty->assign('infoGravacao', new HtmlInfo('Se habilitada passar� a gravar todas as liga��es da fila'));				
				$smarty->assign('checkDeslogarAgNaoAtende', $fila->htmlCheck("indispna"));
				$smarty->assign('checkReceberComFilaVazia', $fila->htmlCheck("joinempty"));
				$smarty->assign('checkLimpaFilaVazia', $fila->htmlCheck("leavewhenempty"));
				$smarty->assign('infoLimpaFilaVazia', new HtmlInfo('Ao deslogar o ultimo agente as liga��es devem ser desconectadas?'));
				
				// Roteamento
				$smarty->assign('btnToggleRoteamento', new HtmlToggle('linhaRot', false, 'tr'));
				if($fila->flags & FLAG_FILA_TOANUNCIO) $selTOAnuncio = 'checked';
				else                                   $selTOPiloto  = 'checked';
				$smarty->assign('radioTOAnuncio', new HtmlRadio("tipoAcaoTO", "value='A' $selTOAnuncio"));
				$smarty->assign('comboTOAnuncio', $fila->htmlComboArray("timeoutanuncio", $comboAnuncio));
				$smarty->assign('checkTOcallback', new HtmlCheck("timeoutCallBack", ($fila->flags & FLAG_FILA_TOCALLBACK) ? 'checked' : ''));
				$smarty->assign('radioTOPiloto',  new HtmlRadio("tipoAcaoTO", "value='P' $selTOPiloto"));
				$smarty->assign('cxTxtTOPiloto',  $fila->htmltext("timeoutpiloto", 5, "maxlength='5'"));
				if($fila->flags & FLAG_FILA_FCANUNCIO) $selFCAnuncio = 'checked';
				else                                   $selFCPiloto  = 'checked';
				$smarty->assign('radioFCAnuncio', new HtmlRadio("tipoAcaoFC", "value='A' $selFCAnuncio"));
				$smarty->assign('comboFCAnuncio', $fila->htmlComboArray("filacheiaanuncio", $comboAnuncio));
				$smarty->assign('checkFCcallback', new HtmlCheck("filacheiaCallBack", ($fila->flags & FLAG_FILA_FCCALLBACK) ? 'checked' : ''));
				$smarty->assign('radioFCPiloto',  new HtmlRadio("tipoAcaoFC", "value='P' $selFCPiloto"));
				$smarty->assign('cxTxtFCPiloto',  $fila->htmltext("filacheiapiloto", 5, "maxlength='5'"));
				if($fila->flags & FLAG_FILA_FVANUNCIO) $selFVAnuncio = 'checked';
				else                                   $selFVPiloto  = 'checked';
				$smarty->assign('radioFVAnuncio', new HtmlRadio("tipoAcaoFV", "value='A' $selFVAnuncio"));
				$smarty->assign('comboFVAnuncio', $fila->htmlComboArray("filavaziaanuncio", $comboAnuncio));
				$smarty->assign('checkFVcallback', new HtmlCheck("filavaziaCallBack", ($fila->flags & FLAG_FILA_FVCALLBACK) ? 'checked' : ''));
				$smarty->assign('radioFVPiloto',  new HtmlRadio("tipoAcaoFV", "value='P' $selFVPiloto"));
				$smarty->assign('cxTxtFVPiloto',  $fila->htmltext("filavaziapiloto", 5, "maxlength='5'"));
				
				// Hor�rio
				$smarty->assign('btnToggleHorario', new HtmlToggle('linhaHora', false, 'tr'));
				$smarty->assign('checkHorarioAtivo',    new HtmlCheck("horarioAtivo", "onchange='enDisab()' " . ($fila->flags & FLAG_FILA_HORARIOATIVO ? 'checked' : '')));
				if($fila->flags & FLAG_FILA_HORARIOANUNCIO) $selAcaoAnuncio = 'checked';
				else                                        $selAcaoPiloto  = 'checked';
				$smarty->assign('radioHorarioAnuncio', new HtmlRadio("tipoAcaoHorario", "value='A' $selAcaoAnuncio"));
				$smarty->assign('comboHorarioAnuncio', $fila->htmlComboArray("horarioanuncio", $comboAnuncio));
				$smarty->assign('radioHorarioPiloto',  new HtmlRadio("tipoAcaoHorario", "value='P' $selAcaoPiloto"));
				$smarty->assign('cxTxtHorarioPiloto',  $fila->htmltext("horariopiloto", 5, "maxlength='5'"));
				$smarty->assign('cxTxtHorarioIni',  $fila->htmlText("horarioini",    5, "maxlength='	5'"));
				$smarty->assign('cxTxtHorarioFim',  $fila->htmlText("horariofim",    5, "maxlength='5'"));
				$smarty->assign('cxTxtHorarioIniS', $fila->htmlText("horarioinisab", 5, "maxlength='5'"));
				$smarty->assign('cxTxtHorarioFimS', $fila->htmlText("horariofimsab", 5, "maxlength='5'"));
				$smarty->assign('cxTxtHorarioIniD', $fila->htmlText("horarioinidom", 5, "maxlength='5'"));
				$smarty->assign('cxTxtHorarioFimD', $fila->htmlText("horariofimdom", 5, "maxlength='5'"));
				$smarty->assign('cxTxtHorarioIniF', $fila->htmlText("horarioinifer", 5, "maxlength='5'"));
				$smarty->assign('cxTxtHorarioFimF', $fila->htmlText("horariofimfer", 5, "maxlength='5'"));
				
				// Anuncios
				$smarty->assign('btnToggleAnuncios', new HtmlToggle('linhaAnuncio', false, 'tr'));
				$smarty->assign('comboAnuncioINI',       $fila->htmlComboArray("anuncioini", $comboAnuncio));
				$smarty->assign('infoAnuncioINI',        new HtmlInfo('An�ncio tocado ao cliente antes de entrar na fila'));
				$smarty->assign('comboAnuncioAgente',    $fila->htmlComboArray("announce", $comboAnuncio));
				$smarty->assign('infoAnuncioAgente',     new HtmlInfo('An�ncio tocado ao agente logo que atender uma chamada desta fila'));
				$smarty->assign('comboAnuncioCliente',   $fila->htmlComboArray("announcecli", $comboAnuncio));
				$smarty->assign('infoAnuncioCliente',    new HtmlInfo('An�ncio tocado ao cliente logo que for atendido'));
				$smarty->assign('comboAnuncioPeriodico', $fila->htmlComboArray("periodic_announce", $comboAnuncio));
				$smarty->assign('cxTxtAnuncioPerFreq',   $fila->htmlText("periodic_announce_frequency", 2));
				$smarty->assign('infoAnuncioPerFreq',    new HtmlInfo('0 = sem repeti��o do an�ncio do cliente (min. 15s)'));
				
				// Avisos
				$smarty->assign('btnToggleAvisos', new HtmlToggle('linhaAviso', false, 'tr'));
				$smarty->assign('checkAnuncioAvisoPos', new HtmlCheck("avisoPos", "onchange='enDisab()'" . ($fila->flags & FLAG_FILA_AVISA_POS ? ' checked' : '')));
				$smarty->assign('cxTxtAnuncioIntervalo', $fila->htmlText("announce_frequency", 2, "onkeypress='return soNum(event)' maxlength=3"));
				$smarty->assign('comboAnuncioEspera', $fila->htmlComboArray("announce_holdtime", $comboEspera));
				
				// CRM
				$smarty->assign('btnToggleCRM', new HtmlToggle('linhaCRM', false, 'tr'));
				$smarty->assign('cxTxtURLPopup', $fila->htmlText("urlpopup", 60, "maxlength=256"));
				$smarty->assign('btnURLPadraoIni',  new HtmlBtn('urlPadIni', "value='URL Padr�o' onclick='urlPadrao(\"ini\")'"));
				$smarty->assign('cxTxtURLPopupFim', $fila->htmlText("urlpopupfim", 60, "maxlength=256"));
				$smarty->assign('btnURLPadraoFim',  new HtmlBtn('urlPadFim', "value='URL Padr�o' onclick='urlPadrao(\"fim\")'"));
				$smarty->assign('infoURLPopup',  new HtmlInfo('Vazio = Sem popup'));
				$smarty->assign('infoURLPopup2', new HtmlInfo('Substitui��es: %NUM% = numero entrante - %FILA% = nome fila - %IDAG% = ID do Agente'));
				$smarty->assign('infoURLPopup3', new HtmlInfo('Substitui��es: %NUM% = numero entrante - %FILA% = nome fila - %IDAG% = ID do Agente - %UID% = uniqueid da chamada'));
				$tiposTabX = bdFacil::todosSQL('Vazia', "SELECT * FROM cc_tipotabulacao WHERE idfila = '$fila->id' ORDER BY id");
				$setaCima  = new HtmlImg('setaCima.png');
				$setaBaixo = new HtmlImg('setaBaixo.png');
				$btnEdit   = new HtmlImg('btnEdit.png');
				$btnDel    = new HtmlImg('btnDelete.png');
				$tiposTab  = array();
				foreach($tiposTabX as $tt) {
					if(!($tt->flag & TIPOTAB_DESATIVADO))
						$tiposTab[] = $tt;
				}
				$cnt = 1;
				foreach($tiposTab as $tt) {
//					$tt->cima  = $cnt == 1 ? '' : "<a href='javascript:cima($tt->id)'>$setaCima</a>";
//					$tt->baixo = $cnt == count($tiposTab) ? '' : "<a href='javascript:baixo($tt->id)'>$setaBaixo</a>";
					$tt->del   = "<a href='javascript:delTT($tt->id)'>$btnDel</a>";
					$cnt++;
				}
				$smarty->assign('tiposTabulacao', $tiposTab);
				$smarty->assign('pIDTabulacao',   bdFacil::getAtrSql("SELECT MAX(id) FROM cc_tipotabulacao") + 1);
				$smarty->assign('cxTxtNovaTabulacao', new HtmlText('novaTabulacao', 'size="40"'));
				$smarty->assign('btnAddTabulacao',    new HtmlBtn('novaTab', "value='Novo Item' onclick='novoItem()'"));
				
				// CallBack
				$smarty->assign('btnToggleCB', new HtmlToggle('trCB', false, 'tr'));
				$smarty->assign('infoCallerid',    new HtmlInfo('callerid = DDD (2 digitos) + N�mero (8 d�gitos)'));
				$smarty->assign('checkAtivarCB',   $fila->htmlCheck('callback', "onchange='ocCheckCallBack()'"));
				$smarty->assign('cxTxtAgsDispCB',  $fila->htmlText('callbackdisp', 2, "onkeypress='return soNum(event)' maxlength=2"));
				$smarty->assign('infoAgsDispCB',   new HtmlInfo('Numero minimo de agentes dispon�veis para disparar um <i>callback</i>'));
				$smarty->assign('cxTxtTempoMinCB', $fila->htmlText('callbackmin',  2, "onkeypress='return soNum(event)' maxlength=2"));
				$smarty->assign('infoTempoMinCB',  new HtmlInfo('Tempo minimo em fila para dispara <i>callback</i>'));
				$smarty->assign('cxTxtTempoMaxCB', $fila->htmlText('callbackmax',  2, "onkeypress='return soNum(event)' maxlength=2"));
				$smarty->assign('infoTempoMaxCB',  new HtmlInfo('Tempo m�ximo em fila para dispara <i>callback</i> (0 = sem m�ximo)'));
				
				$smarty->assign('checkStripDDDLocalCB', $fila->htmlCheck('callbackstriplocal'));
				$smarty->assign('cxTxtAddLocalCB',      $fila->htmlText('callbackaddlocal',  2, "onkeypress='return soNum(event)' maxlength='16'"));
				$smarty->assign('cxTxtAddDDDCB',        $fila->htmlText('callbackaddddd',  2, "onkeypress='return soNum(event)' maxlength='16'"));
				
				$smarty->assign('comboAnuncioCB', $fila->htmlComboArray('announcecb', $comboAnuncio));
				$smarty->assign('infoAnuncioCB',  new HtmlInfo('An�ncio a ser tocado para o agente ao atender CallBack'));
				
				$smarty->assign('btnOK', new HtmlBtn("vai", "value='$btnCap' onclick='addEditFila()'"));
				break;
			
			case 'relFilas':
				// TODO - Data e Hora do mes/dia
				$smarty->assign('cxTxtDataI', new HtmlText("dataI", "size=10"));
				$smarty->assign('cxTxtDataF', new HtmlText("dataF", "size=10"));
				$smarty->assign('cxTxtHoraI', new HtmlText("horaI", "size=6"));
				$smarty->assign('cxTxtHoraF', new HtmlText("horaF", "size=6"));
				
				$smarty->assign('radioTipoAtdGgrupo', new HtmlRadio("tipoRel", "value='atendimentoGrupo' onchange='ocRadioTipo()'"));
				$smarty->assign('radioTipoResAg',     new HtmlRadio("tipoRel", "value='resumidoAgente' onchange='ocRadioTipo()' checked"));
				$smarty->assign('radioTipoDistTempo', new HtmlRadio("tipoRel", "value='distribuicaoTemporal' onchange='ocRadioTipo()'"));
				
				foreach(bdFacil::todos('Fila') as $fila)
					$vdFilas[$fila->name] = $fila->name;
				if(Util::tem($vdFilas)) asort($vdFilas); 
				$smarty->assign('trocaFilasAG', new HtmlTroca('Filas', array('filasDispAG' => $vdFilas, 'filasAG' => array()), array('titulo' => 'Escolha as Filas')));
				$smarty->assign('trocaFilasDT', new HtmlTroca('Filas', array('filasDispDT' => $vdFilas, 'filasDT' => array()), array('titulo' => 'Escolha as Filas')));
				
				foreach(SistemaCC::todosAgente() as $agente)
					$vdAgentes[$agente->ramal] = $agente->nome;
				if(Util::tem($vdAgentes)) asort($vdAgentes);
				$smarty->assign('trocaAgentes', new HtmlTroca("Agentes", array('agentesDisp' => $vdAgentes, 'agentes' => array()), array('titulo' => 'Escolha os Agentes')));
				
				$smarty->assign('comboAgrupaTempoRA', new HtmlCombo("agrupaTempoRA", array(-1 => 'N�o Agrupar', 5 => '5 min', 10 => '10 min', 15 => '15 min', 30 => '30 min', 60 => '60 min')));
				
				$smarty->assign('comboAgrupaTempoDT', new HtmlCombo("agrupaTempoDT", array(5 => '5 min', 10 => '10 min', 15 => '15 min', 30 => '30 min', 60 => '60 min')));
				
				$smarty->assign('btnOK', new HtmlBtn("emitir", "value='Emitir' onclick='emite()'"));
				break;
			
			case 'agente':
				// Mostra somente os agentes dos centros de custo do usuario logado
				$agentes = $sessao->getMeusUsuarios(true);
				asort($agentes);
				
				$smarty->assign('infoLogin', new HtmlInfo("Para Editar os dados dos agentes acesse [Usu�rios]"));
				if(is_array($agentes) && count($agentes) > 0) {
					$smarty->assign('temAgentes', true);
					foreach($agentes as $ag)
						if(empty($ag->telatual)) $ag->telatual = 'Deslogado'; 
					$smarty->assign('agentes', $agentes);
					
					// Mostra somente as filas dos centros de custo do usuario logado
					$filas = $sessao->usuario->getMinhasFilas();
					if(is_array($filas) && count($filas) > 0) {
						$smarty->assign('temFilas', true);
						$cnt = 0;
						foreach($filas as $fila) {
							$fila->num = $cnt;
							$todos1 = array(); // Todos os agentes que N�O est�o na fila atual
							$todos2 = array(); // Todos os agentes que EST�O na fila atual
							foreach($agentes as $membroFila) {
								foreach(explode(',', $membroFila->idsfilas) as $idFila) {
									if($idFila == $fila->id)
										$todos2[$membroFila->id] = $membroFila->nome;
								}
							}
							foreach($agentes as $ag) {
								if(!in_array($ag->nome, $todos2))
									$todos1[$ag->id] = $ag->nome;
							}
							$nomeCombo1 = "todosAgs$cnt";
							$nomeCombo2 = "agsNaFila$fila->id";
							$fila->combo1 = new HtmlCombo($nomeCombo1, $todos1, "size='10' multiple='yes' class='listaRamais'");
							$fila->btnVai = new HtmlBtn("vai$cnt", "value='>>' onclick='troca($nomeCombo1, $nomeCombo2)'");
							$fila->btnVem = new HtmlBtn("vem$cnt", "value='<<' onclick='troca($nomeCombo2, $nomeCombo1)'");
							$fila->combo2 = new HtmlCombo($nomeCombo2, $todos2, "size='10' multiple='yes' class='listaRamais'");
							$cnt++;
						}
						$smarty->assign('filas', $filas);
					}
					$smarty->assign('btnOK', new HtmlBtn("salvaAltsFilas", "value='Atualizar Agentes em Filas' onclick='salvaAgsFilas()'"));
				}
				break;
				
			case 'paFilas':
				$pas = bdFacil::todos('PA');
				if(Util::tem($pas)) {
					$smarty->assign('temPAs', true);
					// Mostra somente as filas dos centros de custo do usuario logado
					$filas = $sessao->usuario->getMinhasFilas();
					if(Util::tem($filas)) {
						$cnt = 0;
						$pasFilas = bdFacil::todos("PAsFila");
						foreach($filas as $fila) {
							$fila->num = $cnt;
							$todos1 = array(); // Todos os PAs que N�O est�o na fila atual
							$todos2 = array(); // Todos os PAs que EST�O na fila atual
							foreach($pasFilas as $paFila) {
								if($paFila->idfila == $fila->id)
									$todos2[$paFila->idpa] = $paFila->descricao;
							}
							foreach($pas as $pa) {
								if(!in_array($pa->id, array_keys($todos2)))
									$todos1[$pa->id] = $pa->descricao;
							}
							$nomeCombo1 = "todosPAs$cnt";
							$nomeCombo2 = "pasNaFila$fila->id";
							
							$fila->troca = new HtmlTroca('PAs', array($nomeCombo1 => $todos1, $nomeCombo2 => $todos2), array('cntBtn' => $cnt));
							$cnt++;
						}
						$smarty->assign('filas', $filas);
						$smarty->assign('temFilas', true);
					}
					$smarty->assign('btnOK', new HtmlBtn("salvaPAsFilas", "value='Atualizar PAs em Filas' onclick='salvaPAsEmFilas()'"));
				}
				break;
			
			case 'listaPAs':
				$pas = bdFacil::todos('PA');
				if(Util::tem($pas)) {
					$imgEdit  = new HtmlImg("btnEdit.png");
					$imgEditD = new HtmlImg("btnEditDesab.png");
					$imgDel   = new HtmlImg("btnDelete.png");
					$imgRing  = new HtmlImg("btnRing.png", "tile='Tocar o Telefone para testes'");
					
					foreach($pas as $pa) {
						$chan = $pa->tipo . '/' . $pa->nome;
						if($pa->tipo == 'BR') $pa->ico1 = $imgEditD;
						else                  $pa->ico1 = "<a href='javascript:edit($pa->id, \"$pa->nome\")'>$imgEdit</a>";
						$pa->ico2 = "<a href='javascript:del($pa->id, \"$chan\")'>$imgDel</a>";
						$pa->ico3 = "<a href='javascript:ring(\"$chan\")'>$imgRing</a>";
						$pa->nat  = ($pa->nat == '1') ? "<font color='red'>ON</font>" : "Off";
						$pa->sel  = new HtmlCheck("selPAchan-$chan");
					}
					$smarty->assign('pas', $pas);
					$smarty->assign('temPAs', true);
					
					$smarty->assign('comboAcoesSel', new HtmlCombo('acoes', array(0 => '-- Escolha --', 'delPAs' => 'Remover', 'ligaNat' => 'Ligar NAT', 'desligaNat' => 'Desligar NAT'), 'onchange=ocAcoes(this)'));
				}
				break;
			
			case 'addPA':
			case 'editPA':
				$edit = ($nomeTela == 'editPA');
				$id = 0;
				if($edit) {
					list($id, $chan) = explode(':', $sessao->getVar('idPA'));
					$btnCap = "Salvar Altera��es";
					$btnAct = "editPA";
					$editParams = "id=" . $id;
				} else {
					$btnCap = "Adicionar";
					$btnAct = "novaPA";
				}
	
				$pa = new PA($id);
				$passConf = $pa->senha;
	
				if($edit)
					$smarty->assign('hiddenID', ''.new HtmlHidden('paedit', "value='$pa->nome'"));
				$smarty->assign('txtAcao', $btnAct);
				$smarty->assign('txtParams', $editParams);
				
			case 'addPAs':
				if($nomeTela == 'addPAs') {
					$pa = new PA(0);
					$btnCap = 'Adicionar';
					$smarty->assign('infoLogin', new HtmlInfo("Ex.: base = [pa] -> ir� gerar [pa01, pa02, pa03, ...]"));
					$smarty->assign('infoSenha', new HtmlInfo("Inicialmente a senha ser� igual para todos"));
					$smarty->assign('cxTxtQuant', new HtmlText("quantidade", "size='4' onkeypress='return soNum(event)' maxlength='2'"));
					$smarty->assign('cxTxtOffset', new HtmlText("offset", "size='4' onkeypress='return soNum(event)' maxlength='2'"));
					$smarty->assign('infoOffset', new HtmlInfo("Padr�o = [1]"));
				}
				
				$smarty->assign('cxTxtName', $pa->htmlText("nome", 10, "maxlength=16"));
				$smarty->assign('checkNAT',  $pa->htmlCheck('nat'));
				$smarty->assign('infoNAT',   new HtmlInfo('Marque para PAs de fora da sua rede (internet)'));
				
				$smarty->assign('cxTxtSenha', $pa->htmlPass("senha", 10, "maxlength=16"));
				$smarty->assign('cxTxtSenhaConf', new HtmlPass("senhaConf", "value='$passConf' size=10 maxlength=16"));
				
				$vdModeloTel = array(0 => 'Gen�rico', 'optiPoint410s' => 'Siemens - OptiPoint 410s', 'telipTEL' => 'Softphone TELIP');
				$smarty->assign('comboModelo', $pa->htmlComboArray("modelotel", $vdModeloTel));
				
				$smarty->assign('cxTxtDesc', $pa->htmlText("descricao", 40, "maxlength=128"));
				$smarty->assign('infoDesc', new HtmlInfo("Uma boa pr�tica � informar a localiza��o f�sica do aparelho"));

				$smarty->assign('btnOK', new HtmlBtn("ok", "value='$btnCap' onclick='addPA()'"));
				break;
			
			case 'gravacoes':
				$agenteSel = $sessao->getvar('agenteGravacao');
				$ordem     = $sessao->getVar('ordemSortGrFila'); 
				$filaSel   = $sessao->getVar('filaGravacao');
				$paginaAtual  = $sessao->getVar('pagGravacao');
				$regPorPagina = $sessao->getVar('regPorPagGrFila');
				
				if(empty($ordem))        $ordem        = 'calldate';
				if(empty($paginaAtual))  $paginaAtual  = 1;
				if(empty($regPorPagina)) $regPorPagina = 15;
				
				$filas = array('todas' => '-- Todas --');
				$conn = new Conexao();
				$conn->executa("SELECT ramal,name FROM fila");
				while($conn->temMaisDados())
					$filas[$conn->data['ramal']] = $conn->data['name'];
				asort($filas);
				
				$vdAgentes = array('todos' => '-- Todos --');
				$conn->executa("SELECT ramal,nome FROM usuario WHERE funcionalidades & ".FUNC_AGENTE." = ".FUNC_AGENTE);
				while($conn->temMaisDados())
					$vdAgentes[$conn->data['ramal']] = $conn->data['nome'];
				asort($vdAgentes);
				$conn->fecha();
					
				$smarty->assign('comboFila', new HtmlCombo('filaGravacao', $filas, "onchange='ocFila(this.value)'", $filaSel));
				$smarty->assign('comboAgente', new HtmlCombo('agenteGravacao', $vdAgentes, "onchange='ocAgente(this.value)'", $agenteSel));							
				
				$smarty->assign('linkOrdenaData',    ("calldate"    == $ordem) ? "Data"    : "<a href='javascript:ordenarPor(\"calldate\")'>Data</a>");		
				$smarty->assign('linkOrdenaAgente',  ("accountcode" == $ordem) ? "Agente"  : "<a href='javascript:ordenarPor(\"accountcode\")'>Agente</a>");
				$smarty->assign('linkOrdenaTamanho', ("billsec"     == $ordem) ? "Tamanho" : "<a href='javascript:ordenarPor(\"billsec\")'>Dura��o</a>");
				
				if(empty($agenteSel) && empty($filaSel)) $sql="SELECT id,dst,calldate,accountcode,billsec,uniqueid FROM cdr WHERE gravacao = '1' ORDER BY $ordem";
				else {
					$wFila = (empty($filaSel)   || $filaSel   == 'todas')   ? '' : "AND dst = '$filaSel'";
					$wAg   = (empty($agenteSel) || $agenteSel == 'todos') ? '' : "AND accountcode = '$agenteSel'";
					$sql = "SELECT id,calldate,accountcode,billsec,uniqueid FROM cdr WHERE gravacao = '1' $wFila $wAg ORDER BY $ordem";
				}
				
				list($total, $lsCDR) = bdFacil::paginaSQL($sql, $paginaAtual, $regPorPagina);
				if(count($lsCDR) > 0) {
					$gravacoes = array();
					$btnPlay = new HtmlImg("btnPlay.png");
					$btnDel  = new HtmlImg("btnDelete.png");

					foreach($lsCDR as $cdr) {	
						$aux = new Vazia();
						$aux->btnPlay = "<a href='javascript:tocar(\"$cdr->uniqueid\")'>$btnPlay</a>";
						$aux->btnDel  = "<a href='javascript:del(\"$cdr->uniqueid\")'>$btnDel</a>";
						$aux->data    = Util::formataData($cdr->calldate);
						$aux->agente  = $vdAgentes[$cdr->accountcode];
						$aux->tamanho = Util::formataSegundos($cdr->billsec);
						$gravacoes[]  = $aux;
					}
					if(count($gravacoes) > 0) {
						$smarty->assign('temGravacoes', true);
						$smarty->assign('gravacoes', $gravacoes);
					}
					$smarty->assign('linkPaginas', new HtmlPaginas($paginaAtual, ceil($total / $regPorPagina), 5, $regPorPagina, 'Grava��es'));	
				}
				break;
			
			case 'anuncios':
				$pasta = "arquivos/asterisk/anuncios/";
				$arqs = Arquivos::lista($pasta, false);
				if(is_array($arqs) && count($arqs) > 0) {
					$anuncios = array();
					$dir = Arquivos::getBaseDir() . $pasta;
					foreach($arqs as $file) {
						if(substr($file, 0, 8) == 'anuncio_') {
							$anuncio = new Vazia();
							$anuncio->btnPlay = "<a href=''>" . new HtmlImg("btnPlay.png") . "</a>";
							$anuncio->btnDel  = "<a href='javascript:del(\"$file\")'>" . new HtmlImg("btnDelete.png") . "</a>";
							$anuncio->arquivo = substr($file, 8);
							$anuncio->tamanho = Util::formataTamArq(filesize($dir . $file));
							$anuncios[] = $anuncio;
						}
					}
					unset($arqs);
					if(count($anuncios) > 0) {
						$smarty->assign('temAnuncios', true);
						$smarty->assign('anuncios', $anuncios);
					}
				}
				$smarty->assign('formComUpload', ' enctype="multipart/form-data"');
				$smarty->assign('cxArqEnvio', new HtmlFile("arq", "size='40'"));
				$smarty->assign('infoArqEnvio', new HtmlInfo("Arquivos MP3, GSM ou WAV"));
				$smarty->assign('btnVai', new HtmlBtn("vai", "value='OK' onclick='add()'"));
				break;
			
			case 'motivos':
				$tPausa  = array();
				$tIndisp = array();
				foreach(bdFacil::todos('TipoStatusAgente') as $motivo) {
					if($motivo->id > 100 && $motivo->id != 200) {
						$p = new Vazia();
						$p->id = $motivo->id;
						$p->descricao = $motivo->descricao;
						$tipo = ($motivo->id < 200) ? 100 : 200;
						$p->imgEdit = "<a href='javascript:edit($tipo, $motivo->id)'>" . new HtmlImg('btnEdit.png') . "</a>";
						$p->imgDel  = "<a href='javascript:del($motivo->id)'>" . new HtmlImg('btnDelete.png') . "</a>";
						
						if($motivo->id < 200) $tPausa[]  = $p;
						else                  $tIndisp[] = $p;
					}
				}
				$smarty->assign('tiposPausa',  $tPausa);
				$smarty->assign('tiposIndisp', $tIndisp);
				
				$smarty->assign('btnEditDesab', new HtmlImg('btnEditDesab.png'));
				$smarty->assign('btnDeleteDesab', new HtmlImg('btnDeleteDesab.png'));
				
				$smarty->assign('cxTxtDescPausa', new HtmlText('txtCadPausa', 'size=30')); 
				$smarty->assign('btnCadPausa', new HtmlBtn('btnCadPausa', 'value="adicionar" onclick="addMotivo(100)"'));
				$smarty->assign('cxTxtEditPausa', new HtmlText('txtEditPausa', 'size=30'));
				$smarty->assign('btnAtualizarPausa', new HtmlBtn('btnAtzPausa', 'value="atualizar" onclick="atzMot(100)"'));
				$smarty->assign('btnCancelarPausa',  new HtmlBtn('btnCancAtzP', 'value="cancelar" onclick="cancelaEdit(100)"'));
				
				$smarty->assign('cxTxtDescIndisp', new HtmlText('txtCadIndisp', 'size=30')); 
				$smarty->assign('btnCadIndisp', new HtmlBtn('btnCadIndisp', 'value="adicionar" onclick="addMotivo(200)"'));
				$smarty->assign('cxTxtEditIndisp', new HtmlText('txtEditIndisp', 'size=30'));
				$smarty->assign('btnAtualizarIndisp', new HtmlBtn('btnAtzIndisp', 'value="atualizar" onclick="atzMot(200)"'));
				$smarty->assign('btnCancelarIndisp',  new HtmlBtn('btnCancAtzI', 'value="cancelar" onclick="cancelaEdit(200)"'));
				break;
			
			case 'filaConf':
				$nivelLog = file_get_contents('/etc/asterisk/telip/cc/NIVELLOG');
				$smarty->assign('comboNivelLog', new HtmlCombo('cbNivelLog', array(5 => 'LOG_CRITICO',
																				10 => 'LOG_AVISO',
																				20 => 'LOG_NORMAL',
																				25 => 'LOG_DEBUG0',
																				30 => 'LOG_DEBUG1',
																				40 => 'LOG_DEBUG2',
																				50 => 'LOG_DEBUG3'), '', $nivelLog));
				$smarty->assign('btnNivelLog', new HtmlBtn("btnNivel", "value='Alterar Nivel de Log' onclick='nivelLog()'"));
				
				$paramsAux = bdFacil::todos("Parametro");
				$params = array();
				foreach($paramsAux as $param) {
					if($param->flags & PARAM_FILA) {
						if($param->nomeparam == 'filaTempoKA') $param->valor *= 5;
						$param->preparaLinha();
						$params[] = $param;
					}
				}
				$smarty->assign('params', $params);
				$smarty->assign('btnGravar', new HtmlBtn("btGravar", "value='Gravar as Altera��es' onclick='salvaParams()'"));
				break;
		}
	}
}
?>