<?
	include('comandos.php');
	$supervisor = loginOK();
	
	$nomeSistema = buscaNomeSistema();
	
	$filas = buscaNomesFilas();
	$comboFilas = "<select name='fila'>\n<option value='-1'>Todas</option>\n";
	foreach($filas as $id => $fila)
		$comboFilas .= "<option value='$id'>$fila</option>\n";
	$comboFilas .= "</select>\n";

	// Busca os nomes das pausas no banco de dados
	$motivos = buscaMotivos();
	
	$totfilas = count(explode(',', $supervisor->idsfilas));
	$tam = 320 + ($totfilas * 20);
	
	$temFilas = !empty($supervisor->idsfilas);
	
	// Agente
	$temTELIP = false;
	$podeDiscarPausa = true;

	// Busca os nomes das pausas no banco de dados
	$motivos  = buscaMotivos();
	$urlpopup = buscaURLPopup($supervisor);
	$urlpopupfim = buscaURLPopup($supervisor, 'fim');
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
	<head>
		<title>.: <?echo $nomeSistema?> : Supervis�o :.</title>
		<link rel="Stylesheet" href="css/supervisor.css" type="text/css" media="screen">
		<script type="text/javascript" src="javascript/Usuario.js"></script>
		<script type="text/javascript" src="javascript/Fila.js"></script>
		<script type="text/javascript" src="javascript/Total.js"></script>
		<script type="text/javascript" src="javascript/popupmenu.js"></script>
	</head>
	<body>
		<div id="divJanelaSupervisor">	
			<form name="dados">
				<div id="divCabecalho">		
					<div id="divLogo">						
					</div>	
					<table>
						<tr>
							<td>Supervisor Logado:<br><? echo $supervisor->nome ?></td>
							<td>Ramal Monitor: <input type="text" name="ramalMonitor" value="<? echo $supervisor->ramal ?>" size="4"></td>
							<td>Mostra Fila: <? echo $comboFilas ?></td>
							<td id='ultAtz'>&nbsp;</td>
							<? if($temFilas) { ?><td><input type="button" name="entrarAg" value="Entrar como Agente" onclick="entrarAgente()" ></td><? } ?>
							<td><input type="button" name="sair" value="Sair" onclick="saida()" ></td>
						</tr>	
					</table>
				</div><!--Fim Cabe�alho-->
				<div id="divJanelaAgente" style="display: none;">
					<table width="100%" border="1">
					    <tr id="barra_acao">
					    	<td id="tdDisponivel">Login</td>
					    	<td id="tdPausa">Pausa</td>
					    	<td id="tdIndisponivel">Indispon�vel</td>
							<td id="tdDiscar">Discar</td>
							<td id="tdTransferir">Transferir</td>
							<td id="tdConferencia">Confer�ncia</td>
							<? echo ($temTELIP) ? "<td id='tdTELIP'></td>\n" : '<td id="tdDesligar">Desligar</td>'; ?>
					    	<td rowspan="2" id="tdLogoff">Logoff Agente</td>
					    </tr>
					    <tr>
					    	<td colspan="3">
					    		<input class="msgAgente" type="text" size="30" name="mensagem" readonly="true">
					    		<input class="btnMsgAgente" type="button" name="limpa" value="Limpar" onclick="limpaMsg()">
					    	</td>
					    	<td colspan="4"><input type="text" name="caixaEntrada" size="25" onkeypress='return okpCxEntrada(event)'></td>
					    </tr>
					    <tr><td colspan="8"><textarea name="mensagens" rows="4" wrap="virtual" readonly='true'></textarea></td></tr>
					    <tr><td colspan="8" align="right" id="brStatus">status</td></tr>
					</table>
				</div>	
				<div id="divConteudo">
					<table id="tabelaTotais"></table><br>
							
					<table class='fila'>
						<tr>
							<td>Filas:</td>										
							<td class="dir">Mostrar filas sem agentes? <input type="checkbox" name="mostraFilaVazia" checked="true" onchange="atualizaTabelaFilas()"></td>
						</tr>
					</table>		
					<table id="tabelaFilas"></table><br>				
					<table class='agente' >
						<tr>
							<td>Agentes:</td>
							<td class="dir">Mostrar agentes deslogados? <input type="checkbox" name="mostraDeslog" onchange="atualizaTabelaAgentes()"></td>
						</tr>
					</table>			
					<table id="tabelaAgentes"></table>
					
				</div>	<!--Fim Conte�do-->					
				<div id="divRodape"></div>		
				</form>
			<div id="debug"></div>
		</div>	<!-- Fim divJanelaSupervisor	-->
		<script type="text/javascript">
			// Estados <
			DESLOGADO  = <? echo DESLOGADO  ?>;
			DISPONIVEL = <? echo DISPONIVEL ?>;
			CHAMANDO   = <? echo CHAMANDO   ?>;
			ATENDENDO  = <? echo ATENDENDO  ?>;
			SAINTE     = <? echo SAINTE     ?>;
			DISCANDO   = <? echo DISCANDO   ?>;
			ENTRANTE   = <? echo ENTRANTE   ?>;
			SUPLOGADO  = <? echo SUPLOGADO  ?>;
			PAUSA      = <? echo PAUSA      ?>;
			INDISP     = <? echo INDISP     ?>;
			
			// Tempo entre os KeepAlives, em ms
			TOKA = 40000;
			
			// AJAX
			var ajax   = new XMLHttpRequest();
			var ajaxKA = new XMLHttpRequest();
			// Comet
			var comet = null;
			
			// Dados do sistema
			var usuario  = new Usuario();	// Dados do usu�rio logado
			var txtNumEntra = '';			// Ultimo numero recebido
			
			var usuarios = new Array();
			var filas    = new Array();
			var totais   = new Total();
			
			// Nomes das pausas e indisponibilidades
			var pausas   = new Array();
			var indisp   = new Array();
			pausas[100] = 'Supervis�o';
			pausas[199] = 'Autom�tica';
			indisp[200] = 'Nao Atendimento';
<?	foreach($motivos as $id => $nome) echo '			' . (($id < 200) ? 'pausas' : 'indisp') . "[$id] = '$nome';\n"; ?>
	
			/**
			 * Fun��o chamada ao completar a requisi��o Comet
			 * Interpreta os dados de retorno, colocando os dados nos arrays 'usuario', 'filas' e 'totais' 
			 */
			function parseDados(dados) {
				estado = usuario.codstatus;
				filaat = usuario.filaatual;
				uniqueid = usuario.uniqueid;
				numentra = usuario.numentra;
				nameentra = usuario.nameentra;
				
				linhas = dados.split("\n");
				for(l=0; l<linhas.length; l++) {
					tipoLin = linhas[l].split('{');
					if(tipoLin[0] == "Agente") {
						aux = new Usuario();
						aux.parseLin(tipoLin[1]);
						usuarios[aux.id] = aux;
						if(aux.id == <? echo $supervisor->id ?>) usuario = aux;
					} else if(tipoLin[0] == "FilaCC") {
						fila = new Fila();
						fila.parseLin(tipoLin[1]);
						filas[fila.id] = fila;
					} else if(tipoLin[0] == "Totais") {
						totais = new Total();
						totais.parseLin(tipoLin[1]);
					}
				}
				
				divAg = document.getElementById("divJanelaAgente");
				if(logado && (usuario.codstatus == SUPLOGADO || usuario.codstatus == DESLOGADO)) {
					// Deslogou
					addMsg("Deslogado");
					if(usuario.keepalive == -1)
						alert("Agente Deslogado pelo servidor")
					else if(usuario.keepalive == -7) {
						alert("Servi�o desligado")
						// TODO sair
					}
					divAg.style.display = "none";
					logado = 0;
				}
				
				if(!logado) logado = (usuario.codstatus != SUPLOGADO && usuario.codstatus != DESLOGADO);
				if(logado && divAg.style.display == 'none') divAg.style.display = '';
				
				// Chamando
				if(usuario.numentra != txtNumEntra) {
					txtNumEntra = usuario.numentra;
					if(usuario.numentra.length > 0) { // <
						txtFila = (usuario.filaatual.length > 0) ? " vinda da fila [" + usuario.filaatual + "]" : ''; // <
						addMsg("Chamada entrante: [" + usuario.numentra + "]" + txtFila);
						if(usuario.nameentra.length > 0) // <
							addMsg("Dados: [" + usuario.nameentra + "]");
						
						if(urls[usuario.filaatual] != undefined) {
							aux  = urls[usuario.filaatual].replace(/%NUM%/g, usuario.numentra);
							aux2 = aux.replace(/%IDAG%/g, usuario.id);
							url  = aux2.replace(/%FILA%/g, usuario.filaatual);
							popup = window.open(url, 'CRM ' + usuario.numentra, 'width=800,height=600,top=100,left=100');
							if(window.focus) {popup.focus()}
						}
					}
				}
				// Foi para atendendo
				if(estado != ATENDENDO && usuario.codstatus == ATENDENDO) {
					addMsg('Chamada capturada. Tempo que estava em fila: ' + usuario.holdtime + ' s');
					// Envio do UniqueID no momento do atendimento da chamada
					if(popup.document.getElementById('uniqueid'))
						popup.document.getElementById('uniqueid').value = usuario.uniqueid;
				}
				
				// Saiu de atendendo
				if(estado == ATENDENDO && usuario.codstatus != ATENDENDO) {
					if(urlsfim[filaat] != undefined) {
						aux  = urlsfim[filaat].replace(/%NUM%/g, numentra);
						aux2 = aux.replace(/%FILA%/g, filaat);
						aux  = aux2.replace(/%DADOS%/g, nameentra);
						aux2 = aux.replace(/%IDAG%/g, usuario.id);
						url  = aux2.replace(/%UID%/g, uniqueid);
						popup = window.open(url, 'CRM ' + numentra, 'width=800,height=600,top=100,left=100');
						popup.focus();
					}
				}
				
				atualizaTela();
			}
			
			/**
			 * Atualiza a tela conforme os dados do Usu�rio
			 */
			function atualizaTela() {
				atualizaTabelaFilas();
				atualizaTabelaAgentes();
				document.getElementById('ultAtz').innerHTML = '�ltima Atz: ' + totais.agora;
				
				// Agente
				if(usuario.codstatus > 0 && usuario.codstatus != SUPLOGADO) // <
					atualizaDadosUsuario();
			}
			
			function atualizaTabelaFilas() {
				colunas = new Array('Nome', 'Agentes', 'Fila', 'Atendidas', 'Abandonadas', 'N�v.Servi�o', 'T. 1o', 'TME', 'TMA');
				
				novaTabela = document.createElement('table');
				novaTabela.setAttribute("cellspacing", "0");
				novaTabela.setAttribute("align", "center");
				novaTabela.setAttribute("width", "100%");
				novaTabela.setAttribute("class", "tabelaFila");
				novaTabela.setAttribute("id", "tabelaFilas");
				tHead = document.createElement('thead');
				for(th=0; th<colunas.length; th++) {
					col = document.createElement('td');							
					col.innerHTML = colunas[th];					
					if(th==colunas.length-1)col.setAttribute("class","ultimo");
					tHead.appendChild(col);
				}
				
				novaTabela.appendChild(tHead);
				
				filaSel = document.dados.fila.value;
				
				l = 0;
				for(f in filas) {
					totaglog = (filas[f].totaglog) ? filas[f].totaglog : 0;
					//if((filaSel == -1 || filas[f].id == filaSel) && (document.dados.mostraFilaVazia.checked || totaglog > 0)) { // <
					if((filaSel == -1 || (filaSel == 6 && (filas[f].id == 1 || filas[f].id == 3 || filas[f].id == 8)) || filas[f].id == filaSel) && (document.dados.mostraFilaVazia.checked || totaglog > 0)) { // <
						novaLinha = document.createElement('tr');
						novaLinha.setAttribute("class", "linha" + l);
						l = 1 - l;
						for(th=0; th<colunas.length; th++) {
							col = document.createElement('td');
							switch(colunas[th]) {
								case 'Nome':
									 col.innerHTML ="<b>" + filas[f].nome + "</b> - " + filas[f].ramal;	//<
									 break;
								case 'Agentes':
									totag = (filas[f].totag) ? filas[f].totag : 0;
									col.innerHTML = "<b>" + totaglog + "</b> / " + totag;	//<
									break;
								case 'Fila':
									classeAlerta = '';
									if(filas[f].qtdchamespera      > 10) classeAlerta = 'tdAlerta3';//<
									else if(filas[f].qtdchamespera >  6) classeAlerta = 'tdAlerta2';//<
									else if(filas[f].qtdchamespera >  3) classeAlerta = 'tdAlerta1';//<
									else if(filas[f].qtdchamespera >  0) classeAlerta = 'tdAlerta0';//<
									if(classeAlerta != '')
										col.setAttribute("class", classeAlerta);
									col.innerHTML = filas[f].qtdchamespera;
									break;
								case 'Atendidas':   col.innerHTML = filas[f].qtdchamatendida;  break;
								case 'Abandonadas': col.innerHTML = filas[f].qtdchamaband;     break;
								case 'N�v.Servi�o': col.innerHTML = filas[f].servicelevel + "% / " + filas[f].tempons + " s";  break;
								case 'T. 1o':       col.innerHTML = filas[f].tempoespera;      break;
								case 'TME':         col.innerHTML = filas[f].tempomedioespera; break;
								case 'TMA':
									tma = (filas[f].tempototalatend != '' && filas[f].qtdchamatendida > 0) ? formataSegundos(filas[f].tempototalatend / filas[f].qtdchamatendida) : '0:00';	//<
									col.innerHTML = tma;
									break;
							}
							novaLinha.appendChild(col);
						}
						novaTabela.appendChild(novaLinha);
					}
				}
				
				tabela = document.getElementById('tabelaFilas');
				tabela.parentNode.replaceChild(novaTabela, tabela);				
			}
			
			function atualizaTabelaAgentes() {
				colunas = new Array('&nbsp;', 'Estado', 'Nome', 'Ramal', 'Telefone', 'Tempo', 'Eft', 'Rec', 'TTA', 'TMA', 'A��es');
				
				novaTabela = document.createElement('table');
				novaTabela.setAttribute("align", "center");
				novaTabela.setAttribute("width", "100%");
				novaTabela.setAttribute("class", "tabelaAgs");
				novaTabela.setAttribute("id", "tabelaAgentes");
				tHead = document.createElement('thead');
				for(th=0; th<colunas.length; th++) {
					col = document.createElement('td');
					if(colunas[th] == '&nbsp;') col.setAttribute("class", "tdTransp");
					else if(colunas[th] == 'A��es') col.setAttribute("align", "center");
					col.innerHTML = colunas[th];
					tHead.appendChild(col);
				}
				novaTabela.appendChild(tHead);
				
				filaSel = document.dados.fila.value;
				
				temAgs = false;
				l = 0;
				for(usr in usuarios) {
					if(usuarios[usr].codstatus != 10 && (document.dados.mostraDeslog.checked || usuarios[usr].codstatus > 0)) {	//<
						tahNaFila = false;
						if(filaSel == -1) tahNaFila = true;
						else {
							filasUsr = usuarios[usr].idsfilas.split(',');
							for(cnt=0; cnt<filasUsr.length; cnt++)
								if(filasUsr[cnt] == filaSel || (filaSel == 6 && (filasUsr[cnt] == 1 || filasUsr[cnt] == 3 || filasUsr[cnt] == 8))) {
									tahNaFila = true;
									break;
								}
						}
						if(tahNaFila) {
							temAgs = true;
							aux = usuarios[usr].telefone.split("/");
							aux = aux[1];
							tel = (aux != usuarios[usr].ramal) ? " - " + aux : '';
							estado = getClassEstado(usuarios[usr]);
							novaLinha = document.createElement('tr');
							novaLinha.setAttribute("class", "linhaAg" + l);
							l = 1 - l;
							for(th=0; th<colunas.length; th++) {
								col = document.createElement('td');
								switch(colunas[th]) {
									case '&nbsp;':
										col.setAttribute("width", "1px");
										col.innerHTML = "<img src='gfx/status/status_" + estado + ".png'>";	//<
										break;
									case 'Estado':
										col.setAttribute("class", estado);
										col.setAttribute("align", "center");
										col.innerHTML = "<b>" + getNomeEstado(usuarios[usr]) + "</b>"; // <
										break;
									case 'Nome':  col.innerHTML = usuarios[usr].nome;  break;
									case 'Ramal': col.innerHTML = usuarios[usr].ramal + tel; break;
									case 'Telefone':
										if(usuarios[usr].codstatus == ATENDENDO)   col.innerHTML = usuarios[usr].numentra + ((usuarios[usr].filaatual != '') ? ' - ' + usuarios[usr].filaatual : '');
										else if(usuarios[usr].codstatus == SAINTE) col.innerHTML = usuarios[usr].numsai;
										break;
									case 'Tempo': col.innerHTML = formataSegundos(usuarios[usr].tempostatus); break;
									case 'Eft':   col.innerHTML = usuarios[usr].efetuadas;                    break;
									case 'Rec':   col.innerHTML = usuarios[usr].recebidas;                    break;
									case 'TTA':   col.innerHTML = formataSegundos(usuarios[usr].tta);         break;
									case 'TMA':   col.innerHTML = formataSegundos(usuarios[usr].tma);         break;
									case 'A��es':
										col.setAttribute("align", "center");
										col.innerHTML = imagensAcoes(usuarios[usr]);
										break;
								}
								novaLinha.appendChild(col);
							}
							novaTabela.appendChild(novaLinha);
						}
					}
				}
				
				if(!temAgs) {
					novaLinha = document.createElement('tr');
					novaLinha.setAttribute("class", "linha1");
					col = document.createElement('td');
					col.setAttribute("colspan", colunas.length);
					col.innerHTML = (filaSel == -1) ? "Nenhum agente" : "Nenhum agente nesta fila";
					novaLinha.appendChild(col);
					novaTabela.appendChild(novaLinha);
				}
				
				tabela = document.getElementById('tabelaAgentes');
				tabela.parentNode.replaceChild(novaTabela, tabela);
				
				colunas = new Array('total', 'logado', 'disponivel', 'atendendo', 'sainte', 'entrante', 'pausa', 'indisponivel', 'deslogado');
				tabelaTotais = document.createElement('table');
				tabelaTotais.setAttribute("align", "center");
				tabelaTotais.setAttribute("width", "100%");
				tabelaTotais.setAttribute("class", "tabelaTot");
				tabelaTotais.setAttribute("id", "tabelaTotais");
				
				linha = document.createElement('tr');
				for(th=0; th<colunas.length; th++) {
					col = document.createElement('td');
					col.setAttribute("class", colunas[th]);
					switch(colunas[th]) {
						case 'total':	     col.innerHTML = 'Total<br>'          + ((totais.total        > 0) ? totais.total        : 0); break;	//<
						case 'logado':       col.innerHTML = 'Logados<br>'        + ((totais.logado       > 0) ? totais.logado       : 0); break;	//<
						case 'disponivel':   col.innerHTML = 'Dispon�veis<br>'    + ((totais.disponivel   > 0) ? totais.disponivel   : 0); break;	//<
						case 'atendendo':    col.innerHTML = 'Em Atendimento<br>' + ((totais.atendimento  > 0) ? totais.atendimento  : 0); break;	//<
						case 'sainte':       col.innerHTML = 'Sainte<br>'         + ((totais.sainte       > 0) ? totais.sainte       : 0); break;	//<
						case 'entrante':     col.innerHTML = 'Entrante Direta<br>'+ ((totais.entrante     > 0) ? totais.entrante     : 0); break;	//<
						case 'pausa':        col.innerHTML = 'Em Pausa<br>'       + ((totais.empausa      > 0) ? totais.empausa      : 0); break;	//<
						case 'indisponivel': col.innerHTML = 'Indispon�veis<br>'  + ((totais.indisponivel > 0) ? totais.indisponivel : 0); break;	//<
						case 'deslogado':    col.innerHTML = 'Deslogados<br>'     + ((totais.deslogado    > 0) ? totais.deslogado    : 0); break;	//<
					}
					linha.appendChild(col);
				}
				tabelaTotais.appendChild(linha);
				
				tabela = document.getElementById('tabelaTotais');
				tabela.parentNode.replaceChild(tabelaTotais, tabela);
			}
			
			function enviaMsg(idAg, nome) {
				msg = prompt("Digite a mensagem a enviar para " + nome, "");
				enviaComando("enviaMsg:" + idAg + ":" + msg);
			}
			
			function pegaChamada(acao, idAg) {
				ramalSup = document.dados.ramalMonitor;
				if(ramalSup.value == '') {
					alert('Digite o ramal Monitor!');
					ramalSup.focus();
				} else
					enviaComando(acao + ":" + idAg + ":" + ramalSup.value);
			}
		
			function mudaStatus(idAg, stsNovo) {
				enviaComando("mudaStatus:" + idAg + ":" + stsNovo);
			}
			function mudaStatusBase(idAg) {
				enviaComando("pausaStatusBase:" + idAg);
			}
			function desloga(idAg) {
				enviaComando("desloga:" + idAg);
			}
			
			function entrarAgente() {
				atualizaDadosUsuario();
				
				divAg = document.getElementById("divJanelaAgente");
				divAg.style.display = "";
			}
			
			function pause(numberMillis)
			{
				var now = new Date();
				var exitTime = now.getTime() + numberMillis;
				while (true) {
					now = new Date();
					if (now.getTime() > exitTime) // <
						return;
				}
			}
			function saida() {
				enviaComando('logoff');
				pause(800);
				window.location = 'logoff.php';
			}
			
			function getNomeEstado(usuario) {
				     if(usuario.codstatus == DESLOGADO)  return "Deslogado";
				else if(usuario.codstatus == DISPONIVEL) return "Dispon�vel";
				else if(usuario.codstatus == CHAMANDO)   return "Chamando";
				else if(usuario.codstatus == ATENDENDO)  return "Entrante ACD";
				else if(usuario.codstatus == SAINTE)     return "Liga��o Sainte";
				else if(usuario.codstatus == DISCANDO)   return "Discando";
				else if(usuario.codstatus == ENTRANTE)   return "Entrante Direta";
				else if(usuario.codstatus >= INDISP) {	//<
					return indisp[usuario.codstatus];
				} else {
					return pausas[usuario.codstatus];
				}
			}
			
			function getClassEstado(usuario) {
				     if(usuario.codstatus == DESLOGADO)  return "deslogado";
				else if(usuario.codstatus == DISPONIVEL) return "disponivel";
				else if(usuario.codstatus == CHAMANDO)   return "chamando";
				else if(usuario.codstatus == ATENDENDO)  return "atendendo";
				else if(usuario.codstatus == SAINTE)     return "sainte";
				else if(usuario.codstatus == DISCANDO)   return "discando";
				else if(usuario.codstatus == ENTRANTE)   return "entrante";
				else if(usuario.codstatus >= INDISP)     return "indisponivel";	//<
				else                                     return "pausa";
			}
			
			function imagensAcoes(usr) {
				id  = usr.id;
				ret = (usr.codstatus > 0) ? "<a href='javascript:enviaMsg("+id+", \""+usr.nome+"\")'><img src='gfx/acoes/mensagem.png' title='Enviar Mensagem' /></a> " : "";	//<
				if(usr.codstatusbase == 100 && usr.codstatus != 100) {
					ret += "<img title='O agente ser� pausado quando terminar o atendimento' src='gfx/acoes/pausa_sup.png' /> ";
				} else {
					if(usr.codstatus >= 100)    ret += "<a href='javascript:mudaStatus("+id+", "+DISPONIVEL+")'><img src='gfx/acoes/disponivel.png' title='Tornar Dispon�vel' /></a> ";	//< 
					else if(usr.codstatus == 1) ret += "<a href='javascript:mudaStatus("+id+", "+PAUSA+")'><img src='gfx/acoes/pausa.png' title='Pausar' /></a> ";	//<
					else if(usr.codstatus != 0) ret += "<a href='javascript:mudaStatusBase("+id+")'><img src='gfx/acoes/pausa_emlig.png' title='Pausar ap�s atendimento' /></a> ";	//<
				}
				if(usr.codstatus != ATENDENDO) {
					ret +=  "<img src='gfx/acoes/Off/escutaChamada.png' /> " +
							"<img src='gfx/acoes/Off/sussurraChamada.png' /> " +
							"<img src='gfx/acoes/Off/entraChamada.png' /> ";
				} else {	//<
					tel = usr.telefone;
					ret +=  "<a href='javascript:pegaChamada(\"escutaChamada\", "+id+")'><img src='gfx/acoes/escutaChamada.png' title='Escutar Chamada' /></a> " +
							"<a href='javascript:pegaChamada(\"sussurraChamada\", "+id+")'><img src='gfx/acoes/sussurraChamada.png' title='Sussurar na Chamada' /></a> " +
							"<a href='javascript:pegaChamada(\"entraChamada\", "+id+")'><img src='gfx/acoes/entraChamada.png' title='Entrar na Chamada' /></a> ";
				}	//<
				if(usr.codstatus != DESLOGADO) ret += " <a href='javascript:desloga("+id+")'><img src='gfx/acoes/deslogar.png' title='Deslogar' /></a>";	//<
				return ret;
			}
			
			/**
			 * Envia um comando a ser executado pelo controle do CallCenter
			 */
			function enviaComando(cmd) {
				ajax.open("GET", "enviaComando.php?Comando=<?echo $supervisor->id?>:" + cmd, true);
				ajax.send(null);
			}
			
			/**
			 * Inicializa o http 'persistente' (Comet)
			 */
			function initComet() {
				comet = new XMLHttpRequest();
				comet.multipart = true;
				comet.open("GET", "cometSupervisor.php", true);
				comet.onload = handleContent;
				comet.send(null);
				
				setTimeout("initComet()", 45200);// Reinicializa a conex�o Comet a cada 45s
			}
			function handleContent(event) {
				parseDados(event.target.responseText);
			}
			
			function formataSegundos(segs) {
				segundos = Math.ceil(segs);
				minutos = Math.floor(segundos / 60);
				if(minutos > 0) {	//<
					segundos -= (minutos * 60);
					if(segundos < 10) segundos = "0"+segundos;
					horas = Math.floor(minutos / 60);
					if(horas > 0) {
						minutos -= (horas * 60);
						if(minutos < 10) minutos = "0"+minutos;
						return horas+":"+minutos+":"+segundos;
					} else {
						return minutos+":"+segundos;
					}
				} else {
					return (segundos < 10) ? "0:0"+segundos : "0:"+segundos;
				}
			}
			
			
			
			
			
			
			
			
			// Agente
			var urls    = new Array();		// URLs para popup por fila
			var urlsfim = new Array();		// URLs para popup ao desligar por fila
			
			// Variaveis de Controle
			var logado      = 0;			// Flag
			var txtNumEntra = '';			// Ultimo numero recebido
			var ultimoBtn   = '';			// Ultimo bot�o clicado, para prevenir duplo clique nos botoes
			var linha       = true;			// Cor da linha da tabela de filas
			
			// "widgets"
			var cxMsg;
			var btnDisponivel, btnPausa, btnIndisponivel, btnLogoff;
			var btnDiscar, btnTransferir, btnConferencia;
			var cxTxtEntrada, cxMensagens, popupPausa, popupIndisp;
			var popup; // Janela CRM
			
			var msgs = new Array('', '', '', '');
						
			
			function atualizaDadosUsuario() {
				if(!logado) {
					btnDisponivel.innerHTML   = 'Login';
					btnDisponivel.className   = 'botao';
					btnPausa.className        = 'botaoDesab';
					btnIndisponivel.className = 'botaoDesab';
					btnLogoff.className       = 'botao';
					btnDiscar.className       = 'botaoDesab';
					btnTransferir.className   = 'botaoDesab';
					btnConferencia.className  = 'botaoDesab';
					<? echo ($temTELIP) ? "btnTelip.className = 'botaoDesab';\n" : "btnDesligar.className = 'botaoDesab';\n"; ?>
				} else {
					emLig = (usuario.codstatus == ATENDENDO || usuario.codstatus == SAINTE || usuario.codstatus == ENTRANTE || usuario.codstatus == CHAMANDO);
					
					// Bot�o DISPONIVEL
					if(usuario.codstatus == DISPONIVEL) {
						btnDisponivel.innerHTML = 'Dispon�vel';
						btnDisponivel.className = 'botaoDisponivel';
					} else if(usuario.codstatus == CHAMANDO) {
						btnDisponivel.innerHTML = 'Chamando';
						btnDisponivel.className = 'botaoChamando';
					} else if(usuario.codstatus == ATENDENDO) {
						btnDisponivel.innerHTML = 'Atendendo';
						btnDisponivel.className = 'botaoAtendendo';
					} else if(usuario.codstatus == SAINTE) {
						btnDisponivel.innerHTML = 'Sainte';
						btnDisponivel.className = 'botaoAtendendo';
					} else if(usuario.codstatus == ENTRANTE) {
						btnDisponivel.innerHTML = 'Entrante';
						btnDisponivel.className = 'botaoAtendendo';
					} else {
						btnDisponivel.innerHTML = 'Dispon�vel';
						btnDisponivel.className = 'botao';
					}
					
					// Bot�o PAUSA
					btnPausa.className = (emLig) ? 'botaoDesab' : ((usuario.codstatus >= PAUSA && usuario.codstatus < INDISP)  ? 'botaoAtivo' : 'botao');
					btnPausa.innerHTML = (btnPausa.className == 'botaoAtivo') ? '<font size="2">Pausa</font><br>' + pausas[usuario.codstatus] : 'Pausa'; // <
					
					// Bot�o INDISPONIVEL
					btnIndisponivel.className = (emLig) ? 'botaoDesab' : ((usuario.codstatus >= INDISP) ? 'botaoAtivo' : 'botao'); // <
					btnIndisponivel.innerHTML = (btnIndisponivel.className == 'botaoAtivo') ? '<font size="2">Indispon�vel</font><br>' + indisp[usuario.codstatus] : 'Indispon�vel'; // <
					
					// Bot�o LOGOFF
					btnLogoff.className = (emLig) ? 'botaoDesab' : 'botao';

					// Bot�es DISCAR, TRANSFERIR e CONFERENCIA
					atualizaEstadoBotoes();
					
<?	if($temTELIP) { ?>
					// Bot�o TELIP
					if(emLig) {
						btnTelip.innerHTML = 'Desligar';
						btnTelip.className = 'botao';
					} else if(usuario.codstatus == CHAMANDO) {
						btnTelip.innerHTML = 'Atender';
						btnTelip.className = 'botao';
					} else {
						btnTelip.innerHTML = 'Aguarde';
						btnTelip.className = 'botaoDesab';
					}
<?	} else { ?>
					// Bot�o Desligar
					btnDesligar.className = (emLig) ? 'botao' : 'botaoDesab';
<?	} ?>
					
					// Mostrar as mensagens do banco de dados
					cxMsg.value = usuario.msg;
				}
				// Atualiza o rodap� da janela com os dados do agente
				document.getElementById('brStatus').innerHTML = "Ramal: <b><? echo $agente->ramal; ?></b> - PA: <b><? echo $agente->telefone; ?></b> - Efetuadas: <b>" +
																usuario.efetuadas + "</b> - Recebidas: <b>" + usuario.recebidas + "</b>"; // <
				
				// Redimensiona a janela
				//tamLogin = (usuario.codstatus > 0) ? 4 : 0; // <
				//tamPausa = (usuario.codstatus >= 100) ? 22 : 0; // <
				//self.resizeTo(582, 346 + tamLogin + tamPausa + (filas.length * 22));
			}
			
			/**
			 * Separado para ser usado no onKeyPress da caixa de texto
			 */
			function atualizaEstadoBotoes() {
				emLig = (usuario.codstatus == ATENDENDO || usuario.codstatus == SAINTE || usuario.codstatus == ENTRANTE || usuario.codstatus == DISCANDO || usuario.codstatus == CHAMANDO);
				
				// Bot�o DISCAR - desab se estiver em ligacao, e so habilitado caso haja texto na caixa de discagem
				podeDiscarPausa = <? echo($podeDiscarPausa ? 'INDISP' : 'PAUSA'); ?>;
				btnDiscar.className = (!logado || emLig || cxTxtEntrada.value == "" || usuario.codstatus >= podeDiscarPausa) ? 'botaoDesab' : 'botao'; // <
				
				// Bot�o TRANSFERIR - habilitado caso haja texto na caixa de discagem e estiver em liga�ao ou com chamada retida
				btnTransferir.className = (!logado || !emLig || cxTxtEntrada.value == "") ? 'botaoDesab' : 'botao';
				
				// Bot�o CONFERENCIA - habilitado caso haja texto na caixa de discagem e estiver em liga�ao
				btnConferencia.className = (!logado || !emLig || cxTxtEntrada.value == "") ? 'botaoDesab' : 'botao';
			}
			
			/**
			 * O nome do ultimo botao de status clicado fica guardado, para se o usuario clica-lo de novo possamos dar
			 * uma mensagem de 'Em processamento'. Isto s� ocorre no meio tempo em que foi solicitado
			 * mas esta ainda nao refletiu na janela do cliente. Apos ocorrer a mudan�a o botao clicado fica ativo, e assim
			 * nao pode ser clicado. Apos 2 s o nome do botao � removido da memoria, assim podendo ser clicado de novo em 
			 * caso de falha na mudan�a de estado.
			 */
			function setaUltimoBtn(nomeBtn) {
				ultimoBtn = nomeBtn;
				setTimeout("limpaUltimoBtn()", 2000); // zera a var de btn clicado apos 2s
			}
			function limpaUltimoBtn() {
				ultimoBtn = '';
			}
			
			/**
			 * Fun��es dos bot�es
			 */			
			function on_Disponivel_clicked() {
				if(btnDisponivel.className == 'botao') {
					if(!logado) {
						setaUltimoBtn('disponivel');
						enviaComando('loginSupAg:<?echo $supervisor->telefone . (($supervisor->mobilidd) ? ':MOBILIDADE' : '') ?>');
						addMsg('Solicitado Login');
					} else {
						if(ultimoBtn != 'disponivel') {
							setaUltimoBtn('disponivel');
							enviaComando("mudaStatusAg:"+ DISPONIVEL);
							addMsg('Solicitado status de Dispon�vel');
						} else
							addMsg('Por favor aguarde. Em processamento.');
					}
				}
			}
			function on_Pausa_clicked(codP) {
				enviaComando("mudaStatusAg:"+ codP);
				addMsg('Solicitado status de Pausa ' + pausas[codP]);
			}
			function on_Indisponivel_clicked(codI) {
				enviaComando("mudaStatusAg:"+ codI);
				addMsg('Solicitado status de Indispon�vel ' + indisp[codI]);
			}
			function on_Logoff_clicked() {
				if(btnLogoff.className != 'botaoDesab') {
					if(!logado) {
						divAg = document.getElementById("divJanelaAgente");
						divAg.style.display = "none";
					} else {
						enviaComando("logoffSupAg");
						addMsg('Solicitado Logoff');
					}
				}
			}
			function on_Discar_clicked() {
				if(btnDiscar.className != 'botaoDesab') {
					addMsg('Discando para ' + cxTxtEntrada.value);
					enviaComando("disca:"+ cxTxtEntrada.value);
				}
			}
			function on_Transferir_clicked() {
				if(btnTransferir.className != 'botaoDesab') {
					var esp = '';
					if(usuario.canalespera != '') {
						esp = ' em espera';
						desespera = 1;
					}
					enviaComando("transferir:" + cxTxtEntrada.value);
					addMsg('Transferir chamada' + esp + ' para ' + cxTxtEntrada.value);
				}
			}
			function on_Conferencia_clicked() {
				if(btnConferencia.className != 'botaoDesab') {
					enviaComando("conferencia:" + cxTxtEntrada.value);
					addMsg('Entrando em confer�ncia com ' + cxTxtEntrada.value);
				}
			}
<?	if($temTELIP) { ?>
			var cntTELIP = 0;
			function enviaComandoTelip(cmd) {
				out = cmd + '-' + cntTELIP++;
				addMsg('Envia Comando TELIP: ' + out);
				imgTelip = document.getElementById('imgTELIP');
				imgTelip.src = 'http://127.0.0.1:8080/action.' + out;
			}
			function on_TELIP_clicked() {
				if(btnTelip.className != 'botaoDesab') {
					enviaComandoTelip((btnTelip.innerHTML == 'Atender') ? 'a' : 'h');
				}
			}
<?	}  else { ?>
			function on_Desligar_clicked() {
				if(btnDesligar.className != 'botaoDesab') {
					enviaComando("desligar");
					addMsg('Desligando chamada');
				}
			}
<?	} ?>

			/**
			 * Fun�ao de 'onKeyPress' da caixa de discagem, atua sobre o ENTER nesta caixa
			 */
			function okpCxEntrada(e) {
				var codTecla = e.which;
				if(codTecla == 13) { // Pressionou ENTER na caixa de discagem
					if(usuario.codstatus == 3) on_Transferir_clicked();
					else                       on_Discar_clicked();
					return false;
				} else if(codTecla < 32)
					return true;
				
				var regExpNumerico = /^[0-9*][0-9*]*$/;
				var chr = String.fromCharCode(codTecla);
				return(regExpNumerico.test(e.target.value + chr));
			}
			
			/**
			 * Adiciona uma mensagem na TEXTAREA
			 */
			function addMsg(msg) {
				agora = new Date();
				hora = agora.getHours();
				minu = agora.getMinutes();
				secs = agora.getSeconds();
				if(hora < 10) hora = '0' + hora; 
				if(minu < 10) minu = '0' + minu;
				if(secs < 10) secs = '0' + secs; 
				hora = hora + ":" + minu + ":" + secs;
				msg = hora + " > " + msg;
				
				for(c=1; c<4; c++)
					msgs[c - 1] = msgs[c];
				msgs[3] = msg;

				var txtAux = "";
				for(c=0; c<4; c++)
					txtAux += msgs[c] + "\n";
				
				cxMensagens.value = txtAux;
			}
			
			/**
			 * Limpa a mensagem enviada pela supervisao
			 */
			function limpaMsg() {
				enviaComando("limpaMsg");
			}
			
			/**
			 * Envia o comando de keepAlive periodicamente
			 */
			function keepAlive() {
				ajaxKA.onreadystatechange = function() {
			        if(ajaxKA.readyState==4) {
			            if(ajaxKA.responseText == 0) {
							alert("Deslogado pelo servidor (servi�o desligado)")
							window.location = "logoff.php";
						}
			        }
			    };
				ajaxKA.open("GET", "enviaComando.php?Comando=<?echo "$supervisor->id:keepAlive:$supervisor->ramal"?>", true);
				ajaxKA.send(null);
				setTimeout("keepAlive()", TOKA);
			}
			
			/**
			 * Inicializa��o
			 */
			function initAg() {
				btnDisponivel   = document.getElementById('tdDisponivel');
				btnPausa        = document.getElementById('tdPausa');
				btnIndisponivel = document.getElementById('tdIndisponivel');
				btnLogoff       = document.getElementById('tdLogoff');
				btnDiscar       = document.getElementById('tdDiscar');
				btnTransferir   = document.getElementById('tdTransferir');
				btnConferencia  = document.getElementById('tdConferencia');
<?	if($temTELIP) { ?>
				btnTelip        = document.getElementById('tdTELIP');
				btnTelip.innerHTML = 'Aguarde';
<?	} else { ?>
				btnDesligar     = document.getElementById('tdDesligar');
<?	} ?>
				
				btnDisponivel.onclick   = on_Disponivel_clicked;
				btnLogoff.onclick       = on_Logoff_clicked;
				btnDiscar.onclick       = on_Discar_clicked;
				btnTransferir.onclick   = on_Transferir_clicked;
				btnConferencia.onclick  = on_Conferencia_clicked;
				<? echo ($temTELIP) ? "btnTelip.onclick        = on_TELIP_clicked;\n" : "btnDesligar.onclick        = on_Desligar_clicked;\n"; ?>
				
				popupPausa = new PopupMenu(PAUSA);
				pausas[100] = 'Supervisao';
				pausas[199] = 'Autom�tica';
<?	// Nomes das pausas buscados no banco:
	foreach($motivos as $idP => $nomeP) {
		if($idP < 200) { ?>
				pausas[<? echo $idP ?>] = '<? echo $nomeP ?>';
				popupPausa.add('<? echo $nomeP ?>', function(target) {
					on_Pausa_clicked(<? echo $idP ?>);
				});
<?		}
	} ?>
				popupPausa.setSize(170, 0);
				popupPausa.bind('tdPausa');
				
				popupIndisp = new PopupMenu(INDISP);
				indisp[200] = 'Nao Atendimento';
<?	// Nomes das Indisp buscados no banco:
	foreach($motivos as $idI => $nomeI) {
		if($idI > 200) { ?>
				indisp[<? echo $idI ?>] = '<? echo $nomeI ?>';
				popupIndisp.add('<? echo $nomeI ?>', function(target) {
					on_Indisponivel_clicked(<? echo $idI ?>);
				});
<?		}
	} ?>
				popupIndisp.setSize(170, 0);
				popupIndisp.bind('tdIndisponivel');

<?	foreach($urlpopup as $nomeFila => $URL) { // URLs de popup das filas  ?>
				urls['<? echo $nomeFila ?>'] = '<? echo $URL ?>';
<?	} ?>				
<?	foreach($urlpopupfim as $nomeFila => $URL) { // URLs de popup das filas ao desligar  ?>
				urlsfim['<? echo $nomeFila ?>'] = '<? echo $URL ?>';
<?	} ?>	
				cxTxtEntrada         = document.dados.caixaEntrada;
				cxTxtEntrada.onkeyup = atualizaEstadoBotoes;
				
				cxMensagens = document.dados.mensagens;
				cxMsg       = document.dados.mensagem;
/*
				// Busca os dados inciais
				ajax.open("GET", "buscaDados.php", false);
				ajax.send(null);
				parseDados(ajax.responseText);
				
				// Caso F5
				if(usuario.codstatus > 0) {  // <
					logado = true;
					initComet();
					setTimeout("keepAlive()", 6000);
				}
*/
			}
			initAg();
			
			setTimeout("initComet()", 1000);
			setTimeout("keepAlive()", 6000);
		</script>
	<body>
</html>