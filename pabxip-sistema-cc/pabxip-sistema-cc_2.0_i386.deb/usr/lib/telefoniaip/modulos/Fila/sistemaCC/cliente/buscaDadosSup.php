<?php
	include('comandos.php');
	foreach(buscaDadosSup() as $obj)
		echo "$obj\n";
?>
