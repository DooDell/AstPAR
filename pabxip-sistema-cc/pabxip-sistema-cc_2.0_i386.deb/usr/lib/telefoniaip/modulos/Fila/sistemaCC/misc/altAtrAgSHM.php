<?php
	if($argc != 4 || $argv[1] < 1000 || $argv[1] > 9999) {
		echo "Uso: atlAtrAgSHM.php [ID Agente] [nomeAtr] [valAtr]\n";
		exit(1);
	}
	
	include('../constantes.php');
	
	$atr  = $argv[2];
	if(!in_array($atr, array_keys(get_class_vars('Agente'))) || $atr == 'IDSHMEM' || $atr == 'POSICAOSHMEM' || $atr == 'MEMPOROBJ') {
		echo "Atributo de Agente [$atr] invalido.\n";
		exit(2);
	}
	
	$idAg = $argv[1];
	$val  = $argv[3];	
	
	$mem = new SharedMem(ID_SHMEM_AGS, 'Agente', null, '', 'ESCRITA', array('incializa' => false));
	$agente = $mem->get('ramal', $idAg);
	if(is_a($agente, 'Agente')) {
		echo "Agente [$agente->nome] => setar $atr = $val: ";
		$agente->$atr = $val;
		$conCC = new ControleCC();
		if(($err = $agente->atualiza(true, $mem->getID())) === true) $err = "OK";
		echo "$err\n";
	} else {
		echo "ID de Agente [$idAg] invalido.\n";
		exit(10);
	}
	$mem->shut();
	
	
	
	
	
// Classe para "fingir" que � o controleCC
class ControleCC {
	public static $memFlags, $memAgs;
	function ControleCC() {
		ControleCC::$memFlags = @shmop_open(ID_SHMEM_FLAGS, 'w', 0, 0);
		if (!ControleCC::$memFlags) {
			echo "Problemas inicializar memoria compartilhada de flags!";
			die;
		}
		ControleCC::$memAgs = new SharedMem(ID_SHMEM_AGS, 'Agente');
	}
	static function setaFlagAltSups() {
		$supervisores = ControleCC::$memAgs->getObjs('funcionalidades', FUNC_SUPERVISOR, '&');
		foreach($supervisores as $sup)
			shmop_write(ControleCC::$memFlags, '1', $sup->ramal);
	}
	static function loga($nivel, $msg) {
		echo "[$nivel] => $msg\n";
	}
}
?>