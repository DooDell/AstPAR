<?php
class InfoHost {
	public $host, $port, $user, $pass, $db;
	function InfoHost($host, $port, $user, $pass, $db='') {
		$this->host = $host;
		$this->port = $port;
		$this->user = $user;
		$this->pass = $pass;
		$this->db   = $db;
	}
}
?>