<?php
	include(''.'/usr/lib/telefoniaip/modulos/Fila/sistemaCC/constantes.php');
	
	$DEBUG = false;
	
	// Buscar agentes logados no sistemaCC
	$memAgs = new SharedMem(ID_SHMEM_AGS, 'Agente');
	$agsCC = $memAgs->getObjs('codstatus', '0', '>');

	// Conectar AMI
	$errno = $errstr = null;
	$connAMI = @fsockopen('localhost', 5038, &$errno, &$errstr, 4);
	if(!$connAMI) {
		echo 'ERRO:21 MSG:ServidorAsteriskNaoResponde';
		return 21;
	} else {
		fputs($connAMI, "Action: login\r\nEvents: off\r\nUsername: admin\r\nSecret: sapo\r\n\r\n");
		do { $r = fgets($connAMI); } while($r != "\r\n");		
	}
	// Buscar dados dos agentes direto no asterisk
	$pausadoAst = array();
	foreach(readAMICmdOutput('queue show', false) as $lin) {
		if(strstr($lin, 'has taken')) {
			list($nome) = explode(' (', trim($lin));
			$pausadoAst[$nome] = strstr($lin, '(paused)');
		}
	}
	
//----------------
	// Verificar inconsistencias, se houver arrumar status no asterisk para igualar com status no sistemaCC
	// Faz uma lista das inconsistencias:
	$errados = array();
	foreach($agsCC as $agCC) {
		if(($agCC->codstatus != SUPLOGADO) && ($pausadoAst[$agCC->nome] && $agCC->codstatus < 4) || (!$pausadoAst[$agCC->nome] && $agCC->codstatus >= PAUSA))
			$errados[] = $agCC->id;
	}

	if(count($errados) > 0) {
		sleep(3);
		$pausadoAst = array();
		// Verificar inconsistencias novamente para a lista de "errados", para verificar se o erro persiste apos 3 segundos
		$agsCC = $memAgs->getObjs('codstatus', '0', '>');
		foreach(readAMICmdOutput('queue show', false) as $lin) {
			if(strstr($lin, 'has taken')) {
				list($nome) = explode(' (', trim($lin));
				$pausadoAst[$nome] = strstr($lin, '(paused)');
			}
		}
		foreach($errados as $idAg) {
			$agCC = null;
			foreach($agsCC as $ag) {
				if($ag->id == $idAg) {
					$agCC = $ag;
					break;
				}
			}
			if($agCC != null) {
				if($agCC->codstatus != SUPLOGADO) {
					if($pausadoAst[$agCC->nome] && $agCC->codstatus < 4) {
						echo date('d/m/Y H:i:s') . "> Agente $agCC->nome em pausa no Asterisk porem no status[$agCC->codstatus](< 100): desPAUSAR no asterisk: ";
						echo sendAMICmd("Action: QueuePause\r\nInterface: $agCC->telefone\r\nPaused: false\r\n\r\n"). "\n";
					}
					if(!$pausadoAst[$agCC->nome] && $agCC->codstatus >= PAUSA) {
						echo date('d/m/Y H:i:s') . "> Agente $agCC->nome despausado no Asterisk porem no status[$agCC->codstatus](>= 100): PAUSAR no asterisk: ";
						echo sendAMICmd("Action: QueuePause\r\nInterface: $agCC->telefone\r\nPaused: true\r\n\r\n") . "\n";
					}
				}
			}
		}
	}
//---------------

	// Fechar acesso a memoria de agentes
	$memAgs->shut();
	    
	// Fechar conn AMI
	fputs($connAMI, "Action: Logoff\r\n\r\n");
	do { $r = fgets($connAMI); } while($r != "\r\n");
	fclose($connAMI);

// funx aux --------------------------------------------------------	
function readAMICmdOutput($cmd, $ultLinha=true) {
	global $connAMI;
	$linhasDescarte = array("Response: Follows\r\n", "Privilege: Command\r\n", "--END COMMAND--\r\n");
	$ret = ($ultLinha) ? '' : array();
	
	fputs($connAMI, "Action: Command\r\nCommand: $cmd\r\n\r\n");
	while(true) {
		$r = fgets($connAMI);
		if($r == "\r\n") break;
		if(!in_array($r, $linhasDescarte)) {
			if($ultLinha) $ret   = $r;
			else          $ret[] = substr($r, 0, -1);
		}
	}
	if($ultLinha) $ret = substr($ret, 0, -1);
	return $ret;
}

function sendAMICmd($strAMI) {
	global $connAMI, $DEBUG;
	if($DEBUG) {echo $strAMI; return true;}
	fputs($connAMI, $strAMI);
	$ret = 'Sem Message';
	while(true) {
		$lin = fgets($connAMI);
		if($lin == "\r\n") break;
		if(strstr($lin, 'Message')) $ret = substr($lin,0,-2);
	}
	return $ret;
}
?>