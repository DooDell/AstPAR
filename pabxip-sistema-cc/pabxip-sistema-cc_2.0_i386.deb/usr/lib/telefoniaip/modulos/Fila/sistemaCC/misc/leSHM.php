<?php
	include('../constantes.php');
	
	$shm_id = @shmop_open(ID_SHMEM_AGS, 'a', 0, 0);
	if($shm_id) {
		echo "<h1>Dados dos Agentes</h1>\n";
		for($c=0; $c<MAX_OBJS; $c++) {
			$offset = $c * MEM_POR_OBJ;
			$tam = trim(shmop_read($shm_id, $offset, 5)) + 0;
			$id  = trim(shmop_read($shm_id, $offset+5, 5)) + 0;
			if($id > 0 && $tam > 0) {
				$str = shmop_read($shm_id, $offset+10, $tam);
				echo "[$id][$c] $str <br>\n\n";
			}
		}
		shmop_close($shm_id);
	} else
		echo "Impossivel acessar memoria compartilhada de Agentes\n";
	
	$shm_id = @shmop_open(ID_SHMEM_FILAS, 'a', 0, 0);
	if($shm_id) {
		echo "<br><h1>Dados das Filas</h1>\n";
		for($c=0; $c<MAX_OBJS; $c++) {
			$offset = $c * MEM_POR_OBJ;
			$tam = trim(shmop_read($shm_id, $offset, 5)) + 0;
			$id  = trim(shmop_read($shm_id, $offset+5, 5)) + 0;
			if($id > 0 && $tam > 0) {
				$str = shmop_read($shm_id, $offset+10, $tam);
				echo "[$id][$c] $str <br>\n\n";
			}
		}
		shmop_close($shm_id);
	} else
		echo "Impossivel acessar memoria compartilhada de Filas\n";
?>