<?php
class Agente extends ShMemObj {
	public $id, $codstatus, $login, $ramal, $telefone, $nome, $senha, $funcionalidades, $contexto, $idsfilas, $nomesfilas;
	public $tempologin, $tempostatus, $tempologado, $numsai, $numentra, $nameentra, $filaatual, $uniqueid, $msg, $mobilidd, $holdtime;
	public $expirado, $efetuadas, $recebidas, $atendidas, $abandonadas, $nivelserv, $tta, $tma, $keepalive;
	public $codstatusbase, $supervisor;
	
	function Agente($arrayBDAst=0, $shm_id=0, $pos=0, $memPorObj=0) {
		if($shm_id > 0) {
			parent::__construct($shm_id, $pos, $memPorObj);
			if(is_array($arrayBDAst)) {
				// Atributos PABX
				$this->setAtrsDoArray($arrayBDAst);
				
				// Valores Padr�o
				$this->codstatusbase = 1;
				$this->keepalive   = 0;
				$this->codstatus   = 0;
				$this->telefone    = '';
				$this->tempologin  = 0;
				$this->tempostatus = 0;
				$this->tempologado = 0;
				$this->numsai      = '';
				$this->numentra    = '';
				$this->nameentra   = '';
				$this->filaatual   = '';
				$this->uniqueid    = '';
				$this->msg         = '';
				$this->expirado    = 0;
				$this->efetuadas   = 0;
				$this->recebidas   = 0;
				$this->atendidas   = 0;
				$this->abandonadas = 0;
				$this->nivelserv   = 0;
				$this->tta         = 0;
				$this->tma         = 0;
				$this->mobilidd    = false;
				$this->holdtime    = 0;
				
				$this->supervisor  = false;
			}
		}
	}
	
	function atualiza($setaFlagAtz=true, $idMem=null) {
		$err = $this->atualizaShMem($idMem);
		if($err === true && $setaFlagAtz)
			$this->setaFlagAlt();
		return $err;
	}
	
	function keepAlive() {
		$this->keepalive = 0;
		if($this->atualizaShMem() !== true)
			return "Erro ao zerar keepAlive do usu�rio $this->nome";
		return true;
	}
	
	function setaFlagAlt() {
		if($this->ramal >= 1000 && $this->ramal <= 9999) {
			ControleCC::setaFlagAltSups();
			shmop_write(ControleCC::$memFlags, '1', $this->ramal);
			ControleCC::loga(LOG_DEBUG2, "Setada flags de atualizacao para o Agente [$this->nome]");
		}
	}
	
	/**
	 * Aten��o: Recebe o ID e nao o ramal
	 */
	static function setaAltFlagPorID($id=null) {
		$ags = (is_null($id)) ? ControleCC::$memAgs->getObjs() : ControleCC::$memAgs->getObjs('id', explode(',', $id));
		foreach($ags as $ag)
			shmop_write(ControleCC::$memFlags, '1', $ag->ramal);
	}
	
	/**
	 * Aten��o: Recebe o ID e nao o ramal
	 */
	static function syncFilas2($id=null, $setaFlag=true) {
		$ags = (is_null($id)) ? ControleCC::$memAgs->getObjs() : ControleCC::$memAgs->getObjs('id', explode(',', $id));
		foreach($ags as $ag) {
			$ag->syncFilas();
			if($setaFlag)
				shmop_write(ControleCC::$memFlags, '1', $ag->ramal);
			if($ag->codstatus > 0)
				ControleCC::$telAgentes[$ag->telefone] = $ag->telefone;
		}
	}
	
	static function setaAltFlagPorFila($idFila) {
		$idsFila = (is_array($idFila)) ? $idFila : array($idFila);
		foreach(ControleCC::$memAgs->getObjs() as $ag) {
			if($ag->codstatus > 0 && $ag->codstatus != SUPLOGADO) {
				$idsFilaAg = explode(',', $ag->idsfilas);
				if(count(array_intersect($idsFila, $idsFilaAg)) > 0)
					shmop_write(ControleCC::$memFlags, '1', $ag->ramal);
			}
		}
	}
	
	function pausa($paused=true) {
		if(!empty($this->telefone) && strstr($this->telefone, '/')) {
			$sucesso = ControleCC::$comandosAst->enviaComando('QueuePause', array(
					'Interface' => $this->telefone,
					'Paused'    => ($paused ? '1' : '0')
				), 0.2);
			if($sucesso !== true) {
				// Tentar novamente
				usleep(10);
				$sucesso = ControleCC::$comandosAst->enviaComando('QueuePause', array(
						'Interface' => $this->telefone,
						'Paused'    => ($paused ? '1' : '0')
					), 0.25);
			}
		} else {
			$nomeAgente = $this->getNome();
			$acao = $paused ? 'pausar' : 'despausar';
			ControleCC::loga(LOG_CRITICO, "Imposs�vel $acao agente $nomeAgente. Telefone [$this->telefone] inv�lido");
		}
		return $sucesso;
	}

	function login($telefone, $mobilidade=null, $supervisor=false) {
		$nomeAgente = $this->getNome();
		if(!empty($telefone) && strstr($telefone, '/')) {
			$this->codstatusbase = DESLOGADO;
			$this->telefone      = $telefone;
			$this->mobilidd      = isset($mobilidade) && $mobilidade == 'MOBILIDADE';
			$this->supervisor    = $supervisor;
			
			if(($sucesso = $this->syncFilas(true, true)) === true) {	// Sinc com as filas, mantendo-o pausado por enquanto
				if(($sucesso = $this->mudaEstado(DISPONIVEL, array('codstatusbase' => DISPONIVEL, 'tempologin' => '_AGORA_','numSai' => '','numEntra' => '','msg' => '', 'keepalive' => 0))) === true) {
					// setar flag de logado
					shmop_write(ControleCC::$memLogin, '1', $this->ramal);
					
					// Setar usuario em mobilidade caso ele tenha escolhi o PA no login
					//Util::cmdAsterisk(($this->mobilidd) ? "database put mobilidade $this->ramal $this->telefone" : "database del mobilidade $this->ramal");
					ControleCC::$comandosAst->enviaComando('DBPut', array(
							'Family' => 'mobilidade',
							'Key'    => $this->ramal,
							'Val'    => ($this->mobilidd) ? $this->telefone : ''
						));
					// Adicionar este agente na lista de Telefones de Agentes
					ControleCC::$telAgentes[$this->telefone] = $this->telefone;
					ControleCC::$comandosAst->enviaComando('Originate', array(
							'Channel'  => $this->telefone,
							'Context'  => 'agentes',
							'Exten'    => '***124',
							'Priority' => 1,
							'Timeout'  => 30000,
							'Async'    => 1
						));
					$sucesso = $this->pausa(0);
					if($sucesso !== true) {
						ControleCC::loga(LOG_CRITICO, "Erro ao despausar $nomeAgente para efetuar login - deixando-o em PAUSA - msg [$sucesso]");
						$err = $this->mudaEstado(PAUSA, array('codstatusbase' => PAUSA));
						if($err !== true)
							ControleCC::loga(LOG_CRITICO, "Erro2 ao despausar $nomeAgente para efetuar login - impossivel deixa-lo em PAUSA - msg [$err]");
						return $sucesso;
					}
					ControleCC::logaEvento(EVENTO_LOGIN, $this->id, $this->ramal, $this->telefone);
					ControleCC::loga(LOG_NORMAL, ">>>> Login de $nomeAgente no telefone $this->telefone efetuado");
				} else
					ControleCC::loga(LOG_CRITICO, "Erro ao mudar estado de $nomeAgente - msg [$sucesso]");
			} else {
				ControleCC::loga(LOG_CRITICO, "Erro ao inserir agente $nomeAgente em fila - msg [$sucesso]");
			}
		} else {
			ControleCC::loga(LOG_CRITICO, "Imposs�vel logar agente $nomeAgente. Telefone [$telefone] inv�lido");
		}
		return true;
	}
	
	function mudaEstado($estadoNovo, $atrSet=array(), $filas=null) {
		$ret = true;
		$estadoAnt  = $this->codstatus;
		$nomeAgente = $this->getNome();
		$tempoEstadoAnt = $this->tempostatus;
				
		if(isset($atrSet['codstatusbase'])) {
			// statusBase so pode ser DISPONIVEL, PAUSA ou INDISP
			if($atrSet['codstatusbase']==DISPONIVEL || $atrSet['codstatusbase']>=PAUSA)
				$this->codstatusbase = $atrSet['codstatusbase'];
			unset($atrSet['codstatusbase']);
		}
		if($estadoNovo == DISPONIVEL) $estadoNovo = $this->codstatusbase;
		
		// Nao efetuar mudan�a para o mesmo estado
		if($estadoNovo == $this->codstatus) {
			ControleCC::loga(LOG_DEBUG0, "### Pedido de alteracao de [$estadoAnt] para [$estadoNovo] para $nomeAgente cancelado. Estados iguais.");
			return 'Estados iguais';
		}
		
		// Nao efetuar mudan�a de DESLOGADO para qualquer coisa que nao seja DISPONIVEL
		if($estadoAnt == DESLOGADO && ($estadoNovo != DISPONIVEL && $estadoNovo != SUPLOGADO)) {
			ControleCC::loga(LOG_AVISO, "### Imposs�vel mudar de DESLOGADO para qualquer coisa que n�o for DISPONIVEL");
			return 'Imposs�vel de DESLOGADO para != DISPONIVEL';
		}
		
		$agora = time();
		if(is_array($atrSet) && count($atrSet) > 0) {
			// Setar os atributo adicionais
			$nomeAtrsObj = array_keys(get_class_vars('Agente'));
			foreach($atrSet as $nomeAtr => $valAtr) {
				if(in_array($nomeAtr, $nomeAtrsObj) && $nomeAtr != 'codstatus')
					$this->$nomeAtr = (($valAtr === "_AGORA_") ? $agora : $valAtr);
			}
		}
		
		// Setar o novo Status
		$this->codstatus = $estadoNovo;
		$this->tempostatus = $agora;
		
		if($this->atualiza() === true) {
			ControleCC::loga(LOG_DEBUG0, "MUDA_STATUS: Alterado de [$estadoAnt] para [$estadoNovo] o Estado de $nomeAgente");
			
			// Logar a mudan�a de estado na cc_historico
			$filas = (is_null($filas)) ? ",$this->nomesfilas," : $filas;				
			$ret = ControleCC::logaEvento(EVENTO_MUDAESTADO, $this->ramal, $estadoAnt, $estadoNovo, ($agora - $tempoEstadoAnt), $filas);
			
		} else
			$ret = "Erro ao alterar estado anterior de $nomeAgente";

		return $ret;
	}
	
	function desloga($causa=0) {
		$nomeAgente = $this->getNome();
		if($this->codstatus > 0) {
			if($causa == -1 && !ControleCC::$conf->kaAtivo) {
				ControleCC::loga(LOG_AVISO, ">>>> Efetuar logoff de $nomeAgente. Causa: \033[31;1mFalta do KeepAlive\033[0m - DESLOGA POR KEEPALIVE DESLIGADO!");
				return true;
			}
			
			$ret = true;
			switch($causa) {
				case  0: $msg = $msgAg = 'Solicitacao do Agente';  break;
				case -1:
					$msg   = "\033[31;1mFalta do KeepAlive\033[0m";
					$msgAg = 'Falta do KeepAlive';
					break;
				case -2:
					$msg   = "\033[35;1mNao Atendimento\033[0m";
					$msgAg = 'Nao Atendimento';
					break;
				case -3:
					$msg   = "\033[35;1mSupervisao\033[0m";
					$msgAg = 'Supervisao';
					break;
				case -4:
					$msg   = "\033[35;1mErro no Asterisk\033[0m";
					$msgAg = 'Erro no PABX';
					break;
				case -5: $msg = $msgAg = 'Solicitacao do Supervisor';  break;
				case -6: $msg = $msgAg = 'Agente removido do sistema'; break;
				case -7: $msg = $msgAg = 'Sistema desligando';         break;
			}
			
			if(!empty($this->telefone)) {
				$sucesso = ControleCC::$comandosAst->enviaComando('QueueRemove', array('Interface' => $this->telefone), 0.04); // Patch GSD
				if($sucesso !== true && !strstr($sucesso, 'Not there')) {
					$this->msg = "Erro ao remove-lo da(s) fila(s), tente novamente";
					$this->atualiza();
					$aux = empty($sucesso) ? ControleCC::$comandosAst->getPacotesUltCmd() . '' : $sucesso;
					ControleCC::loga(LOG_CRITICO, "Erro ao remover agente $nomeAgente das filas - msg [$aux]");
					//return $sucesso;
				}
				
				// Remover este agente na lista de Telefones de Agentes
				unset(ControleCC::$telAgentes[$this->telefone]);
			} else
				ControleCC::loga(LOG_AVISO, "Deslogando agente $nomeAgente sem telefone. causa [$causa]");
			
			$atrSet = array('codstatusbase' => 0, 'telefone' => '', 'numsai' => '', 'numentra' => '', 'keepalive' => $causa, 'msg' => $msgAg);
			$stsNovo = ($this->supervisor && ($causa == 0 || $causa == -3)) ? SUPLOGADO : DESLOGADO;
			$ret = $this->mudaEstado($stsNovo, $atrSet);
			if($ret === true) {
				// resetar flag de logado
				if($stsNovo != SUPLOGADO)
					shmop_write(ControleCC::$memLogin, '0', $this->ramal);
				
				if($this->funcionalidades & FUNC_SEL_PA) {
					// Desregistra do telefone somente os Agentes que selecionam o PA
					// TODO : Verificar se o PA nao estava em mobilidade originalmente
					Util::cmdAsterisk("database del mobilidade $this->ramal");
				}
				
				$tempoLogado = time() - $this->tempologin;
				ControleCC::logaEvento(EVENTO_LOGOFF, $this->id, $this->ramal, $causa, $tempoLogado);
				
				ControleCC::loga(($causa==0 ? LOG_NORMAL : LOG_AVISO), "Logoff de $nomeAgente efetuado com sucesso. Causa: $msg");
			} else {
				$ret = "Erro ao deslogar $nomeAgente. Msg [$ret]";
				ControleCC::loga(LOG_CRITICO, $ret);
			}
			return $ret;
		} else
			return "Impossivel deslogar $nomeAgente. codtatus = 0";
	}
	
	function syncFilas($paused=false, $force=false) {
		$nomeAgente = $this->getNome();
		
		if(empty($this->telefone))
			return "Imposs�vel sincronizar agente $nomeAgente sem telefone.";
		
		if(!$force && ($this->codstatus == 0 || $this->codstatus == 10))
			return "Imposs�vel sincronizar agente $nomeAgente deslogado.";
		
		// Remover de todas as filas primeiro
		$sucesso = ControleCC::$comandosAst->enviaComando('QueueRemove', array('Interface' => $this->telefone), 0.1); // Patch GSD
		if($sucesso !== true && !strstr($sucesso, 'Not there')) {
			$msg = ControleCC::$comandosAst->getPacotesUltCmd() . '';
			ControleCC::loga(LOG_CRITICO, "syncFilas: Erro ao zerar as filas do Agente $nomeAgente [$msg]");
			return $sucesso;
		}
		
		// Verificar se devemos for�ar a pausa
		if(!$paused) $paused = ($this->codstatusbase >= PAUSA) ? '1' : '0';
		else         $paused = '1';
		
		// Adicionar as filas
		$sucesso = '';
		$filasAdd = array();
		foreach(explode(',', $this->nomesfilas) as $fila) {
			$err = ControleCC::$comandosAst->enviaComando('QueueAdd', array(
					'Queue'      => $fila,
					'Interface'  => $this->telefone,
					'MemberName' => $this->nome,
					'Penalty'    => 0,
					'Paused'     => $paused
				), 0.05);
			if($err === true || strstr($err, 'Already there')) $filasAdd[] = $fila;
			else                                               $sucesso .= $err;
		}
		
		if(!empty($sucesso)) {
			ControleCC::loga(LOG_CRITICO, "syncFilas: Erro ao adicionar $nomeAgente nas filas addOK(".Util::separaPorVirgula($filasAdd).") [$sucesso]");
			return $sucesso;
		}
		
		ControleCC::loga(LOG_DEBUG0, "syncFilas: Agente $nomeAgente adicionado as filas [" . Util::separaPorVirgula($filasAdd) . ']');
		return true;
	}
	
	/**
	 * Retorna o nome colorido
	 */
	function getNome() {
		return "[\033[31;1m$this->nome\033[0m]";
	}
	
	/**
	 * Busca o canal desta agente, o opcionalemnte o canal ao qual linkado
	 */
	function getCanal($link=false) {
		ControleCC::$comandosAst->enviaComando("Status");
		$aux =& ControleCC::$comandosAst->getPacotesUltCmd();
		while($aux) {
			if($aux->getAtr('Event') == "Status" && Util::comecaCom($aux->getAtr('Channel'), $this->telefone))
				return ($link) ? array('agente' => $aux->getAtr('Channel'), 'link' => $aux->getAtr('Link')) : $aux->getAtr('Channel');
			$aux = $aux->prox;
		}
		return null;
	}
}
?>