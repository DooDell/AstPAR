<?php
class SharedMem {
	private $shm_id;
	private $classe, $conn, $sql, $modo;
	private $memPorObj, $maxObjs;
	
	function SharedMem($key, $classe, $conn=null, $sql='', $modo='LEITURA', $conf=array()) {
		if(!(new $classe instanceof ShMemObj)) {
			echo "Classe para uso em memoria compartilhada nao eh filha de ShMemObj\n";
			die;
		}
		
		$this->classe = $classe;
		$this->conn   = $conn;
		$this->sql    = $sql;
		$this->modo   = $modo;
		
		$this->memPorObj = (isset($conf['memPorObj']) && $conf['memPorObj'] <= MEM_POR_OBJ) ? $conf['memPorObj'] : MEM_POR_OBJ;
		$this->maxObjs   = (isset($conf['maxObjs'])   && $conf['maxObjs']   <= MAX_OBJS)    ? $conf['maxObjs']   : MAX_OBJS;
		
		if($this->modo == 'ESCRITA') {
			$tam = $this->maxObjs * $this->memPorObj;
			$this->shm_id = @shmop_open($key, 'c', 0644, $tam);
			if (!$this->shm_id) {
				echo "Impossivel criar memoria compartilhada\n";
				die;
			}
			if(!isset($conf['incializa']) || $conf['incializa'] === true) {
				// Inicializar os slots
				for($c=0; $c<$this->maxObjs; $c++) {
					$objOK = false;
					$offset = $c * $this->memPorObj;
					$id = shmop_read($this->shm_id, $offset + 5, 5) + 0;
					if(is_numeric($id) && $id > 0) {
						$obj = $this->_readObj($offset);
						if(get_class($obj) == $this->classe)
							$objOK = true;
					}
					if(!$objOK)
						shmop_write($this->shm_id, '0    0    ', $offset);
				}
				$this->refresh();
			}
		} else if($this->modo == 'LEITURA') {
			$this->shm_id = @shmop_open($key, 'a', 0, 0);
			if (!$this->shm_id) {
				echo "Impossivel acessar memoria compartilhada\n";
				die;
			}
		}
	}
	
	function getID() {
		return $this->shm_id;
	}
	
	function refresh($id=0) {
		if($this->modo == 'ESCRITA') {
			if($id !== 0) {
				// Procura pelo ORDER BY
				if(($posOrd = strpos($this->sql, 'ORDER')) > 0)
					$sql = substr($this->sql, 0, $posOrd) . " WHERE id IN ($id) " . substr($this->sql, $posOrd);
				else
					$sql = $this->sql . " WHERE id IN ($id)";
			} else
				$sql = $this->sql;
			$this->conn->executa($sql);
			while($this->conn->temMaisDados()) {
				$obj = $this->get('id', $this->conn->data['id']);
				if($obj instanceof $this->classe) {
					$obj->IDSHMEM = $this->shm_id;
					$obj->MEMPOROBJ = $this->memPorObj;
					$obj->setAtrsDoArray($this->conn->data); // TODO - verificar erros da fun��o
				} else {
					$pos = $this->getFreePos();
					$obj = new $this->classe($this->conn->data, $this->shm_id, $pos, $this->memPorObj);
					// TODO - verificar erros da fun��o a seguir
					$obj->atualizaShMem();
				}
			}
			return true;
		} else
			return 'Sem permiss�o de ESCRITA';
	}
		
	function get($atributo, $valor) {
		$ret = $this->getObjs($atributo, $valor, '=', true);
		return (count($ret) == 1) ? array_shift($ret) : false;
	}
	
	function getObjs($atributo='_TODOS_', $valor=array(), $comparacao='=', $limite1=false) {
		$objetos = array();
		if($atributo != '_TODOS_')
			$valores = (is_array($valor)) ? $valor : array($valor);
		for($c=0; $c<$this->maxObjs; $c++) {
			$offset = $c * $this->memPorObj;
			$idSHM = shmop_read($this->shm_id, $offset + 5, 5) + 0;
			if($idSHM > 0) {
				switch($atributo) {
					case '_TODOS_':
						$objetos[$idSHM] = $this->_readObj($offset);
						break;
					
					case 'id':
						if(Util::testa($idSHM, $valores, $comparacao))
							$objetos[$idSHM] = $this->_readObj($offset);
						break;
					
					default:
						$aux = $this->_readObj($offset);
						if(Util::testa($aux->$atributo, $valores, $comparacao)) {
							$objetos[] = $aux;
							if($limite1) break 2;
						}
				}
			}
		}
		return $objetos;
	}
	
	function setAtributos($atrSel, $valorSel, $atributos) {
		$setou = false;
		$obj = $this->get($atrSel, $valorSel);
		$nomeClasse = get_class($obj);
		if($nomeClasse == $this->classe) {
			$nomeAtrsObj = array_keys(get_class_vars($nomeClasse));
			foreach($atributos as $nomeAtr => $valAtr) {
				if(in_array($nomeAtr, $nomeAtrsObj)) {
					$obj->$nomeAtr = $valAtr;
					$setou = true;
				}
			}
			if($setou)
			// TODO - verificar erros da fun��o a seguir
				$obj->atualizaShMem();
		}
		return $obj;
	}
	
	function setObjs($objetos) {
		if($this->modo == 'ESCRITA') {
			if($objetos instanceof ShMemObj) {
				// TODO - verificar erros da fun��o a seguir
				$objetos->atualizaShMem();
			} else if(is_array($objetos)) {
				foreach($objetos as $obj) {
					if($obj instanceof ShMemObj)
						$obj->atualizaShMem(); // TODO - verificar erros da fun��o
				}
			}
		}
	}
	
	function getFreePos() {
		for($c=0; $c<$this->maxObjs; $c++)
			if(shmop_read($this->shm_id, $c * $this->memPorObj, 10) == '0    0    ') return $c;
		return false;
	}
	
	private function _readObj($offset) {
		$tam = shmop_read($this->shm_id, $offset, 5) + 0;
		if($tam > $this->memPorObj) $tam = $this->memPorObj;
		return unserialize(shmop_read($this->shm_id, $offset + 10, $tam));
	}
		
	function shut($apaga=false) {
		if($apaga) shmop_delete($this->shm_id);
		else       shmop_close($this->shm_id);
	}
}
?>