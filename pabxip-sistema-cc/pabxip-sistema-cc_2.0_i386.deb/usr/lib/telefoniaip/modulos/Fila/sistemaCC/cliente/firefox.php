<html>
	<head>
		<title>.: CAC01 : Erro :.</title>
	</head>
	<body bgcolor="#C0C0F0">
		<div align="center">
			<br>
			Desculpe!<br>
			<br>
			Este sistema est� homologado para utiliza��o apenas pelo navegador Firefox
		</div>
	</body>
</html>
