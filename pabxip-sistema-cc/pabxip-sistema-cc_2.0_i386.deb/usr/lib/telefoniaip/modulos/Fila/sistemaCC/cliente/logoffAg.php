<?php
	session_start();
	unset($_SESSION['agenteLogado']);
?>
<script type="text/javascript">
	window.close();
</script>