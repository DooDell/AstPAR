<?php
class ShMemObj {
	public $IDSHMEM, $POSICAOSHMEM, $MEMPOROBJ;
	
	function ShMemObj($shm_id, $pos, $memPorObj) {
		$this->IDSHMEM      = $shm_id;
		$this->POSICAOSHMEM = $pos;
		$this->MEMPOROBJ    = $memPorObj;
	}
	
	function atualizaShMem($idMem=null) {
		if($idMem==null) $idMem=$this->IDSHMEM;
		$str = serialize($this);
		$tam = strlen($str);
		if($tam > $this->MEMPOROBJ)
			return "Objeto serializado maior que MEMPOROBJ($this->MEMPOROBJ). Considere aumentar esta constante.";
		$offset = $this->POSICAOSHMEM * $this->MEMPOROBJ;
		shmop_write($idMem, $tam . '     ', $offset);							// Bytes 0-4 = Tamanho da string serializada deste Objeto
		shmop_write($idMem, $this->id . '     ', $offset + 5);		// Bytes 5-9 = ID do Objeto (para �ndice)
		$bytesEscritos = shmop_write($idMem, $str, $offset + 10);	// Bytes 10-MEM_POR_OBJ = Objeto serializado
		if ($bytesEscritos != $tam) {
			$class = get_class($this);
			return "Impossivel escrever dados de $class '$this->id' na SHMEM";
		}
		return true;
	}
	
	function setAtrsDoArray($array) {
		if(is_array($array) && count($array) > 0) {
			$setou = false;
			$nomesReserv = array('IDSHMEM', 'POSICAOSHMEM', 'MEMPOROBJ');
			$nomeAtrsObj = array_keys(get_class_vars(get_class($this)));
			foreach($array as $nomeAtr => $valAtr) {
				if(in_array($nomeAtr, $nomeAtrsObj) && !in_array($nomeAtr, $nomesReserv)) {
					$this->$nomeAtr = $valAtr;
					$setou = true;
				}
			}
			if($setou)
				return $this->atualizaShMem();
		}
	}
	
	function delete() {
		if(isset($this->IDSHMEM) && isset($this->POSICAOSHMEM) && isset($this->MEMPOROBJ))
			shmop_write($this->IDSHMEM, '0    0    ', $this->POSICAOSHMEM * $this->MEMPOROBJ);
	}
	
	function __toString() {
		$ret = get_class($this) . '{';
		foreach(get_object_vars($this) as $c => $v)
			$ret .= "$c=$v|";
		return $ret;
	}
}
?>