<?php
	include('../constantes.php');
	$ramal = $argv[1];
	$prop  = (empty($argv[2])) ? 'codstatus' : $argv[2];
	
	if(!empty($ramal)) {
		$mem = new SharedMem(ID_SHMEM_AGS, 'Agente');
		while(true) {
			$agente = $mem->get('ramal', $ramal);
			echo "ramal $ramal - prop $prop: " . $agente->$prop . "\n";
			sleep(1);
		}
	} else
		echo "Digite o ramal\n";
?>