<?php
	include('comandos.php');
	$idAg    = $_SESSION['agenteLogado']->id;
	$ramalAg = $_SESSION['agenteLogado']->ramal;
	
	if(!empty($idAg) && !empty($ramalAg)) {
		$memFlags = @shmop_open(ID_SHMEM_FLAGS, 'w', 0, 0);
		if ($memFlags) {
		    $delimiter = 'kanduske123kadunske';
		    header('Content-type: multipart/x-mixed-replace;boundary="'.$delimiter.'"');
		
		    $header   = "Content-type: text/html\n\n";
		    $boundary = "--{$delimiter}\n\n";
		    $footer   = "--{$delimiter}--\n\n";
		
		    if (ob_get_level() == 0) ob_start();
	    	
	    	$sts = 1;
	    	$ini = true;
	    	$agora = time();
		    $timeout = $agora + 45; // 45s por requisi��o
		    $refresh = $agora + 5; // 5s para refresh
			while($sts > 0 && $agora < $timeout) {
		    	if($ini || (shmop_read($memFlags, $ramalAg, 1) == '1') || $agora > $refresh) {		// Verifica a mem�ria de flags de altera��o
		    		$refresh = $agora + 5; // 5s para refresh
		    		shmop_write($memFlags, '0', $ramalAg);			// Zera a flag
		    		$ini = false;
					echo $header;
					$objs = buscaDadosAgente($idAg, false);
					$sts = $objs['ag']->codstatus;
					foreach($objs as $obj)
						echo "$obj\n";
		        	echo $boundary;
		        	ob_flush();
		        	flush();
		       	}
				usleep(250000);
				$agora = time();
		    }
		    shmop_close($memFlags);
		    echo $header . '_EOR_' . $footer;
		    ob_end_flush();
		} else
			echo "Erro ao abrir SHMEM\n";
	} else
		echo "Nao logado\n";
?>