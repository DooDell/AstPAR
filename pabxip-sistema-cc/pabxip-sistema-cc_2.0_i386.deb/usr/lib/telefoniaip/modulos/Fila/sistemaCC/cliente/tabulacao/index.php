<html>
	<head>
		<title>.: Tabula��o :.</title>
	</head>
	<body>
		<a href='cadastro.php'>Cadastro</a><br>
		<a href='relatorio.php'>Relat�rio</a>
	</body>
</html>
