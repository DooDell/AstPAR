<?php
	include('comandos.php');	
	$ramal = $_REQUEST['ramal'];
	$senha = $_REQUEST['senha'];
	
	$agente = buscaAgentePorLogin($ramal, $senha);
	if(is_a($agente, 'Agente')) {
		if($agente->codstatus === 0) {
			if($agente->funcionalidades & FUNC_SUPERVISOR) {
				$agente->telefone = "SIP/$agente->ramal";
				$_SESSION['agenteLogado'] = $agente;
				enviaComando("$agente->id:loginSup:$agente->telefone", 10);
				header("location:janelaSupervisor.php");
			} else if($agente->funcionalidades & FUNC_AGENTE) {
				if(empty($agente->idsfilas)) {
					$_SESSION['agenteLogado'] = 0;
					header("location:login.php?msg=Agente $agente->nome n�o est� em nenhuma fila");
				} else {
					if($agente->funcionalidades & FUNC_SEL_PA) {
						$agente->telefone = '';
						$_SESSION['agenteLogado'] = $agente;
						header("location:loginAg.php");
					} else {
						$agente->telefone = (empty($agente->telatual)) ? "SIP/" . $agente->ramal : $agente->telatual;
						$_SESSION['agenteLogado'] = $agente;
						header("location:popupagente.php");
					}
				}
			} else {
				$_SESSION['agenteLogado'] = 0;
				header("location:login.php?msg=Tipo de usu�rio inv�lido");
			}
		} else {
			$_SESSION['agenteLogado'] = 0;
			header("location:login.php?msg=Usu�rio j� em uso");
		}
	} else {
		$_SESSION['agenteLogado'] = 0;
		header("location:login.php?msg=Usu�rio/Senha incorretos");
	}
?>