<?
	$msg = $_REQUEST['msg'];
	$nav = strtolower($_SERVER["HTTP_USER_AGENT"]);
	if(!strstr($nav, "mozilla")) {
		header("location:firefox.php");
		exit;
	}
	if(!file_exists('/var/run/asterisk/asterisk.ctl') || !file_exists('/etc/asterisk/telip/cc/RODANDO')) {
		header("location:sistemaForaDoAr.php");
		exit;
	}
?>
<html>
	<head>
		<title>.: CAC01 : Login :.</title>
		<link rel="Stylesheet" href="css/login.css" type="text/css" media="screen">
	</head>
	<body>
		<div id="barra_top"></div>
		<div id="divJanelaLogin">
			<div id="divLogo"></div>
			<div id="divMensagem"><? if(!empty($msg)) echo $msg; ?></div>
		</div>
			<div id="divConteudo">
				<form action="controleLogin.php" method="post">
					<table width="400px">
						<tr><td class='esqSup'></td><td class='dirSup'></td></tr>
						<th colspan='2'>Central de Atendimento Celepar</th>
						<tr><td align="right" width='50%'>Ramal:</td><td><input type="text" name="ramal" size="6" maxlength="4"></td></tr>
						<tr><td align="right">Senha:</td><td><input type="password" name="senha" size="6" maxlength="6"></td></tr>
						<tr><td align="center" colspan='2'><input type="submit" class="submit button" name="login" value="Login"></td></tr>
						<tr><td class='esqInf'></td><td class='dirInf'></td></tr>		
					</table>
				</form>
			</div>
		<div id="barra_bottom"></div>
	</body>
</html>