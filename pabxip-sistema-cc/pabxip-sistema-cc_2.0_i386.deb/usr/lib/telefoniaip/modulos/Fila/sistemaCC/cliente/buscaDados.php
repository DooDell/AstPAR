<?php
	include('comandos.php');
	foreach(buscaDadosAgente($_SESSION['agenteLogado']->id) as $obj)
		echo "$obj\n";
?>
