<?php
class EventosAMI {
	var $loginOK;
	private $AMI, $eventosTrataveis, $pacotesUltCmd;
	
	function EventosAMI($config) {
		$this->loginOK = false;
		
		// Eventos aceitos pelo processador
		$this->eventosTrataveis = array(
									'AgentCalled',
									'AgentConnect',
									'AgentComplete',
									'AgentRingNoAnswer', // Equivalente 1.6.1 ao AgentSkip do Patch 1.4.19
									'AgentSkip',	// Patch GSD
									'Join',
									'Leave',
									'QueueCallerAbandon',
									'QueueParams',
									'QueueEntry',
									'Dial',
									'OriginateResponse',
									'Hangup',
									'Shutdown'
								);
		
		$this->AMI = new AMI($config);
		if($this->AMI->pacoteLogin === false)
			return;

		$this->processaEventos($this->AMI->pacoteLogin);
		$this->loginOK = true;
	}
		
	function processa($to=0.1) {
		$pacoteRecebido = $this->AMI->recebeEventos($to);
		if($pacoteRecebido === false) {
			ControleCC::loga(LOG_AVISO, "Asterisk desligou/caiu. saindo.");
			ControleCC::$loopPrincipal = 100;
			return false;
		}
		if(!$pacoteRecebido->vazio())
			$this->processaEventos($pacoteRecebido);
	}
	
	static function getAgentePorTel($telefone, $evento, $telEhCanal=false) {
		if($telEhCanal) {
			$pos = strrpos($telefone, '-'); // Acha o ultimo traco no canal do telefone
			if($pos > 0)
				$telefone = substr($telefone, 0, $pos);
		}
		if(in_array($telefone, ControleCC::$telAgentes)) {
			$agente = ControleCC::$memAgs->get('telefone', $telefone);
			if(!is_a($agente, 'Agente')) {
				ControleCC::loga(LOG_CRITICO, "ERRO EV: $evento - Erro ao buscar dados do Agente no telefone $telefone");
				return null;
			}
			return $agente;
		}
		return null;
	}
	
	static function getCallerID($pacote, $comNome=true) {
		// Pegar o CallerID - Tentar v�rias maneiras
		$cidNum  = $pacote->getAtr('CallerIDNum');
		if(empty($cidNum))
			$cidNum = $pacote->getAtr('CallerID');
		if(empty($cidNum)) {
			$cidNum = $pacote->getAtr('ChannelCalling');
			if(strstr($cidNum, '/')) {
				list($d, $cid) = explode("/", $cidNum);
				list($cidNum, $d) = explode("-", $cid);
			} else
				$cidNum = "?";
		}
		if($comNome) {
			$cidName = $pacote->getAtr('CallerIDNum');
			return (!empty($cidName) && $cidName != '<unknow>' && $cidName != '<Unknow>') ? "$cdiName <$cidNum>" : $cidNum;
		} else
			return $cidNum;
	}
	
	function processaEventos($pacote, $excecoes=array()) {
		$aux =& $pacote;
		while($aux) {
			$evento = $aux->getAtr('Event');
			if(!empty($evento) && in_array($evento, $this->eventosTrataveis) && !in_array($evento, $excecoes) && ($evento != 'OriginateResponse' || strstr($aux->getAtr('ActionID'), '-') === false)) { // Ignorar os Originates do Discador
				ControleCC::loga(($evento == 'QueueParams'||$evento == 'QueueEntry') ? LOG_DEBUG3 : LOG_DEBUG0, "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Evento Tratado: [\033[32;1m$evento\033[0m]");
				switch($evento) {
					case 'AgentCalled':
/*
Event: AgentCalled
Privilege: agent,all
AgentCalled: SIP/cac01
Queue: pac                            ***** Esta linha Queue s� ser� enviada mediante a patch no Asterisk 1.4.19!!!!!!
AgentName: Gabriel Ortiz Lour
ChannelCalling: SIP/2549-0832ef90
CallerID: 2549
CallerIDName: timothy
Context: irrestrito
Extension: 5008
Priority: 4
 */
						if(($agente = EventosAMI::getAgentePorTel($aux->getAtr('AgentCalled'), $evento))) {
							$nomeFila = $aux->getAtr('Queue');
							$cidName  = $pacote->getAtr('CallerIDName');
							
							// Verificar se � uma fila de eMail
							$email = '';
							$fila  = ControleCC::$memFilas->get('name', $nomeFila);
							if(is_a($fila, 'FilaCC') && $fila->tipopiloto == 'M') {
								$email   = $pacote->getVariable('EMAIL');
								if(strstr($email, '<')) {
									list($d, $email) = explode('<', $email);
									list($email)     = explode('>', $email);
								}
								$idEmail = $pacote->getVariable('IDEMAIL');
							}
							
							$cid = !empty($email) ? $email : EventosAMI::getCallerID($aux); 
							
							$sucesso = $agente->mudaEstado(CHAMANDO, array('filaatual' => $nomeFila, 'numentra' => $cid, 'nameentra' => $cidName, 'email' => $email, 'idemail' => $idEmail));
							$nomeAgente = $agente->getNome();
							if($sucesso === true) ControleCC::loga(LOG_NORMAL,  ">>EV: AgentCalled. Setado codstatus(CHAMANDO), filaatual($nomeFila), numentra($cid), nameentra($cidName), email($email), idemail($idEmail) para $nomeAgente");
							else                  ControleCC::loga(LOG_CRITICO, "EV: AgentCalled - Erro ao alterar status para CHAMANDO de $nomeAgente - Msg [$sucesso]");
						}
						break;
					
					case 'AgentConnect':
/*
Event: AgentConnect
Privilege: agent,all
Queue: teste
Uniqueid: 1237674627.3
Channel: SIP/1201-08331448
Member: SIP/1201
MemberName: Teste Ortiz
Holdtime: 13
BridgedChannel: 1237674627.4
 */
						$telefone = $aux->getAtr('Member');
						
						$agente = EventosAMI::getAgentePorTel($telefone, $evento);
						if($agente) {
							$nomeFila = $aux->getAtr('Queue');
							$tempoEsp = $aux->getAtr('Holdtime');
							$uid      = $aux->getAtr('Uniqueid');
							$chan     = $aux->getAtr('Channel');
							$callChan = $aux->getAtr('ChannelCalling');
							
							$atrsSet = array('holdtime' => $tempoEsp, 'uniqueid' => $uid, 'recebidas' => $agente->recebidas + 1, 'channel' => $chan, 'link' => $callChan);
							$sucesso = $agente->mudaEstado(ATENDENDO, $atrsSet, ",$nomeFila,");
							$nomeAgente = $agente->getNome();
							if($sucesso === true) ControleCC::loga(LOG_NORMAL,  ">>EV: AgentConnect. Setado codstatus(ATENDENDO), holdtime($tempoEsp) para $nomeAgente");
							else                  ControleCC::loga(LOG_CRITICO, "EV: AgentConnect - Erro ao alterar status para ATENDENDO de $nomeAgente - Msg [$sucesso]");
						}
						break;
					
					case 'AgentComplete':
/*
Event: AgentComplete
Privilege: agent,all
Queue: paranaDigital
Uniqueid: 1237831534.59
Channel: SIP/cac01-083353a8
Member: SIP/gism                            ***** Esta linha Member s� ser� enviada mediante a patch no Asterisk 1.4.19!!!!!!
MemberName: Gabriel Ortiz Lour
HoldTime: 9
TalkTime: 30
Reason: agent
 */
						$telefone = $aux->getAtr('Member');
						$nomeFila = $aux->getAtr('Queue');
						$tempoH   = $aux->getAtr('HoldTime');
						$tempoA   = $aux->getAtr('TalkTime');
						
						$fila = ControleCC::$memFilas->get('name', $nomeFila);
						if(is_a($fila, 'FilaCC')) {
							$fila->qtdchamatendida++;
							$fila->tempototalatend += $tempoA;
							if($tempoA > $fila->tempototalatend) $fila->tempototalatend = $tempoA;
							$fila->atualizaShMem();
						} else
							ControleCC::loga(LOG_CRITICO, "ERRO EV: AgentComplete - Erro ao buscar dados da fila($nomeFila)");
						
						$agente = EventosAMI::getAgentePorTel($telefone, $evento);
						if($agente) {
							$uniqueid = $aux->getAtr('Uniqueid');
							$nomeAgente = $agente->getNome();
							
							ControleCC::logaEvento(EVENTO_ATENDIMENTO, $agente->ramal, $tempoH, $tempoA, $uniqueid, ",$nomeFila,");
							
							if(is_a($fila, 'FilaCC') && $fila->flags & FLAG_FILA_PAUSA_AUTO) {
								$nomeEstado = 'PAUSA';
								$estado  = PAUSA_AUTO;
								$sucesso = $agente->pausa();
							} else {
								$nomeEstado = 'DISPONIVEL';
								$estado  = DISPONIVEL;
								$sucesso = true;
							}
							if($sucesso === true) {
								$sucesso = $agente->mudaEstado($estado, array('filaatual' => '', 'numentra' => '', 'uniqueid' => '', 'channel' => '', 'link' => ''));
								if($sucesso === true) ControleCC::loga(LOG_NORMAL,  ">>EV: AgentComplete. Setado codstatus($nomeEstado) para $nomeAgente");
								else                  ControleCC::loga(LOG_CRITICO, "EV: AgentComplete - Erro ao alterar status para $nomeEstado de $nomeAgente - Msg [$sucesso]");
							} else
								ControleCC::loga(LOG_CRITICO, "EV: AgentComplete - Erro ao AUTO-PAUSAR $nomeAgente - Msg [$sucesso]");
						}
						break;
						
					case 'AgentRingNoAnswer': // Vers�o 1.6.1.X do Asterisk
					case 'AgentSkip':
/*
*** Este Evento s� ser� enviado mediante a patch no Asterisk 1.4.X!!!!!!
Event: AgentSkip
Privilege: agent,all
Queue: GISM
Uniqueid: 1242101824.4
Channel: SIP/2549-08321138
Member: SIP/gism
MemberName: Paloma Giovana Groxko
 */
						$nomeFila  = $aux->getAtr('Queue');
						$telefone  = $aux->getAtr('Member');
						$temporing = $aux->getAtr('Ringtime'); // Asterisk 1.6.1.x
						
						$agente = EventosAMI::getAgentePorTel($telefone, $evento);
						if($agente) {
							$nomeAgente = $agente->getNome();
							ControleCC::logaEvento(EVENTO_NAOATENDIMENTO, $agente->ramal, $temporing, '', '', ",$nomeFila,");
							
							$atzAg = false;
							$fila = ControleCC::$memFilas->get('name', $nomeFila);
							if(is_a($fila, 'FilaCC')) {
								if($fila->indispna == '1') {
									$sucesso = $agente->pausa('1');
									if($sucesso === true) {
										$sucesso = $agente->mudaEstado(INDISP, null, ",$nomeFila,");
										if($sucesso === true) {
											ControleCC::loga(LOG_AVISO, ">>EV: AgentSkip. Agente $nomeAgente indisponivel por Nao Atendimento");
										} else {
											ControleCC::loga(LOG_CRITICO, "ERRO EV: AgentSkip $nomeAgente - Msg [$sucesso]");
											$agente->msg = "PAUSADO POR NAO ATENDIEMNTO. Erro ao estado.";
											$atzAg = true;
										}
									} else {
										ControleCC::loga(LOG_CRITICO, "AG: Erro ao pausar $nomeAgente por Nao Atendimento - Msg [$sucesso]");
										$agente->msg = "Erro ao pausar por n�o atendimento.";
										$atzAg = true;
									}
								} else
									ControleCC::loga(LOG_AVISO, "++ EV: AgentSkip $nomeAgente nao atendeu a chamada de Fila - Indisponivel por NA desligado");
							} else
								ControleCC::loga(LOG_CRITICO, "ERRO EV: AgentSkip $nomeAgente - Erro ao buscar dados da fila($nomeFila)");
							
							if($atzAg)
								$agente->atualiza();
						}
						break;
					
					case 'Join':
					case 'Leave':
/*
Event: Join
Privilege: call,all
Channel: SIP/2549-08336780
CallerID: 2549
CallerIDName: timothy
Queue: ParanaDigital
Position: 1
Count: 1
Uniqueid: 1240940364.70

Event: Leave
Privilege: call,all
Channel: SIP/2549-08330228
Queue: GISM
Count: 0
Uniqueid: 1242060070.26
 */
						$nomeFila = $aux->getAtr('Queue');
						$emEspera = $aux->getAtr('Count');
						
						$fila = ControleCC::$memFilas->get('name', $nomeFila);
						if(is_a($fila, 'FilaCC')) {
							$fila->qtdchamespera = $emEspera;
							$fila->atualizaShMem();
							Agente::setaAltFlagPorFila($fila->id);
						} else
								ControleCC::loga(LOG_CRITICO, "ERRO EV: $evento - Erro ao buscar dados da fila($nomeFila)");
						break;
						
					
					case 'QueueCallerAbandon':
/*
Event: QueueCallerAbandon
Privilege: agent,all
Queue: teste
Uniqueid: 1237673457.3
CallerID: 2549					// CallerID - patch GSD
CallerIDName: teste				// CallerIDName - patch GSD
Position: 1
OriginalPosition: 1
HoldTime: 3
 */
						$nomeFila = $aux->getAtr('Queue');
						if($nomeFila != 'telefonista') {
							$cid      = EventosAMI::getCallerID($aux);
							$tempo    = 0;
							
							$fila = ControleCC::$memFilas->get('name', $nomeFila);
							if(is_a($fila, 'FilaCC')) {
								$tempo = $aux->getAtr('HoldTime');
								if(!is_numeric($tempo)) $tempo = 0;
								
								$fila->qtdchamaband++;
								$fila->tempototalabandono += $tempo;
								if($tempo > $fila->tempomaxabandono) $fila->tempomaxabandono = $tempo;
								
								if($fila->callback && (($fila->callbackmin == 0 || $tempo >= $fila->callbackmin) && ($fila->callbackmax == 0 || $tempo <= $fila->callbackmax))) {
									// Colocar chamada na fila de callbacks desta fila
									$uid = $aux->getAtr('Uniqueid');
									$fila->addCallBack($cid, $uid);
								}
								$fila->atualizaShMem();
								Agente::setaAltFlagPorFila($fila->id);
							} else
								ControleCC::loga(LOG_CRITICO, "ERRO EV: QueueCallerAbandon - Erro ao buscar dados da fila($nomeFila)");
													
							ControleCC::logaEvento(EVENTO_ABANDONO, $tempo, $aux->getAtr('Position'), $cid, "", ",$nomeFila,");
							ControleCC::loga(LOG_NORMAL, ">>> EV >>> QueueCallerAbandon. Setado qtdchamaband($fila->qtdchamaband), tempototalabandono($fila->tempototalabandono) para a fila($nomeFila)");
						}
						break;
					
					case 'QueueParams': // Evento gerado pela requisicao do status das filas
/*
Event: QueueParams
Queue: todos
Max: 0
Calls: 0
Holdtime: 0
Completed: 0
Abandoned: 0
ServiceLevel: 0
ServicelevelPerf: 0.0
Weight: 0
 */
						$nomeFila  = $aux->getAtr('Queue');
						if(!empty($nomeFila) && $nomeFila != 'telefonista' && substr($nomeFila, 0, 9) != 'poolSecrt') {
							$fila = ControleCC::$memFilas->get('name', $nomeFila);
							if(is_a($fila, 'FilaCC')) {
								$nivServ  = $aux->getAtr('ServicelevelPerf');
								$nivServ  = (empty($nivServ) || !is_numeric($nivServ))  ? '0.0' : $nivServ;
								$tempoNS  = $aux->getAtr('ServiceLevel');
								$tempoNS  = (empty($tempoNS) || !is_numeric($tempoNS))  ? '0' : $tempoNS;
								$emEspera = $aux->getAtr('Calls');
								$emEspera = (empty($emEspera) || !is_numeric($emEspera))  ? 0 : $emEspera;
								$tempoMedEsp = $aux->getAtr('Holdtime');
								$tempoMedEsp = (empty($tempoMedEsp) || !is_numeric($tempoMedEsp))  ? 0 : $tempoMedEsp;
								
								$fila->servicelevel     = $nivServ;
								$fila->tempons          = $tempoNS;
								$fila->qtdchamespera    = $emEspera;
								$fila->tempomedioespera = Util::formataSegundos($tempoMedEsp);
								if($emEspera == 0) $fila->tempoespera = '0:00';
								$fila->atualizaShMem();
								Agente::setaAltFlagPorFila($fila->id);
								
								ControleCC::loga(LOG_DEBUG3, ">>> EV >>> QueueParams. Setado qtdChamEspera($emEspera), tempoMedioEspera($tempoMedEsp) para a fila($nomeFila)");
							} else
								ControleCC::loga(LOG_CRITICO, "ERRO EV: QueueParams - Erro ao buscar dados da fila($nomeFila)");
						}
						break;
					
					case 'QueueEntry':
/*
Event: QueueEntry
Queue: teste
Position: 1
Channel: SIP/1200-08327288
CallerID: 1200
CallerIDName: Ekiga
Wait: 12
 */
						$nomeFila = $aux->getAtr('Queue');
						if($aux->getAtr('Position') == '1' && !empty($nomeFila) && $nomeFila != 'telefonista') {
							$fila = ControleCC::$memFilas->get('name', $nomeFila);
							if(is_a($fila, 'FilaCC')) {
								$tempoEsp = Util::formataSegundos($aux->getAtr('Wait'));
								$fila->tempoespera = $tempoEsp;
								$fila->atualizaShMem();
								Agente::setaAltFlagPorFila($fila->id);
							
								ControleCC::loga(LOG_DEBUG3, ">>> EV >>> QueueEntry[1]. Setado tempoespera($tempoEsp) para a fila($nomeFila)");
							} else
								ControleCC::loga(LOG_CRITICO, "ERRO EV: QueueEntry - Erro ao buscar dados da fila($nomeFila)");
						}
						break;
					
					case 'Dial':
/*
Event: Dial
Privilege: call,all
Source: SIP/2549-0832ad80
Destination: SIP/gism-0833bbe0
CallerID: 2549
CallerIDName: timothy
SrcUniqueID: 1241018347.53
DestUniqueID: 1241018347.54
 */
						// Verificar se o agente esta recebendo uma chamada
						$telefone = $aux->getAtr('Destination');
						$agente = EventosAMI::getAgentePorTel($telefone, $evento, true);
						if($agente) {
							if($agente->codstatus > DESLOGADO && $agente->codstatus != ATENDENDO && $agente->codstatus != SUPLOGADO) {
								$nomeAgente = $agente->getNome();
								
								$cid = EventosAMI::getCallerID($aux);
								$uid      = $aux->getAtr('Uniqueid');
								$callChan = $aux->getAtr('Source');
								
								ControleCC::logaEvento(EVENTO_RECEBE, $agente->ramal, $cid, $uid);
								
								$sucesso = $agente->mudaEstado(ENTRANTE, array('numentra' => $cid, 'channel' => $telefone, 'link' => $callChan));
								if($sucesso === true) ControleCC::loga(LOG_NORMAL,  ">>EV: Dial. Setado codstatus(ENTRANTE) L($callChan) para $nomeAgente");
								else                  ControleCC::loga(LOG_CRITICO, "ERRO EV: Dial $nomeAgente - Msg [$sucesso]");
							}
						} else {
							// Verificar se o agente esta fazendo uma chamada
							$telefone = $aux->getAtr('Source');
							$agente = EventosAMI::getAgentePorTel($telefone, $evento, true);
							if($agente) {
								$nomeAgente = $agente->getNome();
								$callChan = $aux->getAtr('Destination');
								
								$agente->channel = $telefone;
								$agente->link    = $callChan;
								if($agente->atualiza() === true)
									ControleCC::loga(LOG_DEBUG0, "Ev Dial: Salvando Chan($telefone) e Link($callChan) para $nomeAgente");
							}
						}
						break;
					
					case 'OriginateResponse':
/*
Event: OriginateResponse
Privilege: call,all
ActionID: 7793
Response: Failure
Channel: SIP/1201
Context: agentes
Exten: ***124
Reason: 5
Uniqueid: <null>
CallerID: <unknown>
CallerIDNum: <unknown>
CallerIDName: <unknown>
 */
 						$num = $aux->getAtr('Exten');
 						if(substr($num, 0, 3) != '***') {
 							$telefone = $aux->getAtr('Channel');
							$agente = EventosAMI::getAgentePorTel($telefone, $evento, true);
							if($agente) {
								$nomeAgente = $agente->getNome();
 								$sucesso = AMI::verificaStatus($aux);
								if($sucesso === true) {
									$uid = $aux->getAtr('Uniqueid');
									ControleCC::logaEvento(EVENTO_DISCA, $agente->ramal, $num, $uid);
									
									$atrs = array('numsai' => $num);
									if(strlen($num) > 4) $atrs['efetuadas'] = $agente->efetuadas + 1;
									$sucesso = $agente->mudaEstado(SAINTE, $atrs);
									if($sucesso === true) ControleCC::loga(LOG_NORMAL, ">>EV: OriginateResponse. Setado numSai($num) para o agente $nomeAgente");
									else                  ControleCC::loga(LOG_CRITICO, "Erro ao alterar numsai de $nomeAgente - Msg [$sucesso]");
								} else {
									ControleCC::loga(LOG_AVISO, ">>EV: OriginateResponse. Erro ao efetuar chamada de $nomeAgente para $num - Msg [$sucesso]");
									
									$agente->msg = "Erro ao efetuar ligacao. Verifique seu telefone.";
									if(($sucesso = $agente->atualiza()) !== true)
										ControleCC::loga(LOG_AVISO, "Erro ao enviar mensagem para $nomeAgente - Msg [$sucesso]");
								}
							}
 						}
						break;
					
					case 'Hangup': // Alguem desligou
/*
Event: Hangup
Privilege: call,all
Channel: SIP/2549-0835d760
Uniqueid: 1238438800.193
Cause: 0
Cause-txt: Unknown
 */
						$telefone = $aux->getAtr('Channel');
						
						$agente = EventosAMI::getAgentePorTel($telefone, $evento, true);
						if($agente) {
							$nomeAgente = $agente->getNome();
							$msg = '';
							$filas = null;
							$atrs = array('uniqueid' => '', 'channel' => '', 'link' => '');
							switch($agente->codstatus) {
								case ATENDENDO:
									$msg = ''; // Ignorar o hangupo no atendendo, pois sera feita a mudan�a no AgentComplete
									ControleCC::loga(LOG_DEBUG2,  ">>EV: Hangup. Ignorando Hangup durante atendendo");
									break;
								
								case CHAMANDO:
									$msg = "Ligacao na fila $agente->filaatual vinda de $agente->numentra desligou durante CHAMANDO";
									$filas = $agente->filaatual;
									$atrs['numentra'] = '';
									$atrs['filaatual'] = '';
									break;
								
								case SAINTE:
									$msg = "$nomeAgente desligou chamada sainte";
									$atrs['numsai'] = '';
									break;
								
								case DISCANDO:
									$msg = "$nomeAgente nao atendeu propria chamada sainte";
									$atrs['numsai'] = '';
									break;
								
								case ENTRANTE:
									$msg = "$nomeAgente desligou chamada entrante direta";
									$atrs['numentra'] = '';
									break;
							}
							if($msg != '') {
								ControleCC::loga(LOG_NORMAL, ">> Ev. Hangup. $msg");
								$sucesso = $agente->mudaEstado(DISPONIVEL, $atrs, $filas);
								if($sucesso === true) ControleCC::loga(LOG_NORMAL,  ">>EV: Hangup. Setado codstatus(DISPONIVEL) para $nomeAgente");
								else                  ControleCC::loga(LOG_CRITICO, "ERRO EV: Hangup $nomeAgente - Msg [$sucesso]");
							}
						} else
							ControleCC::loga(LOG_DEBUG2,  ">>EV: Hangup. Ignorando Hangup de nao agente");
						break;
					
					case 'Shutdown':
/*
Event: Shutdown
Privilege: system,all
Shutdown: Cleanly
Restart: False
 */
 						$razao = $aux->getAtr('Shutdown');
						ControleCC::loga(LOG_AVISO, "Asterisk desligou[$razao]. Saindo!");
						ControleCC::$loopPrincipal = 0;
						break;
				}
			}
			$aux = $aux->prox;
		}
		return true;
	}
	
	function enviaQueueStatus() {
		$actID = $this->AMI->getActionID();
		$pacote = $this->AMI->enviaComando('QueueStatus', array('Member' => '--NenhuM--')); // Filtro --NenhuM-- para nao receber eventos de membros das filas
		$this->processaEventos($pacote);
		return AMI::comandoOK($pacote, $actID);
	}
	
	function shut() {
		$this->AMI->logoff();
	}
}
?>