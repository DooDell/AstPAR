<?php
	define('ID_SHMEM_FLAGS', 0xf0f3);
	$ramalAg = $argv[1];
	if($ramalAg >= 1000 && $ramalAg <= 9999) {
		$memFlags = @shmop_open(ID_SHMEM_FLAGS, 'w', 0, 0);
		if($memFlags) {
			shmop_write($memFlags, '1', $ramalAg);
			shmop_close($memFlags);
		} else
			echo "Erro ao abrir SHMEM\n\n";
	} else
		echo "Digite o ramal [1000-9999]\n\n";
?>