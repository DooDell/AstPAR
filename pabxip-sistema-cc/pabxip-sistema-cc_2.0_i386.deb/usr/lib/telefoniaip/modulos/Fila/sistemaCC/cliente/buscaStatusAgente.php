<?php
	include('comandos.php');
	$idAg = $_SESSION['agenteLogado']->id;
	
	if($idAg > 0) {
		$ag = buscaDadosAgente($idAg, true);
		echo ($ag->codstatus === 0) ? '0' : $ag->codstatus;
	} else
		echo '0';
?>
