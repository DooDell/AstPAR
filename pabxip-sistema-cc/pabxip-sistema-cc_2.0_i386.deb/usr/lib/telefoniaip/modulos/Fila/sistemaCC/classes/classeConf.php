<?php
class Conf {
	public $arq, $ami, $ast, $kaAtivo;
	
	public function init($arq = "/etc/controleCC.conf") {
		$this->arq = $arq;
		if(!$this->ler()) {
			$this->ami = new InfoHost("localhost", 5038, "admin", "sapo");
			$this->kaAtivo   = 1;
			$this->salvar();
			return false;
		}
		return true;
	}
	
	function salvar() {
		$txt = 
'// Arquivo de configuracao do Controle do CallCenter
$amiHost = "' .$this->ami->host. '";
$amiPort = '  .$this->ami->port. ';
$amiUser = "' .$this->ami->user. '";
$amiPass = "' .$this->ami->pass. '";

$kaAtivo = "' .$this->kaAtivo.   '";
';
		file_put_contents($this->arq, $txt);
	}
	
	function ler() {
		if(!file_exists($this->arq)) return false;
		$txt = file_get_contents($this->arq);
		if(strstr($txt, "// Arquivo de configuracao do Controle do CallCenter")) {
			$amiHost = $amiPort = $amiUser = $amiPass = null;
			$kaAtivo = null;
			eval($txt);
			
			$this->ami = new InfoHost($amiHost,$amiPort,$amiUser,$amiPass);
			$this->kaAtivo = $kaAtivo;
			
			return true;
		}
	}
}
?>