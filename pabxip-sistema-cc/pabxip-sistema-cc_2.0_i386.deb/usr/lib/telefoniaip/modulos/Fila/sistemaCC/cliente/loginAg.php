<?
	include('comandos.php');
	
	$agente = $_SESSION['agenteLogado'];
	if(empty($agente->id) || empty($agente->ramal) || empty($agente->senha))
		header('location:logoff.php');
		
	$nav = strtolower($_SERVER["HTTP_USER_AGENT"]);
	if(!strstr($nav, "mozilla")) {
		header("location:firefox.php");
	}
	if(!file_exists('/var/run/asterisk/asterisk.ctl') || !file_exists('/etc/asterisk/telip/cc/RODANDO')) {
		header("location:sistemaForaDoAr.php");
		exit;
	}
	
	$tels = buscaPAsDisponiveis($agente->id);
	
	if(count($tels)) {
		$comboPAs = "<select name='telefone'>\n";
		foreach($tels as $tel => $desc)
			$comboPAs .= "<option value='$tel'>$desc</option>\n";
		$comboPAs .= "</select>\n";
	} else
		$comboPAs = "Nenhum PA dispon�vel";
?>
<html>
	<head>
		<title>.: Login de Agentes :.</title>
		<link rel="Stylesheet" href="css/login.css" type="text/css" media="screen">
	</head>
	<body>	
		<div id="barra_top"></div>	
		<div id="divJanelaLogin">
			<div id="divLogo"></div>
			<div id="divMensagem">
				<? if(!empty($msg)) echo $msg; ?>		
			</div>										
		</div>
		<div id="divConteudo">				
			<form action="controleLoginAg.php" method="post">				
				<table width="400px">						
					<tr>
						<td class='esqSup'></td>
						<td class='dirSup'></td>
					</tr>										
					<th colspan='2'>Central de Atendimento Celepar</th>
					<tr><td align="right">Nome:</td><td><? echo $agente->nome; ?></td></tr>	
					<tr><td align="right">Ramal:</td><td><? echo $agente->ramal; ?></td></tr>
					<tr><td align="right">PA:</td><td><? echo $comboPAs ?></td></tr>
					<tr>
						<td align="center" colspan='2'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
							<? if(count($tels)) { ?>
								<input type="submit" name="login" value="Login" /> 
							<? } ?>
							<input type="button" name="cancelar" value="Cancelar" onclick="saida()" />
						</td>
					</tr>
					<tr>
						<td class='esqInf'></td>
						<td class='dirInf'></td>
					</tr>		
				</table>
			</form>
		</div>
		<script type="text/javascript">
			function saida() {
				window.location = "logoff.php";
			}
		</script>
		<div id="barra_bottom"></div>
	</body>
</html>