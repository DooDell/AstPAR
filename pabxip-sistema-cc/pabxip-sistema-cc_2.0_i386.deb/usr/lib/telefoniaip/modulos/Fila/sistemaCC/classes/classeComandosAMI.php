<?php
class ComandosAMI {
	var $loginOK;
	private $AMI, $pacotesUltCmd;
	
	function ComandosAMI($config) {
		$this->loginOK = false;
				
		$this->AMI = new AMI($config);
		if($this->AMI->pacoteLogin === false)
			return;

		$this->loginOK = true;
	}
	
	public function getPacotesUltCmd() {
		return $this->pacotesUltCmd;
	}
	function enviaComando($cmd, $params = array(), $to=0.02) {
		$actID  = $this->AMI->getActionID();
		$this->pacotesUltCmd = $this->AMI->enviaComando($cmd, $params, $to);
		if($this->pacotesUltCmd === false) {
			ControleCC::loga(LOG_AVISO, "Asterisk desligou/caiu. saindo.");
			ControleCC::$loopPrincipal = 100;
			return false;
		}
		$ret = AMI::comandoOK($this->pacotesUltCmd, $actID);
		if($ret === false) {
			// Em caso de n�o encontrar o ActionID na primeira leva de pacotes recebidos tentar novamente
			$aux = $this->AMI->recebeEventos($to);
			$ret = AMI::comandoOK($aux, $actID);
			// Juntar as duas listas de pacotes recebidas para retornar
			$this->pacotesUltCmd->merge($aux);
		}
		return $ret;
	}
		
	function shut() {
		$this->AMI->logoff();
	}
}
?>