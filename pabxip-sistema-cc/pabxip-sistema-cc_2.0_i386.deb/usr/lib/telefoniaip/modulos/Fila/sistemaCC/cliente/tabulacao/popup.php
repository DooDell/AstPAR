<?
	session_name('popupTabulacao');
	include(''.'/usr/lib/telefoniaip/modulos/Fila/sistemaCC/cliente/comandos.php');
	
	$tempo = $_REQUEST['timer'];
	if($tempo < 5) $tempo = 5;
	
	$idag     = $_REQUEST['idag'];
	$callerid = $_REQUEST['num'];
	$nomeFila = $_REQUEST['fila'];
	$uniqueid = $_REQUEST['uid'];
	
	$itens = buscaItensTabulacao($nomeFila);
?>
<html>
	<head>
		<title>.: Tabula��o - <? echo $nomeFila ?> :.</title>
		<script>
			self.resizeTo(350, 550);
			
			function foi() {
				document.dadosPopup.submit();
			}
			
			tempo = <? echo $tempo ?>;
			function atzTimer() {
				tempo--;
				document.getElementById('timer').innerHTML = tempo; //'Fechando em ' + tempo + 's';
				if(tempo > 0) setTimeout("atzTimer()", 1000);
				else          foi();
			}
			setTimeout("atzTimer()", 1000);
		</script>
	</head>
	<body>
		<h2>.: Tabula��o - <? echo $nomeFila ?> :.</h2>
		<form name='dadosPopup' action="insereTab.php">
			<input type='hidden' name='uid' id='uniqueid' value='<? echo $uniqueid ?>' />
			<input type='hidden' name='fila' value='<? echo $nomeFila ?>' />
			<input type='hidden' name='cid'  value='<? echo $callerid ?>' />
			<input type='hidden' name='idag' value='<? echo $idag ?>' />
			
			<input type='radio'  name='item' value='0' checked='true' onchange='foi()' /> <b>N�o tabulado</b><br>
<?
	foreach($itens as $cod => $desc)
		echo "<input type='radio' name='item' value='$cod' onchange='foi()' /> $desc<br>\n";
?>
		</form>
		<h3>Fechando em <span id='timer'><? echo $tempo ?></span>s</h3>
	</body>
</html>
