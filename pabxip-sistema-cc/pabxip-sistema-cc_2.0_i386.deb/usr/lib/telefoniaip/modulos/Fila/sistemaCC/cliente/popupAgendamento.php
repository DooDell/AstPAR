<?
	session_name('popupAgendamento');
	include(''.'/usr/lib/telefoniaip/modulos/Fila/sistemaCC/cliente/comandos.php');
	
	$idAg       = $_REQUEST['idagente'];
	$idAlvo     = $_REQUEST['idalvo'];
	$dadosAlvo  = $_REQUEST['dadosalvo'];
	$filaAlvo   = $_REQUEST['filaalvo'];
	$numsAlvo   = explode('-', $_REQUEST['numsalvo']);
	$dthrAgd    = $_REQUEST['datahora'];
	$idCampanha = $_REQUEST['idcampanha'];
?>
<html>
	<head>
		<title>.: Agendamento - <? echo $filaAlvo ?> :.</title>
	</head>
	<body>
		<h2>.: Agendamento - Fila [<? echo $filaAlvo ?>] :.</h2><br>
		<br>
		ID: <? echo $idAlvo ?><br>
		Camp: <? echo $idCampanha ?><br>
		Dados: <? echo $dadosAlvo ?><br>
		Agendado para: <? echo $dthrAgd ?><br>
		<br>
<?
	foreach($numsAlvo as $num)
		echo "<a href='javascript:disca($num)'>$num</a><br>\n";
?>
	</body>
</html>
