<?php
class PacoteAMI {
	private $atributos;
	public  $prox, $dados;
	
	public function PacoteAMI($atrs=null) {
		$this->atributos = array();
		$this->prox = null;
		$this->dados = null;
		if(is_array($atrs))
			$this->setAtr($atrs);
	}

	static function parse($rbuff) {
    	$ret = new PacoteAMI();
		$aux =& $ret;
		$novoPacote = false;
    	if(strlen($rbuff) > 0) {
    		$lenAnterior = 1;
    		foreach(explode("\r\n", $rbuff) as $lin) {
				$len = strlen($lin);
				if($len == 0 && $lenAnterior == 0) break;
				if($len < 1) {
					$novoPacote = true;		
    			} else {
					if($novoPacote) {
						$aux->prox = new PacoteAMI();
						$aux =& $aux->prox;
						$novoPacote = false;
					}
					$pos = strpos($lin, ':');
					$chave = trim(substr($lin, 0, $pos));
					$valor = trim(substr($lin, $pos+1));
					
    				if($chave == 'Response' && $valor == 'Follows' && strstr($chave, ' ')) {
    					$aux->dados = $lin;
    				} else if($chave != 'Privilege') {
    					$aux->setAtr($chave, $valor);
    				}
				}
    			$lenAnterior = $len;
    		}
        	$aux->prox = null;
    	}
		return $ret;
	}
	
	function vazio() {
		return (count($this->atributos) == 0);
	}
	
	function setAtr($chave, $valor=null) {
		if(is_array($chave)) {
			foreach($chave as $c => $v)
				$this->atributos[$c] = $v;
		} else {
			$this->atributos[$chave] = $valor;
		}
	}
	
	function getAtr($chave) {
		if(in_array($chave, array_keys($this->atributos)))
			return $this->atributos[$chave];
		else
			return '';
	}
	
	function mostra() {
		$ret = '';
		$aux =& $this;
		while($aux) {
			$str = '' . $aux;
			if(strlen($str)) $ret .= "$str \n";
			$aux = $aux->prox;
		}
		return $ret;
	}
	
	function merge($pacAdd) {
		$aux =& $this;
		while($aux) {
			if($aux->prox === null) {
				$aux->prox = $pacAdd;
				break;
			}
			$aux = $aux->prox;
		}
	}
	
	function __toString() {
		if(!count($this->atributos)) return '';
		$ret = '';
		foreach($this->atributos as $chave => $valor)
			$ret .= "$chave = $valor\n";
		if($this->dados)
			$ret .= "Dados: $this->dados\n";
		return "$ret\n";
	}
}
?>