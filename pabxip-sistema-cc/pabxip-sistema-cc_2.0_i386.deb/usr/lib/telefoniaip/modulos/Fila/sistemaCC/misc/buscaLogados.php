<?php
	define('ID_SHMEM_LOGIN', 0xf0f4);
	
	$tipo = (isset($argv[1]) && $argv[1] == 'SUP') ? '2' : '1';
	$nome = ($tipo == '1') ? 'Agente' : 'Supervisor';
	
	$memLogin = @shmop_open(ID_SHMEM_LOGIN, 'a', 0, 0);
	$mapa = shmop_read($memLogin, 0, 10000);
	$pos = 999;
	$achou = false;
	while(($pos = strpos($mapa, $tipo, $pos + 1))) {
		echo "$nome ramal [$pos] logado.\n";
		$achou = true;
	}
	if(!$achou)
		echo "Nenhum $nome logado.\n"
?>