<?php
	include('../constantes.php');
	$mem = new SharedMem(ID_SHMEM_AGS, 'Agente');
	foreach($mem->getObjs('codstatus', 0, '>') as $ag) {
		     if($ag->keepalive > 10) $cor = 'FF';
		else if($ag->keepalive > 7)  $cor = 'CC';
		else if($ag->keepalive > 4)  $cor = '99';
		else if($ag->keepalive > 1)  $cor = '66';
		else                         $cor = '00';
		echo "KA: <b><font color='#$cor"."3333'>$ag->keepalive</font></b> === $ag->ramal - $ag->nome  <br>\n";
	}
?>
<script language='javascript'>setTimeout("location.reload(true);", 3000); // refresh a cada 3s</script>