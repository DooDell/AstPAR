<?php
	include(''.'/usr/lib/telefoniaip/modulos/Fila/sistemaCC/constantes.php');
	session_start();
	
	function loginOK() {
		$agente = $_SESSION['agenteLogado'];
		if(!is_a($agente, 'Agente') || empty($agente->id) || empty($agente->ramal) || empty($agente->telefone))
			header('location:logoff.php');
		return $agente;
	}
	
	function enviaComando($cmd, $tipo=1) {
		$ret = 0;
		$msg_err = null;
		$mq_id = msg_get_queue(ID_MSG_QUEUE);
		if (!msg_send ($mq_id, $tipo, time() . ':' . $cmd, false, false, $msg_err))
			return "Erro [$msg_err] ao enviar comando.";
		if($tipo == 10) {
			list($id,$act,$p1,$p2) = explode(':', $cmd);
			if($act == 'pausaStatusBase')
				$ret = "Pedido de pausa apos ligacao para o agente [$p2] OK";
		}
		return $ret;
	}
	
	function buscaDadosAgente($idAg, $soAgente=false, $tipoSel='id') {
		$ret = array();
		$mem = new SharedMem(ID_SHMEM_AGS, 'Agente');
		$agente = $mem->get($tipoSel, $idAg);
		$mem->shut();
		if(is_a($agente, 'Agente')) {
			if($soAgente) return $agente;
			$ret['ag'] = $agente;
			$mem = new SharedMem(ID_SHMEM_FILAS, 'FilaCC');
			$filas = $mem->getObjs('id', explode(',', $agente->idsfilas));
			foreach($filas as $fila)
				$ret[$fila->id] = $fila;
			$mem->shut();
		}
		return $ret;
	}
	
	function buscaAgentePorLogin($ramal, $senha) {
		$memAg = new SharedMem(ID_SHMEM_AGS, 'Agente');
		$agente = $memAg->get('ramal', $ramal);
		if(is_a($agente, 'Agente') && $agente->senha == $senha)
			return $agente;
		return 'Agente n�o encontrado';
	}
	
	function buscaPAsDisponiveis($idAg) {
		$memAg = new SharedMem(ID_SHMEM_AGS, 'Agente');
		$agente = $memAg->get('id', $idAg);
		
		$telsPAs = array();
		$conn = new Conexao();
		$conn->executa("SELECT chan,descricao FROM pasfila WHERE idfila IN ($agente->idsfilas) ORDER BY descricao");
		while($conn->temMaisDados())
			$telsPAs[$conn->data['chan']] = $conn->data['descricao'];
		$conn->fecha();
		
		// Buscar os telefones atualmente em uso na SHMEM
		if(count($telsPAs) > 0) {
			foreach($memAg->getObjs('telefone', array_keys($telsPAs)) as $agente)
				unset($telsPAs[$agente->telefone]);
		}
		return $telsPAs;
	}

	function buscaNomeSistema() {
		$conn = new Conexao();
		$ret  = $conn->getStr("SELECT valor FROM parametro WHERE nomeparam = 'nomePABX'");
		$conn->fecha();
		return $ret;
	}
	
	function buscaMotivos() {
		$conn = new Conexao();
		$ret = array();
		$conn->executa('SELECT id,descricao FROM tipostatusagente WHERE id > 100 AND id != 200 ORDER BY id');
		while($conn->temMaisDados())
			$ret[$conn->data['id']] = $conn->data['descricao'];
		$conn->fecha();
		return $ret;
	}
	
	function buscaURLPopup($agente, $fim='') {
		$ret = array();
		if(is_a($agente, 'Agente')) {
			$campo = "urlpopup$fim";
			$memFila = new SharedMem(ID_SHMEM_FILAS, 'FilaCC');
			foreach($memFila->getObjs('id', explode(',', $agente->idsfilas)) as $fila) {
				if(isset($fila->$campo) && !empty($fila->$campo))
					$ret[$fila->name] = $fila->$campo;
			}
		}
		return $ret;
	}
	
	//**************************************
	// ------------ Supervisor ------------
	//**************************************
	function buscaNomesFilas() {
		$ret = array();
		$memFila = new SharedMem(ID_SHMEM_FILAS, 'FilaCC');
		foreach($memFila->getObjs() as $fila)
			$ret[$fila->id] = $fila->name;
		return $ret;
	}
	
	/**
	 * Retorna a lista de ramais de agentes e ids de filas
	 */
	function buscaRamaisEFilas() {
		$ramaisAgs = array();
		$mem = new SharedMem(ID_SHMEM_AGS, 'Agente');
		$agentes = $mem->getObjs();
		$mem->shut();
		foreach($agentes as $ag)
			$ramaisAgs[$ag->id] = $ag->ramal;
		
		$idsFilas = array();
		$mem = new SharedMem(ID_SHMEM_FILAS, 'FilaCC');
		$filas = $mem->getObjs();
		$mem->shut();
		foreach($filas as $fila)
			$idsFilas[] = $fila->id;
			
		return array('ramais' => $ramaisAgs, 'filas' => $idsFilas);
	}

	function comparaAgentes($ag1, $ag2) {
	    if ($ag1->codstatus == $ag2->codstatus) {
	        if($ag1->tempostatus == $ag2->tempostatus) return 0;
	        return ($ag1->tempostatus > $ag2->tempostatus) ? -1 : 1;
	    }
	    return ($ag1->codstatus < $ag2->codstatus) ? -1 : 1;
	}
	function buscaDadosSup($ramaisAlt=false, $filasAlt=false) {
		$mem = new SharedMem(ID_SHMEM_AGS, 'Agente');
		$agentes = ($ramaisAlt !== false) ? $mem->getObjs('ramal', $ramaisAlt) : $mem->getObjs();
		$mem->shut();
		uasort($agentes, "comparaAgentes");

		$mem = new SharedMem(ID_SHMEM_FILAS, 'FilaCC');
		$filas = ($filasAlt !== false) ? $mem->getObjs('id', $filasAlt) : $mem->getObjs();
		$mem->shut();
														
		return array_merge($agentes, $filas, array(new Totais($agentes)));
	}
	
	//**************************************
	// ------------- Tabula��o -------------
	//**************************************
	function buscaItensTabulacao($nomeFila) {
		$itens = array();
		$conn = new Conexao();
		$idFila = $conn->getStr("SELECT id FROM fila WHERE LOWER(name) = '".strtolower($nomeFila)."'");
		if(empty($idFila)) return false;
		$conn->executa("SELECT id,descricao FROM cc_tipotabulacao WHERE idfila = '$idFila' AND (flag & 1) != 1 ORDER BY ordem");
		while($conn->temMaisDados())
			$itens[$conn->data['id']] = $conn->data['descricao'];
		$conn->fecha();
		return $itens;
	}
	
	function insereTabulacao($nomeFila, $idag, $uniqueid, $item) {
		// Insere o dado da tabula��o
		$conn = new Conexao();
		$conn->executa("SELECT id,flags FROM fila WHERE LOWER(name) = '".strtolower($nomeFila)."'");
		if($conn->temMaisDados()) {
			$idFila = $conn->data['id'];
			$flags  = $conn->data['flags'];
			$conn->executa("INSERT INTO cc_tabulacao(uniqueid, idtipo, idfila) VALUES('$uniqueid', '$item', '$idFila')");
			
			if($flags & FLAG_FILA_PAUSA_AUTO) {
				// Despausa o Agente, somente se a fila estiver configurada para pausa automatica
				enviaComando("$idag:mudaStatus:TABULACAO");
			}
		}
		$conn->fecha();
	}
?>