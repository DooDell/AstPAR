<?php
	define('ID_MSG_QUEUE_AST', 0xf0f5);

	$idMQ = msg_get_queue(ID_MSG_QUEUE_AST);
	
	if(msg_send($idMQ, 1, time().':Saia', false, true, $msg_err) !== true)
		echo "Msg not sent because $msg_err\n";
?>