Call Center Celepar

* Descri��o

  O sistema de Call Center desenvolvido com a necessidades da Central de Atendimento Celepar (CAC) em mente � uma poderosa solu��o para ambientes de Filas de Atendimento com todas as funcionalidades esperadas. Com esta plataforma � poss�vel acompanhar o funcionamento do Call Center atrav�s de qualquer computador que tenha acesso ao servidor da solu��o, inclusive efetuando o monitoramento on-line dos atendimentos em andamento.


* Componentes

  Cada papel desemepenhado no sistema conta com um respectivo aplicativo que centraliza todas as fun��es esperadas:
  - O adminstrador do sistema pode gerenciar qualquer configura��o de forma simples atrav�s do portal de administra��o web. � atrav�s desta interface que � poss�vel delegar os n�veis de acesso dos usu�rios do sistema, sendo assim ap�s a cria��o de um usu�rio supervisor este pode se tornar o respons�vel pela cria��o subsequente dos pr�ximos usu�rios.
  
  - Os supervisores contam com um aplicativo web de monitoramento em tempo real do estado do Call Center. Atrav�s desta interface � poss�vel perceber o estado atual do Call Center (carga, tamanho das filas) em um simples relance. Neste ambiente tamb�m � poss�vel controlar o estado e enviar mensagens aos agentes e efetuar o monitoramento dos atendimentos em andamento.
  
  - Os agentes de atendimento por sua vez contam com o seu aplicativo web para receber informa��es das chamadas e da supervis�o, assim como alterar o seu estado e controlar o atendimento em curso.


* Funcionalidades

  - Filas de atendimento altamente customizaveis, com prioridades e hor�rio de atendimento
  - Motivos de Pausas flex�veis
  - Tabula��o de chamadas
  - Relat�rios de Grupos, Agentes, Distribui��o Temporal e de Tabula��es
  - Cadastro de Posi��es de Atendimento (PAs) independente do Agente
  - Grava��es dos atendimentos com filtros de pesquisa para escuta via web
  - An�ncios para o cliente e para o agente
  - Monitoramento on-line
  - Callback
  - Popups de atendimento customiz�veis

