#!/usr/bin/php -q
<?php
		include(''.'/usr/lib/telefoniaip/classes/control/classeUtil.php');
	
		$connData = Util::getAstPgConnData();
		$host = $connData['dbhost'];
		$user = $connData['dbuser'];
		$pass = $connData['dbpass'];
		$db   = $connData['dbname'];
		
        echo "Inicializando filas: ";

        $connOK = false;
        $conn = pg_connect("host=$host user=$user password=$pass dbname=$db");
        if($conn && pg_connection_status($conn) == PGSQL_CONNECTION_OK) {
                $dthr = date('Y-m-d H:i:s');
                $sql = "SELECT name FROM fila";
                $res = pg_query($conn, $sql);
                if($res) {
                        $connOK = true;
                        while($dados = pg_fetch_assoc($res))
                                $nomesFilas[] = $dados['name'];
                } else
                        echo "Erro ao executar query [$sql] no BD $nomeBD\n";
                pg_close($conn);
        } else {
                echo "Erro ao conectar no BD $nomeBD\n";
        }

        if(count($nomesFilas) > 0) {
                foreach($nomesFilas as $nome)
                        exec("asterisk -rx 'queue show $nome'");

                echo "OK\n";
        } else
                echo "Nenhuma fila configurada.\n";
?>