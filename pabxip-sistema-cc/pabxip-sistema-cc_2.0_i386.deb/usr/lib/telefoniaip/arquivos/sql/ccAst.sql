SELECT setval('parametro_id_seq', max(id)) FROM parametro;

INSERT INTO parametro(nome, valor, nomeparam, flags, info)
	VALUES ('Este PABX atende a um Call Center', '1', 'modocc', 18, 'Esta funcao habilita agentes e filas de atendimento');

