<?php
	include('comandos.php');
	define('DIAS_ATRAS', 7);
	
	session_start();       // Manter a sess�o aberta o m�nimo poss�vel
	$agLogado = loginOK(); // Verifica se o Supervisor logado esta na sess�o
	session_write_close();
	
	$nomeEvento = array(
			DESLOGADO  => 'Deslogado',
			DISPONIVEL => 'Disponivel',
			CHAMANDO   => 'Chamando',
			ATENDENDO  => 'Atendimento',
			SAINTE     => 'Sainte',
			DISCANDO   => 'Discando',
			ENTRANTE   => 'Entrante',
			SUPLOGADO  => 'SupLogado',
			PAUSA      => 'Pausa',
			INDISP     => 'Indisp',
		);
	$conn = new Conexao();
	$conn->executa('SELECT id,descricao FROM tipostatusagente WHERE id > 100 AND id != 200');
	while($conn->temMaisDados())
		$nomeEvento[$conn->data['id']] = $conn->data['descricao'];
	
	$tabulacoes = array();
	$conn->executa('SELECT id,descricao FROM cc_tipotabulacao');
	while($conn->temMaisDados())
		$tabulacoes[$conn->data['id']] = $conn->data['descricao'];
	
	$dia = date('d');
	$mes = date('m');
	$ano = date('Y');
	$data = isset($_REQUEST['data']) ? $_REQUEST['data'] : "$dia/$mes/$ano";
	
	$combaData = "<select name='data' onchange='OCdata(this)'>";
	for($d=0; $d<DIAS_ATRAS; $d++) {
		$dtAux = date('d/m/Y', mktime(0,0,0,$mes,$dia-$d,$ano));
		$sel = ($dtAux == $data) ? " selected='true'" : '';
		$combaData .= "<option value='$dtAux'$sel>$dtAux</option>";
	}
	$combaData .= "</select>";
	
	$agsDia = array();
	list($d,$m,$a) = explode('/', $data);
	$diaBD = "$a-$m-$d";
	$conn->executa("SELECT DISTINCT ON (h.campo1) h.campo1 as idag, u.nome, u.ramal FROM cc_historico h JOIN usuario u ON h.campo1 = u.id::varchar WHERE tipoevento = 1 AND data = '$diaBD'");
	while($conn->temMaisDados()) {
		$agsDia[$conn->data['idag']] = $conn->data['ramal'] . ' - ' . $conn->data['nome'];
	} 
	$conn->fecha();
	asort($agsDia);

	// Pega o ID do ag escolhido pelo request ou o primeiro da lista
	if($agLogado->funcionalidades & FUNC_SUPERVISOR) {
		$idAg = isset($_REQUEST['idAg']) ? $_REQUEST['idAg'] : array_shift(array_flip($agsDia));
		
		$comboAg = "<br>Agente: <select name='idAg' onchange='OCidAg(this)'>";
		foreach($agsDia as $idAux => $nomeAux) {
			$sel = ($idAux == $idAg) ? " selected='true'" : '';
			$comboAg .= "<option value='$idAux'$sel /> $nomeAux</option>\n";
		}
		$comboAg .= "</select>";
	} else {
		$idAg = $agLogado->id;
		$comboAg = "";
	}
	$agente = buscaDadosAgente($idAg, true);
	
	$dadosHist = buscaHistoricoDiaCompleto($agente, $diaBD);
	$linhasHist = $dadosHist['eventos'];
	$linhasAtds = $dadosHist['atendimentos'];
	$linhasSaintes = $dadosHist['saintes'];

	function buscaHistoricoDiaCompleto($agente, $diaBD) {
		$conn = new Conexao();
		$evs = $atds = $saintes = array();
		
		$cntAtd = 0;
		$cntSainte = 0;
		$sql = "SELECT hora, campo2 AS eant, campo3 AS eat, campo4 AS tempo, campo5 AS filas FROM cc_historico WHERE tipoevento = 20 AND campo1 = '$agente->ramal' AND data = '$diaBD' ORDER BY hora";
		$conn->executa($sql);
		while($conn->temMaisDados()) {
			if($conn->data['eat'] == SAINTE)    $conn->data['cntSainte'] = $cntSainte++; // Marcar esta linha como sainte X
			if($conn->data['eat'] == ATENDENDO) $conn->data['cntAtd'] = $cntAtd++; // Marcar esta linha como atendimento X
			$evs[] = (object)$conn->data;
		}

		$cntAtd = 0;		
		$sql = "SELECT c.src, tab.idtipo, ch.hora, ch.campo4 AS uid, ch.campo5 AS fila, tab.flags " .
				"FROM cc_historico ch " .
				"JOIN cdr c ON ch.campo4 = c.uniqueid " .
				"LEFT JOIN cc_tabulacao tab ON tab.uniqueid = ch.campo4 " .
				"WHERE ch.tipoevento = 17 AND ch.campo1 = '$agente->ramal' AND ch.data = '$diaBD' " .
				"ORDER BY ch.hora";
		$conn->executa($sql);
		while($conn->temMaisDados())
			$atds[$cntAtd++] = (object)$conn->data;
		
		$cntSainte = 0;
		$sql = "SELECT hora, campo2 AS num FROM cc_historico WHERE tipoevento = 9 AND campo1 = '$agente->ramal' AND data = '$diaBD' ORDER BY hora";
		$conn->executa($sql);
		while($conn->temMaisDados())
			$saintes[$cntSainte++] = (object)$conn->data;
		
		$conn->fecha();
		return array('eventos' => $evs, 'atendimentos' => $atds, 'saintes' => $saintes);
	}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
	<head>
		<title>.: Hist�rico de <?echo $data;?> :.</title>
		<link rel="Stylesheet" href="css/historico.css" type="text/css" media="screen">
		<script type="text/javascript">
			function OCidAg(combo) {
				document.dados.idAg.value = combo.value;
				document.dados.submit();
			}
			function OCdata(combo) {
				document.dados.data.value = combo.value;
				document.dados.submit();
			}
			function tabular(nomeFila, cid, uid, flags) {
				var url = "tabulacao/popup.php?timer=60&idag=<?echo $idAg?>&num="+cid+"&fila="+nomeFila+"&uid="+uid+"&flags="+flags;
				var popup = window.open(url, 'CRM' + cid, 'top=100,left=100,scrollbars=yes');
				popup.focus();
			}
		</script>
	</head>
	<body>
		<input type="hidden" name="identificador" id="ehHistDia" value="janelaHistDia" />
		<form name="dados" action="" method="post">
			<input type='hidden' name='idAg' value="<?echo $idAg?>">
			<input type='hidden' name='data' value="<?echo $data?>">
		</form>
		<table width='100%'>
			<tr>
				<td bgcolor='#EEE'>
					Data: <?echo $combaData . $comboAg?>
				</td>
				<td align='center'><h1><? echo "Hist�rico de $data - $agente->nome"; ?></h1></td>
			</tr>
		</table>
		<center>
		<table width='90%'>
			<thead bgcolor='#EEE'>
				<td width='100px'>Hor�rio</td>
				<td width='250px'>Evento</td>
				<td width='100px'>Tempo</td>
				<td>Info</td>
			</thead>
<?
	if(count($linhasHist) > 0) {
		for($c=0; $c<count($linhasHist); $c++) {
			$lin = $linhasHist[$c];
			$info = $cl = $c1 = '';
			if($lin->eat == DISPONIVEL && $lin->eant == DESLOGADO) {
				$cl = 'Disponivel';
				$c1 = 'Login';
				$tempo = '';
			} else {
				if($lin->eat == DISCANDO) {
					if(isset($linhasHist[$c + 1]) && $linhasHist[$c + 1]->eat == SAINTE) {
						$cl = 'Sainte';
						$td = $linhasHist[$c + 1]->tempo;
						$c1 = "Discando($td) => Sainte";
						// Buscar os dados da discagem
						if(isset($linhasSaintes[$linhasHist[$c + 1]->cntSainte])) {
							$dtSai = $linhasSaintes[$linhasHist[$c + 1]->cntSainte];
							$info  = "discado: $dtSai->num";
						}
						$c++;
					} else {
						// Discando nao foi para sainte -> Cancelado
					}
				} else if($lin->eat == CHAMANDO) {
					if(isset($linhasHist[$c + 1])) {
						$tc = $linhasHist[$c + 1]->tempo;
						if($linhasHist[$c + 1]->eat == ATENDENDO) {
							$cl = 'Chamando';
							$c1 = "Chamando($tc) => Atendendo";
							// Buscar os dados do atendimento
							if(isset($linhasAtds[$linhasHist[$c + 1]->cntAtd])) {
								$dtAtd = $linhasAtds[$linhasHist[$c + 1]->cntAtd];
								$nomeFila = substr($dtAtd->fila, 1, -1);
								$tab = empty($dtAtd->idtipo) ? 
									"<a href=\"javascript:tabular('$nomeFila','$dtAtd->src','$dtAtd->uid','$dtAtd->flags')\">Tabular</a>" :
									$tabulacoes[$dtAtd->idtipo]." <a href=\"javascript:tabular('$nomeFila','$dtAtd->src','$dtAtd->uid','$dtAtd->flags')\">Corrigir</a>"; 
								$info = "$dtAtd->src - $tab";
							}
							$c++;
						} else if($linhasHist[$c + 1]->eat == INDISP) {
							$cl = 'Indisp';
							$c1 = "Chamando($tc) => Indispon�vel";
							$info = 'N�o Atendimento';
							$c++;
						}
					}
				} else {
					$cl = ($lin->eat >= 200) ? 'Indisp' : (($lin->eat >= 100) ? $cl = 'Pausa' : $nomeEvento[$lin->eat]);
					$c1 = (($cl == 'Pausa') ? 'PAUSA ' : (($cl == 'Indisp') ? 'INDISP ' : '')) . $nomeEvento[$lin->eat];
				}
				$tempo = isset($linhasHist[$c + 1]) ? formataSegundos($linhasHist[$c + 1]->tempo) : '';
			}
?>
			<tr>
				<td class='data'><?echo $lin->hora?></td>
				<td class='<?echo $cl?>'><?echo $c1?></td>
				<td class='data'><?echo $tempo?></td>
				<td class='info'><?echo $info?></td>
			</tr>
<?		}
	} else { ?>
			<tr class='lin1'><td colspan='4'>Sem eventos no per�odo</td></tr>
<?	} ?>
		</table>
		</center>
	</body>
</html>
