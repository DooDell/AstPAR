<?php
	session_start();
	unset($_SESSION['agenteLogado']);
	$msg = (isset($_REQUEST['msg']) && !empty($_REQUEST['msg'])) ? '?msg=' . $_REQUEST['msg'] : '';
	header("location:login.php$msg");
?>
