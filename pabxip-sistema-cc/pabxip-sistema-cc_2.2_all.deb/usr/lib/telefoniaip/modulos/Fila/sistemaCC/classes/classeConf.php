<?php
/**
 * Classe para a leitura do arquivo de configura��o do controleCC
 * @author Gabriel Ortiz
 */
class Conf {
	public $arq, $ami, $ast, $kaAtivo, $hooks;
	
	public function init($arq = '/etc/controleCC.conf') {
		$this->arq = $arq;
		if(!$this->ler()) {
			$this->ami     = new InfoHost("localhost", 5038, "admin", "sapo");
			$this->kaAtivo = 12;
			$this->hooks   = array();
			$this->salvar();
			return false;
		}
		return true;
	}
	
	/**
	 * Salva os atributos da classe de volta para o arquivo de conf
	 */
	function salvar() {
		$txt = 
'// Arquivo de configuracao do Controle do CallCenter
$amiHost = "' .$this->ami->host. '";
$amiPort = '  .$this->ami->port. ';
$amiUser = "' .$this->ami->user. '";
$amiPass = "' .$this->ami->pass. '";

$kaAtivo = "' .$this->kaAtivo.   '";
';
		file_put_contents($this->arq, $txt);
	}
	
	/**
	 * L� o arquivo de conf setando os atributos correspondentes na classe
	 * Testa pelo "header" "// Arquivo de configuracao do Controle do CallCenter"
	 */
	function ler() {
		if(!file_exists($this->arq))
			return false;
		
		$txt = file_get_contents($this->arq);
		
		if(!strstr($txt, "// Arquivo de configuracao do Controle do CallCenter"))
			return false;
		
		$amiHost = $amiPort = $amiUser = $amiPass = null;
		$kaAtivo = $hooks = null;
		eval($txt);
		
		$this->ami     = new InfoHost($amiHost,$amiPort,$amiUser,$amiPass);
		$this->kaAtivo = $kaAtivo;
		$this->hooks   = (is_array($hooks)) ? $hooks : array();
		
		return true;
	}
}
?>