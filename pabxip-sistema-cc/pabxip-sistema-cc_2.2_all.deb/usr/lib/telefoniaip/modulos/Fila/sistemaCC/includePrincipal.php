<?php
	require_once('constantes.php');
	require_once('logHeader.php');
	
	define("VERSAO", '2.0.3');
	
	define("EVENTO_LOGIN",        1); //(1, 'Login', 'Codigo do Usuario', 'Ramal', 'Telefone', '');
	define("EVENTO_LOGOFF",       2); //(2, 'Logoff', 'Codigo do Usuario', 'Ramal', 'Causa', '');
	define("EVENTO_STATUS",       3); //(3, 'Status', 'Codigo do Usuario', 'Status Anterior', 'Status Novo', 'Codigo do Usuario');
	define("EVENTO_ENTRACH",      4); //(4, 'Entra na Chamada', 'Codigo do Ouvinte', 'Telefone Ouvinte', 'Codigo do Ouvido', 'Telefone do Ouvido');
	define("EVENTO_ESCUTACH",     5); //(5, 'Escuta Chamada', 'Codigo do Ouvinte', 'Telefone Ouvinte', 'Codigo do Ouvido', 'Telefone do Ouvido');
	define("EVENTO_CONFERENCIA",  6); //(6, 'Conferencia', 'Codigo do Usuario', 'Telefone do usuario', 'Numero do Destino', '');
	define("EVENTO_ADDFILA",      7); //(7, 'Adicionar em Fila', 'Codigo do Supervisor', 'Codigo do Agente', 'Codigo da Fila', 'Nome da Fila');
	define("EVENTO_DELFILA",      8); //(8, 'Remover de Fila', 'Codigo do Supervisor', 'Codigo do Agente', 'Codigo da Fila', 'Nome da Fila');
	define("EVENTO_DISCA",        9); //(9, 'Discagem', 'Ramal do Usuario', 'Numero Discado', 'UniqueID', '', '');
	define("EVENTO_TRANSFERE",   10); //(10, 'Transferencia', 'Codigo do Usuario', 'Telefone', 'Numero Origem', 'Numero Destino');
	define("EVENTO_REGISTRAMAC", 13); //(13, 'Registro de PA', 'Codigo do Usuario', 'Telefone', 'MAC Address', '');
	define("EVENTO_LOGINSUP",    14); //(14, 'Login de Supervisor', 'Ramal', 'Telefone', '', '');
	define("EVENTO_CONTAGEM",    15); //(15, 'Contagem de Chamadas Diaria', 'Codigo do Usuario', 'Recebidas', 'Efetuadas', 'TMA');
	define("EVENTO_HANGUP",      16); //(16, 'Hangup', 'Codigo do Usuario', '', '', '');
	define("EVENTO_ATENDIMENTO", 17); //(17, 'Atendimento', 'Ramal do Agente', 'Tempo de Espera', 'Tempo de Atendimento', 'UniqueID', ',nomeFila,')
	define("EVENTO_ABANDONO",    18); //(18, 'Abandono', 'Tempo em Fila', 'Posi��o na fila', 'CallerID', '', ',Nome Fila,');
	define("EVENTO_RECEBE",      19); //(19, 'Entrante nao ACD', 'Ramal', 'Callerid', 'UniqueID', '');
	define("EVENTO_MUDAESTADO",  20); //(20, 'Mudan�a de Estado', 'Codigo do Usuario', 'Estado Anterior', 'Estado Novo', 'Tempo no Estado Anterior');
	define("EVENTO_NAOATENDIMENTO", 21); //(21, 'Agente n�o Atendeu', 'Ramal do Usuario', 'Tempo de ring', '', '', 'Nome da Fila');
	define("EVENTO_CALLBACK",    22); //(22, 'Liga��o foi para CallBack', 'CallerID', '', '', '', 'Nome da Fila');
?>