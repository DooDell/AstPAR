<?php
	include(''.'/usr/lib/telefoniaip/modulos/Fila/sistemaCC/logger.php');
	include('comandos.php');
	
	$ramal = $_REQUEST['ramal'];
	$senha = $_REQUEST['senha'];
	
	$agente = buscaAgentePorLogin($ramal, $senha);
	
	session_start(); // Manter a sess�o aberta o m�nimo poss�vel
	if(!is_a($agente, 'Agente')) {
		$_SESSION['agenteLogado'] = 0;
		header('location:login.php?msg=Usu�rio/Senha incorretos');
		loga(LOG_AVISO, "Tentativa fracassada de login: Usuario: $ramal - Senha: $senha", " [\033[33;1mcontroleLogin\033[0m]", '/var/log/controleCallCenter.log');
		exit;
	}
	
	if($agente->codstatus !== 0) {
		$_SESSION['agenteLogado'] = 0;
		header('location:login.php?msg=Usu�rio j� em uso');
		$nomeAg = $agente->getNome();
		loga(LOG_AVISO, "Usuario [$nomeAg] ja em uso no login", " [\033[33;1mcontroleLogin\033[0m]", '/var/log/controleCallCenter.log');
		exit;
	}
	
	if($agente->funcionalidades & FUNC_SUPERVISOR) {
		if(empty($agente->idsfilas)) {
			$_SESSION['agenteLogado'] = 0;
			header("location:login.php?msg=Supervisor $agente->nome n�o est� em nenhuma fila");
		} else {
			$agente->telefone = "SIP/$agente->ramal";
			$_SESSION['agenteLogado'] = $agente;
			enviaComando("$agente->id:loginSup:$agente->telefone", 10);
			header('location:janelaSupervisor.php');
		}
	} else if($agente->funcionalidades & FUNC_AGENTE) {
		if(empty($agente->idsfilas)) {
			$_SESSION['agenteLogado'] = 0;
			header("location:login.php?msg=Agente $agente->nome n�o est� em nenhuma fila");
		} else {
			if($agente->funcionalidades & FUNC_SEL_PA) {
				$agente->telefone = '';
				$_SESSION['agenteLogado'] = $agente;
				header('location:loginAg.php');
			} else {
				$agente->telefone = (empty($agente->telatual)) ? "SIP/" . $agente->ramal : $agente->telatual;
				$_SESSION['agenteLogado'] = $agente;
				header('location:popupagente.php');
			}
		}
	} else {
		$_SESSION['agenteLogado'] = 0;
		header('location:login.php?msg=Tipo de usu�rio inv�lido');
	}
?>