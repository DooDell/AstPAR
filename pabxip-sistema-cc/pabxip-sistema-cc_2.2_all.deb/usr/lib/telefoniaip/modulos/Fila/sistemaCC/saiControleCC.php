<?php
	define('ID_MSG_QUEUE', 0xf0f0);
	$mq_id = msg_get_queue(ID_MSG_QUEUE);
	
	if (!msg_send ($mq_id, 100, time() . ':ADM:SAIA', false, false, $msg_err))
		echo "Msg not sent because $msg_err\n";
?>