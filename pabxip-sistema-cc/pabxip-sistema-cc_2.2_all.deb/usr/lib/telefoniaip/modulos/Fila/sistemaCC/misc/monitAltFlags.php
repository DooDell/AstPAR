<?php
	define('ID_SHMEM_FLAGS', 0xf0f3);
	
	$memFlags = @shmop_open(ID_SHMEM_FLAGS, 'w', 0, 0);
	if($memFlags) {
		$ramaisAlt = array();
		while(true) {
			$flags = shmop_read($memFlags, 0, 10000);
			foreach($ramaisAlt as $ramal) {
				if(substr($flags, $ramal, 1) != '1')
					unset($ramaisAlt[$ramal]);
			}
			$offset = 0;
			while(($offset = strpos($flags, '1', $offset)) !== false) {
				if(!$ramaisAlt[$offset]) {
					$ramaisAlt[$offset] = true;
					echo "Ramal $offset alterado!";
				}
			}
			usleep(100000);
		}
		shmop_close($memFlags);
	} else
		echo "Erro ao abrir SHMEM\n\n";
?>