<?php
class Hooks
{
	// Definir aqui funcoes de "gancho" para personalizar o controleCC

	// Nao mexer aqui	
	static function chamaFuncoes($nomeHook, $p1=null, $p2=null, $p3=null, $p4=null) {
		if(in_array($nomeHook, array_keys(ControleCC::$conf->hooks))) {
			$nomeFuncs = ControleCC::$conf->hooks[$nomeHook];
			if(!is_array($nomeFuncs)) $nomeFuncs = array($nomeFuncs);
			foreach($nomeFuncs as $nFunc) {
				// Chama a funcao(se existir) passando o pacote e o agente(se houver)
				if(is_callable("Hooks::$nFunc"))
					Hooks::$nFunc($p1, $p2, $p3, $p4);
			}
		}
	}
}
?>