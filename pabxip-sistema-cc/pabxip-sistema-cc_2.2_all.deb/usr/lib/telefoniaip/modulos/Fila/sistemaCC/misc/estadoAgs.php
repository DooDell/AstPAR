<?php
	include('../constantes.php');
	
	$estadosAst = array();
	
	function mostraAgsFila($idFila, $nomeFila, $ags) {
		global $estadosAst;
		
		echo "Agentes na fila [$nomeFila]:\n";
		foreach($ags as $ag) {
			if($ag->codstatus > 0 && in_array($idFila, explode(',', $ag->idsfilas))) {
				$err = '';
				$stsAst = $estadosAst[$nomeFila][$ag->nome];
				if($ag->codstatus != $stsAst) {
					if($stsAst == 100 && $ag->codstatus >= 100) $err = '';
					else if($stsAst == 3 && $ag->codstatus > 1 && $ag->codstatus < 10) $err = '';
					else $err = "\033[31;1mCRITCO\033[0m";
				}
				echo "$ag->nome: $ag->codstatus - Status no Asterisk: ($stsAst) $err\n";
			}
		}
		echo "\n";
	}
	
	function buscaDadosAst() {
		global $estadosAst;
		exec("asterisk -rx 'queue show'", &$lins);
		$nomeFila = '';
		$pass = 1;
		foreach($lins as $lin) {
			if($pass == 1) {
				list($nomeFila) = explode(' ', $lin);
				$pass = 2;
			} else if($pass == 2) {
				$pass = 3;
			} else if($pass == 3) {
				$args = explode(' ', trim($lin));
				if(count($args) > 3) {
					list($nomeAg,$d,$stsAg) = explode('(', trim($lin));
					list($stsAg) = explode(')', $stsAg);
					switch($stsAg) {
						case 'Not in use':  $sts =   1; break;
						case 'Busy':        $sts =   3; break;
						case 'paused':      $sts = 100; break;
						case 'Unavailable': $sts = 200; break;
						default:            $sts = "??? $stsAg";
					}
					$estadosAst[$nomeFila][trim($nomeAg)] = $sts;
				} else
					$pass = 4;
			} else if($pass == 4) {
				if(empty($lin)) $pass = 1;
			}
		}
	}
	
	buscaDadosAst();
	var_dump($estadosAst);
	
	$nomeFila = $argv[1];
	
	$memAg = new SharedMem(ID_SHMEM_AGS, 'Agente');
	$ags = $memAg->getObjs();
	
	$memF = new SharedMem(ID_SHMEM_FILAS, 'FilaCC');
	if(empty($nomeFila)) {
		foreach($memF->getObjs() as $fila) {
			mostraAgsFila($fila->id, $fila->nome, $ags);
		}
	} else {
		$fila = $memF->get('nome', $nomeFila);
		mostraAgsFila($fila->id, $nomeFila, $ags);
	}
	echo "\n";
?>