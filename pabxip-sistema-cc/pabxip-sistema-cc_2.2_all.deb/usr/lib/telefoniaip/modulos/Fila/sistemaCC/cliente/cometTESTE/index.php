<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<title>Server push technology with multipart XMLHttpRequest(multipart/x-mixed-replace)</title>
		<style>h1{font-size:14px;font-weight:bold;}</style>
		<script type="text/Javascript">
			var comet = new XMLHttpRequest();
			var ajax  = new XMLHttpRequest();
			
			function handleContent(event) {
				document.getElementById('ThirdProject').innerHTML = event.target.responseText;
				//if(event.target.responseText == '_EOR_')
					//setTimeout("init()", 500);
			}
		
			function init() {
			    comet.multipart = true;
			    comet.open("GET","comet.php", false);
		    	comet.onload = handleContent;
		    	comet.send(null);
			}
			
			function acao() {
			    ajax.open("GET","acao.php?var=123", false);
		    	ajax.send(null);
		    	setTimeout("acao()", 1000);
			}
		</script>
	</head>
	<body>
		<h1>Server push technology with multipart XMLHttpRequest(multipart/x-mixed-replace)</h1>
		
		<hr />
		<div>
			This page is Firefox Only.<br /><br />
			result:<br />
			<span id="ThirdProject" style="color:#FF0000;font-weight:bold"></span>
		</div>
		
		<input type="button" value="Iniciar" onclick="init()" />
		<input type="button" value="Aciona" onclick="acao()" />
	</body>
</html>