<?php
	$ramalOrig   = $argv[1];
	$canalEscuta = $argv[2];
	
	if(empty($ramalOrig) || empty($canalEscuta)) {
		echo "USO: escutaChamada [ramal] [canal para escutar]\n\n";
		return 10;
	}
	
	// Conectar AMI
	$errno = $errstr = null;
	$connAMI = @fsockopen('localhost', 5038, &$errno, &$errstr, 4);
	if(!$connAMI) {
		echo "ERRO:21 MSG:ServidorAsteriskNaoResponde\n";
		return 21;
	} else {
		fputs($connAMI, "Action: login\r\nEvents: off\r\nUsername: admin\r\nSecret: sapo\r\n\r\n");
		do { $r = fgets($connAMI); } while($r != "\r\n");		
	}
	
	echo sendAMICmd("Action: Originate\r\n" .
					"Channel: Local/$ramalOrig@todos\r\n" .
					"Application: ChanSpy\r\n" .
					"Data: SIP/$canalEscuta\r\n" .
					"Async: 1\r\n" .
					"\r\n") . "\n";
	    
	// Fechar conn AMI
	fputs($connAMI, "Action: Logoff\r\n\r\n");
	do { $r = fgets($connAMI); } while($r != "\r\n");
	fclose($connAMI);

// funx aux --------------------------------------------------------	

function sendAMICmd($strAMI) {
	global $connAMI;

	fputs($connAMI, $strAMI);
	$ret = 'Sem Message';
	while(true) {
		$lin = fgets($connAMI);
		if($lin == "\r\n") break;
		if(strstr($lin, 'Message')) $ret = substr($lin,0,-2);
	}
	return $ret;
}
?>