<?php
	include('comandos.php');
	
	session_start();     // Manter a sess�o aberta o m�nimo poss�vel
	$agente = loginOK(); // Verifica se o Agente logado esta na sess�o
	session_write_close();
	
	$hoje = date('d/m/Y');
	
	$linhasHist = buscaHistoricoDia($agente);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
	<head>
		<title>.: Hist�rico de <?echo $hoje;?> :.</title>
		<link rel="Stylesheet" href="css/historico.css" type="text/css" media="screen">
		<script type="text/javascript">
			function tabular(nomeFila, cid, uid, flags) {
				var url = "tabulacao/popup.php?timer=15&idag=<?echo $agente->id?>&num="+cid+"&fila="+nomeFila+"&uid="+uid+"&flags"+flags;
				var popup = window.open(url, 'CRM ' + cid, 'width=400,height=400,top=100,left=100');
				popup.focus();
			}
		</script>
	</head>
	<body>
		<input type="hidden" name="identificador" id="ehHistDia" value="janelaHistDia" />
		<h1><? echo "Hist�rico de $hoje - $agente->nome"; ?></h1>
		<table>
			<thead>
				<td>Hor�rio</td>
				<td>Fila</td>
				<td>N�mero</td>
				<td>Tempo Atd.</td>
				<td>Tabula��o</td>
			</thead>
<?
	if(count($linhasHist) > 0) {
		foreach($linhasHist as $lin) {
			$nomeFila = substr($lin->nomefila, 1, -1);
			$tab = (empty($lin->tab)) ? "<a href=\"javascript:tabular('$nomeFila','$lin->cid','$lin->uid','$lin->flags')\">Tabular</a>" : $lin->tab;
			$cl = ($lin->flags & FLAG_NAO_TABULADO) ? 'linErr' : 'lin1';
?>
			<tr class='<? echo $cl ?>'>
				<td><?echo $lin->hora ?></td>
				<td><?echo $nomeFila ?></td>
				<td><?echo $lin->cid ?></td>
				<td><?echo formataSegundos($lin->tatd)?></td>
				<td><?echo $tab ?></td>
			</tr>
<?		}
	} else { ?>
			<tr class='lin1'><td colspan='4'>Ainda sem atendimentos no dia</td></tr>
<?	} ?>
		</table>
	</body>
</html>
