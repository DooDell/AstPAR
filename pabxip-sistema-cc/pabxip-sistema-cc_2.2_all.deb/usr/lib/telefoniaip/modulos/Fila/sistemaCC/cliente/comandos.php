<?php
	include(''.'/usr/lib/telefoniaip/modulos/Fila/sistemaCC/constantes.php');
	
	function loginOK($sup=false) {
		$agente = $_SESSION['agenteLogado'];
		if(!is_a($agente, 'Agente') || empty($agente->id) || empty($agente->ramal) || empty($agente->telefone) || ($sup && !($agente->funcionalidades & FUNC_SUPERVISOR)))
			header('location:logoff.php');
		return $agente;
	}
	
	function enviaComando($cmd, $tipo=1) {
		$ret = 0;
		$msg_err = null;
		$mq_id = msg_get_queue(ID_MSG_QUEUE);
		if (!msg_send ($mq_id, $tipo, time() . ':' . $cmd, false, false, $msg_err))
			return "Erro [$msg_err] ao enviar comando.";
		if($tipo == 10) {
			list($id,$act,$p1,$p2) = explode(':', $cmd);
			if($act == 'pausaStatusBase')
				$ret = "Pedido de pausa apos ligacao para o agente [$p2] OK";
		}
		return $ret;
	}
	
	function buscaNomeSistema() {
		$conn = new Conexao();
		$ret  = $conn->getStr("SELECT valor FROM parametro WHERE nomeparam = 'nomePABX'");
		$conn->fecha();
		return $ret;
	}
	
	function buscaMotivos() {
		$conn = new Conexao();
		$ret = array();
		$conn->executa('SELECT id,descricao FROM tipostatusagente WHERE id > 100 AND id != 200 AND flags & '.FUNC_DESABILITADO.' = 0 ORDER BY id');
		while($conn->temMaisDados())
			$ret[$conn->data['id']] = $conn->data['descricao'];
		$conn->fecha();
		return $ret;
	}
	
	//**************************************
	// -------------- Agente ---------------
	//**************************************
	function buscaDadosAgente($idAg, $soAgente=false, $tipoSel='id') {
		$ret = array();
		$mem = new SharedMem(ID_SHMEM_AGS, 'Agente');
		$agente = $mem->get($tipoSel, $idAg);
		$mem->shut();
		if(is_a($agente, 'Agente')) {
			$agente->tempostatus = time() - $agente->tempostatus;
			if($soAgente) return $agente;
			$ret['ag'] = $agente;
			$mem = new SharedMem(ID_SHMEM_FILAS, 'FilaCC');
			$filas = $mem->getObjs('id', explode(',', $agente->idsfilas));
			foreach($filas as $fila)
				$ret[$fila->id] = $fila; // TODO otimizr - array_merge()
			$mem->shut();
		}
		return $ret;
	}
	
	function buscaAgentePorLogin($ramal, $senha) {
		$memAg = new SharedMem(ID_SHMEM_AGS, 'Agente');
		$agente = $memAg->get('ramal', $ramal);
		if(is_a($agente, 'Agente') && $agente->senha == $senha)
			return $agente;
		return 'Agente n�o encontrado';
	}
	
	function buscaPAsDisponiveis($idAg) {
		$memAg = new SharedMem(ID_SHMEM_AGS, 'Agente');
		$agente = $memAg->get('id', $idAg);
		
		$telsPAs = array();
		$conn = new Conexao();
		$conn->executa("SELECT chan,descricao FROM pasfila WHERE idfila IN ($agente->idsfilas) ORDER BY descricao");
		while($conn->temMaisDados())
			$telsPAs[$conn->data['chan']] = $conn->data['descricao'];
		$conn->fecha();
		
		// Buscar os telefones atualmente em uso na SHMEM
		if(count($telsPAs) > 0) {
			foreach($memAg->getObjs('telefone', array_keys($telsPAs)) as $agente)
				unset($telsPAs[$agente->telefone]);
		}
		return $telsPAs;
	}
	
	function buscaHistoricoDia($agente) {
		$historico = array();
		
		$hoje = date('Y-m-d');
		$sql = "SELECT DISTINCT ON (cch.id) cch.hora, c.src as cid, cch.campo3 as tatd, cctt.descricao as tab, campo5 as nomefila, c.uniqueid as uid, cct.flags " .
				"FROM cc_historico cch " .
				"JOIN cdr c ON cch.campo4 = c.uniqueid " .
				"LEFT JOIN cc_tabulacao cct ON cch.campo4 = cct.uniqueid " .
				"LEFT JOIN cc_tipotabulacao cctt ON cct.idtipo = cctt.id " .
				"WHERE " .
				"cch.tipoevento = 17 AND " .
				"cch.campo1 = '$agente->ramal' AND " .
				"cch.data = '$hoje' " .
				"ORDER BY cch.id, cch.hora";
		$conn = new Conexao();
		$conn->executa($sql);
		while($conn->temMaisDados())
			$historico[] = (object)$conn->data;
		$conn->fecha();
		
		return $historico;
	}
	
	function buscaURL($nomeURL) {
		$conn = new Conexao();
		$ret = $conn->getStr("SELECT valor FROM parametro WHERE nomeparam = 'url$nomeURL'");
		$conn->fecha();
		return $ret;
	}
	
	function buscaDadosFila($agente) {
		$ret = array();
		if(is_a($agente, 'Agente')) {
			$memFila = new SharedMem(ID_SHMEM_FILAS, 'FilaCC');
			foreach($memFila->getObjs('id', explode(',', $agente->idsfilas)) as $fila)
				$ret[$fila->name] = (object)array('urlpopup' => $fila->urlpopup, 'urlpopupfim' => $fila->urlpopupfim, 'tipopiloto' => $fila->tipopiloto);
		}
		return $ret;
	}
	
	//**************************************
	// ------------ Supervisor ------------
	//**************************************
	function buscaDadosJanelaSup($supervisor) {
		$ret = array();
		$ret['nomeSistema']  = buscaNomeSistema();
		$ret['nomesFilas']   = buscaNomesFilas($supervisor);
		$ret['nomesMotivos'] = buscaMotivos();
		return $ret;
	}
	
	function buscaNomesFilas($supervisor) {
		$ret = array();
		$idsFilas = explode(',', $supervisor->idsfilas);
		if(!count($idsFilas)) return $ret;
		
		$memFila = new SharedMem(ID_SHMEM_FILAS, 'FilaCC');
		foreach($memFila->getObjs() as $fila) {
			if(in_array($fila->id, $idsFilas))
				$ret[$fila->id] = $fila->name;
		}
		return $ret;
	}
	
	/**
	 * Fun��o auxiliar para ordenar os agentes por codstatus,tempostatus
	 * Utilizada pelo uasort da fun��o buscaDadosSup abaixo
	 */
	function comparaAgentes($ag1, $ag2) {
	    if ($ag1->codstatus == $ag2->codstatus) {
	        if($ag1->tempostatus == $ag2->tempostatus) return 0;
	        return ($ag1->tempostatus > $ag2->tempostatus) ? -1 : 1;
	    }
	    return ($ag1->codstatus < $ag2->codstatus) ? -1 : 1;
	}
	/**
	 * Fun��o chamada no cometSupervisor
	 * Envia os dados dos agentes, filas e totais para a janela de supervis�o
	 */
	function buscaDadosSup($sup) {
		$idFilaSel = ($sup->idfilasel > 0) ? $sup->idfilasel : explode(',', $sup->idsfilas);
		if(strstr($idFilaSel, ',')) $idFilaSel = explode(',', $idFilaSel);

		$mem = new SharedMem(ID_SHMEM_AGS, 'Agente');
		$agentes = $mem->getObjs('idsfilas', $idFilaSel, 'incsv');
		$mem->shut();
		uasort($agentes, 'comparaAgentes');

		$mem = new SharedMem(ID_SHMEM_FILAS, 'FilaCC');
		$filas = $mem->getObjs('id', $idFilaSel);
		$mem->shut();
														
		return array_merge($agentes, $filas, array(new Totais($agentes)));
	}
	
	//**************************************
	// ------------- Tabula��o -------------
	//**************************************
	function buscaItensTabulacao($nomeFila) {
		$conn = new Conexao();
		$conn->executa("SELECT id,flags FROM fila WHERE LOWER(name) = '".strtolower($nomeFila)."'");
		if(!$conn->temMaisDados() || empty($conn->data['id']))
			return false;
			
		$idFila = $conn->data['id'];
		$itens  = array('ID_FILA' => $idFila, 'PAUSA_AUTO' => ($conn->data['flags'] & FLAG_FILA_PAUSA_AUTO));
		
		$conn->executa("SELECT id,descricao FROM cc_tipotabulacao WHERE idfila = '$idFila' AND (flag & 1) != 1 ORDER BY ordem");
		while($conn->temMaisDados())
			$itens[$conn->data['id']] = $conn->data['descricao'];
		$conn->fecha();
		return $itens;
	}
	
	function insereTabulacao($idFila, $idag, $uniqueid, $item, $pausaAutomatica, $ehAtz) {
		// Insere o dado da tabula��o
		$conn = new Conexao();
		if($ehAtz) {
			$conn->executa("UPDATE cc_tabulacao SET idtipo = '$item' WHERE uniqueid = '$uniqueid'");
		} else {
			$flags = ($item != '0') ? FLAG_NAO_TABULADO : 0; // Flag de n�o tabulado
			$conn->executa("INSERT INTO cc_tabulacao(uniqueid, idtipo, idfila, flags) VALUES('$uniqueid', '$item', '$idFila', $flags)");
		}
		if($pausaAutomatica) {
			// Despausa o Agente, somente se a fila estiver configurada para pausa automatica
			enviaComando("$idag:mudaStatus:TABULACAO");
		}
		$conn->fecha();
	}
	
	// Utils
	function formataSegundos($segundos) {
		$minutos = floor($segundos / 60);
		if($minutos > 0) {
			$segundos -= ($minutos * 60);
			if($segundos < 10) $segundos = "0$segundos";
			$horas = floor($minutos / 60);
			if($horas > 0) {
				$minutos -= ($horas * 60);
				if($minutos < 10) $minutos = "0$minutos";
				return "$horas:$minutos:$segundos";
			} else {
				if($minutos < 10) $minutos = "0$minutos";
				return "$minutos:$segundos";
			}
		} else {
			return ($segundos < 10) ? "00:0$segundos" : "00:$segundos";
		}
	}
?>