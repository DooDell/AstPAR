<?php
	include('../constantes.php');
	
	$idAg = (isset($argv[1]) && is_numeric($argv[1])) ? $argv[1] : 0;
	
	$mem = new SharedMem(ID_SHMEM_AGS, 'Agente');
	$agentes = $idAg > 0 ? $mem->getObjs('id', $idAg) : $mem->getObjs();
	$mem->shut();
	
	foreach($agentes as $ag)
		print_r($ag);
	
	if($idAg == 0) {
		$mem = new SharedMem(ID_SHMEM_FILAS, 'FilaCC');
		$filas = $mem->getObjs();
		$mem->shut();
		
		foreach($filas as $fila)
			print_r($fila);
	}
?>