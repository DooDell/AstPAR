<?php
   	// Configuracao
	$porta = 13633;			// Porta TCP para utilizar:
	$ipsOK = '10.0.4.';		// Prefixo de IPs credenciados para acesso
	// ------------
	
	$dirPipe = '/var/lib/asterisk/pipeMarili/';
	
	// Script ------------------------------------------------------------------
	echo "Abrindo porta $porta.\n";
	if(($sock = @socket_create(AF_INET, SOCK_STREAM, SOL_TCP)) === false) {
		$errNo = socket_last_error();
		echo "Erro1[$errNo] ao criar socket " .socket_strerror($errNo). "\n";
		return 1;
	}
	socket_set_option($sock, SOL_SOCKET, SO_REUSEADDR, 1);
	if(@socket_bind($sock, 0, $porta) === false) {
		$errNo = socket_last_error();
		echo "Erro2[$errNo] ao criar socket " .socket_strerror($errNo). "\n";
		return 2;
	}
	if(@socket_listen($sock) === false) {
		$errNo = socket_last_error();
		echo "Erro3[$errNo] ao criar socket " .socket_strerror($errNo). "\n";
		return 3;
	}

    $socketAgente  = array($sock);
    $sockAgPorTel  = array();
    $telAgPorRamal = array();
    
    $msgIdle = true;
    while (true) {
    	if($msgIdle) {
			echo "Aguardando comandos ou eventos: ";
			$msgIdle = false;
		}
			
    	// Verifica se ha algum evento do asterisk
		if(is_dir($dirPipe)) {
		    if($dh = opendir($dirPipe)) {
		        while(($file = readdir($dh)) !== false) {
		        	$cmdAst = file_get_contents($dir.$file);
		        	unlink($dir.$file);	// Remover o arquivo
		        	
		        	echo "Evento/Comando asterisk recebido: [$cmdAst]: ";
		        	$msgIdle = true;
		        	
		        	$params = explode(':', $cmdAst);
		        	$cmd = array_shift($params);
		        	$sockOut = $telAg = $msg = '';
		        	switch($cmd) {
		        		case 'E':
		        			$nomeEvento = $params[0];
		        			$msg = "Ev:$nomeEvento ";
		        			switch($nomeEvento) {
		        				case 'AgentCalled':
		        					$telAg     = $params[1];
		        					$idCliente = $params[2];
		        					$cid       = $params[3];
		        					$sockOut   = "C$idCliente;$cid#";
		        					$msg .= "Chamada do cliente '$idCliente' <$cid> para o ag na PA {$telAg}";
		        					break;
		        			}
		        			break;
		        		default: $msg = 'Comando invalido';
		        	}
		            
		        	if(!empty($sockOut)) { 
		        		if(isset($sockAgPorTel[$telAg]))
		        			socket_send($sockAgPorTel[$telAg], $sockOut, strlen($sockOut), 0);
		        		else
		        			$msg .= " - PA [$telAg] invalida(semSocket) ";
		        	}
		        	
		        	if(!empty($msg)) echo "$msg\n";
		        }
		        closedir($dh);
		    }
		}
		
        // Cria uma copia, para o socket_select nao modificar o $socketAgente
        $read = $socketAgente;
        $ssRes = socket_select($read, $write = NULL, $except = NULL, 0, 150000);
        if($ssRes === false)
        	echo "Falha em socket_select(): " . socket_strerror(socket_last_error()) . "\n";
        else if($ssRes > 0) {
	        // Verificar se ha uma nova conexao
	        if(in_array($sock, $read)) {
	            $newsock = socket_accept($sock);
	            socket_getpeername($newsock, $ip);
	            if(substr($ip, 0, strlen($ipsOK)) == $ipsOK) {
	            	echo "IP <$ip> conectado.\n";
	                $socketAgente[] = $newsock;
	                $msgIdle = true;
	            } else {
	            	echo "Conexao de IP <$ip> nao autorizado. Desconectando-o.\n";
					socket_write($newsock, "Voce nao esta autorizado a acessar este servidor\n\n");
					socket_close($newsock);
					$msgIdle = true;
	            }
	            // Ja tratamos o $sock, remover do array de sockets ativos
	            $key = array_search($sock, $read);
	            unset($read[$key]);
	        }
	       
	        // loop pelos sockets clientes que tem dados
	        foreach ($read as $read_sock) {
	        	socket_getpeername($read_sock, $ip);
	        	
	        	// Le no maximo 64 bytes
	            $data = @socket_read($read_sock, 64, PHP_NORMAL_READ);
	            if ($data === false) {
	                // Cliente desconectou. Remover da lista de sockets
	                $key = array_search($read_sock, $socketAgente);
	                unset($socketAgente[$key]);
	                echo "Client <$ip> desconectou.\n";
	                $msgIdle = true;
	                continue;
	            }
	           
	            $data = trim($data);
	            if(trataComando($data, $read_sock, $ip)) {
	            	// Cliente enviou QUIT. Desconecta-lo e remove-lo da lista de sockets
	            	$key = array_search($read_sock, $socketAgente);
	                unset($socketAgente[$key]);
					echo "IP <$ip> cancelou (QUIT).\n";
					socket_close($read_sock);
					$msgIdle = true;
					continue;
				}
				$msgIdle = !empty($data);
	        }
        }
    }
    socket_close($sock);
    return 0;

    // =========================
	function trataComando($data, $clisock, $ip) {
		global $sockAgPorTel, $telAgPorRamal;
		
		// Tratar o comando recebido
		if(!empty($data)) {
			if(substr($data, -1) != '#') {
				echo "Comando de <$ip> [$data] invalido (deve terminar com '#')\n";
			} else {
				$data = substr($data, 0, -1); // Remover o '#' do final
				
				echo "Comando recebido de <$ip>: [$data]\n";
				if($data == 'QUIT') return true;
				
				if(substr($data, 0, 5) == 'LOGON') {
					$ramal = substr($data, 5);
					if(strstr($ramal, ';')) list($ramal, $tel) = explode(';', $ramal);
					else $tel = $ramal;
					
					$tel = "SIP/$tel";
					$msg = "Logar <$ramal> em $tel";
					$cmd = "login:$tel";
					
					// Salvar o agente em um array indexado por PA e cria tabela de conversao ramal X PA
					$sockAgPorTel[$tel] = $clisock;
					$telAgPorRamal[$ramal] = $tel;
					
				} else if(substr($data, 0, 6) == 'LOGOFF') {
					$ramal = substr($data, 6);
					$msg = "DesLogar <$ramal>";
					$cmd = "logoff";
					
					// Remover o agente do array indexado por ramal/PA
					$tel = $telAgPorRamal[$ramal];
					unset($sockAgPorTel[$tel]);
					unset($telAgPorRamal[$ramal]);
					
				} else if(substr($data, 0, 6) == 'SUSPON') {
					$ramal = substr($data, 6);
					if(strstr($ramal, ';')) list($ramal, $cod) = explode(';', $ramal);
					else $cod = 100;
					$msg = "Pausar <$ramal> - TipoPausa($cod)";
					$cmd = "mudaStatus:$cod";
				} else if(substr($data, 0, 7) == 'SUSPOFF') {
					$ramal = substr($data, 7);
					$msg = "DesPausar <$ramal>";
					$cmd = "mudaStatus:1";
				} else if(substr($data, 0, 5) == 'DISCA') {
					$ramal = substr($data, 5);
					if(strstr($ramal, ';')) {
						list($ramal, $tel, $num) = explode(';', $ramal);
						if(!isset($num) || empty($num))
							$msg = "Comando DISCA invalido (nao veio o tel/numero)";
						else {
							$tel = "SIP/$tel";
							$msg = "Agente <$ramal:$tel> discando para $num";
							$cmd = "disca:$num";
						}
					} else
						$msg = "Comando DISCA invalido (nao veio o tel/numero)";
				} else if(substr($data, 0, 4) == 'PING') {
					$msg = 'PONG!';
					socket_write($clisock, "PONG!\n");
				} else {
					$msg = "Comando [$data] desconhecido"; // MSG padrao
					$cmd = '';
				}
				
				echo ">>> $msg\n";
				if(!empty($cmd)) {
					if($ramal < 1000) echo "Ramal [$ramal] invalido.\n";
					else              enviaComando($ramal, $cmd);
				}
			}
		}
		return false;
	}
	
	function refreshCodUsu() {
		global $usuarios;
		
		$bdcon = pg_connect(getAstPgStrConn());
		if(pg_connection_status($bdcon) != PGSQL_CONNECTION_OK) return false;
		
		$res = pg_query($bdcon, 'SELECT id,ramal FROM usuario');
		while($registro = pg_fetch_assoc($res))
			$usuarios[$registro['ramal']] = $registro['id'];
		pg_close($bdcon);
	}
	
	function buscaIdPorRamal($ramal) {
		global $usuarios;
		if(!isset($usuarios[$ramal])) {
			refreshCodUsu();
			if(!isset($usuarios[$ramal])) {
				echo "EE: Usuario ramal $ramal nao encontrado!\n";
				return false;
			}
		}
		return $usuarios[$ramal];
	}
	
	function enviaComando($ramal, $cmd) {
		if(($idUsu = buscaIdPorRamal($ramal)) === false)
			return false;
		$mq_id = msg_get_queue(0xf0f0);
		$msg = time().":$idUsu:$cmd";
		echo("+++ Enviando comando ao controleCC: [$msg]\n");
		if(msg_send ($mq_id, 1, $msg, false, false, $msg_err='') === false) {
			$mq_id = msg_get_queue(ID_MSG_QUEUE);	// Init da fila de mensagens
			return msg_send ($mq_id, 100, $msg, false, false, $msg_err='');
		}
		return true;
	}
	
	function getAstPgStrConn() {
		$atrsOK = array('dbname' => 'dbname', 'dbhost' => 'host', 'dbuser' => 'user', 'dbpass' => 'password');
		$ret = '';
		$lins = file('/etc/asterisk/res_pgsql.conf', FILE_IGNORE_NEW_LINES);
		if($lins) {
			foreach($lins as $lin) {
				if(strstr($lin, '=')) {
					list($ch, $val) = explode('=', $lin);
					$ch  = trim($ch);
					$val = trim($val);
					if(in_array($ch, array_keys($atrsOK))) {
						$atr = $atrsOK[$ch];
						$ret .= "$atr=$val ";
					}
				}
			}
		}
		return trim($ret);
	}
?>