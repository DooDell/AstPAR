<?php
class ShMemObj {
	public $IDSHMEM, $POSICAOSHMEM, $MEMPOROBJ;
	
	function ShMemObj($shm_id, $pos, $memPorObj) {
		$this->IDSHMEM      = $shm_id;
		$this->POSICAOSHMEM = $pos;
		$this->MEMPOROBJ    = $memPorObj;
	}
	
	function atualizaShMem($idMem=null) {
		if($idMem==null) $idMem=$this->IDSHMEM;
		$str = serialize($this);
		$tam = strlen($str);
		if($tam > $this->MEMPOROBJ)
			return "Objeto serializado maior que MEMPOROBJ($this->MEMPOROBJ). Considere aumentar esta constante.";
		// Como vai gravado na SHMEM:
		// Bytes 0-4 = Tamanho da string serializada deste Objeto
		// Bytes 5-9 = ID do Objeto (para �ndice)
		// Bytes 10-MEM_POR_OBJ = Objeto serializado
		if(shmop_write($idMem, (str_pad($tam, 5) . str_pad($this->id, 5) . $str), $this->POSICAOSHMEM * $this->MEMPOROBJ) != $tam+10) {
			$class = get_class($this);
			return "Impossivel escrever dados de $class '$this->id' na SHMEM";
		}
		return true;
	}
	
	function setAtrsDoArray($array) {
		if(is_array($array)) {
			reset($array);
			while(key($array) !== null) {
				$key = key($array);
				$this->$key = current($array);
				next($array);
			}
			return $this->atualizaShMem();
		}
	}
	
	function __toString() {
		$ret = get_class($this) . '{';
		foreach(get_object_vars($this) as $c => $v)
			$ret .= "$c=$v|";
		return $ret;
	}
}
?>