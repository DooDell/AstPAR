<?php
	define('ID_MSG_QUEUE',   0xf0f0);
	
	if(($mq_id = msg_get_queue(ID_MSG_QUEUE))) {
		// Verificar o tipo da mensagem baseado na URL de origem
		// Se estamos vindo de uma pagina que contenha 'agente'     no nome o comando enviado ser� do tipo 1
		// Se estamos vindo de uma pagina que contenha 'supervisor' no nome o comando enviado ser� do tipo 10
		// caso contrario enviamos comandos do tipo 0 (que provavelmente ser� ignorado pelo controle e dada uma msg de erro)
		$tipo = stristr($_SERVER['HTTP_REFERER'], 'agente') ? 1 : 10;
		
		// Tenta enviar o comando
		echo (msg_send($mq_id, $tipo, time() . ':' . $_REQUEST['Comando'], false, false, $msg_err)) ? '1' : '10';
	} else
		echo '20';
	
	// Devolve os seguintes c�digos para o cliente
	//  1 - Comandos OK
	// 10 - Erro ao enviar comando (msg_send)
	// 20 - Erro ao enviar comando (msg_get_queue)
?>