<?
	session_name('popupExemplo');
	include(''.'/usr/lib/telefoniaip/modulos/Fila/sistemaCC/cliente/comandos.php');
	
	// URL: exemploChanVars.php?num=%NUM%&name=%NAME%&idag=%IDAG%&fila=%FILA%&%CHANVARS%
	
	$excecoes = array('PHPSESSID', 'Cacti');
?>
<html>
	<head>
		<title>.: Exemplo de popup inicial :.</title>
		<script>
			self.resizeTo(600, 550);
		</script>
	</head>
	<body>
		<h1>.: Variaveis Recebidas :.</h1>
<?
	foreach($_REQUEST as $nome => $valor) {
		if(!in_array($nome, $excecoes))
			echo "<h2>$nome: <b>$valor</b></h2>\n";
	}
?>
	</body>
</html>
