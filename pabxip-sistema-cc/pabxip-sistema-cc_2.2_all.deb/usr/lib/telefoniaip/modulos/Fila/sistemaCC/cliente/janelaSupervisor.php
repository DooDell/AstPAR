<?
	include('comandos.php');
	
	session_start(); // Manter a sess�o aberta o m�nimo poss�vel
	$supervisor = loginOK(true);
	session_write_close();
	
	$dadosJanela = buscaDadosJanelaSup($supervisor);
	$totFilas = count($dadosJanela['nomesFilas']);
	
	if($totFilas == 0) {
		header("Location: logoff.php?msg=Supervisor logado n�o est� em nenhuma fila");
		die;
	} else if($totFilas > 1) {
		$comboFilas = "<select name='fila' onchange='OCcomboFilas(this)'>\n<option value='-1'>Todas</option>\n";
		foreach($dadosJanela['nomesFilas'] as $idFila => $nomeFila) {
			$sel = ($idFila == $supervisor->idfilasel) ? " selected='true'" : '';
			$comboFilas .= "<option value='$idFila'$sel>$nomeFila</option>\n";
		}
		$comboFilas .= "</select>\n";
		$idFilaSel = null;
	} else {
		// foreach esquisito para pegar chave => valor da primeira posicao 
		foreach($dadosJanela['nomesFilas'] as $idFilaSel => $nomeFila)
			break;
		$comboFilas = "<b>$nomeFila</b>";
	}
	
	// Popup da janelaAgente:
	$temJA = false;
	if($temJA) {
		$tdJA = '<td><input type="button" name="entrarAg" value="Entrar como Agente" onclick="entraAg()" ></td>';
		$totfilas = count(explode(',', $supervisor->idsfilas)); 
		$tamJA = 328 + ($totfilas * 21);
		$ocJA = "function entraAg() {
				popup = window.open('janelaAgente.php', 'Agente $supervisor->nome', 'width=582,height=$tamJA,scrolling=auto,top=100,left=100,scrollbar=no,resizable=no,minimize=no,maximize=no');
				if(window.focus) popup.focus();
			}
";
	} else {
		$ocJA = $tdJA = '';
	}
	
	// Modo Painel
	$modoPainel = ($supervisor->ramal == 5989 || $supervisor->ramal == 5991 || $supervisor->ramal == 5992 || $supervisor->ramal == 5993);
	$msgPainel  = $modoPainel ? '<center><font face="Arial"><h2>DISPONIBILIDADE DA EQUIPE</h2></font></center>' : '';
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html>
	<head>
		<title>.: <?echo $dadosJanela['nomeSistema']?> : Supervis�o :.</title>
		<link rel="Stylesheet" href="css/supervisor.css" type="text/css" media="screen">
		<script type="text/javascript" src="javascript/Usuario.js"></script>
		<script type="text/javascript" src="javascript/Fila.js"></script>
		<script type="text/javascript" src="javascript/Total.js"></script>
		<script type="text/javascript" src="javascript/popupmenu.js"></script>
	</head>
	<body>
		<div id="divJanelaSupervisor">	
			<form name="dados">
				<div id="divCabecalho">		
					<div id="divLogo"></div>	
					<table>
						<tr>
							<td>Supervisor Logado:<br><? echo $supervisor->nome ?></td>
							<td>Ramal Monitor: <input type="text" name="ramalMonitor" value="<? echo $supervisor->ramal ?>" size="4"></td>
							<td>Mostra Fila: <? echo $comboFilas ?></td>
							<? echo $tdJA ?>
							<td id='ultAtz'>&nbsp;</td>
							<td><input type="button" name="sair" value="Sair" onclick="saida()" ></td>
						</tr>	
					</table>
				</div>
				<div id="divConteudo">
					<table id="tabelaTotais"></table><br>
							
					<table class='fila'>
						<tr>
							<td>Filas:</td>										
							<td class="dir">Mostrar filas sem agentes? <input type="checkbox" name="mostraFilaVazia" checked="true" onchange="atualizaTabelaFilas()"></td>
						</tr>
					</table>		
					<table id="tabelaFilas"></table><br>
					<? echo $msgPainel ?>
					<table class='agente' >
						<tr>
							<td>Agentes:</td>
							<td class="dir">
								Separar Dispon�veis? <input type="checkbox" name="separaDisp" checked="true" onchange="atualizaTabelaAgentes()"> 
								Mostrar agentes deslogados? <input type="checkbox" name="mostraDeslog" onchange="atualizaTabelaAgentes()">
							</td>
						</tr>
					</table>			
					<table id="tabelaAgentes"></table>
					
				</div>	<!--Fim Conte�do-->					
				<div id="divRodape"></div>		
				</form>
			<div id="debug"></div>
		</div>	<!-- Fim divJanelaSupervisor	-->
		<script type="text/javascript">
			// Estados <
			DESLOGADO  = <? echo DESLOGADO  ?>;
			DISPONIVEL = <? echo DISPONIVEL ?>;
			CHAMANDO   = <? echo CHAMANDO   ?>;
			ATENDENDO  = <? echo ATENDENDO  ?>;
			SAINTE     = <? echo SAINTE     ?>;
			DISCANDO   = <? echo DISCANDO   ?>;
			ENTRANTE   = <? echo ENTRANTE   ?>;
			SUPLOGADO  = <? echo SUPLOGADO  ?>;
			PAUSA      = <? echo PAUSA      ?>;
			INDISP     = <? echo INDISP     ?>;
			
			// Tempo entre os KeepAlives, em ms
			TOKA = 40000;
			
			// AJAX
			var ajax   = new XMLHttpRequest();
			var ajaxKA = new XMLHttpRequest();
			// Comet
			var comet = null;
			
			var usuarios = new Array();
			var filas    = new Array();
			var totais   = new Total();
			
			var colunasTot = {
					'total':        'Total',
					'logado':       'Logados',
					'supervisor':   'Sup Logado',
					'disponivel':   'Dispon�veis',
					'atendendo':    'Em Atendimento',
					'sainte':       'Sainte',
					'entrante':     'Entrante Direta',
					'pausa':        'Em Pausa',
					'indisponivel': 'Indispon�veis',
					'deslogado':    'Deslogados'
				};

			var ordemAgs   = 'tempostatus';
			var corLinhaAg = 0;
			
<? if($modoPainel) { ?>
			var colunasAg  = { "0":    '&nbsp;', // Nomes das colunas da tabela de agentes
			            "codstatus":   'Estado',
			            "nome":        'Nome',
			            "ramal":       'Ramal',
			            "tempostatus": 'Tempo'
				 };
			colunasAgLength = 5; // Para colspan
<? } else { ?>
			var colunasAg  = { "0":    '&nbsp;', // Nomes das colunas da tabela de agentes
			            "codstatus":   'Estado',
			            "nome":        'Nome',
			            "ramal":       'Ramal',
			            "numentra":    'Telefone',
			            "tempostatus": 'Tempo',
				        "efetuadas":   'Eft',
				        "recebidas":   'Rec',
			            "tta":         'TTA',
			            "tma":         'TMA',
			            "1":           'A��es'
				 };
			colunasAgLength = 11; // Para colspan
<? } ?>

			var colunasFilas = new Array('Nome', 'Agentes', 'Fila', 'Atendidas', 'Abandonadas', 'N�v.Servi�o', 'T. 1o', 'TME', 'TMA');
			
			// Nomes das pausas e indisponibilidades
			var pausas   = new Array();
			var indisp   = new Array();
			pausas[100] = 'Supervis�o';
			pausas[199] = 'Autom�tica';
			indisp[200] = 'Nao Atendimento';
<?	foreach($dadosJanela['nomesMotivos'] as $idMot => $nomeMot) echo '			' . (($idMot < 200) ? 'pausas' : 'indisp') . "[$idMot] = '$nomeMot';\n"; ?>
	
			/**
			 * Fun��o chamada ao completar a requisi��o Comet
			 * Interpreta os dados de retorno, colocando os dados nos arrays 'usuario', 'filas' e 'totais' 
			 */
			function parseDados(dados) {
				if(dados == '_EOR_') return; // String enviada ao final de cada requisi��o (45s). Ignora-la
				
				usuarios = new Array();
				filas    = new Array();
				
				linhas = dados.split("\n");
				for(l=0; l<linhas.length; l++) {
					tipoLin = linhas[l].split('{');
					if(tipoLin[0] == "Agente") {
						aux = new Usuario();
						aux.parseLin(tipoLin[1]);
						usuarios[aux.id] = aux;
					} else if(tipoLin[0] == "FilaCC") {
						fila = new Fila();
						fila.parseLin(tipoLin[1]);
						filas[fila.id] = fila;
					} else if(tipoLin[0] == "Totais") {
						totais = new Total();
						totais.parseLin(tipoLin[1]);
					}
				}
				atualizaTela();
			}
			
			/**
			 * Atualiza a tela conforme os dados do Usu�rio
			 */
			function atualizaTela() {
				atualizaTabelaFilas();
				atualizaTabelaAgentes();
				document.getElementById('ultAtz').innerHTML = '�ltima Atz: ' + totais.agora;
			}
			
			function atualizaTabelaFilas() {
				// Declarar aqui para ficar em escopo local
				var thead, th, col, corLinFila, f, totaglog, totag, novaLinha, classeAlerta, tma, fila;
				var novaTabela = document.createElement('table');
				
				novaTabela.setAttribute("cellspacing", "0");
				novaTabela.setAttribute("align", "center");
				novaTabela.setAttribute("width", "100%");
				novaTabela.setAttribute("class", "tabelaFila");
				novaTabela.setAttribute("id", "tabelaFilas");
				tHead = document.createElement('thead');
				for(th in colunasFilas) {
					col = document.createElement('td');							
					col.innerHTML = colunasFilas[th];					
					if(th == colunasFilas.length - 1)
						col.setAttribute("class","ultimo");
					tHead.appendChild(col);
				}
				
				novaTabela.appendChild(tHead);
				
				filaSel = <? echo $idFilaSel==null ? 'document.dados.fila.value' : $idFilaSel; ?>;
				
				corLinFila = 0;
				for(f in filas) {
					fila = filas[f];
					//if(filaSel != -1 && fila.id != filaSel)
					//	continue;
					
					totaglog = (fila.totaglog) ? fila.totaglog : 0;
					if(totaglog > 0 || document.dados.mostraFilaVazia.checked) { // <
						novaLinha = document.createElement('tr');
						novaLinha.setAttribute("class", "linha" + corLinFila);
						corLinFila = 1 - corLinFila;
						for(th in colunasFilas) {
							col = document.createElement('td');
							switch(colunasFilas[th]) {
								case 'Nome':
									col.innerHTML = "<b>" + filas[f].nome + "</b> - " + filas[f].ramal;	//<
									break;
								case 'Agentes':
									totag = (filas[f].totag) ? filas[f].totag : 0;
									col.innerHTML = "<b>" + totaglog + "</b> / " + totag;	//<
									break;
								case 'Fila':
									classeAlerta = '';
									if(filas[f].qtdchamespera      > 10) classeAlerta = 'tdAlerta3';//<
									else if(filas[f].qtdchamespera >  6) classeAlerta = 'tdAlerta2';//<
									else if(filas[f].qtdchamespera >  3) classeAlerta = 'tdAlerta1';//<
									else if(filas[f].qtdchamespera >  0) classeAlerta = 'tdAlerta0';//<
									if(classeAlerta != '')
										col.setAttribute("class", classeAlerta);
									col.innerHTML = filas[f].qtdchamespera;
									break;
								case 'Atendidas':   col.innerHTML = filas[f].qtdchamatendida;  break;
								case 'Abandonadas': col.innerHTML = filas[f].qtdchamaband;     break;
								case 'N�v.Servi�o': col.innerHTML = filas[f].servicelevel + "% / " + filas[f].tempons + " s";  break;
								case 'T. 1o':       col.innerHTML = filas[f].tempoespera;      break;
								case 'TME':         col.innerHTML = filas[f].tempomedioespera; break;
								case 'TMA':
									tma = (filas[f].tempototalatend != '' && filas[f].qtdchamatendida > 0) ? formataSegundos(filas[f].tempototalatend / filas[f].qtdchamatendida) : '0:00';	//<
									col.innerHTML = tma;
									break;
							}
							novaLinha.appendChild(col);
						}
						novaTabela.appendChild(novaLinha);
					}
				}
				
				tabela = document.getElementById('tabelaFilas');
				tabela.parentNode.replaceChild(novaTabela, tabela);				
			}
			
			function getLinhaAg(usr) {
				var col, aux, tel, estado, th;
				var novaLinha = document.createElement('tr');
				
				if(usr == -1) {
					// Linha separadora
					novaLinha.setAttribute("class", "linhaZero");
					
					col = document.createElement('td');
					col.setAttribute("colspan", 11);
					col.innerHTML = "&nbsp;";
					novaLinha.appendChild(col);
				} else {
					corLinhaAg = 1 - corLinhaAg;
					novaLinha.setAttribute("class", "linhaAg" + corLinhaAg);
					
					tel = '';
					if(usuarios[usr].telefone != '') {
						aux = usuarios[usr].telefone.split("/");
						aux = aux[1];
						tel = (aux != usuarios[usr].ramal) ? " - " + aux : '';
					}
					estado = getClassEstado(usuarios[usr]);
					for(th in colunasAg) {
						col = document.createElement('td');
						switch(colunasAg[th]) {
							case '&nbsp;':
								col.setAttribute("width", "1px");
								col.innerHTML = "<img src='gfx/status/status_" + estado + ".png'>";	//<
								break;
							case 'Estado':
								col.setAttribute("class", estado);
								col.setAttribute("align", "center");
								col.innerHTML = "<b>" + getNomeEstado(usuarios[usr]) + "</b>"; // <
								break;
							case 'Nome':  col.innerHTML = usuarios[usr].nome;  break;
							case 'Ramal': col.innerHTML = usuarios[usr].ramal + tel; break;
							case 'Telefone':
								if(usuarios[usr].codstatus == ATENDENDO)   col.innerHTML = usuarios[usr].numentra + ((usuarios[usr].filaatual != '') ? ' - ' + usuarios[usr].filaatual : '');
								else if(usuarios[usr].codstatus == SAINTE) col.innerHTML = usuarios[usr].numsai;
								break;
							case 'Tempo': col.innerHTML = formataSegundos(usuarios[usr].tempostatus); break;
							case 'Eft':   col.innerHTML = usuarios[usr].efetuadas;                    break;
							case 'Rec':   col.innerHTML = usuarios[usr].recebidas;                    break;
							case 'TTA':   col.innerHTML = formataSegundos(usuarios[usr].tta);         break;
							case 'TMA':   col.innerHTML = formataSegundos(usuarios[usr].tma);         break;
							case 'A��es':
								col.setAttribute("align", "center");
								col.innerHTML = imagensAcoes(usuarios[usr]);
								break;
						}
						novaLinha.appendChild(col);
					}
				}
				return novaLinha;
			}
			
			function atualizaTabelaAgentes() {
				var tHead, th, col, filaSel, listaAgs, idsNaOrdem, aux, usr, tahNaFila, filasUsr, cnt, tabela, tabelaTotais, linha, val;
				var novaTabela = document.createElement('table');
				
				novaTabela.setAttribute("align", "center");
				novaTabela.setAttribute("width", "100%");
				novaTabela.setAttribute("class", "tabelaAgs");
				novaTabela.setAttribute("id", "tabelaAgentes");
				tHead = document.createElement('thead');
				for(th in colunasAg) {
					col = document.createElement('td');
					col.innerHTML = (th != ordemAgs && isNaN(th)) ? "<a href='javascript:ordenaAgs(\""+th+"\")'>" + colunasAg[th] + "</a>" : colunasAg[th]; // <
					tHead.appendChild(col);
				}
				novaTabela.appendChild(tHead);
				
				filaSel = <? echo $idFilaSel==null ? 'document.dados.fila.value' : $idFilaSel; ?>;
				
				listaAgs = new Array();
				idsNaOrdem = getIdsOrdem(usuarios, ordemAgs);
				for(aux in idsNaOrdem) {
					usr = idsNaOrdem[aux];
					if(usuarios[usr].codstatus != 10 && (document.dados.mostraDeslog.checked || usuarios[usr].codstatus > 0)) {	//<
						listaAgs[listaAgs.length] = usr;
					}
				}
				
				if(listaAgs.length > 0) { // <
					if(document.dados.separaDisp.checked) {
						// Separar a lista: primeiro os disponiveis, depois os outros
						var lAux = new Array();
						for(aux in listaAgs) {
							usr = listaAgs[aux];
							if(usuarios[usr].codstatus == 1) lAux[lAux.length] = usr;
						}
						if((lAux.length > 1 || (lAux.length == 1 && listaAgs.length > 1)) && lAux.length != listaAgs.length) lAux[lAux.length] = -1; // Linha separadora <
						for(aux in listaAgs) {
							usr = listaAgs[aux];
							if(usuarios[usr].codstatus != 1) lAux[lAux.length] = usr;
						}
						listaAgs = lAux;
					}
					
					listaAgs[listaAgs.length] = -1; // Linha final
					corLinhaAg = 0;
					for(aux in listaAgs) {
						usr = listaAgs[aux];
						novaTabela.appendChild(getLinhaAg(usr));
					}
				} else {
					var novaLinha = document.createElement('tr');
					novaLinha.setAttribute("class", "linha1");
					col = document.createElement('td');
					col.setAttribute("colspan", colunasAgLength);
					col.innerHTML = (filaSel == -1) ? "Nenhum agente" : "Nenhum agente nesta fila";
					novaLinha.appendChild(col);
					novaTabela.appendChild(novaLinha);
				}
				
				tabela = document.getElementById('tabelaAgentes');
				tabela.parentNode.replaceChild(novaTabela, tabela);
				
				tabelaTotais = document.createElement('table');
				tabelaTotais.setAttribute("align", "center");
				tabelaTotais.setAttribute("width", "100%");
				tabelaTotais.setAttribute("class", "tabelaTot");
				tabelaTotais.setAttribute("id", "tabelaTotais");
				
				linha = document.createElement('tr');
				for(th in colunasTot) {
					col = document.createElement('td');
					col.setAttribute("class", th);
					val = ((totais[th] > 0) ? totais[th] : 0);
					if(th == 'logado' && val == 0) val = "<font color='#FF0000'>0</font>";
					col.innerHTML = colunasTot[th] + '<br>' + val; // <
					linha.appendChild(col);
				}
				tabelaTotais.appendChild(linha);
				
				tabela = document.getElementById('tabelaTotais');
				tabela.parentNode.replaceChild(tabelaTotais, tabela);
			}
			
			function sortNumber(a, b) {
				return parseInt(a) - parseInt(b);
			}
			function getIdsOrdem(objs, ordem) {
				ret     = new Array();
				listAux = new Array(); 
				for(obj in objs)
					listAux[listAux.length] = objs[obj][ordem] + "&&&&" + obj;
				if(ordem == 'ramal' || ordem == 'tempostatus' || ordem == 'efetuadas' || ordem == 'recebidas' || ordem == 'tta' || ordem == 'tma') {
					listAux.sort(sortNumber);
				} else {
					listAux.sort();
				}
				for(nOrd in listAux) {
					pos = listAux[nOrd].lastIndexOf("&&&&");
					ret[ret.length] = listAux[nOrd].substr(pos+4);
				}
				return ret;
			}
			
			function ordenaAgs(ordem) {
				ordemAgs = ordem;
				atualizaTabelaAgentes();
			}
			function ordenaFilas(ordem) {
				ordemFilas = ordem;
			}
			
			function OCcomboFilas(combo) {
			
				// PERSONALIZACAO CAC - Ao selecionar CAC somar PAC, DER e PRD
				var fSel = (combo.value == 6) ? '6,1,3,8' : combo.value;
				
				enviaComando("setFilaSel:" + fSel);
				atualizaTela();
			}
			
			function enviaMsg(idAg, nome) {
				msg = prompt("Digite a mensagem a enviar para " + nome, "");
				enviaComando("enviaMsg:" + idAg + ":" + msg);
			}
			
			function pegaChamada(acao, idAg) {
				ramalSup = document.dados.ramalMonitor;
				if(ramalSup.value == '') {
					alert('Digite o ramal Monitor!');
					ramalSup.focus();
				} else
					enviaComando(acao + ":" + idAg + ":" + ramalSup.value);
			}
		
			function mudaStatus(idAg, stsNovo) {
				enviaComando("mudaStatus:" + idAg + ":" + stsNovo);
			}
			function mudaStatusBase(idAg) {
				enviaComando("pausaStatusBase:" + idAg);
			}
			function desloga(idAg) {
				enviaComando("desloga:" + idAg);
			}
			
			function atvDia(idAg) {
				var link = 'atividadesDoDia.php?idAg=' + idAg;
				window.open(link, 'Atividades do Dia', 'width=650,height=700,top=10,left=100,scrollbars=yes');
			}
			
			function pause(numberMillis)
			{
				var now = new Date();
				var exitTime = now.getTime() + numberMillis;
				while (true) {
					now = new Date();
					if (now.getTime() > exitTime) // <
						return;
				}
			}
			function saida() {
				enviaComando('logoff');
				pause(800);
				window.location = 'logoff.php';
			}
			
			function getNomeEstado(usuario) {
				     if(usuario.codstatus == DESLOGADO)  return "Deslogado";
				else if(usuario.codstatus == DISPONIVEL) return "Dispon�vel";
				else if(usuario.codstatus == CHAMANDO)   return "Chamando";
				else if(usuario.codstatus == ATENDENDO)  return "Entrante ACD";
				else if(usuario.codstatus == SAINTE)     return "Liga��o Sainte";
				else if(usuario.codstatus == DISCANDO)   return "Discando";
				else if(usuario.codstatus == ENTRANTE)   return "Entrante Direta";
				else if(usuario.codstatus >= INDISP) {	//<
					return indisp[usuario.codstatus];
				} else {
					return pausas[usuario.codstatus];
				}
			}
			
			function getClassEstado(usuario) {
				     if(usuario.codstatus == DESLOGADO)  return "deslogado";
				else if(usuario.codstatus == DISPONIVEL) return "disponivel";
				else if(usuario.codstatus == CHAMANDO)   return "chamando";
				else if(usuario.codstatus == ATENDENDO)  return "atendendo";
				else if(usuario.codstatus == SAINTE)     return "sainte";
				else if(usuario.codstatus == DISCANDO)   return "discando";
				else if(usuario.codstatus == ENTRANTE)   return "entrante";
				else if(usuario.codstatus >= INDISP)     return "indisponivel";	//<
				else                                     return "pausa";
			}
			
			function imagensAcoes(usr) {
				id  = usr.id;
				ret = "<a href='javascript:atvDia("+id+")'><img src='gfx/acoes/atividades.png' title='Atividades do Dia' /></a> "; //<
				ret += (usr.codstatus > 0) ? "<a href='javascript:enviaMsg("+id+", \""+usr.nome+"\")'><img src='gfx/acoes/mensagem.png' title='Enviar Mensagem' /></a> " : "";	//<
				if(usr.codstatusbase == 100 && usr.codstatus != 100) {
					ret += "<img title='O agente ser� pausado quando terminar o atendimento' src='gfx/acoes/pausa_sup.png' /> ";
				} else {
					if(usr.codstatus >= 100)    ret += "<a href='javascript:mudaStatus("+id+", "+DISPONIVEL+")'><img src='gfx/acoes/disponivel.png' title='Tornar Dispon�vel' /></a> ";	//< 
					else if(usr.codstatus == 1) ret += "<a href='javascript:mudaStatus("+id+", "+PAUSA+")'><img src='gfx/acoes/pausa.png' title='Pausar' /></a> ";	//<
					else if(usr.codstatus != 0) ret += "<a href='javascript:mudaStatusBase("+id+")'><img src='gfx/acoes/pausa_emlig.png' title='Pausar ap�s atendimento' /></a> ";	//<
				}
				if(usr.codstatus != ATENDENDO) {
					ret +=  "<img src='gfx/acoes/Off/escutaChamada.png' /> " +
							"<img src='gfx/acoes/Off/sussurraChamada.png' /> " +
							"<img src='gfx/acoes/Off/entraChamada.png' /> ";
				} else {	//<
					tel = usr.telefone;
					ret +=  "<a href='javascript:pegaChamada(\"escutaChamada\", "+id+")'><img src='gfx/acoes/escutaChamada.png' title='Escutar Chamada' /></a> " +
							"<a href='javascript:pegaChamada(\"sussurraChamada\", "+id+")'><img src='gfx/acoes/sussurraChamada.png' title='Sussurar na Chamada' /></a> " +
							"<a href='javascript:pegaChamada(\"entraChamada\", "+id+")'><img src='gfx/acoes/entraChamada.png' title='Entrar na Chamada' /></a> ";
				}	//<
				if(usr.codstatus != DESLOGADO) ret += " <a href='javascript:desloga("+id+")'><img src='gfx/acoes/deslogar.png' title='Deslogar' /></a>";	//<
				return ret;
			}
			
			/**
			 * Envia um comando a ser executado pelo controle do CallCenter
			 */
			function enviaComando(cmd) {
				ajax.open("GET", "enviaComando.php?Comando=<?echo $supervisor->id?>:" + cmd, true);
				ajax.send(null);
			}
			
			<? echo $ocJA ?>
						
			/**
			 * Inicializa o http 'persistente' (Comet)
			 */
			function initComet() {
				comet = new XMLHttpRequest();
				comet.multipart = true;
				comet.open("GET", "cometSupervisor.php", true);
				comet.onload = handleContent;
				comet.send(null);
				
				setTimeout("initComet()", 45200);// Reinicializa a conex�o Comet a cada 45s
			}
			function handleContent(event) {
				parseDados(event.target.responseText);
			}
			
			function formataSegundos(segs) {
				segundos = Math.ceil(segs);
				minutos = Math.floor(segundos / 60);
				if(minutos > 0) {	//<
					segundos -= (minutos * 60);
					if(segundos < 10) segundos = "0"+segundos;
					horas = Math.floor(minutos / 60);
					if(horas > 0) {
						minutos -= (horas * 60);
						if(minutos < 10) minutos = "0"+minutos;
						return horas+":"+minutos+":"+segundos;
					} else {
						return minutos+":"+segundos;
					}
				} else {
					return (segundos < 10) ? "0:0"+segundos : "0:"+segundos;
				}
			}
			
			/**
			 * Envia o comando de keepAlive periodicamente
			 */
			function keepAlive() {
				ajaxKA.open("GET", "enviaComando.php?Comando=<?echo "$supervisor->id:keepAlive:$supervisor->ramal"?>", true);
				ajaxKA.send(null);
				setTimeout("keepAlive()", TOKA);
			}
			
			setTimeout("initComet()", 1000);
			setTimeout("keepAlive()", 6000);
			enviaComando("setFilaSel:" + <? echo $idFilaSel==null ? 'document.dados.fila.value' : $idFilaSel; ?>);
		</script>
	<body>
</html>
