<?php
class FilaCC extends ShMemObj {
	var $id, $name, $flags, $qtdchamespera, $tempomedioespera, $tempoespera;
	var $qtdchamrecebida, $qtdchamatendida, $qtdchamaband, $tempomaxatend, $tempomaxabandono;
	var $tempototalatend, $tempototalabandono, $maxagspausa, $urlpopup, $urlpopupfim, $indispna;
	var $totag, $totaglog, $servicelevel, $tempons, $timeout;
	
	var $callback, $callbackdisp, $callbackmin, $callbackmax, $callbacknums;
	var $callbackstriplocal, $callbackaddlocal, $callbackaddddd;
	var $ramal, $tipopiloto;
	
	function FilaCC($arrayBDAst=0, $shm_id=0, $pos=0, $memPorObj=0) {
		if($shm_id > 0) {
			parent::__construct($shm_id, $pos, $memPorObj);
			if(is_array($arrayBDAst)) {
				$this->setAtrsDoArray($arrayBDAst);
				
				// Valores Padr�o
				$this->callbacknums       = array();
				$this->qtdchamespera      = 0;
				$this->tempomedioespera   = '0:00';
				$this->tempoespera        = '0:00';
				$this->qtdchamrecebida    = 0;
				$this->qtdchamatendida    = 0;
				$this->qtdchamaband       = 0;
				$this->tempomaxatend      = 0;
				$this->tempomaxabandono   = 0;
				$this->tempototalatend    = 0;
				$this->tempototalabandono = 0;
				$this->totag              = 0;
				$this->totaglog           = 0;
				$this->servicelevel       = 100;
				$this->tempons            = 120;
			}
		}
	}
	
	function addCallBack($cid, $uniqueid) {
		if(count($this->callbacknums) < MAX_CALLBACK_FILA) {
			if(strlen($cid) == 10) {
				$ddd = substr($cid, 0, 2);
				$num = substr($cid, 2);
				if($ddd == ControleCC::$params['DDDLocal']) {
					if($this->callbackstriplocal) $numCB = $this->callbackaddlocal . $num;
					else                          $numCB = $this->callbackaddlocal . $cid;
				} else {
					$numCB = $this->callbackaddddd . $cid;
				}
			} else
				$numCB = $cid;
			if(!in_array($numCB, $this->callbacknums)) {	// Impedir numeros duplicados na fila de callback
				$this->callbacknums[$uniqueid] = $numCB;
				ControleCC::loga(LOG_NORMAL, "Chamada($cid) abandonada agendada para callback na fila($this->name)($numCB)");
			} else
				ControleCC::loga(LOG_NORMAL, "Chamada($cid) abandonada NAO agendada para callback na fila($this->name)($numCB) - ja estava na fila de CB");
		} else
			ControleCC::loga(LOG_AVISO, "Chamada abandonada NAO agendada para callback na fila($this->name)- Num Max callback atingido");
	}
	
	function agentesDisponiveis() {
		// TODO
	}
	
	function processaCallBack($disps=null) {
		if(count($this->callbacknums)) {
			if($disps == null) $disps = $this->agentesDisponiveis();
			if($disps == 0) return;
			
			// Podem haver multiplos piloto no campo ramal, pegar o primeiro
			list($piloto) = explode(',', $this->ramal);
			
			$uidsOK = array();
			foreach($this->callbacknums as $uid => $num) {
				// Disparar callback
				$sucesso = ControleCC::$comandosAst->enviaComando('Originate', array(
						'Channel'  => "Local/$num@todos/n",
						'Context'  => 'filas',
						'Exten'    => $piloto,
						'Priority' => 1,
						'Callerid' => "--CALLBACK-- <$num>",
						'Timeout'  => 30000,
						'Async'    => 1,
						'Variable' => "CDR(callback)=$uid",
						'Variable' => "CALLBACK=$uid"
					));
				if($sucesso === true) {
					$disps--;
					ControleCC::loga(LOG_NORMAL, "Callback para $num efetuado na fila($this->name)");
					$uidsOK[] = $uid;
					
					ControleCC::logaEvento(EVENTO_CALLBACK, $num, $uid, '', '', ",$this->name,");
				} else
					ControleCC::loga(LOG_AVISO,  "Falha ao efetuar callback para $num na fila($this->name) - msg [$sucesso]");
				
				if($disps == 0) break;
			}
			
			foreach($uidsOK as $uid)
				unset($this->callbacknums[$uid]);
		}
	}
	
	/**
	 * Retorna o nome colorido
	 */
	function getNome() {
		return "[\033[35;1m$this->name\033[0m]";
	}
}
?>