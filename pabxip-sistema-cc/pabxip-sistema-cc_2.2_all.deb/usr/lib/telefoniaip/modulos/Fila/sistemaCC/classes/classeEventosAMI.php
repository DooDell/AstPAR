<?php
class EventosAMI {
	var $loginOK;
	private $AMI, $eventosTrataveis, $pacotesUltCmd;
	private $bufferInfoQS;
	
	function EventosAMI($config) {
		$this->loginOK = false;
		
		// Eventos aceitos pelo processador
		$this->eventosTrataveis = array(
									'AgentCalled',
									'AgentConnect',
									'AgentComplete',
									'AgentRingNoAnswer', // Equivalente 1.6.1 ao AgentSkip do Patch 1.4.19
									'AgentSkip',	// Patch GSD
									'Join',
									'Leave',
									'QueueCallerAbandon',
									'QueueParams',
									'QueueEntry',
									'QueueStatusComplete',
									'Dial',
									'OriginateResponse',
									'Bridge',
									'Hangup',
									'Shutdown'
								);
		
		$this->AMI = new AMI($config, 'Eventos');
		if($this->AMI->pacoteLogin === false)
			return;

		$this->processaEventos($this->AMI->pacoteLogin);
		$this->loginOK = true;
	}
		
	function processa($to=0.1) {
		$ret = false;
		
		$pacoteRecebido = $this->AMI->recebeEventos($to);
		if($pacoteRecebido === false) {
			ControleCC::loga(LOG_AVISO, "Asterisk desligou/caiu. saindo.");
			ControleCC::$loopPrincipal = 100;
			return false;
		}
		if(!$pacoteRecebido->vazio())
			$ret = $this->processaEventos($pacoteRecebido);
		
		return $ret;
	}
	
	static function getAgentePorTel($telefone, $evento, $telEhCanal=false) {
		if($telEhCanal) {
			$pos = strrpos($telefone, '-'); // Acha o ultimo traco no canal do telefone
			if($pos > 0)
				$telefone = substr($telefone, 0, $pos);
		}
		if(in_array($telefone, ControleCC::$telAgentes)) {
			$agente = ControleCC::$memAgs->get('telefone', $telefone);
			if(!is_a($agente, 'Agente')) {
				ControleCC::loga(LOG_CRITICO, "ERRO EV: $evento - Erro ao buscar dados do Agente no telefone $telefone");
				return null;
			}
			return $agente;
		}
		return null;
	}
	
	static function getCallerID($pacote, $comNome=true) {
		// Pegar o CallerID - Tentar v�rias maneiras
		$cidNum  = $pacote->getAtr('CallerIDNum');
		if(empty($cidNum))
			$cidNum = $pacote->getAtr('CallerID');
		if(empty($cidNum)) {
			$cidNum = $pacote->getAtr('ChannelCalling');
			if(strstr($cidNum, '/')) {
				list($d, $cid) = explode("/", $cidNum);
				list($cidNum, $d) = explode("-", $cid);
			} else
				$cidNum = "?";
		}
		if($comNome) {
			$cidName = $pacote->getAtr('CallerIDName');
			return (!empty($cidName) && $cidName != '<unknow>' && $cidName != '<Unknow>') ? "$cidName <$cidNum>" : $cidNum;
		} else
			return $cidNum;
	}
	
	/**
	 * Retorna true para indicar que devemos sinalizar altera��es na tela de supervis�o
	 */
	function processaEventos($pacote) {
		$atzSups = false;
		
		$aux =& $pacote;
		while($aux) {
			$evento = $aux->getAtr('Event');
//if(!empty($evento) && substr($evento, 0, 5) != 'Queue') ControleCC::loga(LOG_AVISO, ">>>>>>>>> EVENTO: $evento");
			if(in_array($evento, $this->eventosTrataveis)) {
				
				// Ignorar filas n�o tratadas aqui (telefonista, poolSecretaria, ...)
				$nomeFila = $aux->getAtr('Queue');
				if($nomeFila !== null && ($nomeFila == 'telefonista' || $nomeFila == 'telefonista-espera' || substr($nomeFila, 0, 9) == 'poolSecrt')) {
					$aux = $aux->prox;
					continue;
				}
				
				ControleCC::loga(($evento == 'QueueParams'||$evento == 'QueueEntry'||$evento == 'QueueStatusComplete') ? LOG_DEBUG3 : LOG_DEBUG2, "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% Evento Tratado: [\033[32;1m$evento\033[0m]");
				switch($evento) {
					case 'AgentCalled':
/*
Event: AgentCalled
Privilege: agent,all
AgentCalled: SIP/cac01
Queue: pac                            ***** Esta linha Queue s� ser� enviada mediante a patch no Asterisk 1.4.19!!!!!!
AgentName: Gabriel Ortiz Lour
ChannelCalling: SIP/2549-0832ef90
CallerID: 2549
CallerIDName: timothy
Context: irrestrito
Extension: 5008
Priority: 4
 */
						if(($agente = EventosAMI::getAgentePorTel($aux->getAtr('AgentCalled'), $evento))) {
							$fila     = ControleCC::$memFilas->get('name', $nomeFila);
							$cidName  = $aux->getAtr('CallerIDName');
							
							// Verificar se � uma fila de eMail
							$email = $idEmail = '';
							if(is_a($fila, 'FilaCC') && $fila->tipopiloto == 'M') {
								$email   = $aux->getVariable('EMAIL');
								if(strstr($email, '<')) {
									list($d, $email) = explode('<', $email);
									list($email)     = explode('>', $email);
								}
								$idEmail = $aux->getVariable('IDEMAIL');
							}
							$cid = !empty($email) ? $email : EventosAMI::getCallerID($aux, false);
							$vars = $aux->getVariables();
							 
							$sucesso = $agente->mudaEstado(CHAMANDO, array('filaatual' => $nomeFila, 'numentra' => $cid, 'nameentra' => $cidName, 'email' => $email, 'idemail' => $idEmail, 'chanvars' => $vars));
							$nomeAgente = $agente->getNome();
							if($sucesso === true) {
								$atzSups = true;
								$nomeFilaCl = $fila->getNome();
								$numFila  = $aux->getAtr('Extension');
								$msgEmail = !empty($email) ? ", email($email), idemail($idEmail)" : '';
								$msgVars  = !empty($vars)  ? ", chanvars($vars)" : '';
								ControleCC::loga(LOG_NORMAL,  ">>EV: AgentCalled. Setado codstatus(CHAMANDO), filaatual($nomeFilaCl($numFila)), numentra($cid), nameentra($cidName)$msgVars$msgEmail para $nomeAgente");
							} else
								ControleCC::loga(LOG_CRITICO, "EV: AgentCalled - Erro ao alterar status para CHAMANDO de $nomeAgente - Msg [$sucesso]");
						}
						break;
					
					case 'AgentConnect':
/*
Event: AgentConnect
Privilege: agent,all
Queue: teste
Uniqueid: 1237674627.3
Channel: SIP/1201-08331448
Member: SIP/1201
MemberName: Teste Ortiz
Holdtime: 13
BridgedChannel: 1237674627.4
 */
						$telefone = $aux->getAtr('Member');
						
						$agente = EventosAMI::getAgentePorTel($telefone, $evento);
						if($agente) {
							$tempoEsp = $aux->getAtr('Holdtime');
							$uid      = $aux->getAtr('Uniqueid');
							$chan     = $aux->getAtr('Channel');
							$callChan = $aux->getAtr('ChannelCalling');
							$vars     = $pacote->getVariables();
							
							$atrsSet = array(
									'holdtime'        => $tempoEsp,
									'uniqueid'        => $uid,
									'recebidas'       => $agente->recebidas + 1,
									'channel'         => $chan,
									'link'            => $callChan,
									'emtransferencia' => '',
									'emconferencia'   => '',
									'chanvars'        => $vars
								);
							$sucesso = $agente->mudaEstado(ATENDENDO, $atrsSet, ",$nomeFila,");
							
							$nomeAgente = $agente->getNome();
							$nomeFila   = "[\033[35;1m$nomeFila\033[0m]";
							if($sucesso === true) {
								$atzSups = true;
								ControleCC::loga(LOG_NORMAL,  ">>EV: AgentConnect.  Setado codstatus(ATENDENDO), holdtime($tempoEsp) para $nomeAgente na fila $nomeFila");
							} else
								ControleCC::loga(LOG_CRITICO, "EV: AgentConnect - Erro ao alterar status para ATENDENDO de $nomeAgente na fila $nomeFila - Msg [$sucesso]");
						}
						break;
					
					case 'AgentComplete':
/*
Event: AgentComplete
Privilege: agent,all
Queue: paranaDigital
Uniqueid: 1237831534.59
Channel: SIP/cac01-083353a8
Member: SIP/gism                            ***** Esta linha Member s� ser� enviada mediante a patch no Asterisk 1.4.19!!!!!!
MemberName: Gabriel Ortiz Lour
HoldTime: 9
TalkTime: 30
Reason: agent
 */
						$telefone = $aux->getAtr('Member');
						$tempoH   = $aux->getAtr('HoldTime');
						$tempoA   = $aux->getAtr('TalkTime');
						
						$fila = ControleCC::$memFilas->get('name', $nomeFila);
						if(is_a($fila, 'FilaCC')) {
							$fila->qtdchamatendida++;
							$fila->tempototalatend += $tempoA;
							if($tempoA > $fila->tempototalatend) $fila->tempototalatend = $tempoA;
							$fila->atualizaShMem();
						} else
							ControleCC::loga(LOG_CRITICO, "ERRO EV: AgentComplete - Erro ao buscar dados da fila($nomeFila)");
						
						$agente = EventosAMI::getAgentePorTel($telefone, $evento);
						if($agente) {
							$uniqueid = $aux->getAtr('Uniqueid');
							$nomeAgente = $agente->getNome();
							
							ControleCC::logaEvento(EVENTO_ATENDIMENTO, $agente->ramal, $tempoH, $tempoA, $uniqueid, ",$nomeFila,");
							
							if(is_a($fila, 'FilaCC') && $fila->flags & FLAG_FILA_PAUSA_AUTO) {
								$nomeEstado = 'PAUSA';
								$estado  = PAUSA_AUTO;
								$sucesso = $agente->pausa();
							} else {
								$nomeEstado = 'DISPONIVEL';
								$estado  = DISPONIVEL;
								$sucesso = true;
							}
							if($sucesso === true) {
								$atzSups = true;
								$nomeFilaCl = is_a($fila, 'FilaCC') ? $fila->getNome() : $nomeFila;
								$sucesso = $agente->mudaEstado($estado, array('filaatual' => '', 'numentra' => '', 'uniqueid' => '', 'channel' => '', 'link' => '', 'chanvars' => ''));
								if($sucesso === true) ControleCC::loga(LOG_NORMAL,  ">>EV: AgentComplete. Setado codstatus($nomeEstado) para $nomeAgente na fila $nomeFilaCl");
								else                  ControleCC::loga(LOG_CRITICO, "EV: AgentComplete - Erro ao alterar status para $nomeEstado de $nomeAgente na fila $nomeFilaCl - Msg [$sucesso]");
							} else
								ControleCC::loga(LOG_CRITICO, "EV: AgentComplete - Erro ao AUTO-PAUSAR $nomeAgente - Msg [$sucesso]");
						}
						break;
						
					case 'AgentRingNoAnswer': // Vers�o 1.6.1.X do Asterisk
					case 'AgentSkip':
/*
*** Este Evento s� ser� enviado mediante a patch no Asterisk 1.4.X!!!!!!
Event: AgentSkip
Privilege: agent,all
Queue: GISM
Uniqueid: 1242101824.4
Channel: SIP/2549-08321138
Member: SIP/gism
MemberName: Paloma Giovana Groxko
 */
						$telefone  = $aux->getAtr('Member');
						$temporing = $aux->getAtr('Ringtime') / 1000; // Asterisk 1.6.1.x
						
						$agente = EventosAMI::getAgentePorTel($telefone, $evento);
						if($agente) {
							$nomeAgente = $agente->getNome();
							$foiIndisp = 0;
							$atzAg = false;
							$fila = ControleCC::$memFilas->get('name', $nomeFila);
							if(is_a($fila, 'FilaCC')) {
								$nomeFilaCl = $fila->getNome();
								if($fila->indispna == '1') {
									if($temporing >= $fila->timeout) {
										$foiIndisp = 1;
										$sucesso = $agente->pausa('1');
										if($sucesso === true) {
											$atzSups = true;
											$sucesso = $agente->mudaEstado(INDISP, null, ",$nomeFila,");
											if($sucesso === true) {
												ControleCC::loga(LOG_AVISO, ">>EV: AgentSkip. Agente $nomeAgente indisponivel por Nao Atendimento($temporing) na fila $nomeFilaCl");
												$foiIndisp = 2;
											} else {
												ControleCC::loga(LOG_CRITICO, "ERRO EV: AgentSkip($temporing) $nomeAgente na fila $nomeFilaCl - Msg [$sucesso]");
												$agente->msg = "PAUSADO POR NAO ATENDIEMNTO. Erro ao mudar de estado.";
												$atzAg = true;
											}
										} else {
											ControleCC::loga(LOG_CRITICO, "AG: Erro ao pausar $nomeAgente por Nao Atendimento($temporing) na fila $nomeFilaCl - Msg [$sucesso]");
											$agente->msg = "Erro ao pausar por n�o atendimento.";
											$atzAg = true;
										}
									} else {
										ControleCC::loga(LOG_AVISO, ">>EV: AgentSkip. Timeout da fila $nomeFilaCl atingido antes do Agente $nomeAgente atender($temporing)");
									}
								} else {
									ControleCC::loga(LOG_AVISO, "++ EV: AgentSkip($temporing) $nomeAgente nao atendeu a chamada da Fila $nomeFilaCl - Indisponivel por NA desligado");
								}
							} else {
								ControleCC::loga(LOG_CRITICO, "ERRO EV: AgentSkip($temporing) $nomeAgente - Erro ao buscar dados da fila($nomeFila)");
							}
							
							if($atzAg)
								$agente->atualiza();
							
							ControleCC::logaEvento(EVENTO_NAOATENDIMENTO, $agente->ramal, $temporing, $foiIndisp, '', ",$nomeFila,");
						}
						break;
					
					case 'Join':
					case 'Leave':
/*
Event: Join
Privilege: call,all
Channel: SIP/2549-08336780
CallerID: 2549
CallerIDName: timothy
Queue: ParanaDigital
Position: 1
Count: 1
Uniqueid: 1240940364.70

Event: Leave
Privilege: call,all
Channel: SIP/2549-08330228
Queue: GISM
Count: 0
Uniqueid: 1242060070.26
 */
						$fila = ControleCC::$memFilas->get('name', $nomeFila);
						if(is_a($fila, 'FilaCC')) {
							$nomeFilaCl = $fila->getNome();
							if($evento == 'Join') {
								$cid = EventosAMI::getCallerID($aux);
								ControleCC::loga(LOG_DEBUG0, "Cliente ($cid) entrou na fila $nomeFilaCl");
							}
							$fila->qtdchamespera = $aux->getAtr('Count');
							$fila->atualizaShMem();
							Agente::setaAltFlagPorFila($fila->id);
						} else
							ControleCC::loga(LOG_CRITICO, "ERRO EV: $evento - Erro ao buscar dados da fila($nomeFila)");
						break;
						
					
					case 'QueueCallerAbandon':
/*
Event: QueueCallerAbandon
Privilege: agent,all
Queue: teste
Uniqueid: 1237673457.3
CallerID: 2549					// CallerID - patch GSD
CallerIDName: teste				// CallerIDName - patch GSD
Position: 1
OriginalPosition: 1
HoldTime: 3
 */
						$cid      = EventosAMI::getCallerID($aux);
						$tempo    = 0;
						$nomeFilaCl = $nomeFila;
						
						$fila = ControleCC::$memFilas->get('name', $nomeFila);
						if(is_a($fila, 'FilaCC')) {
							$nomeFilaCl = $fila->getNome();
							$tempo = $aux->getAtr('HoldTime');
							if(!is_numeric($tempo)) $tempo = 0;
							
							$fila->qtdchamaband++;
							$fila->tempototalabandono += $tempo;
							if($tempo > $fila->tempomaxabandono) $fila->tempomaxabandono = $tempo;
							
							if($fila->callback && (($fila->callbackmin == 0 || $tempo >= $fila->callbackmin) && ($fila->callbackmax == 0 || $tempo <= $fila->callbackmax))) {
								// Colocar chamada na fila de callbacks desta fila
								$uid = $aux->getAtr('Uniqueid');
								$fila->addCallBack($cid, $uid);
							}
							$fila->atualizaShMem();
							//Agente::setaAltFlagPorFila($fila->id);
						} else
							ControleCC::loga(LOG_CRITICO, "ERRO EV: QueueCallerAbandon - Erro ao buscar dados da fila($nomeFila)");
						
						ControleCC::logaEvento(EVENTO_ABANDONO, $tempo, $aux->getAtr('Position'), $cid, "", ",$nomeFila,");
						ControleCC::loga(LOG_NORMAL, ">>> EV >>> QueueCallerAbandon. Setado qtdchamaband($fila->qtdchamaband), tempototalabandono($fila->tempototalabandono) para a fila($nomeFilaCl)");
						break;
					
					case 'QueueParams': // Evento gerado pela requisicao do status das filas
/*
Event: QueueParams
Queue: todos
Max: 0
Calls: 0
Holdtime: 0
Completed: 0
Abandoned: 0
ServiceLevel: 0
ServicelevelPerf: 0.0
Weight: 0
 */
						$nivServ     = $aux->getAtr('ServicelevelPerf');
						$tempoNS     = $aux->getAtr('ServiceLevel');
						$emEspera    = $aux->getAtr('Calls');
						$tempoMedEsp = $aux->getAtr('Holdtime');

						$this->bufferInfoQS[$nomeFila]['servicelevel']     = (empty($nivServ) || !is_numeric($nivServ))          ? '0.0'   : $nivServ;
						$this->bufferInfoQS[$nomeFila]['tempons']          = (empty($tempoNS) || !is_numeric($tempoNS))          ? '0'     : $tempoNS;
						$this->bufferInfoQS[$nomeFila]['qtdchamespera']    = (empty($emEspera) || !is_numeric($emEspera))        ? 0       : $emEspera;
						$this->bufferInfoQS[$nomeFila]['tempomedioespera'] = (empty($tempoMedEsp) || !is_numeric($tempoMedEsp))  ? '00:00' : Util::formataSegundos($tempoMedEsp);
						break;
					
					case 'QueueEntry':
/*
Event: QueueEntry
Queue: teste
Position: 1
Channel: SIP/1200-08327288
CallerID: 1200
CallerIDName: Ekiga
Wait: 12
 */
						if($aux->getAtr('Position') == '1') {
							$this->bufferInfoQS[$nomeFila]['tempoespera'] = Util::formataSegundos($aux->getAtr('Wait'));
						}
						break;
					
					case 'QueueStatusComplete':
						$tsI = microtime(true);
						foreach($this->bufferInfoQS as $nomeFila => $atrsFila) {
							$fila = ControleCC::$memFilas->get('name', $nomeFila);
							if(is_a($fila, 'FilaCC')) {
								$fila->tempoespera = '0:00';
								foreach($atrsFila as $nomeAtr => $valAtr)
									$fila->$nomeAtr = $valAtr;
								$fila->atualizaShMem();
							}
						}
						ControleCC::loga(LOG_DEBUG2,  "Tempo de atz das filas: " . (microtime(true) - $tsI));
						break;
					
					case 'Dial':
/*
Event: Dial
Privilege: call,all
Source: SIP/2549-0832ad80
Destination: SIP/gism-0833bbe0
CallerID: 2549
CallerIDName: timothy
SrcUniqueID: 1241018347.53
DestUniqueID: 1241018347.54

1.6:
Event: Dial
Privilege: call,all
SubEvent: Begin
Channel: SIP/pabxip_gism-00005320
Destination: SIP/codec-00005321
CallerIDNum: 6699
CallerIDName: ORTIZ
UniqueID: 1306244257.21608
DestUniqueID: 1306244257.21609
Dialstring: codec
 */
						// Verificar se o agente esta recebendo uma chamada
						{
							$telefone = $aux->getAtr('Destination');
							$agente   = EventosAMI::getAgentePorTel($telefone, $evento, true);
							if($agente && $agente->codstatus > DESLOGADO && $agente->codstatus != ATENDENDO && $agente->codstatus != SUPLOGADO) {
								$nomeAgente = $agente->getNome();
								
								$cid      = EventosAMI::getCallerID($aux);
								$uid      = $aux->getAtr('Uniqueid');
								$callChan = ControleCC::$ehAsterisk16 ? $aux->getAtr('Channel') : $aux->getAtr('Source');
								
								ControleCC::logaEvento(EVENTO_RECEBE, $agente->ramal, $cid, $uid);
								
								// Alterando estado para ENTRANTE - salva channel e link e o CID
								$sucesso = $agente->mudaEstado(ENTRANTE, array('numentra' => $cid, 'channel' => $telefone, 'link' => $callChan));
								if($sucesso === true) {
									$atzSups = true;
									ControleCC::loga(LOG_NORMAL,  ">>EV: Dial. Setado codstatus(ENTRANTE) C($telefone)L($callChan) para $nomeAgente");
								} else
									ControleCC::loga(LOG_CRITICO, "ERRO EV: Dial(mudaEstado) $nomeAgente - Msg [$sucesso]");
							}
						}
						
						// Verificar se o agente esta fazendo uma chamada (sem else pois pode ser um agente ligando para outro)
						{
							$telefone = ControleCC::$ehAsterisk16 ? $aux->getAtr('Channel') : $aux->getAtr('Source');
							$agente   = EventosAMI::getAgentePorTel($telefone, $evento, true);
							if($agente) {
								$nomeAgente = $agente->getNome();
								$callChan = $aux->getAtr('Destination');
								
								$agente->channel = $telefone;
								$agente->link    = $callChan;
								
								$sucesso = $agente->atualiza();
								if($sucesso === true) {
									$atzSups = true;
									ControleCC::loga(LOG_DEBUG1, "Ev Dial: Salvando Chan($telefone) e Link($callChan) para $nomeAgente");
								} else
									ControleCC::loga(LOG_CRITICO, "ERRO EV: Dial(atualiza) $nomeAgente - Msg [$sucesso]");
							}
						}
						break;
					
					case 'OriginateResponse':
/*
Event: OriginateResponse
Privilege: call,all
ActionID: 7793
Response: Failure
Channel: SIP/1201
Context: agentes
Exten: ***124
Reason: 5
Uniqueid: <null>
CallerID: <unknown>
CallerIDNum: <unknown>
CallerIDName: <unknown>
 */
 						$num = $aux->getAtr('Exten');
 						if(substr($num, 0, 3) != '***') {
 							$telefone = $aux->getAtr('Channel');
 							if(substr($telefone,0,6) == 'Local/') {
 								$actID = $aux->getAtr('ActionID');
 								if(substr($actID,0,3) == '000') {
 									// Agente iniciando uma conferencia
 									$agente = ControleCC::$memAgs->get('emconferencia', $actID);
									if(is_a($agente, 'Agente')) {
										$agente->emconferencia = $aux->getAtr('Uniqueid');
										$agente->atualiza();
										$nomeAgente = $agente->getNome();
										ControleCC::loga(LOG_DEBUG0, ">>EV: OriginateResponse. Salvo UID do canal em conferencia com $nomeAgente");
									}
 								}
 							} else {
								$agente = EventosAMI::getAgentePorTel($telefone, $evento, true);
								if($agente) {
									$nomeAgente = $agente->getNome();
	 								$sucesso = AMI::verificaStatus($aux);
									if($sucesso === true) {
										$uid = $aux->getAtr('Uniqueid');
										ControleCC::logaEvento(EVENTO_DISCA, $agente->ramal, $num, $uid);
										
										$atrs = array('numsai' => $num);
										if(strlen($num) > 4) $atrs['efetuadas'] = $agente->efetuadas + 1;
										$sucesso = $agente->mudaEstado(SAINTE, $atrs);
										if($sucesso === true) ControleCC::loga(LOG_NORMAL, ">>EV: OriginateResponse. Setado numSai($num) para o agente $nomeAgente");
										else                  ControleCC::loga(LOG_CRITICO, "Erro ao alterar numsai de $nomeAgente - Msg [$sucesso]");
									} else {
										ControleCC::loga(LOG_AVISO, ">>EV: OriginateResponse. Erro ao efetuar chamada de $nomeAgente para $num - Msg [$sucesso]");
										
										$agente->msg = file_exists('/etc/asterisk/telip/EH_RESTART') ? 'Restart periodico. Aguarde 15 segundos' : 'Erro ao efetuar ligacao. Verifique seu telefone.';
										if(($sucesso = $agente->mudaEstado(DISPONIVEL)) !== true)
											ControleCC::loga(LOG_AVISO, "Erro ao enviar mensagem para $nomeAgente - Msg [$sucesso]");
									}
									if($sucesso === true) $atzSups = true;
								}
 							}
 						}
						break;
					
					case 'Bridge':
/*
Event = Bridge
Bridgestate = Link
Bridgetype = core
Channel1 = SIP/codec-0000001d
Channel2 = Local/6699@irrestrito-user-d248;1
Uniqueid1 = 1310072454.50
Uniqueid2 = 1310072459.51
CallerID1 = 6010
CallerID2 = 6010
 */
						$chan1 = $aux->getAtr('Channel1');
						
						$agente = EventosAMI::getAgentePorTel($chan1, $evento, true);
						if($agente && $agente->emtransferencia) {
							// Salvar o canal bridge do agente fazendo transferencia
							$chan2 = $aux->getAtr('Channel2');
							if($agente->link != $chan2) {
								$nomeAgente = $agente->getNome();
								$agente->link = $chan2;
								$agente->atualiza();
								
								ControleCC::loga(LOG_NORMAL,  ">>EV: Bridge. Salvo canal link $chan2 para $nomeAgente (atxfer)");
							}
						}
						break;
					
					case 'Hangup': // Alguem desligou
//ControleCC::loga(LOG_CRITICO, ">>>>>>> HANGUP: $aux");
/*
Event: Hangup
Privilege: call,all
Channel: SIP/2549-0835d760
Uniqueid: 1238438800.193
Cause: 0
Cause-txt: Unknown
 */
						$telefone = $aux->getAtr('Channel');
						$testaHangupConf = false;
						
						$agente = EventosAMI::getAgentePorTel($telefone, $evento, true);
						if($agente) {
							$nomeAgente = $agente->getNome();
							$msg   = '';
							$filas = null;
							$atrs  = array('uniqueid' => '', 'channel' => '', 'link' => '', 'chanvars' => '');
							
							if($agente->codstatus != ATENDENDO && $agente->codstatus != DISPONIVEL) {
								switch($agente->codstatus) {
									case CHAMANDO:
										$msg = "Ligacao na fila $agente->filaatual para $nomeAgente vinda de $agente->numentra desligou durante CHAMANDO";
										$filas = $agente->filaatual;
										$atrs['numentra'] = '';
										$atrs['filaatual'] = '';
										break;
									
									case SAINTE:
										$msg = "$nomeAgente desligou chamada sainte";
										$atrs['numsai'] = '';
										break;
									
									case DISCANDO:
										$msg = "$nomeAgente nao atendeu propria chamada sainte";
										$atrs['numsai'] = '';
										break;
									
									case ENTRANTE:
										$msg = "$nomeAgente desligou chamada entrante direta";
										$atrs['numentra'] = '';
										break;
								}
								if($agente->emtransferencia) {
									$msg .= ". Finalizada transferencia assistida";
									$atrs['emtransferencia'] = '';
								}
								if($agente->emconferencia) {
									$msg .= ". Finalizada conferencia";
									$atrs['emconferencia'] = '';
								}

								$sucesso = $agente->mudaEstado(DISPONIVEL, $atrs, $filas);
								if($sucesso === true) {
									$atzSups = true;
									ControleCC::loga(LOG_NORMAL,  ">>EV: Hangup:$msg. Setado codstatus(DISPONIVEL)");
								} else
									ControleCC::loga(LOG_CRITICO, "ERRO EV: Hangup:$msg. MsgERR [$sucesso]");
							} else {
								$msg = '';
								if($agente->emtransferencia) {
									$msg = " Finalizada transferencia assistida.";
									$agente->emtransferencia = '';
								}
								if($agente->emconferencia) {
									$msg .= " Finalizada conferencia.";
									$agente->emconferencia = '';
								}
								if($msg != '') {
									ControleCC::loga(LOG_NORMAL,  ">>EV: Hangup. $nomeAgente:$msg");
									$agente->atualiza();
								}
							}
						} else if(substr($telefone, 0, 6) == 'Local/' && substr($telefone, -2) == ';1') {
							// Verificar se � um canal de atxfer desligando
							$agente = ControleCC::$memAgs->get('link', $telefone);
							if($agente) {
								$nomeAgente = $agente->getNome();
								ControleCC::loga(LOG_NORMAL,  ">>EV: Hangup. Retorno de transferencia assistida de $nomeAgente");
								$agente->link = $agente->emtransferencia;
								$agente->emtransferencia = '';
								$agente->atualiza();
							}
							
							$testaHangupConf = $telefone;
						} else {
							$testaHangupConf = $aux->getAtr('Uniqueid');
						}
						
						if($testaHangupConf) {
							// Verificar se � um canal de conferencia (chanspy) desligando
							$agente = ControleCC::$memAgs->get('emconferencia', $testaHangupConf);
							if($agente) {
								$nomeAgente = $agente->getNome();
								ControleCC::loga(LOG_NORMAL,  ">>EV: Hangup. Canal conferencia de $nomeAgente desligou");
								$agente->emconferencia = '';
								$agente->atualiza();
							}
						}
						break;
					
					case 'Shutdown':
/*
Event: Shutdown
Privilege: system,all
Shutdown: Cleanly
Restart: False
 */
 						$razao = $aux->getAtr('Shutdown');
						ControleCC::loga(LOG_AVISO, "Asterisk desligou[$razao]. Saindo!");
						ControleCC::$loopPrincipal = 0;
						break;
				}
				
				// Chama funcoes de integracao, se existirem
				//$ag = (isset($agente) && is_a($agente, 'Agente')) ? $agente : null;
				//Hooks::chamaFuncoes("Evento::$evento", $aux, $ag);
			}
			$aux = $aux->prox;
		}
		return $atzSups;
	}
	
	function enviaQueueStatus() {
		// Zerar o buffer
		$this->bufferInfoQS = array();
		
		$actID = $this->AMI->getActionID();
		$pacote = $this->AMI->enviaComando('QueueStatus', array('Member' => '--NenhuM--')); // Filtro --NenhuM-- para nao receber eventos de membros das filas
		$this->processaEventos($pacote);
		return AMI::comandoOK($pacote, $actID);
	}
	
	function shut() {
		$this->AMI->logoff();
	}
}
?>