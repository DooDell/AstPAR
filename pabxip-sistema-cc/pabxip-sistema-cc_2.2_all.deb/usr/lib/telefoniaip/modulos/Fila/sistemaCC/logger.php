<?php
require_once('logHeader.php');

// Inicializar o logger
$nivelLog = file_get_contents('/etc/asterisk/telip/cc/NIVELLOG');
$descNivLog = array();
$descNivLog[LOG_CRITICO] = "\033[31;1mLOG_CRITCO\033[0m";
$descNivLog[LOG_AVISO]   = "\033[35;1mLOG_AVISOS\033[0m";
$descNivLog[LOG_NORMAL]  = "\033[37;1mLOG_NORMAL\033[0m";
$descNivLog[LOG_DEBUG0]  = "\033[33;1mLOG_DEBUG0\033[0m";
$descNivLog[LOG_DEBUG1]  = "\033[32;1mLOG_DEBUG1\033[0m";
$descNivLog[LOG_DEBUG2]  = "\033[34;1mLOG_DEBUG2\033[0m";
$descNivLog[LOG_DEBUG3]  = "\033[36;1mLOG_DEBUG3\033[0m";

function loga($nivelDebug, $texto, $mais='', $arq='') {
	global $nivelLog, $descNivLog;
	if($nivelDebug <= $nivelLog) {
		$nivLog = $descNivLog[$nivelDebug];
		switch($nivelDebug) {
			case LOG_CRITICO: $add = '!!!>>> '; break;
			case LOG_AVISO:   $add = '>>> ';    break;
			default:          $add = '';        break;
		}
		$str = date('[d/m/y H:i:s]') . "[$nivLog] >$mais $add$texto\n";
		if(empty($arq))	echo $str;
		else            file_put_contents($arq, $str, FILE_APPEND);
	}
}
?>