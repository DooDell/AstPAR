<?php
	$nomeFila = $_REQUEST['fila'];
	
	if($nomeFila == 'SAC')
		$goTo = 'popupSAC.php';
	else
		$goTo = 'popupCAC.php';
	header('Location: '.$goTo.'?' . http_build_query($_REQUEST));
?>