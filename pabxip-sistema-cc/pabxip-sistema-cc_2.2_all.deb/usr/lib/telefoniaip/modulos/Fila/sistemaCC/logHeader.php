<?php
	define("LOG_CRITICO",  5);
	define("LOG_AVISO",   10);
	define("LOG_NORMAL",  20);
	define("LOG_DEBUG0",  25);
	define("LOG_DEBUG1",  30);
	define("LOG_DEBUG2",  40);
	define("LOG_DEBUG3",  50);
?>