<?php
class Util {
	static function cmdAsterisk($cmd) {
		exec("asterisk -rx \"$cmd\"");
	}
	
	static function comecaCom($str, $comeco) {
		return(substr($str, 0, strlen($comeco)) == $comeco);
	}
	
	static function testa($v1, $v2, $comparacao) {
		switch($comparacao) {
			case '=': return(in_array($v1, $v2));
			case '>': return($v1 >  array_shift($v2));
			case '<': return($v1 <  array_shift($v2));
			case '!': return($v1 != array_shift($v2));
			case '&': return($v1 &  array_shift($v2));
			
			case 'incsv': return(array_intersect($v2, explode(',', $v1)));
		}
	}
	
	static function separaPorVirgula($array, $atr='') {
		$ret = '';
		if(is_array($array) && count($array) > 0) {
			foreach($array as $a) {
				if(!empty($ret)) $ret .= ',';
				if(empty($atr))  $ret .= $a;
				else             $ret .= $a->$atr;
			}
		}
		return $ret;
	}
	
	static function formataSegundos($segundos) {
		if(!$segundos) return '0:00';
		
		$minutos = floor($segundos / 60);
		if($minutos > 0) {
			$segundos -= ($minutos * 60);
			if($segundos < 10) $segundos = "0$segundos";
			$horas = floor($minutos / 60);
			if($horas > 0) {
				$minutos -= ($horas * 60);
				if($minutos < 10) $minutos = "0$minutos";
				return "$horas:$minutos:$segundos";
			} else {
				return "$minutos:$segundos";
			}
		} else {
			return ($segundos < 10) ? "0:0$segundos" : "0:$segundos";
		}
	}
	
	/*
	static function procuraNomeFilaPorCanal($canal)
	{
		global $listaIdChamadaFila;
		$aux =& $listaIdChamadaFila;
		while($aux) {
			if($aux->canal == $canal) break;
			$aux =& $aux->prox;
		}
		return $aux;
	}

	static function pegaChanDoPacote($pacote, $tipo='Channel') {
		list($sip, $d) = explode("-", $pacote->getAtr($tipo));
		return $sip;
	}
	
	static function comecaCom($str, $comeco) {
		return(substr($str, 0, strlen($comeco)) == $comeco);
	}
	
	static function tiraEspacosDuplicados($str) {
		$ret = "";
		foreach(explode(" ", $str) as $pal) {
			if(strlen($pal)) {
				if(!empty($ret)) $ret .= " ";
				$ret .= $pal;
			}
		}
		return $ret;
	}
	
	static function pegaPalavraAnterior($palavras, $procura) {
		$ret = false;
		for($c=1; $c<count($palavras); $c++) {
			if(Util::comecaCom($palavras[$c], $procura)) {
				$ret = $palavras[$c - 1];
				break;
			}
		}
		return $ret;
	}
	
	static function pegaPalavraPorPrefixo($palavras, $prefixo) {
		$ret = false;
		for($c=1; $c<count($palavras); $c++) {
			if(Util::comecaCom($palavras[$c], $prefixo)) {
				$ret = $palavras[$c];
				break;
			}
		}
		return $ret;
	}
	
	static function limpaNomeCanal($nomeCanal) {
		return str_replace(array("/", ",", "-"), "", $nomeCanal);
	}
	*/
}
?>