<?php
	include(''.'/usr/lib/telefoniaip/modulos/Fila/sistemaCC/classes/classeUtil.php');
	include(''.'/usr/lib/telefoniaip/modulos/Fila/sistemaCC/classes/classeSharedMem.php');
	include(''.'/usr/lib/telefoniaip/modulos/Fila/sistemaCC/classes/model/classeShMemObj.php');
	include(''.'/usr/lib/telefoniaip/modulos/Fila/sistemaCC/classes/model/classeAgente.php');
	include(''.'/usr/lib/telefoniaip/modulos/Fila/sistemaCC/classes/model/classeFilaCC.php');
	include(''.'/usr/lib/telefoniaip/modulos/Fila/sistemaCC/classes/model/classeTotais.php');
	
	define('ID_SHMEM_AGS',   0xf0f1);
	define('ID_SHMEM_FILAS', 0xf0f2);
	define('ID_SHMEM_FLAGS', 0xf0f3);
	
	define('MAX_OBJS',      1024);
	define('MEM_POR_OBJ',   4096);
	
	session_start(); // Manter a sess�o aberta o m�nimo poss�vel
	$idSup    = $_SESSION['agenteLogado']->id;
	$ramalSup = $_SESSION['agenteLogado']->ramal;
	session_write_close();
	
	if(empty($idSup) || empty($ramalSup)) {
		echo "Nao logado\n";
		die;
	}
	
	$memAgs = new SharedMem(ID_SHMEM_AGS, 'Agente');
	$sup = $memAgs->get('id', $idSup);
	if(!is_a($sup, 'Agente')) {
		echo "Nao logado 2\n";
		$memAgs->shut();
		die;
	}
	if($sup->codstatus <= 0) {
		echo "Nao logado 3\n";
		$memAgs->shut();
		die;
	}
	
	$memFlags = @shmop_open(ID_SHMEM_FLAGS, 'w', 0, 0);
	if (!$memFlags) {
		echo "Erro ao abrir SHMEM de FLAGS\n";
		$memAgs->shut();
		die;
	}
	
	// Configura o Header e os limites dos envios
    $delimiter = 'kanduskeS123kadunskeS';
    header('Content-type: multipart/x-mixed-replace;boundary="'.$delimiter.'"');
    $header   = "Content-type: text/html\n\n";
    $boundary = "--{$delimiter}\n\n";
    $footer   = "--{$delimiter}--\n\n";
    if (ob_get_level() == 0) ob_start();
	
	// Variaveis do Loop
	$memFilas = new SharedMem(ID_SHMEM_FILAS, 'FilaCC');
	$agora    = time();
    $timeout  = $agora + 45; // 45s por requisi��o
    $refresh  = 0;
    while($sup->codstatus > 0 && $agora < $timeout) {
    	// Verifica a mem�ria de flags de altera��o e o tempo minimo de refresh
    	$supOK = false;
    	$idFilaSelOld = $sup->idfilasel;
    	if( shmop_read($memFlags, $ramalSup, 1) == '1' || $agora > $refresh ) {
    		$refresh = $agora + 5; // 5s para refresh
    		shmop_write($memFlags, '0', $ramalSup);			// Zera a flag
    		
    		echo $header;
    		
			$idFilaSel = ($sup->idfilasel > 0) ? $sup->idfilasel : explode(',', $sup->idsfilas);
			if(strstr($idFilaSel, ',')) $idFilaSel = explode(',', $idFilaSel);
			$agentes = $memAgs->getObjs('idsfilas', $idFilaSel, 'incsv');
			foreach($agentes as $ag) {
				$ag->tempostatus = $agora - $ag->tempostatus;
				if($ag->id == $idSup) {
					$sup = $ag;
					$supOK = true;
				}
				echo "$ag\n";
			}
			
			foreach($memFilas->getObjs('id', $idFilaSel) as $fila)
				echo "$fila\n";

			echo new Totais($agentes) . "\n";
			
        	echo $boundary;
        	ob_flush();
        	flush();
       	}
       	
		sleep(1);
		$agora = time();
		
		if(!$supOK)
			$sup = $memAgs->get('id', $idSup);
		
		if($idFilaSelOld != $sup->idfilasel) {
			// For�ar o refresh
			$refresh  = 0;
		}
    }
    shmop_close($memFlags);
    echo $header . '_EOR_' . $footer;
    ob_end_flush();
?>