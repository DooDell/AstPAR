<?php
	/**
	 * Script chamado na inicializacao da janelaAgente, para popular os dados iniciais
	 */
	include('comandos.php');
	
	session_start(); // Manter a sess�o aberta o m�nimo poss�vel
	$id = $_SESSION['agenteLogado']->id;
	session_write_close();
	
	foreach(buscaDadosAgente($id) as $obj)
		echo "$obj\n";
?>
