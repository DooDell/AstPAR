<?
	session_name('popupTabulacaoInicial');
	include(''.'/usr/lib/telefoniaip/modulos/Fila/sistemaCC/cliente/comandos.php');
	
	// REQUISITO da URL....: url    = endereco do frame interno
	// OPCIONAL  da URL....: alerta = msg de alerta
	
	// Substitui��es na URL: num=%NUM%  name=%NAME%  idag=%IDAG%  fila=%FILA%  %CHANVARS%
	$frame  = $_REQUEST['url'];
	$alerta = $_REQUEST['alerta'];
	$alertaJS = ($_REQUEST['alertaJS'] == 'true');
	
	$titulo = $_REQUEST['titulo'];
	if(empty($titulo)) $titulo = '.: Popup Inicial :.';
	
	$tamanho = $_REQUEST['tamanho'];
	if(empty($tamanho) || !strstr(',', $tamanho)) $tamanho = '800,600';
	list($tamX, $tamY) = explode(',', $tamanho);
	if($tamX < 100) $tamX = 100;
	if($tamY < 100) $tamY = 100;
	
	$corFundo = $_REQUEST['corFundo'];
	if(empty($corFundo)) $corFundo = "ddddff";
	
	$clTR = $_REQUEST['tipoAlerta'];
	if(empty($clTR)) $clTR = "Normal";
?>
<html>
	<head>
		<title><? echo $titulo ?></title>
		<style type="text/css">
			tr.Normal { background-color: "#ccccff"; }
			tr.Alerta { background-color: "#ffdddd"; }
			tr.Erro   { background-color: "#ff6666"; }
		</style>
		<script>
			self.resizeTo(<? echo "$tamX, $tamY"; ?>);
<?	if($alertaJS) { ?>
			window.onLoad = alert('<?echo $alerta;?>');
<?	} ?>
		</script>
	</head>
	<body bgcolor="#<? echo $corFundo; ?>">
		<table width="100%">
			<tr align="center" class="<? echo $clTR; ?>"><td><? echo $alerta; ?></td></tr>
			<tr><td><iframe src="<? echo $frame; ?>" width="100%" height="<? echo $tamY-200; ?>px"></iframe></td></tr>
		</table>
	</body>
</html>
