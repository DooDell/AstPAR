<?php
	include('comandos.php');
	
	session_start(); // Manter a sess�o aberta o m�nimo poss�vel
	$agente = loginOK();
	$agente->telefone = $_REQUEST['telefone'];
	$agente->mobilidd = true;
	$_SESSION['agenteLogado'] = $agente;
	
	header("location:popupagente.php");
?>
