<?php
	include(''.'/usr/lib/telefoniaip/modulos/Fila/sistemaCC/classes/classeUtil.php');
	include(''.'/usr/lib/telefoniaip/modulos/Fila/sistemaCC/classes/classeSharedMem.php');
	include(''.'/usr/lib/telefoniaip/modulos/Fila/sistemaCC/classes/model/classeShMemObj.php');
	include(''.'/usr/lib/telefoniaip/modulos/Fila/sistemaCC/classes/model/classeAgente.php');
	include(''.'/usr/lib/telefoniaip/modulos/Fila/sistemaCC/classes/model/classeFilaCC.php');
	
	define('ID_SHMEM_AGS',   0xf0f1);
	define('ID_SHMEM_FILAS', 0xf0f2);
	define('ID_SHMEM_FLAGS', 0xf0f3);
	
	define('MAX_OBJS',      1024);
	define('MEM_POR_OBJ',   4096);
	
	session_start(); // Manter a sess�o aberta o m�nimo poss�vel
	$idAg    = $_SESSION['agenteLogado']->id;
	$ramalAg = $_SESSION['agenteLogado']->ramal;
	session_write_close();
	
	if(empty($idAg) || empty($ramalAg)) {
		echo "Nao logado\n";
		die;
	}
	
	$memAgs = new SharedMem(ID_SHMEM_AGS, 'Agente');
	$agente = $memAgs->get('id', $idAg);
	if(!is_a($agente, 'Agente')) {
		echo "Nao logado 2\n";
		$memAgs->shut();
		die;
	}
	if($agente->codstatus <= 0) {
		echo "Nao logado 3\n";
		$memAgs->shut();
		die;
	}
	
	$memFlags = @shmop_open(ID_SHMEM_FLAGS, 'w', 0, 0);
	if (!$memFlags) {
		echo "Erro ao abrir SHMEM de FLAGS\n";
		$memAgs->shut();
		die;
	}
	
	// Configura o Header e os limites dos envios
	$delimiter = 'kanduske123kadunske';
	header('Content-type: multipart/x-mixed-replace;boundary="'.$delimiter.'"');
	$header   = "Content-type: text/html\n\n";
	$boundary = "--{$delimiter}\n\n";
	$footer   = "--{$delimiter}--\n\n";
	if (ob_get_level() == 0) ob_start();

	// Variaveis do Loop
	$memFilas = new SharedMem(ID_SHMEM_FILAS, 'FilaCC');
	$agora    = time();
	$timeout  = $agora + 45; // 45s por requisi��o
	$refresh  = 0;
	while($agente->codstatus > 0 && $agora < $timeout) {
		// Verifica a mem�ria de flags de altera��o e o tempo minimo de refresh
		if( shmop_read($memFlags, $ramalAg, 1) == '1' || $agora > $refresh ) {
			$refresh = $agora + 5;                   // 5s para refresh
			shmop_write($memFlags, '0', $ramalAg);   // Zera a flag
			
			echo $header;
			
			// Enviar info do agente
			$agente = $memAgs->get('id', $idAg);
			$agente->tempostatus = $agora - $agente->tempostatus;
			echo "$agente\n";
			
			// Enviar info das filas
			foreach($memFilas->getObjs('id', explode(',', $agente->idsfilas)) as $fila)
				echo "$fila\n";
			
			echo $boundary;
			ob_flush();
			flush();
		}
		sleep(1);
		$agora = time();
	}
	// Finaliza a reguisicao
	echo $header . '_EOR_' . $footer;
	ob_end_flush();
	
	// Fecha as memorias abertas
	shmop_close($memFlags);
	$memFilas->shut();
	$memAgs->shut();
?>