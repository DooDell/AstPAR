<?
	session_name('popupTabulacao');
	include(''.'/usr/lib/telefoniaip/modulos/Fila/sistemaCC/cliente/comandos.php');
	
	insereTabulacao($_REQUEST['idfila'], $_REQUEST['idag'], $_REQUEST['uid'], $_REQUEST['item'], $_REQUEST['pausaAuto'], $_REQUEST['ehAtz']);
?>
OK
<script type="text/javascript">
	function fecha() {
		tipoJanelaOrigem = window.opener.document.getElementById('ehHistDia');
		if(tipoJanelaOrigem != null && tipoJanelaOrigem.value == 'janelaHistDia') {
			// Recarregar a janela de Historico do Dia
			window.opener.location.href = window.opener.location.href;
			window.opener.focus();
		}
		window.close();
	}
	setTimeout("fecha()", 250);
</script>