<?php
	include(''.'/usr/lib/telefoniaip/modulos/Fila/sistemaCC/constantes.php');
	
	$EXEC = ($argv[1] == 'EXEC');
	$VER  = ($argv[1] == 'VER');
	
	// Buscar agentes logados no sistemaCC
	$memAgs = new SharedMem(ID_SHMEM_AGS, 'Agente');
	$agsCC = $memAgs->getObjs('codstatus', '0', '>');

	// Conectar AMI
	$errno = $errstr = null;
	$connAMI = @fsockopen('localhost', 5038, &$errno, &$errstr, 4);
	if(!$connAMI) {
		echo "ERRO:21 MSG:ServidorAsteriskNaoResponde\n";
		return 21;
	} else {
		fputs($connAMI, "Action: login\r\nEvents: off\r\nUsername: admin\r\nSecret: sapo\r\n\r\n");
		do { $r = fgets($connAMI); } while($r != "\r\n");		
	}
	
	// Buscar dados dos canais ativos no asterisk
	$canaisAtv = array();
	foreach(readAMICmdOutput("Action: Status\r\n\r\n") as $lin) {
		if(substr($lin, 0, 9) == 'Channel: ')
			$canaisAtv[] = substr($lin, 9);
	}
	
	if(count($canaisAtv) > 0) {
		$agsPresos = array();
		foreach($canaisAtv as $canal) {
			$tel = substr($canal, 0, strrpos($canal, '-'));
			foreach($agsCC as $id => $ag) {
				if($ag->telefone == $tel) {
					if($VER) {
						$nome   = $ag->getNome();
						$estado = $_nomeEstado[$ag->codstatus];
						echo "MSG:02 Agente[$estado] $nome => Canal: $canal\n";
					}
					if($ag->codstatus == 1 || $ag->codstatus >= 100)
						$agsPresos[$id] = $canal;
				}
			}
		}
		
		if(count($agsPresos) > 0) {
			// Atualizar o estado dos ags ap�s 3 segundos
			sleep(3);
			$agsCC = $memAgs->getObjs('codstatus', '0', '>');
			
			foreach($agsPresos as $id => $canal) {
				$ag = $agsCC[$id];
				if($ag->codstatus == 1 || $ag->codstatus >= 100) {
					$nome   = $ag->getNome();
					$estado = $_nomeEstado[$ag->codstatus];
					echo "MSG:10 Agente[$estado] $nome => Canal: $canal <- NAO DEVERIA ESTAR EM CHAMADA! (Assumindo Canal Preso)\n";
					if($EXEC) {
						echo "MSG:11  -- Enviando comando de Hangup: ";
						echo sendAMICmd("Action: Hangup\r\nChannel: $canal\r\n\r\n") . "\n";
					}
				}
			}
		}
	} else
		echo "MSG:13 Nenhum canal ativo.\n";
	
	// Fechar a memoria de agentes
	$memAgs->shut();
	    
	// Fechar conn AMI
	fputs($connAMI, "Action: Logoff\r\n\r\n");
	do { $r = fgets($connAMI); } while($r != "\r\n");
	fclose($connAMI);

// funx aux --------------------------------------------------------	
function readAMICmdOutput($cmd) {
	global $connAMI;
	$ret = array();
	$scan = 1;
	
	fputs($connAMI, $cmd);
	while(true) {
		$r = substr(fgets($connAMI), 0, -2);
		if($r == 'Message: Channel status will follow' || $r == 'Event: Status') $scan++;
		
		if(!empty($r)) $ret[] = $r;
		else           $scan--;
		
		if($scan < 1) break;
	}
	return $ret;
}

function sendAMICmd($strAMI) {
	global $connAMI;

	fputs($connAMI, $strAMI);
	$ret = 'Sem Message';
	while(true) {
		$lin = fgets($connAMI);
		if($lin == "\r\n") break;
		if(strstr($lin, 'Message')) $ret = substr($lin,0,-2);
	}
	return $ret;
}
?>