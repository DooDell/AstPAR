<?php
/**
 * Classe respons�vel por enviar comandos pelo AMI em uma conexao exclusiva.
 * 
 * Os comandos podem ser tratados de forma sincrona ou assincrona. Em geral comandos
 * que tem respostas mais demoradas s�o enviados assincronamente para n�o impactarem
 * na execu��o do controleCC
 * @author Gabriel Ortiz
 */
class ComandosAMI {
	var $loginOK;
	private $AMI, $pacotesUltCmd;
	
	/**
	 * Construtor recebe um array de configura��o com os seguintes itens:
	 * hostAMI, userAMI, passAMI, eventosAMI('on' ou 'off')
	 * @param Array $config
	 */
	function ComandosAMI($config) {
		$this->loginOK = false;
				
		$this->AMI = new AMI($config, 'Comandos');
		if($this->AMI->pacoteLogin === false)
			return;

		$this->loginOK = true;
	}
	
	/**
	 * Fun��o chamada pelo loop principal do controleCC para verificar as respostas
	 * de comandos assincronos
	 */
	public function processa($to=0.02) {
		return $this->recebeEventos($to, true);
	}

	/**
	 * M�todo respons�vel por dar prosseguimento nas a��es assincronas, conforme o
	 * parametro "ActionID". Chamado pelo m�todo "processa" e pelo "enviaComando"
	 * @param PacoteAMI $pacote - lista linkada de pacotes para processar
	 */
	public function processaPacotes($pacote) {
		$atzSups = false;
		
		if(!$pacote->vazio()) {
			$aux =& $pacote;
			while($aux) {
				$actID = $aux->getAtr('ActionID');
				if($actID != null && substr($actID,0,2) == '__') {
					$params = explode('-', substr($actID, 2));
					$acao   = array_shift($params);
					$idAg   = array_shift($params);
					
					$agente = ControleCC::$memAgs->get('id', $idAg);
					if(!is_a($agente, 'Agente')) {
						ControleCC::loga(LOG_CRITICO, "Continuacao de acao de Agente \033[35;1mRECUSADO\033[0m - ID do Agente($idAg) inv�lido");
						continue;
					}
					
					$nomeAgente = $agente->getNome();
					switch($acao) {
						case 'sync_ag':
							ControleCC::loga(LOG_DEBUG2, "Continuar login do agente $nomeAgente");
							$agente->login2();
							break;
						
						case 'pausa_login':
							ControleCC::loga(LOG_DEBUG2, "Continuar despausa do agente $nomeAgente");
							$agente->login3();
							break;
						
						case 'pausa_estado':
							ControleCC::loga(LOG_DEBUG2, "Continuar Pausa ESTADO do agente $nomeAgente");
							$estadoNovo = array_shift($params);
							$agora      = array_shift($params);
							$filas      = array_shift($params);
							if($agente->mudaEstado2($estadoNovo, $agora, $filas) === true) {
								$atzSups = true;
								$nomeSts = ControleCC::getNomeStatus($agente->codstatus);
								ControleCC::loga(LOG_NORMAL, "Status de $nomeAgente alterado com sucesso para [$nomeSts](ASYNC)");
							}
							break;
						
						case 'dbPut_login':
							ControleCC::loga(LOG_AVISO, "DBPUT: $nomeAgente");
							var_dump($aux);
							break;
					}
				}
				
				$aux = $aux->prox;
			}
		}
		
		return $atzSups;
	}
	
	/**
	 * M�todo getter para buscar os pacotes recebidos pelo ultimo comando (sincrono) enviado
	 */
	public function getPacotesUltCmd() {
		return $this->pacotesUltCmd;
	}
	
	function enviaComando($cmd, $params = array(), $to=0.02) {
		$actID = $this->AMI->getActionID($params);
		if($this->AMI->enviaComandoAsync($cmd, $params) !== true)
			ControleCC::loga(LOG_CRITICO, "Erro ao enviar comando $cmd");
		
		if($to == 'async') {
			ControleCC::loga(LOG_DEBUG2, "%%% Enviado comando [$cmd - ACTID:$actID] ASYNC");
			return true;
		}
		
		$this->pacotesUltCmd = $this->recebeEventos($to);
		$ret = ($this->pacotesUltCmd !== false) ? AMI::comandoOK($this->pacotesUltCmd, $actID) : false;
		ControleCC::loga(LOG_DEBUG2, "%%% Enviado comando [$cmd - ACTID:$actID] -> resposta: [$ret]");
		return $ret;
	}
	
	/**
	 * Recebe as respostas dos comandos enviados
	 * Retorna os pacotes recebidos, ou um boleano indicando atualizacao de supervisores,
	 * conforme o parametro $flagAtz
	 * @param int  $to
	 * @param bool $flagAtz
	 */
	function recebeEventos($to=0, $flagAtz=false) {
		$pacoteRecebido = $this->AMI->recebeEventos($to);
		if($pacoteRecebido === false) {
			ControleCC::loga(LOG_AVISO, "Asterisk desligou/caiu. saindo.");
			ControleCC::$loopPrincipal = 100;
			return false;
		}
		
		$ret = $this->processaPacotes($pacoteRecebido);
		
		return $flagAtz ? $ret : $pacoteRecebido;
	}
		
	function shut() {
		$this->AMI->logoff();
	}
}
?>