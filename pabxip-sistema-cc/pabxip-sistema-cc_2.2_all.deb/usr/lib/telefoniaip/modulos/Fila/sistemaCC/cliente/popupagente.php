<?php
	include('comandos.php');
	
	session_start(); // Manter a sess�o aberta o m�nimo poss�vel
	$agente = loginOK();
	session_write_close();
	
	$totfilas = count(explode(',', $agente->idsfilas)); 
	$tam = 328 + ($totfilas * 21);
 ?>
<script type="text/javascript">
	popup = window.open('janelaAgente.php','agente <?$agente->nome?>','width=582,height=<?echo $tam?>,scrolling=auto,top=100,left=100,scrollbar=no,resizable=no,minimize=no,maximize=no');
	if (window.focus) {popup.focus()}
	window.location = 'login.php';
</script>