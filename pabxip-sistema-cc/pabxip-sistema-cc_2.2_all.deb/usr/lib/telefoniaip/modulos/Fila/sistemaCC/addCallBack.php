#!/usr/bin/php
<?php
	define('ID_MSG_QUEUE', 0xf0f0);
	
	if(!isset($argv[1]) || !isset($argv[2]) || !isset($argv[3]))
		return 10;
		
	$mq_id = msg_get_queue(ID_MSG_QUEUE);
	if (!msg_send ($mq_id, 100, time() . ':ADM:addCallBack:'.$argv[1].':'.$argv[2].':'.$argv[3], false, false, $msg_err))
		return 10;
	
	return 0;
?>