<?
	// Link cadastrado na interface:
	// tabulacao/popup.php?timer=15&idag=%IDAG%&num=%NUM%&fila=%FILA%&uid=%UID%

	session_name('popupTabulacao');
	include(''.'/usr/lib/telefoniaip/modulos/Fila/sistemaCC/cliente/comandos.php');
	
	$tempo = $_REQUEST['timer'];
	if($tempo < 5) $tempo = 5;
	
	$idag     = $_REQUEST['idag'];
	$callerid = $_REQUEST['num'];
	$nomeFila = $_REQUEST['fila'];
	$uniqueid = $_REQUEST['uid'];
	$ehAtz    = isset($_REQUEST['flags']) && (($_REQUEST['flags'] + 0) & FLAG_NAO_TABULADO);
	
	$itens = buscaItensTabulacao($nomeFila);
	//asort($itens);
	
	
	$pausaAutomatica = $itens['PAUSA_AUTO'];
	$idfila          = $itens['ID_FILA'];
	unset($itens['PAUSA_AUTO']);
	unset($itens['ID_FILA']);
?>
<html>
	<head>
		<title>.: Tabula��o - <? echo $nomeFila ?> :.</title>
		<script>
			self.resizeTo(480, screen.availHeight);
			
			function foi() {
				document.dadosPopup.submit();
			}
			
			tempo = <? echo $tempo ?>;
			function atzTimer() {
				tempo--;
				document.getElementById('timer').innerHTML = tempo; //'Fechando em ' + tempo + 's';
				if(tempo > 0) setTimeout("atzTimer()", 1000);
				else          foi();
			}
			setTimeout("atzTimer()", 1000);
		</script>
	</head>
	<body>
		<h2>.: Tabula��o - <? echo $nomeFila ?> :.</h2>
		<form name='dadosPopup' action="insereTab.php">
			<input type='hidden' name='uid' id='uniqueid' value='<? echo $uniqueid ?>' />
			<input type='hidden' name='fila' value='<? echo $nomeFila ?>' />
			<input type='hidden' name='cid'  value='<? echo $callerid ?>' />
			<input type='hidden' name='idag' value='<? echo $idag ?>' />
			<input type='hidden' name='idfila'    value='<? echo $idfila ?>' />
			<input type='hidden' name='pausaAuto' value='<? echo $pausaAutomatica ? '1' : '0' ?>' />
			<input type='hidden' name='ehAtz'     value='<? echo $ehAtz ? '1' : '0' ?>' />
			
			<span style="display:none;"><input type='radio'  name='item' value='0' checked='true' onchange='foi()' /> <b>N�o tabulado</b></span><br>
			<script type="text/javascript">
				function ClicaTexto(id)
				{
					var radiobutton = document.getElementById(id);
					radiobutton.click();
				}
				function MouseOver(span)
				{
					span.style.color = 'white';
					span.style.backgroundColor = '#999999';
					//alert(span.style.backgroundColor);
				}
				function MouseOut(span, cor)
				{
					span.style.color = 'black';
					span.style.backgroundColor = cor;
				}
			</script>
<?
	$i = 1;
	$cor[0] = '#FFFFFF';
	$cor[1] = '#F0F0F0';
	
	foreach($itens as $cod => $desc)
	{
		$k = $i%2;
		echo "<span id = 'span$cod' style='background-color: $cor[$k]' onclick = \"ClicaTexto('radio$cod')\" onMouseOver=\"MouseOver(this)\" onMouseOut=\"MouseOut(this, '$cor[$k]')\"> <input type='radio' id='radio$cod' name='item' value='$cod' onchange='foi()' /> $desc </span> <br>\n";
		$i = $i + 1;
	}

?>
		</form>
		<h3>Fechando em <span id='timer'><? echo $tempo ?></span>s</h3>
	</body>
</html>
