<?
	session_name('popupTabulacao');
	include(''.'/usr/lib/telefoniaip/modulos/Fila/sistemaCC/cliente/comandos.php');
	
	$idag     = empty($_REQUEST['idag']) ? '0' : $_REQUEST['idag'];
	
	$nomeFila = $_REQUEST['fila'];
	if(empty($nomeFila)) {
		echo "Adicione o nome da fila na URL: exemplo: http://www.pabx.exemplo:81/tabulacao/tabulacaoManual?fila=DETRAN";
		die;
	}
	
	$itens = buscaItensTabulacao($nomeFila);
	if($itens === false) {
		echo "Fila inv�lida";
		die;
	}
	
	$pausaAutomatica = $itens['PAUSA_AUTO'];
	$idfila          = $itens['ID_FILA'];
	unset($itens['PAUSA_AUTO']);
	unset($itens['ID_FILA']);
	
	if(!count($itens)) {
		echo "Fila sem itens para tabula��o";
		die;
	}
?>
<html>
	<head>
		<title>.: Tabula��o - <? echo $nomeFila ?> :.</title>
		<script>
			function foi() {
				document.dadosPopup.submit();
			}
		</script>
	</head>
	<body>
		<h2>.: Tabula��o - <? echo $nomeFila ?> :.</h2>
		<form name='dadosPopup' action="insereTab.php">
			<input type='hidden' name='uid' id='uniqueid' value='0' />
			<input type='hidden' name='fila' value='<? echo $nomeFila ?>' />
			<input type='hidden' name='cid'  value='0' />
			<input type='hidden' name='idag' value='<? echo $idag ?>' />
			<input type='hidden' name='idfila'    value='<? echo $idfila ?>' />
			<input type='hidden' name='pausaAuto' value='<? echo $pausaAutomatica ? '1' : '0' ?>' />
			<input type='hidden' name='ehAtz'     value='0' />
			
			<input type='radio'  name='item' value='0' checked='true' onchange='foi()' /> <b>N�o tabulado</b><br>
<?
	foreach($itens as $cod => $desc)
		echo "<input type='radio' name='item' value='$cod' onchange='foi()' /> $desc<br>\n";
?>
		</form>
	</body>
</html>
