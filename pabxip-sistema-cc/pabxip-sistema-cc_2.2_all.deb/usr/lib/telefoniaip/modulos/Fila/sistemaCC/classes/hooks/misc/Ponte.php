<?php
	// Configuracao
	// Porta TCP para utilizar:
	$porta = 13633;
	// IPs credenciados para acesso
	$ipsOK = array(
		'10.100.25.104'
	);
	$dirPipe = '/var/lib/asterisk/pipeMarili/';
	// ------------
	
	// Script ------------------------------------------------------------------
	echo "Abrindo porta $porta.\n";
	if(($sock = @socket_create(AF_INET, SOCK_STREAM, SOL_TCP)) === false) {
		$errNo = socket_last_error();
		echo "Erro1[$errNo] ao criar socket " .socket_strerror($errNo). "\n";
		return 1;
	}
	if(@socket_bind($sock, 0, $porta) === false) {
		$errNo = socket_last_error();
		echo "Erro2[$errNo] ao criar socket " .socket_strerror($errNo). "\n";
		return 2;
	}
	if(@socket_listen($sock) === false) {
		$errNo = socket_last_error();
		echo "Erro3[$errNo] ao criar socket " .socket_strerror($errNo). "\n";
		return 3;
	}
	
	while(true) {
		// Bloqueia o script aqui ate que alguem conecte (1 por vez)
		echo "\n===\nAguardando conexao: ";
		if(($newsock = @socket_accept($sock)) === false) {
			$errNo = socket_last_error();
			echo "Erro4[$errNo] ao aceitar conexao " .socket_strerror($errNo). "\n";
			continue;
		}
		
		// Pega o IP de quem conectou
		socket_getpeername($newsock, $ip);
		if(!in_array($ip, $ipsOK)) {
			echo "IP <$ip> nao autorizado. Desconectando-o.\n";
			socket_write($newsock, "Voce nao esta autorizado a acessar este servidor\n\n");
			socket_close($newsock);
	        continue;
        }
		echo "IP <$ip> conectado.\n";
		
		$msgIdle = true;
		while(true) {
			if($msgIdle) {
				echo "Aguardando comandos ou eventos: ";
				$msgIdle = false;
			}
			
			// Verifica se ha comandos no socket (150ms de timeout)
			$read = array($newsock);
	        if (socket_select($read, $write = NULL, $except = NULL, 0, 100000) > 0) {
				$data = socket_read($newsock, 1024, PHP_NORMAL_READ);
				if ($data === false) {
					echo "IP <$ip> desconectou.\n";
					break;
				}
				
				$data = trim($data);
				if(trataComando($data, $newsock)) {
					echo "IP <$ip> cancelou.\n";
					socket_close($newsock);
					break;
				}
				$msgIdle = !empty($data);
	        }
	        
	        // Verifica se ha algum evento do asterisk
			if(is_dir($dirPipe)) {
			    if($dh = opendir($dirPipe)) {
			        while(($file = readdir($dh)) !== false) {
			        	$out = file_get_contents($dir.$file);
			            echo "Evento asterisk recebido: [$out] -> enviando\n";
			        	socket_send($newsock, $out, strlen($out), 0);
			        	usleep(1000); // 1ms
			        	unlink($dir.$file);	// Remover o arquivo
			        	$msgIdle = true;
			        }
			        closedir($dh);
			    }
			}
		}
	}
	socket_close($sock);
	
	
	// =========================
	function trataComando($data, $newsock) {
		// Tratar o comando recebido
		if(!empty($data)) {
			if(substr($data, -1) != '#') {
				echo "Comando [$data] invalido (deve terminar com '#')\n";
			} else {
				$data = substr($data, 0, -1); // Remover o '#' do final
				
				echo "Comando recebido: [$data]\n";
				if($data == 'QUIT') return true;
				
				if(substr($data, 0, 5) == 'LOGON') {
					$ramal = substr($data, 5);
					if(strstr($ramal, ';')) list($ramal, $tel) = explode(';', $ramal);
					else $tel = $ramal;
					$msg = "Logar $ramal em SIP/$tel";
					$cmd = "login:SIP/$tel";
				} else if(substr($data, 0, 6) == 'LOGOFF') {
					$ramal = substr($data, 6);
					$msg = "DesLogar $ramal";
					$cmd = "logoff";
				} else if(substr($data, 0, 6) == 'SUSPON') {
					$ramal = substr($data, 6);
					if(strstr($ramal, ';')) list($ramal, $cod) = explode(';', $ramal);
					else $cod = 100;
					$msg = "Pausar $ramal - TipoPausa($cod)";
					$cmd = "mudaStatus:$cod";
				} else if(substr($data, 0, 7) == 'SUSPOFF') {
					$ramal = substr($data, 7);
					$msg = "DesPausar $ramal";
					$cmd = "mudaStatus:1";
				} else {
					$msg = "Comando [$data] desconhecido"; // MSG padrao
					$cmd = '';
				}
				
				echo ">>> $msg\n\n";
				if(!empty($cmd))
					enviaComando($ramal, $cmd);
			}
		}
		return false;
	}
	
	function refreshCodUsu() {
		global $usuarios;
		
		$bdcon = pg_connect(getAstPgStrConn());
		if(pg_connection_status($bdcon) != PGSQL_CONNECTION_OK) return false;
		
		$res = pg_query($bdcon, 'SELECT id,ramal FROM usuario');
		while($registro = pg_fetch_assoc($res))
			$usuarios[$registro['ramal']] = $registro['id'];
		pg_close($bdcon);
	}
	
	function buscaIdPorRamal($ramal) {
		global $usuarios;
		if(!isset($usuarios[$ramal])) {
			refreshCodUsu();
			if(!isset($usuarios[$ramal])) {
				echo "EE: Usuario ramal $ramal nao encontrado!\n";
				return false;
			}
		}
		return $usuarios[$ramal];
	}
	
	function enviaComando($ramal, $cmd) {
		if(($idUsu = buscaIdPorRamal($ramal)) === false)
			return false;
		$mq_id = msg_get_queue(0xf0f0);
		echo("+++ Enviando comando ao controleCC: [$cmd]\n");
		$msg = time().":$idUsu:$cmd";
		if(msg_send ($mq_id, 1, $msg, false, false, $msg_err='') === false) {
			$mq_id = msg_get_queue(ID_MSG_QUEUE);	// Init da fila de mensagens
			return msg_send ($mq_id, 100, $msg, false, false, $msg_err='');
		}
		return true;
	}
	
	function getAstPgStrConn() {
		$atrsOK = array('dbname' => 'dbname', 'dbhost' => 'host', 'dbuser' => 'user', 'dbpass' => 'password');
		$ret = '';
		$lins = file('/etc/asterisk/res_pgsql.conf', FILE_IGNORE_NEW_LINES);
		if($lins) {
			foreach($lins as $lin) {
				if(strstr($lin, '=')) {
					list($ch, $val) = explode('=', $lin);
					$ch  = trim($ch);
					$val = trim($val);
					if(in_array($ch, array_keys($atrsOK))) {
						$atr = $atrsOK[$ch];
						$ret .= "$atr=$val ";
					}
				}
			}
		}
		return trim($ret);
	}
?>