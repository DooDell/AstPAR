<?php
	define('BASE_DIR', '/usr/lib/telefoniaip/modulos/Fila/sistemaCC/');
	define('MAX_KEEPALIVE', 4);
	
	// Constantes
	define('ID_MSG_QUEUE',   0xf0f0);
	
	define('ID_SHMEM_AGS',   0xf0f1);
	define('ID_SHMEM_FILAS', 0xf0f2);
	define('ID_SHMEM_FLAGS', 0xf0f3);
	
	define('MAX_OBJS',      1024);
	define('MEM_POR_OBJ',   4096);
	
	define('FUNC_AGENTE',     256);
	define('FUNC_SUPERVISOR', 512);
	define('FUNC_SEL_PA',     2048);
	define('FUNC_DESABILITADO',   65536);
	
	// LEMBRAR DE ALTERAR EM /usr/lib/telefoniaip/includePrincipal.php QUANDO ALTERAR AQUI!!!!!!!!!!
	define('FLAG_FILA_PAUSA_AUTO',   4096);
	define('FLAG_NAO_TABULADO' , 1);
	
	define('DESLOGADO',  0);
	define('DISPONIVEL', 1);
	define('CHAMANDO',   2);
	define('ATENDENDO',  3);
	define('SAINTE',     4);
	define('DISCANDO',   5);
	define('ENTRANTE',   6);
	define('SUPLOGADO',  10);
	define('PAUSA',      100);
	define('PAUSA_AUTO', 199);
	define('INDISP',     200);
	
	$_nomeEstado = array(
			DESLOGADO  => 'DESLOGADO ',
			DISPONIVEL => 'DISPONIVEL',
			CHAMANDO   => 'CHAMANDO  ',
			ATENDENDO  => 'ATENDENDO ',
			SAINTE     => 'SAINTE    ',
			DISCANDO   => 'DISCANDO  ',
			ENTRANTE   => 'ENTRANTE  ',
			SUPLOGADO  => 'SUPLOGADO ',
			PAUSA      => 'PAUSA     ',
			PAUSA_AUTO => 'PAUSA_AUTO',
			INDISP     => 'INDISP    '
		);
	
	define('MAX_CALLBACK_FILA', 64);
	
	function __autoload($nomeDaClasse) {
		if(file_exists(BASE_DIR . "classes/classe$nomeDaClasse.php"))
		  require_once(BASE_DIR . "classes/classe$nomeDaClasse.php");
		else if(file_exists(BASE_DIR . "classes/model/classe$nomeDaClasse.php"))
		       require_once(BASE_DIR . "classes/model/classe$nomeDaClasse.php");
		else if(file_exists(BASE_DIR . "classes/hooks/classe$nomeDaClasse.php"))
		       require_once(BASE_DIR . "classes/hooks/classe$nomeDaClasse.php");
		else 
			return false;
	}
	
	function __DBG($msg) {
		system("echo '$msg' >> /tmp/DBG");
	}
?>