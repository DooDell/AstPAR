<?php
	include('comandos.php');
	
	session_start(); // Manter a sess�o aberta o m�nimo poss�vel
	$idAg = $_SESSION['agenteLogado']->id;
	session_write_close();
	
	if($idAg > 0) {
		$ag = buscaDadosAgente($idAg, true);
		echo ($ag->codstatus === 0) ? '0' : $ag->codstatus;
	} else
		echo '0';
?>
