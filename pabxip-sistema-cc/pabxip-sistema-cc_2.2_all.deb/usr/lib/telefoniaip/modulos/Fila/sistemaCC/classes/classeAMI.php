<?php
/**
 * Classe para comunica��o com o AMI (Asterisk Manager Interface)
 * @author Gabriel Ortiz
 */
class AMI
{
	private $SOCKET = null, $DEBUG, $actID = 1000, $nomeDBG;
	public $conectado = false, $pacoteLogin = null;

	/**
	 * Construtor recebe um array de configura��o com os seguintes itens:
	 * hostAMI, userAMI, passAMI, eventosAMI('on' ou 'off'), tentativasConnAMI(default 4).
	 * Efetua o login no AMI.
	 * @param Array  $config
	 * @param String $nomeDBG - String de identifica��o desta conexao AMI nos logs
	 */
	public function AMI($conf, $nomeDBG='') {
		$this->DEBUG   = true;
		$this->nomeDBG = $nomeDBG;
		$this->eventos = (isset($conf['eventosAMI']) && $conf['eventosAMI'] == 'off') ? false : true;
		
		$tents = 0;
		$pacote = null;
		$maxTents = (isset($conf['tentativasConnAMI']) && $conf['tentativasConnAMI'] > 0) ? $conf['tentativasConnAMI'] : 4;
		while($tents++ < $maxTents) {
			$this->pacoteLogin = $this->login($conf);
			if($this->pacoteLogin !== false) break;
			sleep(1);
		}
	}
	
	public function debugMsg($msg) {
		if($this->DEBUG) ControleCC::loga(LOG_DEBUG1, $this->nomeDBG . "AMI> $msg");
	}

	/**
	 * Efetua o login no AMI com os parametros passados para o construtor
	 */
	private function login($conf) {
		if(!isset($conf['hostAMI']) || !isset($conf['userAMI']) || !isset($conf['passAMI'])) {
			$this->debugMsg('Faltam parametros para o login no AMI');
			return false;
		}
		
		if(($this->SOCKET = socket_create(AF_INET, SOCK_STREAM, SOL_TCP)) < 0) {
			$this->debugMsg('Impossivel criar socket');
			return false;
		}
		
		$portaAMI = (isset($conf['portAMI']) && is_numeric($conf['portAMI'])) ? $conf['portAMI'] : 5038;
		if(!@socket_connect($this->SOCKET, $conf['hostAMI'], $portaAMI)) {
			$this->debugMsg('Impossivel conectar ao Asterisk AMI');
			return false;
		}
			
		if ($this->SOCKET == false) {
			$this->debugMsg("Impossivel conectar ao asterisk manager");
			return false;
		}
		
		// Espera chegarem dados no socket
		while(!$this->temDadosNoSocket()) {}
		
		// Le todos os dados iniciais enviados pelo Asterisk para o buffer
		$buffer = $this->recebeBuffer();

		if ($buffer === false || !stristr($buffer, 'Asterisk Call Manager')) {
			$this->debugMsg('String de identificacao do AMI nao encontrada');
			$this->logoff();
			return false;
		}
		
		$actID = $this->actID;
		$pacote = $this->enviaComando('Login', array(
				'Username' => $conf['userAMI'],
				'Secret'   => $conf['passAMI'],
				'Events'   => ($this->eventos  ? 'On' : 'Off')
			));
			
	    if (!AMI::comandoOK($pacote, $actID)) {
			$this->debugMsg('Falha no login. Verifique os dados de usuario e senha.');
			$this->logoff();
	        return false;
	    }
		        
		$this->conectado = true;
		$this->debugMsg('Conexao com o AMI bem sucedida.');
		
		return $pacote;
	}

	/**
	 * Desloga do AMI e fecha o SOCKET de rede
	 */
	public function logoff() {
		$ret = true;
		if(is_resource($this->SOCKET)) {
			if($this->conectado)
				$ret = $this->enviaComando('Logoff');
			@socket_shutdown($this->SOCKET, 2);
			@socket_close($this->SOCKET);
		}
		return $ret;
	}
	
	/**
	 * Recebe uma lista linkada de pacotes e um ActionID. Procura pelo ActionID
	 * nos pacotes da lista e testa o atributo 'Response' procurando por 'Success'
	 * @param PacoteAMI $pacote
	 * @param String    $actID
	 */
	static function comandoOK($pacote, $actID) {
		$aux =& $pacote;
		while($aux) {
			if($aux->getAtr('ActionID') == $actID) {
				if($aux->getAtr('Response') == 'Success') return true;
				else {
					$msg = $aux->getAtr('Message');
					return (empty($msg)) ? $aux. '' : $msg;
				}
			}
			$aux = $aux->prox;
		}
		return false;
	}
	
	/**
	 * Busca o ActionID "vigente" do pacote. Procura no array de parametros pelo
	 * atributo ActionID e caso n�o encontre devolve o ActionID default da classe
	 * @param Array $params - Atributos do pacote
	 */
	public function getActionID($params=array()) {
		if(isset($params['ActionID'])) return $params['ActionID'];
		return $this->actID;
	}
	
	/**
	 * Envia um comando pelo AMI e aguarda pela resposta
	 * @param String $acao
	 * @param Array  $params
	 * @param int    $to
	 */
	public function enviaComando($acao, $params = array(), $to=0.02) {
		$cmd = "Action: $acao\r\n";
		$temActID = false;
		foreach($params as $chave => $valor) {
			if(substr($chave, 0, 8) == 'Variable') $chave = 'Variable';
			else if($chave == 'ActionID') $temActID = true;
			$cmd .= "$chave: $valor\r\n";
		}
		if(!$temActID)
			$cmd .= 'ActionID: ' .$this->actID++. "\r\n";
		$cmd .= "\r\n";
		socket_write($this->SOCKET, $cmd);
		$pacote = $this->recebeEventos($to);
		if($acao == 'Logoff' && $pacote === false)
			$pacote = new PacoteAMI(array('Response' => 'Goodbye', 'Message' => 'Thanks for all the fish.'));
		return $pacote;
	}
	
	/**
	 * Envia um comando pelo AMI sem aguardar pela resposta
	 * @param String $acao
	 * @param Array  $params
	 */
	public function enviaComandoAsync($acao, $params = array()) {
		$cmd = "Action: $acao\r\n";
		$temActID = false;
		foreach($params as $chave => $valor) {
			if(substr($chave, 0, 8) == 'Variable') $chave = 'Variable';
			else if($chave == 'ActionID') $temActID = true;
			$cmd .= "$chave: $valor\r\n";
		}
		if(!$temActID)
			$cmd .= 'ActionID: ' .$this->actID++. "\r\n";
		$cmd .= "\r\n";
		
		return (socket_write($this->SOCKET, $cmd) !== false);
	}
	
	/**
	 * Retorna true ou a mensagem de erro (Message), baseado no atributo Response
	 */
	static function verificaStatus($pacote) {
		if($pacote->getAtr('Response') == 'Success')
			return true;
		else {
			$msg = $pacote->getAtr('Message');
			return (empty($msg)) ? $pacote. '' : $msg;
		}
	}

	/**
	 * Procura por um atributo dentro da lista de pacotes
	 * @param PacoteAMI $pacote - lista linkada
	 * @param String    $atr    - nome do atributo desejado
	 * @param String    $actID  - OPCIONAL - ActionID do pacote desejado
	 */
	static function achaAtributo($pacote, $atr, $actID='') {
		$aux =& $pacote;
		while($aux) {
			if(!empty($actID) && $aux->getAtr('ActionID') != $actID)
				continue;
			
			$getAtr = $aux->getAtr($atr);
			if($getAtr !== null);
				return $getAtr;
			
			$aux = $aux->prox;
		}
		return false;
	}

	/**
	 * Fun��o que l� os dados recebidos de "recebeBuffer" e devolve
	 * uma lista linkada de pacotes j� "parseados"
	 * @param int $timeout - Tempo m�ximo de espera pela recep��o de dados
	 */
	function recebeEventos($timeout = 0.1) {
		$rbuff = $this->recebeBuffer($timeout);
		return ($rbuff === false) ? false : PacoteAMI::parse($rbuff);
	}
	
	/**
	 * Fun��o que l� os dados diretamente do SOCKET de rede e os retorna em forma
	 * de String. Retorna FALSE em caso de erro
	 * @param int $timeout - Tempo m�ximo de espera pela recep��o de dados
	 */
	function recebeBuffer($timeout = 0.1) {
		$rbuff = '';
		while($this->temDadosNoSocket($timeout) > 0) {
			$sockData = socket_read($this->SOCKET, 2048);
			if($sockData === '' || $sockData === false) return false;
			$rbuff .= $sockData;
		}
		return $rbuff;
	}
	
	/**
	 * Fun��o auxiliar para verificar se o SOCKET apresenta dados dispon�veis para leitura
	 * @param int $timeout - Tempo m�ximo de espera pela recep��o de dados
	 */
	function temDadosNoSocket($timeout = 0.1) {
		$read = array($this->SOCKET);
		return socket_select($read, $write = null, $except = null, 0, $timeout*1000000);
	}
}
?>