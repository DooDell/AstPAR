<?php
/**
 * Conexao com o banco de dados PostgreSQL
 * @author Gabriel Ortiz - ortiz@celepar.pr.gov.br
 * @version 1.0, 22/05/2006
 */
class Conexao {
	private $id, $res, $bd;
	public $qtdSel, $qtdAff, $data, $erro, $loginOK;
	
	/**
	 * Faz a conexao com o BD
	 */
	function Conexao() {
		// TODO otimizar a leitura do arquivo
		$connData = array();
		$lins = file('/etc/asterisk/res_pgsql.conf', FILE_IGNORE_NEW_LINES);
		if($lins) {
			foreach($lins as $lin) {
				if(strstr($lin, '=')) {
					list($ch, $val) = explode('=', $lin);
					$connData[trim($ch)] = trim($val);
				}
			}
		}

		$this->id = pg_connect("host=$connData[dbhost] dbname=$connData[dbname] user=$connData[dbuser] password=$connData[dbpass] port=$connData[dbport]");
		$this->loginOK = (is_resource($this->id) && pg_connection_status($this->id) == PGSQL_CONNECTION_OK);
	}
	
	/**
	 * Fun��o est�tica para buscar uma lista de Chave-Valor.
	 * 
	 * O SQL deve buscar 2 valores, e por primeiro deve estar a coluna de valores.
	 * Opcionalmente em segundo a coluna de chave.
	 * 
	 * @param string $sql
	 * @param string $indice opcional
	 * @return array
	 */
	static function getArray($sql, $indice=null) {
		$ret  = array();
		$conn = new Conexao();
		$conn->executa($sql);
		while($conn->temMaisDados()) {
			if($indice === null) $ret[] = array_shift($conn->data);
			else                 $ret[$conn->data[$indice]] = array_shift($conn->data);
		}
		$conn->fecha();
		return $ret;
	}
	
	/**
	 * Retorna um array de inteiros conforme o SQL, que deve estar
	 * estruturado de forma a prover um... array de ints!
	 * @param String sql - SQL na forma "SELECT id FROM ....", id ou outro campo int
	 */
	function arrayDeStrings($sql) {
		$ret = array();
		$err = $this->executa($sql);
		if(is_string($err)) return $err;
		while($this->temMaisDados())
			$ret[] = array_shift($this->data);
		return $ret;
	}

	/**
	 * Retorna uma string conforme o SQL, que deve estar
	 * estruturado de forma a prover uma... string (ou int...)!
	 * @param String sql - SQL na forma "SELECT campo FROM ...."
	 */
	function getStr($sql) {
		$ret = false;
		$err = $this->executa($sql);
		if(is_string($err)) return $err;
		if($this->temMaisDados())
			$ret = array_shift($this->data);
		return $ret;
	}

	/**
	 * Executa uma query no BD e retorna os dados.
	 * @param String sql - SQL a ser executado
	 * @return true para OK, ou MSG de erro
	 */
	function executa($sql, $mostra=true) {
		if ($sql == '')	{
			$this->res = 0;
			$this->qtd = 0;
		} else {
			if(pg_connection_status($this->id) !== PGSQL_CONNECTION_OK) {
				$this->__loga(LOG_CRITICO, "Conexao BD. Status RUIM: " . pg_last_error($this->id));
				exit(100);
			}
			
			$this->res = pg_query($this->id, $sql);
			if($mostra)
				$this->__loga(LOG_DEBUG2, "***** Exec SQL: \033[36;1m$sql\033[0m");
			if ($this->res) {
				$this->qtdSel = @pg_num_rows($this->res);		// Num para SELECT
				$this->qtdAff = @pg_affected_rows($this->res);	// Num para INSERT, UPDATE, DELETE
				return true;
			} else {
				$err = "Erro SQL[$sql][" . pg_last_error($this->id) . "]";
				$this->__loga(LOG_AVISO, $err);
				return $err;
			}
		}
	}

	/**
	 * Busca os dados de uma linha do resultado e posiciona o ponteiro na prxima.
	 * Para listar os dados no cdigo basta utilizar por exemplo:
	 *                while ($conn->temMaisDados())  {
	 *                   echo $conn->data["nome"];
	 *                }
	 * Caso o parametro no seja vazio j retorna o valor do campo pedido. Exemplo:
	 * 								$conn->executa("SELECT a FROM b WHERE c=1")
	 * 								echo $conn->temMaisDados("a")
	 */
	function temMaisDados($campo='') {
		if($this->qtdSel <= 0) return false;
		$this->data = pg_fetch_assoc($this->res);
		if($this->data) {
			if(!empty($campo)) return $this->data[$campo];
			return true;
		}
		return false;
	}
	
	function limpaRes() {
		if($this->res)
			pg_free_result($this->res);
	}
	
	/**
	 * Encerra a conexo com o banco de dados.
	 */
	function fecha($deVerdade=false) {
		if($deVerdade) pg_close($this->id);
		$this->id   = null;
		$this->res  = null;
		$this->data = null;
		$this->qtdSel = 0;
		$this->qtdAff = 0;
	}
	
	function __loga($nivLog, $texto) {
		if(function_exists('loga'))
			loga($nivLog, $texto);
	}
}
?>