<?php
class ControleFila extends Controle {
	/**
	 * M�todo Padrao para classes de controle. Executa a A��o solicitada
	 * @param String nomeAcao - Nome da a��o a ser executada
	 * @param HashMap<String, String> params - Parametros a serem passados na execu��o da A��o
	 */
	function executaAcao($nomeAcao, $params) {
		global $sessao;
		$err = false;
		
		$filaAlterada = false;
		$nomeFila = $nomeFilaAnt = '';
		
		switch($nomeAcao) {
			case 'nova': // Adicionar Fila
			case 'edit': // Editar Fila
				$fila = new Fila("doRequest");
				
				$fila->name = Util::removeAcentos($fila->name);
				$nomeFila = $fila->name;
				
				$fila->joinempty      = ($fila->joinempty      == "on") ? "yes" : "no";
				$fila->leavewhenempty = ($fila->leavewhenempty == "on") ? "yes" : "no";
				$fila->avisoRep       = ($fila->avisoRep       == "on") ? "yes" : "no";
				

				$fila->indispna       = ($fila->indispna       == "on") ? "1" : "0";
				$fila->monitor_format = ($fila->monitor_format == "on") ? "wav49" : "";
				
				$fila->callback           = ($fila->callback           == "on") ? "1" : "0";
				$fila->callbackstriplocal = ($fila->callbackstriplocal == "on") ? "1" : "0";
				
				$fila->flags = 0;
				if(Util::pegaAtributoDoRequest('horarioAtivo')      == "on") $fila->flags += FLAG_FILA_HORARIOATIVO;
				if(Util::pegaAtributoDoRequest('timeoutCallBack')   == "on") $fila->flags += FLAG_FILA_TOCALLBACK;
				if(Util::pegaAtributoDoRequest('filacheiaCallBack') == "on") $fila->flags += FLAG_FILA_FCCALLBACK;
				if(Util::pegaAtributoDoRequest('filavaziaCallBack') == "on") $fila->flags += FLAG_FILA_FVCALLBACK;
				if(Util::pegaAtributoDoRequest('pausaAutomatica')   == "on") $fila->flags += FLAG_FILA_PAUSA_AUTO;
				if(Util::pegaAtributoDoRequest('emailssl')          == "on") $fila->flags += FLAG_FILA_EMAIL_SSL;
				
				if(Util::pegaAtributoDoRequest('tipoAcaoHorario') == "A") $fila->flags += FLAG_FILA_HORARIOANUNCIO;
				if(Util::pegaAtributoDoRequest('tipoAcaoTO')      == "A") $fila->flags += FLAG_FILA_TOANUNCIO;
				if(Util::pegaAtributoDoRequest('tipoAcaoFC')      == "A") $fila->flags += FLAG_FILA_FCANUNCIO;
				if(Util::pegaAtributoDoRequest('tipoAcaoFV')      == "A") $fila->flags += FLAG_FILA_FVANUNCIO;

				if(Util::pegaAtributoDoRequest('avisoPos') == 'on') {
					$fila->flags += FLAG_FILA_AVISA_POS;				
				} else {
					$fila->announce_holdtime      = "";
					$fila->announce_frequency     = 0;
				}
				
				if($fila->musiconhold == '0') $fila->musiconhold = 'default';
				if($fila->announce    == '0') $fila->announce = '';
				
				// garante que este valor � 1, para setar o nome do Ag no arquivo da grava��o
				$fila->setinterfacevar = 1;
				$fila->eventwhencalled = 'vars';
				
				if($nomeAcao == "nova") {//adicionando uma nova fila
					if(Util::campoDisponivel('name', $fila->name, 'fila')){
						$err = $fila->salvar();
						if($err === true) {
							$err = SistemaCC::enviaComando("refresh:Fila:$fila->id");
							if($err === true) {
								$err = "Fila [$fila->name] adicionada com sucesso.";
								$sessao->ativaFuncao('fila');
								$filaAlterada = true;
							}
						}
					} else{
						$err = "Fila de nome [". $fila->name . "] j� em uso!";
					}
				} else {//editando uma fila existente
					$nomeFilaAnt = Util::pegaAtributoDoRequest('filaatual');
					if($nomeFilaAnt != $fila->name && !Util::campoDisponivel('name', $fila->name, 'fila')) {
					 	$err = "Fila de nome [$fila->name] j� em uso!";
					} else {
						$filaVelha = new Fila($fila->id); // Para verificar se houve altera��o no piloto da fila
						$err = $fila->atualizar();
						if($err === true) {
							// Alterar possiveis pilotos de filas configurados em URAs
							$urasAlt = ($fila->tipopiloto = 'R' && $fila->ramal != $filaVelha->ramal) ?
								Ura::alteraPilotoFila($filaVelha->ramal, $fila->ramal) : 0;
							
							$err = SistemaCC::enviaComando("refresh:Fila:$fila->id");
							if($err === true) {
								$err = "Fila [$fila->name] atualizada." . ((is_numeric($urasAlt) && $urasAlt > 0) ? " $urasAlt URA(s) alterada(s) e n�o publicada(s)" : '');
								$filaAlterada = true;
							}
						}
					}
				}
				
				if($filaAlterada) {
					$filas = false;
					$agsNaFila = explode(',', $params['agentesNaFila']);
					
					// Salvar altera��es em Ags X Fila
					$agentes = SistemaCC::todosAgente();
					$agsAlterados = array();
					foreach($agentes as $ag) {
						$filasAg    = explode(',', $ag->idsfilas);
						
						$altera = false;
						$deveEstar  = in_array($ag->id,   $agsNaFila); // Flag que indica que o agente DEVE ESTAR nesta fila
						$estaNaFila = in_array($fila->id, $filasAg);   // Flag que indica que o agente ESTA ATUALMENTE nesta fila

						if($deveEstar && !$estaNaFila) {
							// Adicionar este ag nesta fila
							$filasAg[] = $fila->id;
							$altera = true;
						} else if(!$deveEstar && $estaNaFila) {
							// Remover este ag desta fila
							unset($filasAg[array_search($fila->id, $filasAg)]);
							$altera = true;
						}
						
						if($altera) {
							if(!$filas) $filas = bdFacil::todos('Fila');
							
							$nomesFilasAgs = array();
							foreach($filasAg as $idFA)
								$nomesFilasAgs[] = $filas[$idFA]->name;
							if($ag->atualizaIdsFilas($filasAg, $nomesFilasAgs, false) === true)
								$agsAlterados[] = $ag->id;
						}
					}
					if(count($agsAlterados) > 0) {
						$sessao->delMeusUsuarios();
						
						$errAux = SistemaCC::enviaComando('refresh:Agente:' . Util::separaPorVirgula($agsAlterados));
						if($errAux !== true)
							$err .= "Erro ao salvar AgsXFila: [$errAux]";
					}
				}
				break;
			
			case 'novoItemTabulacao':
				$item   = $params['item'];
				$fila   = $params['fila'];
				$idfila = $params['idfila'];
				$err = Conexao::sql("INSERT INTO cc_tipotabulacao(idfila, descricao, flag, ordem) VALUES('$idfila', '$item', '0', (SELECT MAX(ordem) FROM cc_tipotabulacao WHERE idfila = '$idfila') + 1)");
				if($err === true)
					$err = "Item [$item] adicionado a fila [$fila]";
				break;
				
			case 'delTT':
				$id  = $params['id'];
				$err = Conexao::sql("UPDATE cc_tipotabulacao SET flag = flag | ".TIPOTAB_DESATIVADO." WHERE id = '$id'");
				if($err === true)
					$err = "Item removido com sucesso!";
				break;
			
			case 'delete': // Remover Fila
				$idDel = $params['id'];
				// Verificar se existem agentes nesta fila, se houver nao remove
				$temAgs = false;
				foreach(SistemaCC::todosAgente() as $ag) {
					$filasAg = explode(',', $ag->idsfilas);
					$posId = array_search($idDel, $filasAg);
					if($posId !== false) {
						$temAgs = true;
						break;
					}
				}
				if(!$temAgs) {
					if(($err = bdFacil::removerPorId('Fila', $idDel)) === true) {
						SistemaCC::enviaComando("delete:Fila:$idDel");
						$err = 'Fila [' . $params['nome'] . '] removida';
					}
				} else
					$err = 'Fila [' . $params['nome'] . '] contem agentes. Imposs�vel remover';
				break;
			
			case 'mudaOrdemAgs':
				$ordem = ($params['ordem'] == 'ramal') ? 'ramal' : 'nome';
				$sessao->setVar('ordemAgsFilas', $ordem);
				if($params['origem'] == 'addedit')
					$sessao->setVar('abreAgsFilas', '1');
				$err = ''; // Suprimir msgs
				break;
				
			case 'salvaAgentesEmFilas':
				$filas = bdFacil::todos("Fila");
				
				$idsFilasAgs = array();
				$nomesFilasAgs = array();
				foreach(explode(':', $params['agentesEmFilas']) as $fila) {
					$idsAgs = explode(",", $fila);
					$idFila = array_shift($idsAgs);
					foreach($idsAgs as $codAgente){
						$idsFilasAgs[$codAgente][] = $idFila;
						$nomesFilasAgs[$codAgente][] = $filas[$idFila]->name;
					}
				}
				$agentes = SistemaCC::todosAgente();
				// Atualizar o campos idsfilas dos agentes
				$agsAlterados = array();
				foreach($agentes as $ag) {
					$idsFilasNovas = (isset($idsFilasAgs[$ag->id]) && is_array($idsFilasAgs[$ag->id])) ? $idsFilasAgs[$ag->id] : array();
					if($ag->atualizaIdsFilas($idsFilasNovas, $nomesFilasAgs[$ag->id], false) === true)
						$agsAlterados[] = $ag->id;
				}
				
				if(count($agsAlterados) > 0)
					$err = SistemaCC::enviaComando('refresh:Agente:' . Util::separaPorVirgula($agsAlterados));

				if($err === true) {
					$sessao->delMeusUsuarios();
					$err = "Agentes X Filas salvos com sucesso";
				} else
					$err = 'Falha na atualiza��o de Agentes X Filas';
				break;
				
			case 'salvaPAsEmFilas':
				$ret = NULL;
				bdFacil::limpa('PAsFila'); // Zera a tabela
				
				$PAsEmFilas = explode(":", $params['pasEmFilas']);
				if(Util::tem($PAsEmFilas)) {
					$pas = bdFacil::todos('PA');
					$filas = bdFacil::todos('Fila');
					foreach($PAsEmFilas as $PAfila) {
						$filaPAs = explode(',', $PAfila);
						$idFila = array_shift($filaPAs);
						foreach($filaPAs as $idPA) {
							$paFila = new PAsFila();
							$paFila->chan      = (($pas[$idPA]->tipo == 'SIP') ? 'SIP/' : '') . $pas[$idPA]->nome;
							$paFila->idpa      = $idPA;
							$paFila->idfila    = $idFila;
							$paFila->nomepa    = $pas[$idPA]->nome;
							$paFila->nomefila  = $filas[$idFila]->name;
							$paFila->descricao = $pas[$idPA]->descricao;
							$err = $paFila->salvar();
							if($err !== true)
								$ret .= "Erro PA/$nomePA - ";
						}
						if(!is_string($ret)) {
							$err = "PA X Filas salvos com sucesso.";
							$ret = true;
						} else
							$err = $ret;
					}
				}
				break;
			
			case 'paMassa': // Adicionar PAs em Massa
				$baseLogin = Util::pegaAtributoDoRequest('nome');
				if(empty($baseLogin) || strlen($baseLogin) < 2) {
					$err = 'Base de login Inv�lida! (Min. 2 caracteres)';
				} else {
					$quant = Util::pegaAtributoDoRequest('quantidade');
					if(empty($quant) || !is_numeric($quant) || $quant < 2) {
						$err = 'Quantidade inv�lida. M�nimo 2';
					} else {
						$numIni = Util::pegaAtributoDoRequest('offset');
						if(empty($numIni) || !is_numeric($numIni)) $numIni = 1;
						$numFim = ($numIni + $quant) - 1;
						$err = '';
						$telEmUso = '';
						for($c=$numIni; $c<=$numFim; $c++) {
							$num = ($c < 10) ? "0$c" : $c;
							$pa = new PA('doRequest');
							$pa->tipo = 'SIP';
							$pa->nome .= $num;
							$pa->descricao .= " $num";	
							$pa->nat  = ($pa->nat == "on") ? "1" : "0";						
							if(Util::campoDisponivel('nome', $pa->nome, 'pa')) {
								if($pa->salvar() !== true) {
									if(!empty($err)) $err .= ', ';
									if(empty($err)) $err = 'Erro ao salvar:';
									$err .= " $pa->nome";									
								}
							} else {
								$telEmUso .= " $pa->nome";
							}
						}						
						if(!empty($telEmUso)) {							
							$err .= "PA(s) $telEmUso em uso!";											
						} else if(empty($err)) {
							$err = "PAs [$baseLogin".$numIni." a $baseLogin".$numFim.'] adicionados com sucesso!';
							$sessao->ativaFuncao('listaPAs');
							$paAlterada = true;
						}
					}
				}
				break;
				
			case 'novaPA': // Adicionar PA
			case 'editPA': // Adicionar PA
				$pa = new PA('doRequest');
				$pa->tipo = 'SIP';
				$pa->nat  = ($pa->nat == "on") ? "1" : "0";
				$pa->nome = strtolower($pa->nome);
				
				if($nomeAcao == 'novaPA') {
					if(Util::campoDisponivel('nome', $pa->nome, 'pa', false)) {
						$err = $pa->salvar();
						if($err === true) {
							$err = "PA [$pa->nome] adicionada com sucesso.";
							$sessao->ativaFuncao('listaPAs');
							$paAlterada = true;
						}
					} else
						$err = "Login de PA [$pa->nome] j� em uso!";
				} else { // Editando uma PA existente
					if(Util::pegaAtributoDoRequest('paedit') != $pa->nome && !Util::campoDisponivel('nome', $pa->nome, 'pa', false)) {
					 	$err = "Login de PA [$pa->nome] j� em uso!";
					} else {
						$pa->id = $params['id'];
						$err = $pa->atualizar();
						if($err === true) {
							$err = "PA [$pa->nome] alterada com sucesso.";
							$sessao->ativaFuncao('listaPAs');
							$paAlterada = true;
						}
					}
				}
				break;
			
			case 'deletePA': // Remover PA
				if(($err = Fila::delPA($params['chan'])) === true)
					$err = "PA $chan removido.";
				break;
				
			case 'delPAs': // Remover varias PAs
				$err = Fila::getPAsDoRequest();
				if(Util::tem($err)) {
					$rem = $erro = array();
					foreach($err as $chan) {
						if(Fila::delPA($chan) === true) $rem[]  = $chan;
						else                            $erro[] = $chan;
					}
					$err = '';
					if(Util::tem($rem))  $err = 'PAs removidas: ' . Util::separaPorVirgula($rem);
					if(Util::tem($erro)) $err .= ' Erro ao remover: ' . Util::separaPorVirgula($erro);
					$paAlterada = true;
				}
				break;
			
			case 'desligaNat':
			case 'ligaNat':
				$nat  = ($nomeAcao == 'ligaNat') ? '1' : '0';
				$desc = ($nomeAcao == 'ligaNat') ? 'Ativar' : 'Desativar';
				$err = Fila::getPAsDoRequest();
				if(Util::tem($err)) {
					$rem = $erro = array();
					foreach($err as $chan) {
						if(Fila::natPA($chan, $nat) === true) $rem[]  = $chan;
						else                                 $erro[] = $chan;
					}
					$err = '';
					if(Util::tem($rem))  $err  = "$desc NAT: " . Util::separaPorVirgula($rem);
					if(Util::tem($erro)) $err .= " Erro ao $desc NAT: " . Util::separaPorVirgula($erro);
					$paAlterada = true;
				}
				break;
				
			case 'addAnuncio':
				if($_FILES['arq']['error'] == 0) {
					$uploaddir = BASE_DIR.'arquivos/asterisk/anuncios/';
					$uploadfile = $uploaddir . 'anuncio_' . $_FILES['arq']['name'];
					if (move_uploaded_file($_FILES['arq']['tmp_name'], $uploadfile)) {
						$err = 'O arquivo � valido e foi carregado com sucesso. ' . $_FILES['arq']['size'] . ' bytes.';
					} else {
						$err = 'Erro ao mover aquivo. Cheque as permiss�es.';
					}
				} else {
					$err = 'Erro ['.$_FILES['arq']['error'].'] ao no upload do  aquivo. Cheque as permiss�es.';
				}
				break;
				
			case 'getAnuncio':
				$arq = $params['arq'];
				$dir = Arquivos::getNomeDir('ANUNCIOS');
				header("Content-Disposition: attachment; filename = $arq");
				header('Content-Length: ' . filesize($dir . $arq));
				header('Content-Type: audio/mpeg');
				passthru("cat $dir$arq");
				$ret = 'ENVIO';
				$err = '';
				break;
				
			case "delAnuncio":
				$arq = $params['arq'];
				$dir = Arquivos::getNomeDir('ANUNCIOS');
				$err = Util::executaComando("rm -rf \"$dir$arq\"");
				if($err !== true) $err = "Falha ao remover arquivo [$arq]";
				else              $err = "Arquivo [$arq] removido com sucesso!";
				break;
			
			case 'delGravacao':
				$uid = $params['uid'];
				$arq = BASE_DIR . "arquivos/asterisk/monitor/Fila_$uid.WAV";
				if(!@unlink($arq)) $err = "Falha ao remover gravacao $uid";
				else {
					$err = Conexao::sql("UPDATE cdr SET gravacao = \"\" WHERE uniqueid = '$uid'");
					if($err === true) $err = 'Gravacao removida com sucesso!';
				}
				break;
			
			case 'playGravacao':
				$uid = $params['uid'];
				$arq = BASE_DIR . "arquivos/asterisk/monitor/Fila_$uid.WAV";
				Util::executaComando("chown root:www-data $arq");
				header("Content-Disposition: attachment; filename = Fila_$uid.wav");
				header('Content-Length: ' . filesize($arq));
				header('Content-Type: audio/x-wav');
				passthru("cat $arq");
				$err = 'ENVIO';
				break;
			
			case 'playSaintes':
				$uid = $params['uid'];
				$arq = "/var/spool/asterisk/saintes/$uid.WAV";
				Util::executaComando("chown root:www-data $arq");
				header("Content-Disposition:attachment; filename = $uid.WAV");
				header('Content-Length: ' . filesize($arq));
				header('Content-Type: audio/x-wav');
				passthru("cat $arq");
				$err = 'ENVIO';
				break;

			case 'delSaintes':
				$uid = $params['uid'];
				$arq = "/var/spool/asterisk/saintes/$uid.WAV";
				if(!@unlink($arq)) $err = "Falha ao remover gravacao $uid";
				else {
					$err = Conexao::sql("UPDATE cdr SET gravacao = \"\" WHERE uniqueid = '$uid'");
					if($err === true) $err = 'Gravacao removida com sucesso!';
				}
				break;
				
			case 'addMotivo':
			case 'atzMotivo':
				$motivo = new TipoStatusAgente();
				$motivo->descricao = $params['desc'];
				$tipo = $params['tipo'];
				$nomeTipo = ($tipo == 100) ? 'Pausa' : 'Indisponibilidade';
				if($nomeAcao == "addMotivo") {
					$id = bdFacil::getAtrSql("SELECT MAX(id) FROM tipostatusagente WHERE id < " . ($tipo + 100));
					$motivo->id = $id + 1;
					$err = $motivo->salvar("SalvaID");
					if($err === true) {
						$msg = "Novo Tipo de $nomeTipo cadastrado.";
						$sincMP = true;
					}
				} else {
					$motivo->id = $params['id'];
					$err = $motivo->atualizar();
					if($err === true) {
						$msg = "Tipo de $nomeTipo atualizado.";
						$sincMP = true;
					}
				}
				if($sincMP) {
					// TODO sincronizar os motivos com o controleCC
				}
				if($err === true) $err = $msg;
				break;
			
			case 'statusMotivo':
				$id = $params['id'];
				if($params['acao'] == 'del') {
					$acao = '| ';
					$msg = 'desabilitado';
				} else {
					$acao = '& ~';
					$msg = 'habilitado';
				}
				$err = Conexao::sql("UPDATE tipostatusagente SET flags = flags $acao" . FUNC_DESABILITADO . " WHERE id = '$id'");
				if($err === true)
					$err = "Tipo de Pausa $msg";
				break;
			
			case 'salvaParams':
				$err = true;
				$agsSimult = Util::pegaAtributoDoRequest('filaAgsSimult');
				if($agsSimult != Parametro::get('filaAgsSimult')) {
					$maxp = ceil($agsSimult / 10);
					$mpTxt = '"max-procs"';
					$fcgiTxt = '"PHP_FCGI_CHILDREN"';
					$dezTxt = '"10"';
					Util::executaComando("sed -e '/max-procs/c\		$mpTxt => $maxp,' /etc/lighttpd/conf-enabled/10-fastcgi.conf > /tmp/10-fastcgi.new");
					Util::executaComando("sed -e '/PHP_FCGI_CHILDREN/c\			$fcgiTxt => $dezTxt,' /tmp/10-fastcgi.new > /etc/lighttpd/conf-enabled/10-fastcgi.conf");
					Util::executaComando('/etc/init.d/lighttpd restart');
					$err = Parametro::set('filaAgsSimult', $agsSimult);
				}
				$filaKA = ceil(Util::pegaAtributoDoRequest('filaTempoKA') / 5);
				if($filaKA != Parametro::get('filaTempoKA')) {
					Util::executaComando("sed -e '/kaAtivo/c\$kaAtivo = $filaKA;' /etc/controleCC.conf > /etc/controleCC.new; mv /etc/controleCC.new /etc/controleCC.conf");
					Util::executaComando('touch /etc/asterisk/telip/cc/REINICIE');
					$err = Parametro::set('filaTempoKA', $filaKA);
				}
				if($err === true)
					$err = 'Parametros salvos!';
				break;

			case 'pesquisaGravacoesFila':
				//Obter dados do REQUEST e Por na Sessao
				
				$regPorPagGravacao = Util::pegaAtributoDoRequest('qtdeRegPagina');
				$sessao->setVar('pagGravacao',1);
				if(!empty($regPorPagGravacao)) $sessao->setVar('regPorPagGravacao',$regPorPagGravacao);
				else $sessao->setVar('regPorPagGravacao',10);
				$sessao->setVar('ordemSortGravacao','calldate');
				
				$filtroGravacao = new Vazia();
				$filtroGravacao->horaInicial	= Util::pegaAtributoDoRequest("horaInicial");
				$filtroGravacao->horaFinal		= Util::pegaAtributoDoRequest("horaFinal");
				$filtroGravacao->dataInicial	= Util::pegaAtributoDoRequest("dataInicial");
				$filtroGravacao->dataFinal		= Util::pegaAtributoDoRequest("dataFinal");				
				$filtroGravacao->filaGravacao	= Util::pegaAtributoDoRequest("filaGravacao");
				$filtroGravacao->agenteGravacao = Util::pegaAtributoDoRequest("agenteGravacao");
				$filtroGravacao->origemChamada = Util::pegaAtributoDoRequest("origemChamada");
				
				
				if((!empty($filtroGravacao->horaInicial)) || (!empty($filtroGravacao->horaFinal)) || (!empty($filtroGravacao->dataInicial)) || (!empty($filtroGravacao->dataFinal))   
					|| (!empty($filtroGravacao->periodoMensal)) || (!empty($filtroGravacao->filaGravacao)) || (!empty($filtroGravacao->origemChamada)) || (!empty($filtroGravacao->agenteGravacao)))
						$sessao->setVar('filtroGravacao',$filtroGravacao);
				else $sessao->setVar('filtroGravacao',null);
				
				$err = ''; // N�o queremos mostrar mensagem, mas n�o podemos retornar false
				break;
		}
		if($filaAlterada) {
			// For�ar o reload das filas no RealTime do Asterisk
			Asterisk::executaComando("queue show $nomeFila");
			if(!empty($nomeFilaAnt))
				Asterisk::executaComando("queue show $nomeFilaAnt");
			Fila::escreveFilasConf();
		}
		if($paAlterada)
			$sessao->addAviso('escrevePAs');

		return $err;
	}
}
?>