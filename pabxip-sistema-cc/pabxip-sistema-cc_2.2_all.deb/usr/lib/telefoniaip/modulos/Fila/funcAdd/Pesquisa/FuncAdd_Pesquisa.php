<?php
// Desc: Paran� em A��o
class FuncAdd_Pesquisa extends Controle {
	function preparaTela($smarty) {
		global $sessao;
		
		$admOuSup = true;
				
				// Tabela de Grava��es
				$nomeTabela = 'Pesquisa';
				$vdAgentes = $admOuSup ? Util::HtmlComboAgentes('-- Todos --') : array($sessao->usuario->id => $sessao->usuario->nome);
				$cols = array('PLAY',
							'Data'    => array('ORD(c.calldate)',    'periodoData'),
							'Origem'  => array('ORD(c.src)',         'num-12'),
							'Agente'  => array('ORD(c.accountcode)', $vdAgentes),
							'Dura��o' => 'duracao'
						);
				$whereFixo = $admOuSup ? null : "c.accountcode = " . $sessao->usuario->id; // Where fixo para garantir que o id do agente logado fique fixo
				$TS = TabelaSessao::get($nomeTabela, $sessao, $cols, $whereFixo);

				if($TS->filtro && count($TS->filtro->valores) > 0) {
					$TS->filtro->mostra = true;
					/*Dados  Filtro por per�odo de Data e ou Hora */
					list($dtInicial, $dtFinal) = Util::getPeriodoDataBD($TS->filtro->getCampo('Data'));
					
					$origemChamada = $TS->filtro->getCampo('Origem');         // Numero do Telefone que originou a chamada para Fila
					$agenteSel     = $TS->filtro->getCampo('Agente');         // ID do Agente

					// Validar dados do request e format�-los para consulta ao banco
					if(!Util::validaData($dataInicial, '/')) $dataInicial = '';
					if(!Util::validaData($dataFinal,   '/')) $dataFinal   = '';

					if(!empty($dtInicial) && !empty($dtFinal)) {					
						$periodo   = "BETWEEN '$dtInicial 00:00:00' AND '$dtFinal 23:59:59'";
					} else if(!empty($dtInicial)) {
						$periodo   = "> '$dtInicial 00:00:00'";
					} else if(!empty($dtFinal)) {
						$periodo = "< '$dtFinal 23:59:59'";
					}

					//Tratamento do Filtro de Grava��o para preenchimentos dos valores a serem passados para a consulta ao Banco
					$wAgente	= (empty($agenteSel) || $agenteSel == 'todos') ? '' : "AND c.accountcode = '$agenteSel'";
					$wOrigem	= (empty($origemChamada))                      ? '' : "AND c.src = '$origemChamada'";
					$wPeriodo	= (empty($periodo))                            ? '' : "AND c.calldate $periodo";
					$sql = "SELECT c.id,c.calldate,c.accountcode,c.billsec as tempoatd,c.src,c.fila,c.uniqueid " .
							"FROM cdr c " .
							"WHERE c.gravacao = '9' $wAgente $wOrigem $wPeriodo ORDER BY $TS->ordem";
				}
				
				$tabelaGrs = new HtmlTable($nomeTabela, $TS, $sql);
				$tabelaGrs->computaLinhas();
				
				if(count($tabelaGrs->linhas) > 0) {
					$gfxPlay = new HtmlImg('btnPlay.png');
					foreach($tabelaGrs->linhas as $lin) {
						$lin->PLAY        = "<a href='javascript:play(\"$lin->uniqueid\")'>$gfxPlay</a>";
						$lin->calldate    = Util::formataData($lin->calldate);
						$lin->duracao     = Util::formataSegundos($lin->tempoatd);
						$lin->accountcode = $vdAgentes[$lin->accountcode];
					}
				} else {
					$msg = (count($TS->filtro->valores) > 0) ?
							'Nenhuma grava��o encontrada com o filtro definido' :
							'Preencha os campos acima e ap�s pressione o bot�o Pesquisar';
					$tabelaGrs->setMsgVazia($msg);
				}
				$smarty->assign('tabelaGravacao', $tabelaGrs);
	
		return true;
	}
	
	function executaAcao($nomeAcao, $params) {
		global $sessao;
		$err = false;
		
		$trsAbertas = Util::pegaAtributoDoRequest('trsAbertas');
		if(!empty($trsAbertas))
			$sessao->setVAr('trsAbertasPesquisa', $trsAbertas);
		
		switch($nomeAcao) {
			case 'playGravacao':
				$uid = $params['uid'];
				$arq = "/var/spool/asterisk/saintes/$uid.WAV";
				Util::executaComando("chown root:www-data $arq");
				header("Content-Disposition: attachment; filename = ParanaEmAcao_$uid.wav");
				header('Content-Length: ' . filesize($arq));
				header('Content-Type: audio/x-wav');
				passthru("cat $arq");
				$err = 'ENVIO';
				break;
		}
		
		return $err;
	}
}
?>