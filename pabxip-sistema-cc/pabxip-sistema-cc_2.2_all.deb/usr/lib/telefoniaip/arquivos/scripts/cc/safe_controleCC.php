#!/usr/bin/php -c /usr/lib/telefoniaip/arquivos/config/php.ini
<?php
	define('ID_MSG_QUEUE', 0xf0f0);
	define('DELAY_PING',   14);
	
	// Variaveis globais
	$mq_id = msg_get_queue(ID_MSG_QUEUE);	// Init da fila de mensagens
	$ping = 1000;
	
	// Verifica��o inicial, precisamos subir o controle?
	if(getRodando()) {
		$pidContCC = getPIDcontroleCC();
		if(!is_numeric($pidContCC) || $pidContCC < 10)
			execControleCC();
	}
	
	// Loop Principal
	loga('Loop principal');
	while(getRodando()) {
		enviaComando("PING:$ping", true);
		for($w=0; $w<DELAY_PING * 2; $w++) {
			$rstPeriodico = file_exists('/etc/asterisk/telip/EH_RESTART');
			if($rstPeriodico) {
				// Restart periodico
				loga('controleCC reiniciando (periodico)');
				// Esperar que o controleCC.php saia
				while(getRodando()) {
					usleep(500000); // 0.5s
				}
				// Invocar novamente o processo controleCC
				execControleCC();
			}
			
			if(file_exists('/etc/asterisk/telip/cc/REINICIE')) {
				unlink('/etc/asterisk/telip/cc/REINICIE');
				loga('Pedido de reinicializacao');
				encerraControleCC(true);
				execControleCC();
			}
			usleep(500000); // 0.5s
			
			if(!getRodando()) break 2;
		}
		if($ping != file_get_contents('/etc/asterisk/telip/cc/PING')) {
			loga('Comando PING falhou. Reiniciando controleCC');
			encerraControleCC(true);
			
			// Invocar novamente o processo controleCC
			execControleCC();
		}
		$ping++;
	}
	
	loga('controleCC desativado');

	// Garantir que esta desligado
	encerraControleCC();
	
	// FIM
	return 0;
	
	
	
	
	
	// -=-=- Fun��es auxiliares =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
	function execControleCC() {
		loga('Executando /usr/lib/telefoniaip/modulos/Fila/sistemaCC/controleCC.php');
		touch('/etc/asterisk/telip/cc/RODANDO');
		exec('/usr/bin/php -c /usr/lib/telefoniaip/arquivos/config/php.ini /usr/lib/telefoniaip/modulos/Fila/sistemaCC/controleCC.php >> /var/log/controleCallCenter.log 2>> /var/log/controleCallCenter.log &');
		// Sleep para dar tempo do controleCC subir
		sleep(4);
	}
	
	function enviaComando($cmd, $ping=false) {
		global $mq_id;
		if(!$ping) loga("Enviando comando [$cmd]");
		$msg = time().":ADM:$cmd";
		if(!@msg_send ($mq_id, 100, $msg, false, false, $msg_err='')) {
			$mq_id = msg_get_queue(ID_MSG_QUEUE);	// Init da fila de mensagens
			return msg_send ($mq_id, 100, $msg, false, false, $msg_err='');
		}
		return true;
	}
	
	function getRodando() {
		return file_exists('/etc/asterisk/telip/cc/RODANDO');
	}
	
	function getPIDcontroleCC() {
		list($pidContCC) = explode(' ', trim(exec('ps ax | grep sistemaCC/controleCC.php | grep -v grep')));
		return $pidContCC + 0;
	}
	
	function encerraControleCC($restart=false) {
		$pidContCC = getPIDcontroleCC();
		if($pidContCC > 0) {
			enviaComando($restart ? 'RST' : 'SAIA');
			$TO = time() + 5;
			while(time() < $TO && $pidContCC > 0) {
				usleep(250000);
				$pidContCC = getPIDcontroleCC();
			}
			if($pidContCC > 0) {
				loga('controleCC ainda rodando, enviando sinal KILL');
				posix_kill($pidContCC, SIGKILL);
			}
		}
	}
	
	function loga($msg) {
		echo '['.date('d/m/y H:i:s')."][<MONITOR>]  > $msg\n";
	}
?>
