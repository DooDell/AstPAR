#!/usr/bin/php -c /usr/lib/telefoniaip/arquivos/config/php.ini
<?php
	include(''.'/usr/lib/telefoniaip/includePrincipal.php');
	
	echo "Inicializando filas...............: ";
	
	$conn = new Conexao();
	if($conn->connOK()) {
		$nomesFilas = array();
		$conn->executa('SELECT name FROM fila');
		while($conn->temMaisDados())
			$nomesFilas[] = $conn->data['name'];
		$conn->fecha();
	
		if(count($nomesFilas) > 0) {
			$errno = $errstr = 0;
			$host = Parametro::get('hostAsterisk');
			$oSocket = @fsockopen($host, 5038, &$errno, &$errstr, 20);
			if(!$oSocket) {
				echo "Imposs�vel conectar a $host [$errstr ($errno)]\n";
			} else {
				fputs($oSocket, "Action: login\r\n" .
								"Username: admin\r\n" .
								"Secret: sapo\r\n" .
								"Events: off\r\n\r\n");
				$authOK = false;
				do {
					$aux = fgets($oSocket);
					if(!$authOK && strstr($aux, 'Authentication accepted')) $authOK=true;
				} while($aux != "\r\n");
				if(!$authOK) {
					echo "Imposs�vel conectar a $host [$errstr ($errno)]\n";
				} else {
					$primeiraFila = array_shift($nomesFilas);
					for($cnt=0; $cnt<5; $cnt++) {
						$iniOK = true;
						$out = array();
						Asterisk::executaComando("queue show $primeiraFila", $oSocket, $out);
						foreach($out as $outLin) {
							if(strstr($outLin, 'No such command'))
								$iniOK = false;
						}
						if($iniOK) break;
						else       sleep(1);
					}
					if(!$iniOK) {
						echo 'Erro ao executar comandos de fila no AMI';
					} else {
						echo $primeiraFila;
						foreach($nomesFilas as $nome) {
							echo " $nome";
							Asterisk::executaComando("queue show $nome", $oSocket);
						}
					}
					fputs($oSocket, "Action: Logoff\r\n\r\n");
					while(fgets($oSocket) != "\r\n") {}
					fclose($oSocket);
				}
			}
		} else
			echo 'Nenhuma fila configurada';
	} else
		echo 'Erro ao conectar no BD';
		
	echo "\n";
?>