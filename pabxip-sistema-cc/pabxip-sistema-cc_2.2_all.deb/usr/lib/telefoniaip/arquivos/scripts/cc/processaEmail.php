#!/usr/bin/php
<?php
	/**
	 * Este script consume a sa�da do mda "maildrop" (via |) conforme configurado
	 *  (pelo postinst do pacote SISTEMA-CC) no arquivo /etc/maildroprc
	 * Esta sa�da do maildrop � os dados puros (raw) do email recebido,
	 *  com os devidos cabe�alhos
	 */

	include(''.'/usr/lib/telefoniaip/modulos/Fila/sistemaCC/includePrincipal.php');
	include(''.'/usr/lib/telefoniaip/modulos/Fila/sistemaCC/logger.php');
	
	$mais = " [\033[35;1mprocMail\033[0m]";
	
	$destino = $ramal = $corpo = $email = $boundary = $mTP = $to = false;
	$texto = false;
	$textos = array();
	$txtID = 0;
	
	// Carregar a lista de Emails cadastrados
	$filasEmail = array(); // -> Lista indexada pelo ramal
	$aux = file('/etc/asterisk/telip/cc/emailsCad.dat', FILE_IGNORE_NEW_LINES);
	foreach($aux as $filaEmail) {
		list($ramalAux, $nome, $emailAux, $hi, $hf, $his, $hfs, $hid, $hfd, $hif, $hff) = explode('-', $filaEmail);
		$filasEmail[$ramalAux] = (object)array(
			'ramal' => $ramalAux,
			'nome'  => $nome,
			'email' => $emailAux,
			'hni'   => $hi,		// Hor�rio normal
			'hnf'   => $hf,
			'hsi'   => $his,	// Hor�rio S�bado
			'hsf'   => $hfs,
			'hdi'   => $hid,	// Hor�rio Domingo
			'hdf'   => $hfd,
			'hfi'   => $hif,	// Hor�rio Feriado
			'hff'   => $hff
		); 
	}
	
	while(!feof(STDIN)) {
		$line = trim(fgets(STDIN));
		//system("echo '$line' >> /tmp/MAIL");
		
		// Procura a 1a linha em branco
		if(!$corpo && empty($line)) $corpo = true;

		if(!$corpo) {
			// Processar os cabecalhos
			list($head, $val) = explode(': ', $line);
			if($head == 'From') $email = $val;
			if($head == 'Content-Type' && strstr($val, 'boundary=')) list($d,$boundary) = explode('boundary=', $val);
			if($head == 'To') $to = true;
			if($to && !$destino) {
				foreach($filasEmail as $rml => $dados) {
					if(strstr($line, $dados->email)) {
						$destino = $dados->email;
						$ramal  = $rml;
					}
				}
			}
		} else {
			// Processar o corpo da MSG
			if(!$boundary) $texto .= "$line\n";
			else {
				if($line == "--$boundary" || $line == "--$boundary--") {
					$txtID++;
					$textos[$txtID] = false;
				} else {
					if($textos[$txtID] === false) {
						if(empty($line)) $textos[$txtID] = true;
						else if(strstr($head, 'Content-Type: ') && strstr($val, 'text/plain')) $mTP = $txtID;
					} else {
						if($textos[$txtID] === true) $textos[$txtID] = '';
						$textos[$txtID] .= "$line\n";
					}
				}
			}
		}
	}
	
	if(!$destino) {
		loga(LOG_CRITICO, "Email recebido de \033[36;1m$email\033[0m para fila [\033[31;1mDESCONHECIDA\033[0m]", $mais);
		return 0;
	}
	
	$nomeFila = $filasEmail[$ramal]->nome;

	// Calcular o timestamp do arquivo para um hor�rio dentro do atendimento da Fila
	// TODO feriados!
	$TStouch = 0; 
	$agora = time();
	switch(date('w')) {
		case 5:  $hoje = 'n'; $amanha = 's'; break; // Sexta
		case 6:  $hoje = 's'; $amanha = 'd'; break; // S�bado
		case 0:  $hoje = 'd'; $amanha = 'n'; break; // Domingo
		default: $hoje = 'n'; $amanha = 'n'; break; // Segunda a Quinta
	}
	$aux = 'h'.$hoje.'i';
	list($hora, $minuto) = explode(':', $filasEmail[$ramal]->$aux);
// TODO verificar se hoje existe horario de atendimento
	if($agora < mktime($hora, $minuto, 0)) {
		// Estamos no inicio do dia mas ainda n�o entramos no horario de atd, programar a chamada para o hor�rio inicial de atd de hoje
		$TStouch = mktime($hora, $minuto, 0);
	} else {
		$aux = 'h'.$hoje.'f';
		list($hora, $minuto) = explode(':', $filasEmail[$ramal]->$aux);
		if($agora < mktime($hora, $minuto, 0)) {
			// Estamos no hor�rio de atd, disparar a chamada imediatamente
			$TStouch = $agora;
		} else {
			// Estamos no final do dia mas ap�s o horario de atd, programar a chamada para o hor�rio inicial de amanh�
// TODO verificar se amanha existe horario de atendimento
			$aux = 'h'.$amanha.'i';
			list($hora, $minuto) = explode(':', $filasEmail[$ramal]->$aux);
			$TStouch = mktime($hora, $minuto, 0, date('m'), date('d')+1);
		}
	}
	
	$msgAgd = ($TStouch != $agora) ? ". Chamada agendada para " . date('d/m/Y H:i', $TStouch) : '';
	loga(LOG_NORMAL, "Email recebido de \033[36;1m$email\033[0m para fila [\033[34;1m$nomeFila\033[0m]$msgAgd", $mais);
	
	$idEmail = microtime(true);
	// Salva o email em um arquivo que ser� apresentado ao agente	
	if(!$boundary) $txt = $texto;
	else if($mTP)  $txt = $textos[$mTP];
	else           $txt = $textos[1];
	$salvaEmail = "Email recebido em " . date('d/m/y H:i') . "<br><br>\n$txt";
	file_put_contents("/var/spool/asterisk/tmp/EMAIL-$idEmail", $salvaEmail);
	// Privilegio de leitura para o webserver
	chown("/var/spool/asterisk/tmp/EMAIL-$idEmail", 'www-data');

	// Local/999900@filasEmail => MOH
	$callStr = 
"Channel: Local/999900@filasEmail
MaxRetries: 1
Context: filasEmail
Extension: $ramal
Priority: 1
Set: EMAIL=$email
Set: IDEMAIL=$idEmail
";
	file_put_contents("/tmp/CALL-$idEmail", $callStr);
	// Setar o timestamp do arquivo para o hor�rio calculado
	touch("/tmp/CALL-$idEmail", $TStouch, $TStouch);
	
	// Dispara o call file
	rename("/tmp/CALL-$idEmail", "/var/spool/asterisk/outgoing/CALL-$idEmail");
?>