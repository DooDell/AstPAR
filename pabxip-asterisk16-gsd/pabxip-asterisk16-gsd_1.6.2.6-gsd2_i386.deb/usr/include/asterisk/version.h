/*
 * version.h 
 * Automatically generated
 */
#define ASTERISK_VERSION "1.6.2.6"
#define ASTERISK_VERSION_NUM 10602

