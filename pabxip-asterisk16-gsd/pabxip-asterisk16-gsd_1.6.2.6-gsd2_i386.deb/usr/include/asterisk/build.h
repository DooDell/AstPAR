/*
 * build.h 
 * Automatically generated
 */
#define BUILD_HOSTNAME "lennyBase"
#define BUILD_KERNEL "2.6.26-2-686"
#define BUILD_MACHINE "i686"
#define BUILD_OS "Linux"
#define BUILD_DATE "2010-06-09 18:49:39 UTC"
#define BUILD_USER "root"

