#!/usr/bin/php -q
<?php
	include(''."/usr/lib/telefoniaip/includePrincipal.php");
	
	return Arquivos::atzConfsLocaisBD();
?>