#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>

#define PORT 8080

#define BUFSIZE 8096
#define ERROR 42
#define SORRY 43
#define LOG   44

void loga(int type, char *s1, char *s2)
{
	switch (type) {
		case ERROR: (void)printf("ERROR: %s:%s Errno=%d exiting pid=%d\n", s1, s2, errno, getpid()); break;
		case SORRY: (void)printf("SORRY: %s:%s\n", s1, s2); break;
		case LOG:   (void)printf(" INFO: %s:%s\n", s1, s2); break;
	}
	if(type == ERROR || type == SORRY) exit(3);
}

int initHttp()
{
	int listenfd;
	static struct sockaddr_in serv_addr; /* static = initialised to zeros */

	/* setup the network socket */
	if((listenfd = socket(AF_INET, SOCK_STREAM,0)) <0)
		loga(ERROR, "system call", "socket");

	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
	serv_addr.sin_port = htons(PORT);
	if(bind(listenfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)
		loga(ERROR, "system call", "bind");
	if(listen(listenfd, 64) < 0)
		loga(ERROR, "system call", "listen");

	return listenfd;
}

int shutHttp(int listenfd)
{
	(void)close(listenfd);
}

char getAction(int listenfd, char *numDial) {
	char act = '?', ch = 0;
	int socketfd, i = 0;
	size_t length;
	static struct sockaddr_in cli_addr; /* static = initialised to zeros */
	static char buffer[BUFSIZE+1];      /* static so zero filled */

	length = sizeof(cli_addr);
	if((socketfd = accept(listenfd, (struct sockaddr *)&cli_addr, &length)) < 0)
		loga(ERROR, "system call", "accept");

	if(read(socketfd, buffer, BUFSIZE) <= 0) {	/* read failure stop now */
		loga(SORRY, "failed to read browser request", "");
	} else {
		loga(LOG, "request", buffer);
		act = (!strncmp(buffer, "GET /action.", 12)) ? buffer[12] : '?';
		if(act == 'd') {
			while(ch != '-' && i < 64) {
				ch = buffer[i + 13];
				if(ch != '-') numDial[i++] = ch;
			}
			numDial[i] = 0;
		}
	}

	(void)sprintf(buffer,"HTTP/1.0 200 OK\r\nContent-Type: text/plain\r\n\r\n");
	switch(act) {
		case 'r': (void)strcat(buffer, "REGISTER\r\n"); break;
		case 'u': (void)strcat(buffer, "UNREG   \r\n"); break;
		case 'd': (void)strcat(buffer, "DIAL    \r\n"); break;
		case 'a': (void)strcat(buffer, "ANSWER  \r\n"); break;
		case 'h': (void)strcat(buffer, "HANGUP  \r\n"); break;
		case 'q': (void)strcat(buffer, "QUIT    \r\n"); break;
		default:  (void)strcat(buffer, "UNKNOWN \r\n");
	}
	(void)write(socketfd, buffer, strlen(buffer));

	(void)close(socketfd);

	return act;
}
