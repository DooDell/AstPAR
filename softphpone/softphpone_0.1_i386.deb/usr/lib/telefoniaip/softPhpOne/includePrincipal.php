<?php
	require_once('classes/Sip.php');
	require_once('classes/SipRtp.php');
	require_once('classes/PacoteSip.php');
	require_once('classes/InfoHost.php');
	require_once('classes/Util.php');
?>
