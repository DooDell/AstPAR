<?php
class PacoteSip {
	private $metodo;
	private $atributos, $spd;
	public  $prox;
	
	public function PacoteSip($metodo="", $atrs=array(), $sdp=array()) {
		$this->metodo    = $metodo;
		$this->atributos = $atrs;
		$this->sdp       = $sdp;
		$this->prox      = NULL;
	}
	
	static function getCSeq($metodo) {
		if(!isset($GLOBALS[$metodo])) {
			$GLOBALS[$metodo] = 30;
			$cseq = 30;
		} else {
			$cseq = $GLOBALS[$metodo] + 1;
			$GLOBALS[$metodo] = $cseq;
		}
		return "$cseq $metodo";
	}
	
	static function parse($rbuff) {
    	$ret = null;
    	if(strlen($rbuff) > 0) {
    		$utlSL = 10;
    		$aux = null;
    		$temDados = false;
    		$gravaMetodo = true;
    		foreach(explode("\r\n", $rbuff) as $lin) {
				$len = strlen($lin);
				if($len == 0 && $utlSL == 0) break;
    			if($len < 1) {
					$gravaMetodo = true;			
    			} else {
    				if($gravaMetodo) {
    					if(is_a($aux, 'PacoteSip')) {
    						$aux->prox = new PacoteSip();
							$aux =& $aux->prox;
    					} else {
    						$ret = new PacoteSip();
							$aux =& $ret;
    					}
    					$aux->setMetodo($lin);
    					$gravaMetodo = false;
    				} else {
	    				list($chave, $valor) = explode(": ", $lin);
    					$aux->setAtr($chave, $valor);
    				}
	   			}
    			$utlSL = $len;
    		}
    	}
    	$aux->prox = null;
		return $ret;
	}
		
	function vazio() {
		return (count($this->atributos) == 0);
	}
	
	function setMetodo($metodo) {
		$this->metodo = $metodo;
	}
	
	function setAtr($chave, $valor=null) {
		if(is_array($chave)) {
			foreach($chave as $c => $v) {
				if($c == 'Content-Length') $v = $this->getLenSdp();
				$this->atributos[$c] = $v;
			}
		} else {
			if($chave == 'Content-Length') $valor = $this->getLenSdp();
			$this->atributos[$chave] = $valor;
		}
	}
	
	function getAtr($chave) {
		return $this->atributos[$chave];
	}
	
	function temAtr($chave) {
		return in_array($chave, array_keys($this->atributos));
	}
	
	function getCod() {
		list($d,$cod) = explode(' ', $this->metodo);
		return $cod;
	}
	
	function setSdp($chave, $valor=null) {
		if(is_array($chave)) {
			foreach($chave as $c => $v)
				$this->sdp[$c] = $v;
		} else
			$this->sdp[$chave] = $valor;
	}
	
	function getLenSdp() {
		$ret = 0;
		foreach($this->sdp as $sdp)
			$ret += strlen($sdp) + 2 + 2;
		return $ret + 2;
	}
	
	function mostra() {
		$ret = "";
		$aux =& $this;
		while($aux) {
			$str = "" . $aux;
			if(strlen($str)) $ret .= "$str \n";
			$aux = $aux->prox;
		}
		return $ret;
	}
	
	function __toString() {
		$ret = $this->metodo . "\r\n";
		foreach($this->atributos as $chave => $valor)
			$ret .= "$chave: $valor\r\n";
		if(count($this->sdp) > 1) {
			$ret .= "\r\n";
			foreach($this->sdp as $chave => $valor) {
				$ch = substr($chave, 0, 1);
				$ret .= "$ch=$valor\r\n";
			}
		}
		return $ret . "\r\n";
	}
}
?>