<?php
	require_once('includePrincipal.php');
	
	$meusDados = array(
				'IPLocal'       => '192.168.1.117',
				'PortaLocal'    => '5061',
				'PortaRTPLocal' => '5016',
				'HostName'      => 'ortiz'
			);
	
	$sip = new Sip(new InfoHost('127.0.0.1'), $meusDados);
	$sip->conecta();
	
	$err = $sip->efetuaLogin(array('user' => 'teste', 'pass' => '123456'));
	/*if($err === true)
		$err = "Login efetuado com sucesso!";
	echo $err;*/
	
	$err = $sip->invite(array('num' => '6001', 'calerid' => 'Teste SoftPhone'));
	/*if($err === true)
		$err = "Invite efetuado com sucesso!";
	echo $err;*/
	
	$rtp = new SipRtp('192.168.0.222', 5016);
	$rtp->escuta();
	
	$sip->desconecta();
?>
