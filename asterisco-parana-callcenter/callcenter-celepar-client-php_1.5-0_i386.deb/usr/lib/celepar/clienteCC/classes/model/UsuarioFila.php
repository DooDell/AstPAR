<?php
class UsuarioFila extends bdFacil {
	public $codusu, $codfila;
}
?>
