<?php
class Usuario extends bdFacil {
	public $login, $telefone, $nome, $ramal, $senha, $tipo;
	public $codstatus, $tempostatus, $numsai, $numentra, $filaentra;
	public $emligacao, $chamando, $sainte, $timer, $idfila, $msg, $nomefone;
}
?>
