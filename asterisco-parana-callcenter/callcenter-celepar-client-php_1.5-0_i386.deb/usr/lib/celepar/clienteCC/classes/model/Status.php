<?php
class Status extends bdFacil {
	public $nome, $nomestatus;
}
?>
