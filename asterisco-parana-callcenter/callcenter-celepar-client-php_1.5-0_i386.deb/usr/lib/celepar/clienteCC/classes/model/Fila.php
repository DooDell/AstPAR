<?php
class Fila extends bdFacil {
	public $nome, $qtdchamespera, $tempomedioespera, $tempoespera;
	public $qtdchamrecebida, $qtdchamatendida, $tempomedioatend, $tempomedioabandono;
}
?>
