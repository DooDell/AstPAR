<?php
class bdFacil {
	var $id;
	var $atributos;
	
	function bdFacil($id=0) {
		$this->id = $id;
		if($id == "doRequest") {
			$this->id = null;
			$this->carregarDoRequest();
		} else if(is_numeric($id) && $id > 0)
			$this->carregar();
	}
	
	function getNomeTabela() {
		return "cc_" . strtolower(get_class($this));
	}
	
	/**
	 * Carrega um objeto qualquer do banco, pelo seu ID
	 * Relaciona as colunas da respectiva tabela com
	 * os atributos desta mesma classe
	 */
	function carregar() {
		$nomeClasse = $this->getNomeTabela();
		
		if(empty($this->id) || $this->id == 0) return "Objeto sem ID";
		$id = $this->id;
		
		Logger::loga(LOG_DEBUG1, "Carregando $nomeClasse($id)");
		
		$ret = true;
		$conn = new Conexao();
		$sql = "SELECT * FROM $nomeClasse WHERE id = $id";
		if(!is_string($ret=$conn->executa($sql))) {
			if($conn->temMaisDados()) {
				foreach(array_keys($conn->data) as $nomeAtrBD) {
					if(!is_numeric($nomeAtrBD)) {
						$achou = false;
						foreach(array_keys(get_object_vars($this)) as $nomeAtr) {
							if(strcasecmp($nomeAtr, $nomeAtrBD) == 0) {
								$achou = $nomeAtrBD;
								break;
							}
						}
						if($achou) {
							$this->$nomeAtr = $conn->data[$achou];
						} else {
							$err = "A coluna $nomeAtrBD da tabela $nomeClasse n�o tem atributo correspondente na respectiva classe.";
							Logger::loga(LOG_AVISO, "*** $err");
						}
					}
				}
			} else {
				Logger::loga(LOG_CRITICO, "Objeto $nomeClasse [id=$id] n�o encontrado");
			}
		}
		$conn->fecha();
		return $ret;
	}
	
	/**
	 * Popula um objeto relcionando os atributos da classe com os
	 * atributos no request.
	 */
	function carregarDoRequest() {
		$atrsDaClasse = $this->getAtributos();
		foreach(explode(",", $atrsDaClasse) as $nomeAtr) {
			if(isset($_REQUEST[$nomeAtr]))
				$this->$nomeAtr = $_REQUEST[$nomeAtr];
		}
	}

	
	/**
	 * Busca no banco os nomes dos atributos de uma classe
	 */
	private function getAtributos($semID=false) {
		if(empty($this->atributos)) {
			$conn = new Conexao();
			// vers�o MySQL
			/*$sql = "SELECT column_name FROM INFORMATION_SCHEMA.COLUMNS " .
					"WHERE table_name = '". strtolower(get_class($this)) ."' " .
					"AND table_schema = '" .$conn->db. "' " .
					"ORDER BY ordinal_position";*/
			// vers�o PostgreSQL
			$sql = "SELECT a.attnum, a.attname as column_name " .
					"FROM pg_class as c, pg_attribute a " .
					"WHERE a.attnum > 0 AND a.attrelid = c.oid " .
						"AND c.relname = '". $this->getNomeTabela() ."' " .
					"ORDER BY a.attnum";
			$conn->executa($sql);
			while($conn->temMaisDados()) {
				$atr = $conn->data['column_name'];
				if($atr != "id") {
					if(!empty($this->atributos)) $this->atributos .= ",";
					$this->atributos .= $atr;
				}
			}
			$conn->fecha();
		}
		return (($semID)?"":"id,").$this->atributos;
	}
	
	/**
	 * Salva um <b>novo</b> objeto no banco
	 */
	function salvar() {
		$atrsParaSalvar = $this->getAtributos(false);
		$nomeClasse = $this->getNomeTabela();
		Logger::loga(LOG_DEBUG1, "Salvando $nomeClasse");
		
		foreach(explode(",", $atrsParaSalvar) as $atr) {
			if(!empty($valores)) $valores .= ",";
			$valores .= "'". $this->$atr ."'";
		}
		
		$ret  = true;
		$conn = new Conexao();
		$sql  = "INSERT INTO $nomeClasse($atrsParaSalvar) VALUES($valores)";
		$ret  = $conn->executa($sql);
		$conn->fecha();
		return $ret;
	}
	
	/**
	 * Atualiza um Objeto no banco
	 */
	function atualizar() {
		$camposParaAtualizar = $this->getAtributos();
		$nomeClasse = $this->getNomeTabela();
		if(empty($this->id) || $this->id == 0) return "Objeto sem ID";
		$id = $this->id;
		Logger::loga(LOG_DEBUG1, "Atualizando $nomeClasse[$id]");
		foreach(explode(",", $camposParaAtualizar) as $atr) {
			if(!empty($valores)) $valores .= ",";
			$valores .= "'" . $this->$atr . "'";
		}
		$camposSet = "";
		foreach(explode(",", $camposParaAtualizar) as $atr) {
			if(!empty($camposSet)) $camposSet .= ",";
			$camposSet .= "$atr='" . $this->$atr . "'";
		}
		
		$ret  = true;
		$conn = new Conexao();
		$sql  = "UPDATE $nomeClasse SET $camposSet WHERE id = $id";
		$ret  = $conn->executa($sql);
		$conn->fecha();
		return $ret;
	}
	
	/**
	 * Remove um objeto do banco.
	 * @param int idP - Opcional, que indica o ID do objeto desta classe a ser removido
	 */
	function remover($idP="") {
		$id = (empty($idP)) ? $this->id : $idP;
		if(empty($id) || !is_numeric($id)) return "Objeto sem ID";
		$nomeClasse = $this->getNomeTabela();
		Logger::loga(LOG_DEBUG1, "Removendo $nomeClasse[$id]");
		$ret  = true;
		$conn = new Conexao();
		$sql = "DELETE FROM $nomeClasse WHERE id = $id";
		//echo $sql;
		$ret  = $conn->executa($sql);
		$conn->fecha();
		return $ret;
	}
	
	/**
	 * Lista os IDs (por padr�o), ou outro campo, de uma tabela
	 * @param String nomeTabela - Noma da tabela a listar os IDs
	 * @param String ordem - Opcional, coluna para ser usada na ordenao dos IDs
	 */
	static function listaIds($nomeTabela, $ordem="id", $campo="id") {
		$ret = array();
		$conn = new Conexao();
		$ord = (!empty($ordem)) ? " ORDER BY $ordem" : "";
		$sql = "SELECT $campo FROM cc_" . strtolower($nomeTabela) . " $ord";
		if(!is_string($err = $conn->executa($sql))) {
			while($conn->temMaisDados())
				$ret[] = $conn->data[$campo];
		} else $ret = $err;
		$conn->fecha();
		return $ret;
	}
	
	/**
	 * Retorna um array com todos os objetos cadastrados
	 */
	static function todos($nomeTabela, $ids=null) {
		if(!is_array($ids))
			$ids = bdFacil::listaIds($nomeTabela);
		$ret = array();
		foreach($ids as $id)
			$ret[$id] = new $nomeTabela($id);
		return $ret;
	}
	
	/**
	 * Retorna o proximo numero de uma coluna qualquer de uma tabela qualquer
	 * SQL gerado: "SELECT MAX($colunaMax$) FROM $tabela$ "
	 *   + opcionalmente: " WHERE $campoWhere$ = '$valorWhere$'"
	 * @param String colunaMax - nome da coluna (atributo) que se deseja o proximo
	 * @param String tabela - Nome da tabela que contem a colunaMax
	 * @param String campoWhere - Opcional nome do campo restritivo
	 * @param String valorWhere - Opcional valor do campo restritivo
	 * @param int padrao - Opcional, valor a ser retornado caso nao ache outro valor.
	 * @return int proximo numero desejado ou MSG de erro
	 */
	static function proxNum($colunaMax, $tabela, $campoWhere="", $valorWhere="", $padrao=1) {
		$ret = $padrao;
		$conn = new Conexao();
		$url = "SELECT MAX($colunaMax) AS maxNS FROM cc_$tabela";
		if(!empty($campoWhere)) $url .=	" WHERE $campoWhere = '$valorWhere'";
		if($conn->executa($url)) {
			if($conn->temMaisDados())
				$ret = $conn->data[0] + 1;
		}
		$conn->fecha();
		return $ret;
	}
	
	/**
	 * Carrega um array de objetos de uma tabela com alguma restricao
	 * SQL gerado: "SELECT id FROM $estaClasse$ WHERE $nomeOutro$ = $idOutro" 
	 *   + Opcionalmente: " ORDER BY $ordem$"
	 * @param String estaClasse - Nome da tabela/classe a listar 
	 * @param String nomeOutro - Nome do campo restritivo
	 * @param String idOutro - Valor do campo restritivo
	 * @param String ordem - Opcional, coluna a ser usada na ordenao
	 * @return Lista - Lista de objetos da classe $estaClasse$ ou MSG de erro  
	 */
	static function carregarPor($estaClasse, $where, $ordem="", $max="") {
		$conn = new Conexao();
		$sql = "SELECT id FROM cc_$estaClasse " .
			   "WHERE $where " . (!empty($ordem) ? " ORDER BY $ordem" : "") .
			   (!empty($max) ? " LIMIT $max" : "");
		$ids = $conn->arrayDeInteiros($sql);
		$conn->fecha();
		if(is_string($ids)) return $ids;
		$ret = array();
		foreach($ids as $id)
			$ret[] = new $estaClasse($id);
		return $ret;
	}
	
	/**
	 * Carrega um ID de uma tabela com alguma restricao
	 * SQL gerado: "SELECT id FROM $estaClasse$ WHERE $nomeOutro$ = '$valOutro'" 
	 * @param String estaClasse - Nome da tabela/classe a listar 
	 * @param String nomeOutro - Nome do campo restritivo
	 * @param String valOutro - Valor do campo restritivo
	 * @return int - ID do objeto da classe $estaClasse$ ou MSG de erro  
	 */
	static function getIdPor($estaClasse, $nomeOutro, $valOutro) {
		$ret = 0;
		$sql = "SELECT id FROM cc_$estaClasse WHERE $nomeOutro = '$valOutro'";
		$conn = new Conexao();
		$conn->executa($sql);
		if($conn->temMaisDados())
			$ret = $conn->data[0];
		$conn->fecha();
		return $ret;
	}
	
	/**
	 * Retorna o total de linhas de uma tabela.
	 * @param String nomeClasse - Nome da classe a saber o total cadastrado no banco.
	 * @return int do total de linhas
	 */
	static function total($nomeClasse) {
		$conn = new Conexao();
		if(!is_string($ret = $conn->executa("SELECT COUNT(*) AS total FROM cc_$nomeClasse"))) {
			if($conn->temMaisDados())
				$ret = $conn->data["total"];
			else
				$ret = 0;
		}
		$conn->fecha();
		return $ret;
	}
}
?>