<?php
class Config {
	private $arq;
	public $tel, $bdHost, $bdDB, $bdUser, $bdPass;
	
	public function __construct($arq = "clienteCC2.conf") {
		$this->arq = "/etc/" . $arq;
		if(!$this->ler()) {
			$this->tel    = "vazio";
			$this->bdHost = "cac.gism.celepar.parana";
			$this->bdDB   = "cc";
			$this->bdUser = "sa_cc";
			$this->bdPass = "sapo";
			$this->salvar();
		}
	}
	
	function salvar() {
		$txt = 
'// Arquivo de configuracao do clienteCC
$tel = "'    .$this->tel. '";
$bdHost = "' .$this->bdHost. '";
$bdDB = "'   .$this->bdDB. '";
$bdUser = "' .$this->bdUser. '";
$bdPass = "' .$this->bdPass. '";
';
		file_put_contents($this->arq, $txt);
	}
	
	function ler() {
		if(!file_exists($this->arq)) return false;
		$txt = file_get_contents($this->arq);
		if(strstr($txt, "// Arquivo de configuracao do clienteCC")) {
			$tel = $bdHost = $bdDB = $bdUser = $bdPass = null;
			eval($txt);
			$this->tel    = $tel;
			$this->bdHost = $bdHost;
			$this->bdDB   = $bdDB;
			$this->bdUser = $bdUser;
			$this->bdPass = $bdPass;
			return true;
		}
	}
}
?>