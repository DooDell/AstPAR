<?php
class Logger
{
	static function loga($nivelDebug, $texto) {
		if($nivelDebug <= NIVEL_DEBUG) {
			$data = date("d/m/y");
			$hora = date("H:i:s");
			echo("[$data $hora] > $texto\n");
		}
	}
}
?>