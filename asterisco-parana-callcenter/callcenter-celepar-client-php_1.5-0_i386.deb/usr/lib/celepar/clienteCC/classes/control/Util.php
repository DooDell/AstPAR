<?php
class Util
{
	static function alerta($msg) { // note 1
		$dialog = new GtkDialog("Alerta", null, Gtk::DIALOG_MODAL);
		$dialog->set_position(Gtk::WIN_POS_CENTER_ALWAYS);
		$top_area = $dialog->vbox;
		$top_area->pack_start($hbox = new GtkHBox());
		$stock = GtkImage::new_from_stock(Gtk::STOCK_DIALOG_WARNING, Gtk::ICON_SIZE_DIALOG);
		$hbox->pack_start($stock, 0, 0);
		$hbox->pack_start(new GtkLabel($msg));
		$dialog->add_button(Gtk::STOCK_OK, Gtk::RESPONSE_OK);
		$dialog->set_has_separator(false);
		$dialog->show_all();
		$dialog->run();
		$dialog->destroy();
	}
	
	static function comecaCom($str, $comeco) {
		return(substr($str, 0, strlen($comeco)) == $comeco);
	}
}
?>