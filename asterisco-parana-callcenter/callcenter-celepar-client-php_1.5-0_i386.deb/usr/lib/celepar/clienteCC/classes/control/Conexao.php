<?php
/**
 * Conex�o com o banco de dados PostgreSQL
 * @author Gabriel Ortiz - gabrielortizlour@gmail.com
 * @version 1.0, 01/05/2008
 */
class Conexao {
	public $id, $res, $qtd, $data, $erro;
	
	/**
	 * Faz a conex�o com o BD
	 */
	function Conexao() {
		global $config;
		if(!is_a($config, "Config")) die("ERRO: Parametro de Conexao deve ser da classe Config\n");
		if(!is_resource($GLOBALS['idBD']))
			$GLOBALS['idBD'] = @pg_connect("host=$config->bdHost dbname=$config->bdDB user=$config->bdUser password=$config->bdPass");
		$this->id = $GLOBALS['idBD'];
		$this->db = $config->bdDB;
		if(is_resource($GLOBALS['idBD']))
			pg_query("SET NAMES 'LATIN1'");
	}
	
	/**
	 * Retorna um array de inteiros conforme o SQL, que deve estar
	 * estruturado de forma a prover um... array de ints!
	 * @param String sql - SQL na forma "SELECT id FROM ....", id ou outro campo int
	 */
	function arrayDeInteiros($sql) {
		$ret = array();
		$err = $this->executa($sql);
		if(is_string($err)) return $err;
		while($this->temMaisDados())
			$ret[] = $this->data[0];
		return $ret;
	}

	/**
	 * Executa uma query no BD e retorna os dados.
	 * @param String sql - SQL a ser executado
	 * @return true para OK, ou MSG de erro
	 */
	function executa($sql) {
		if ($sql=="")	{
			$this->res = null;
			$this->qtd = null;
		} else {
			global $MOSTRA_SQL;
			
			$this->res = pg_query($this->id, $sql);
			if($MOSTRA_SQL)	Logger::loga(LOG_DEBUG0, ">>> Executando SQL: [$sql]");
			if ($this->res) {
				$this->qtd = @pg_num_rows($this->res);
				return true;
			} else {
				$err = "Erro SQL[" . pg_last_error($this->id) . "]";
				Logger::loga(LOG_CRITICO, "!!! $err");
				return $err;
			}
		}
	}

	/**
	 * Busca os dados de uma linha do resultado e posiciona o ponteiro na prxima.
	 * Para listar os dados no cdigo basta utilizar por exemplo:
	 *                while ($conn->temMaisDados())  {
	 *                   echo $conn->data["nome"];
	 *                }
	 * Caso o parametro no seja vazio j retorna o valor do campo pedido. Exemplo:
	 * 								$conn->executa("SELECT a FROM b WHERE c=1")
	 * 								echo $conn->temMaisDados("a")
	 */
	function temMaisDados($campo="") {
		$this->data = pg_fetch_array($this->res);
		return ($this->data) ? true : false;
		
	}

	/**
	 * Encerra a conexo com o banco de dados.
	 */
	function fecha($deVerdade = false) {
		if($deVerdade && is_resource($this->id))
			pg_close($this->id);
		$this->id = "";
		$this->res = 0;
		$this->qtd = 0;
		$this->data = "";
	}
}
?>