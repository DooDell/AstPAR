<?php
class JanelaAgente extends GtkWindow
{
	private $btnLoginClicado = false, $btnSairClicado = false, $emEspera = false;
	private /* Conexao */ $conn;
	private /* List<Status> */ $statusPausa;

	// Widgets
	private $btnLogin, $btnPausa, $btnIndisp, $btnSair;
	private $listaFilas;
	private $btnDiscar, $btnTransf, $btnEspera, $btnConferencia;
	private $cxDisca, $cxNumEntra;
	private $statusBar;
	private $popupPausa;
	
	public function JanelaAgente() {
		parent::__construct();
		
		$this->connect_simple('destroy', array($this, 'sair'), true);
		$this->set_title(".: Call Center CELEPAR :.");
		$this->set_position(Gtk::WIN_POS_CENTER);
		$this->set_default_size(600, 400);
		//$this->set_border_width(8);
		$this->set_icon(GdkPixbuf::new_from_file("gfx/telefonista.png"));

		$this->initDados();		
		$this->add($this->criaInterface());
		$this->show_all();
		
		Gtk::timeout_add(1500, array($this, "funcTimer"));
	}
	
	function initDados() {
		$this->statusPausa = bdFacil::carregarPor('Status', 'id >= 100 AND id < 200');
	}
	
	function funcTimer() {
		if($this->btnLoginClicado) {
			global $usuario, $MOSTRA_SQL;
$MOSTRA_SQL = false;
			$idU = $usuario->id;
			$usuario = new Usuario($idU);
			//var_dump($usuario);
			
			// Ao deslogar fecha a janela
			if($this->btnSairClicado && $usuario->codstatus == 0) {
				$this->sair();
				return false;
			}
			
			if($this->btnSairClicado) return true;
			
			// Atualizar os bot�es de acordo com o Status do Usu�rio
			$habBtns = ($usuario->codstatus > 0);
			$this->btnDisp->set_sensitive($habBtns);
			$this->btnPausa->set_sensitive($habBtns);
			$this->btnIndisp->set_sensitive($habBtns);
			$this->btnDiscar->set_sensitive($habBtns);
			$this->btnTransf->set_sensitive($habBtns);
			$this->btnEspera->set_sensitive($habBtns);
			$this->btnConferencia->set_sensitive($habBtns);
			
			$this->btnDisp->modify_bg(Gtk::STATE_NORMAL, GdkColor::parse('#FFFFFF'));
			$this->btnPausa->modify_bg(Gtk::STATE_NORMAL, GdkColor::parse('#FFFFFF'));
			$this->btnIndisp->modify_bg(Gtk::STATE_NORMAL, GdkColor::parse('#FFFFFF'));
			
			if($usuario->codstatus == 1) {
				$this->btnDisp->modify_bg(Gtk::STATE_NORMAL, GdkColor::parse('#339999'));
			} else if($usuario->codstatus >= 100 && $usuario->codstatus < 200) {
				$this->btnPausa->modify_bg(Gtk::STATE_NORMAL, GdkColor::parse('#339999'));
			} else if($usuario->codstatus >= 200) {
				$this->btnIndisp->modify_bg(Gtk::STATE_NORMAL, GdkColor::parse('#339999'));
			}
			
			// Atualizar as caixas de texto
			if(!empty($usuario->numentra)) {
				$this->cxNumEntra->set_text($usuario->numentra .
					((!empty($usuario->idfila)) ? ", fila [$usuario->idfila]" : ""));
			}
			// Atualizar a cor das caixas de texto
			if($usuario->emligacao > 0) {
				$this->cxNumEntra->modify_base(Gtk::STATE_NORMAL, GdkColor::parse('#9999FF'));
			} else {
				if($usuario->chamando == "t") {
					$this->cxNumEntra->modify_base(Gtk::STATE_NORMAL, GdkColor::parse('#FF9999'));
				} else {
					$this->cxNumEntra->modify_base(Gtk::STATE_NORMAL, GdkColor::parse('#FFFFFF'));
				}
			}
			
			// Atualizar a tabela de filas
			$conn = new Conexao();
			$sql = "SELECT f.id FROM cc_fila f, cc_usuariofila uf " .
					"WHERE uf.codusu = $usuario->id AND f.id = uf.codfila";
			$ids = $conn->arrayDeInteiros($sql);
			$conn->fecha();
			if(is_array($ids)) {
				$filas = bdFacil::todos("Fila", $ids);
				$this->listaFilas->limpa();
				foreach($filas as $fila)
					$this->listaFilas->addLinha("$fila->nome,$fila->qtdchamespera,$fila->tempoespera,$fila->tempomedioespera");
			}
		}
$MOSTRA_SQL = true;
		return true;
	}
	
	function on_Login_clicked($btn) {
		global $usuario;
		ClienteCC::enviaComando("login:$usuario->ramal:$usuario->telefone:$usuario->senha");
		$this->btnLogin->set_sensitive(false);
		$this->btnLoginClicado = true;
	}
	
	function on_Disponivel_clicked($btn) {
		global $usuario;
		ClienteCC::enviaComando("mudaStatus:$usuario->id:$usuario->codstatus:1");
	}
	
	function on_Pausa_clicked($btn) {
	    $this->popupPausa->mostra();
	}
	
	function on_Indisponivel_clicked($btn) {
		global $usuario;
		ClienteCC::enviaComando("mudaStatus:$usuario->id:$usuario->codstatus:200");
	}
	
	function on_Sair_clicked($btn) {
		if(!$this->btnLoginClicado) {
			$this->sair();
		} else {
			global $usuario;
			ClienteCC::enviaComando("logoff:1:$usuario->ramal:$usuario->senha");
			$this->btnSairClicado = true;
			$this->btnDisp->set_sensitive(false);
			$this->btnPausa->set_sensitive(false);
			$this->btnIndisp->set_sensitive(false);
			$this->btnDiscar->set_sensitive(false);
			$this->btnTransf->set_sensitive(false);
			$this->btnEspera->set_sensitive(false);
			$this->btnConferencia->set_sensitive(false);
		}
	}
	
	function on_Discar_clicked() {
		global $usuario;
		ClienteCC::enviaComando("disca:$usuario->telefone:" . $this->cxDisca->get_text());
	}
	
	function on_Transferencia_clicked() {
		global $usuario;
		ClienteCC::enviaComando("transferir:" . $this->cxDisca->get_text());
	}
	
	function on_Espera_clicked() {
		global $usuario;
		$this->emEspera = !$this->emEspera;
		if(!$this->emEspera) {
			$this->btnDisp->modify_bg(Gtk::STATE_NORMAL, GdkColor::parse('#FFFFFF'));
			ClienteCC::enviaComando("espera:" . $usuario->telefone);
		} else {
			$this->btnDisp->modify_bg(Gtk::STATE_NORMAL, GdkColor::parse('#339999'));
			ClienteCC::enviaComando("desespera:" . $usuario->telefone);
		}
	}
	
	function on_Conferencia_clicked() {
		global $usuario;
		ClienteCC::enviaComando("conferencia");
	}
	
	function on_PopupPausa_clicked($menuItem) {
		global $usuario;
		
	    $txtMenu = $menuItem->child->get_label();
	    foreach($this->statusPausa as $status)
	    	if($status->nome == $txtMenu) break;

		ClienteCC::enviaComando("mudaStatus:$usuario->id:$usuario->codstatus:$status->id");
	}
	
	function sair() {
		$conn = new Conexao();
		$conn->fecha(true);
		gtk::main_quit();
	}
		
	function criaInterface() {
		global $usuario;
		
		$arrayTxtMotPausa = array();
		foreach($this->statusPausa as $status)
			$arrayTxtMotPausa[] = $status->nome;
		$this->popupPausa = new PopupMenu($arrayTxtMotPausa, array($this, 'on_PopupPausa_clicked'));
		
		$linhas = new GtkVBox();
		
		$colLin1BtnAcoes = new GtkHBox();
		$this->btnLogin = new GtkButton("Login");
		$this->btnLogin->set_image(GtkImage::new_from_file("gfx/telefonista.png"));
		$this->btnLogin->connect('clicked', array($this, 'on_Login_clicked'));
		$colLin1BtnAcoes->pack_start($this->btnLogin);
		
		$this->btnDisp = new GtkButton("Dispon�vel");
		$this->btnDisp->set_image(GtkImage::new_from_file("gfx/disponivel.png"));
		$this->btnDisp->connect('clicked', array($this, 'on_Disponivel_clicked'));
		$this->btnDisp->set_sensitive(false);
		$colLin1BtnAcoes->pack_start($this->btnDisp);
		
		$this->btnPausa = new GtkButton("Pausa");
		$this->btnPausa->set_image(GtkImage::new_from_file("gfx/pausa.png"));
		$this->btnPausa->connect('clicked', array($this, 'on_Pausa_clicked'));
		$this->btnPausa->set_sensitive(false);
		$colLin1BtnAcoes->pack_start($this->btnPausa);
		
		$this->btnIndisp = new GtkButton("Indispon�vel");
		$this->btnIndisp->set_image(GtkImage::new_from_file("gfx/indisponivel.png"));
		$this->btnIndisp->connect('clicked', array($this, 'on_Indisponivel_clicked'));
		$this->btnIndisp->set_sensitive(false);
		$colLin1BtnAcoes->pack_start($this->btnIndisp);
		
		$this->btnSair = new GtkButton("Sair");
		$this->btnSair->set_image(GtkImage::new_from_file("gfx/sair.png"));
		$this->btnSair->connect('clicked', array($this, 'on_Sair_clicked'));
		$colLin1BtnAcoes->pack_start($this->btnSair);
		
		$colLin1BtnAcoes->pack_start(GtkImage::new_from_file("gfx/logoAst.png"));
		$linhas->pack_start($colLin1BtnAcoes, false, false);
		
		
		$this->listaFilas = new Lista("Fila,Liga��es em Espera,Tempo de Espera,M�dia");
		$linhas->pack_start($this->listaFilas);
		
		
		$colLin3BtnCh = new GtkHBox();
		$this->btnDiscar = new GtkButton("Discar");
		$this->btnDiscar->set_image(GtkImage::new_from_file("gfx/discar.png"));
		$this->btnDiscar->connect('clicked', array($this, 'on_Discar_clicked'));
		$this->btnDiscar->set_sensitive(false);
		$colLin3BtnCh->pack_start($this->btnDiscar);
		
		$this->btnTransf = new GtkButton("Transfer�ncia");
		$this->btnTransf->set_image(GtkImage::new_from_file("gfx/transferencia.png"));
		$this->btnTransf->connect('clicked', array($this, 'on_Transferencia_clicked'));
		$this->btnTransf->set_sensitive(false);
		$colLin3BtnCh->pack_start($this->btnTransf);
		
		$this->btnEspera = new GtkButton("Espera");
		$this->btnEspera->set_image(GtkImage::new_from_file("gfx/espera.png"));
		$this->btnEspera->connect('clicked', array($this, 'on_Espera_clicked'));
		$this->btnEspera->set_sensitive(false);
		$colLin3BtnCh->pack_start($this->btnEspera);
		
		$this->btnConferencia = new GtkButton("Confer�ncia");
		$this->btnConferencia->set_image(GtkImage::new_from_file("gfx/conferencia.png"));
		$this->btnConferencia->connect('clicked', array($this, 'on_Conferencia_clicked'));
		$this->btnConferencia->set_sensitive(false);
		$colLin3BtnCh->pack_start($this->btnConferencia);
		$linhas->pack_start($colLin3BtnCh, false, false);
		
		$colLin4CxTxt = new GtkHBox();
		$lin4Col1CxTxt = new GtkVBox();
		$this->cxDisca = new GtkEntry("");
		$lin4Col1CxTxt->pack_start($this->cxDisca);
		$lin4Col1HB = new GtkHBox();
		$lin4Col1HB->pack_start(new GtkLabel("Liga��o Entrante"));
		$this->cxNumEntra = new GtkEntry("");
		$this->cxNumEntra->modify_font(new PangoFontDescription("Arial Black 12")); 
		$lin4Col1HB->pack_start($this->cxNumEntra);
		$lin4Col1CxTxt->pack_start($lin4Col1HB);
		$colLin4CxTxt->pack_start($lin4Col1CxTxt);
		$colLin4CxTxt->pack_start(GtkImage::new_from_file("gfx/logoCelepar.png"));
		$linhas->pack_start($colLin4CxTxt, false, false);
		
		$this->statusBar = new GtkStatusbar();
		$context_id = $this->statusBar->get_context_id('msg1');
		$this->statusBar->push($context_id, "$usuario->nome - Ramal: $usuario->ramal - Tel: $usuario->telefone");
		$linhas->pack_start($this->statusBar, false, false);
		
		return $linhas;
	}
}
?>