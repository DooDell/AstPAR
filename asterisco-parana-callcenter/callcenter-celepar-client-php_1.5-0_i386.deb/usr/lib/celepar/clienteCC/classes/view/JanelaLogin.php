<?php
class JanelaLogin extends GtkWindow
{
	private $comboLogin, $senha, $btLogin, $users;
	
	function __construct() {
		parent::__construct();
		$this->connect_simple('delete-event', array($this, 'on_Cancelar_clicked'));
		
		$this->set_title(".: Call Center CELEPAR :.");
		$this->set_position(Gtk::WIN_POS_CENTER);
		$this->set_default_size(200, 130);
		$this->set_border_width(8);
		$this->set_icon(GdkPixbuf::new_from_file("gfx/telefonista.png"));
		
		$this->users = bdFacil::todos('Usuario');
		
		$linhas = new GtkVBox(); // Linha 1 - IMG + (Usu�rio: Label + CxTexto) + (Senha: Label + CxTexto)
		// col 1 - IMG
		$colLin1ImgCxs = new GtkHBox();
		$colLin1ImgCxs->pack_start(GtkImage::new_from_stock(Gtk::STOCK_DIALOG_AUTHENTICATION, Gtk::ICON_SIZE_DIALOG));
		// col 2 - 2 linhas: (Usu�rio: Label + CxTexto) + (Senha: Label + CxTexto)
		$linhas2 = new GtkVBox();
		// col2 - Linha 1 - Usu�io: Label + CxTexto
		$colLin1User = new GtkHBox();
		$colLin1User->pack_start(new GtkLabel("Usuario:"));
		$this->comboLogin = GtkComboBox::new_text();
		$this->comboLogin->append_text("Escolha");
		foreach($this->users as $usu)
			$this->comboLogin->append_text($usu->nome);

// DEV			
		$this->comboLogin->set_active(0);
$this->comboLogin->set_active(1);

		$colLin1User->pack_start($this->comboLogin);
		$linhas2->pack_start($colLin1User, false);
		
		// col2 - Linha 2 - Senha: Label + CxTexto
		$colLin2Pass = new GtkHBox();
		$colLin2Pass->pack_start(new GtkLabel("Senha:"));
// DEV
		$this->senha = new GtkEntry();
$this->senha = new GtkEntry("123456");
		$this->senha->set_visibility(false);
		$colLin2Pass->pack_start($this->senha);
		$linhas2->pack_start($colLin2Pass, false);
		
		$colLin1ImgCxs->pack_start($linhas2);
		$linhas->pack_start($colLin1ImgCxs);
		
		$linhas->pack_start(new GtkHSeparator());
		
		// Linha 3 - 2 bot�es: Cancelar e Login
		$colLin3Btns = new GtkHBox();
		$this->btLogin = new GtkButton("Login");
		$this->btLogin->set_image(GtkImage::new_from_stock(Gtk::STOCK_APPLY, Gtk::ICON_SIZE_MENU));
		$this->btLogin->connect("clicked", array($this, "on_Login_clicked"));
		$colLin3Btns->pack_start($this->btLogin, true, false);
		$btnFecha = new GtkButton("Cancelar");
		$btnFecha->set_image(GtkImage::new_from_stock(Gtk::STOCK_CANCEL, Gtk::ICON_SIZE_MENU));
		$btnFecha->connect("clicked", array($this, "on_Cancelar_clicked"));
		$colLin3Btns->pack_start($btnFecha, true, false);
		$linhas->pack_start($colLin3Btns, false);
		
		$this->senha->connect('activate', array($this, 'on_enter'), $this->btLogin);
		
		$this->add($linhas);
	}
	
	function on_Cancelar_clicked() {
		$conn = new Conexao();
		$conn->fecha(true);
		gtk::main_quit();
	}
	
	function on_Login_clicked() {
		$comboSel = $this->comboLogin->get_active_text();
		if($comboSel == "Escolha") {
			Util::alerta("Selecione um Usuario para efetuar o Login!");
		} else {
			if($this->senha->get_text() == "") {
				Util::alerta("Digite sua senha!");
			} else {
				$nomeUsuSel = "";
				foreach($this->users as $usu) {
					if($usu->nome == $comboSel) {
						$nomeUsuSel = $comboSel;
						break;
					}
				}
				
				if(empty($nomeUsuSel)) {
					Util::alerta("Usu�rio n�o encontrado!!!");
				} else {
					if($this->senha->get_text() != $usu->senha) {
						Util::alerta("Senha incorreta!");
					} else {
						global $usuario, $config;
						
						$usuario = $usu;
						$usuario->telefone = $config->tel;
						$this->hide();
					}
				}
			}
		}
	}
	
	function on_enter($widget, $button) {
		$button->clicked();
	}
	
	function getSelLogin() {
		return $this->comboLogin->get_active_text();
	}
	
	function reseta() {
		$this->comboLogin->set_active(0);
		$this->senha->set_text("");
		$this->show_all();
	}
}
?>