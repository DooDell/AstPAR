<?php
class Lista extends GtkTreeView
{
	private $colunas;
	
	// Ex.: new Lista("Img&P Ramal Nome"); : Img = Imagem, Ramal e Nome = String(default)
	function __construct($colunas) {
		$tipoColunas = null;
		$strGtkListStore = "\$tipoColunas = new GtkListStore(";
		for($c=0; $c<count(explode(",", $colunas)); $c++) {
			if($c) $strGtkListStore .= ",";
			$strGtkListStore .= "GObject::TYPE_STRING";
		}
		eval($strGtkListStore.");");
		parent::__construct($tipoColunas);
		
		$this->colunas = $colunas;
		$c = 0;
		foreach(explode(",", $colunas) as $col) {
			$t = "S";
			if(strstr($col, "&")) list($col, $t) = explode("&", $col);
			switch($t) {
				case "P":
					$renderer = new GtkCellRendererPixbuf();
					$tipoRend = 'pixbuf';
					break;
				default:
					$renderer = new GtkCellRendererText();
					$tipoRend = 'text';
			}
			
			$column = null;
			if($t != "P") $column = new GtkTreeViewColumn($col, $renderer, $tipoRend, $c);
			else          $column = new GtkTreeViewColumn($col, $renderer);
			$column->set_sort_column_id($c++);
			if($t != "P") $column->set_min_width(80);
			$this->append_column($column);
		}
	}
	
	function addLinha($txt) {
		$store = $this->get_model();
		$iter  = $store->append();
		$c = 0;
		foreach(explode(",", $txt) as $t) {
			if(substr($t, strlen($t) - 4) == ".png") {
				$pixbuf = GdkPixbuf::new_from_file("gfx/$t");
				$renderes = $this->get_column($c)->get_cell_renderers();
				$renderes[0]->set_property('pixbuf', $pixbuf);
			} else
				$store->set($iter, $c, $t);
			$c++;
		}
		return $iter;
	}
	
	function delLinha($nomeColuma, $valor) {
		$store = $this->get_model();
		$posColuna = -1;
		
		$c = 0;
		foreach(explode(" ", $this->colunas) as $col) {
			if(strstr($col, "&")) list($col, $t) = explode("&", $col);
			if($col == $nomeColuma) {
				$posColuna = $c;
				break;
			}
			$c++;
		}
		
		if($posColuna >= 0)
			foreach ($store as $row) {
				$iter = $row->iter;
				if($store->get_value($iter, $posColuna) == $valor) {
					$store->remove($iter);
					break;
				}
			}
	}
	
	function limpa() {
		$this->get_model()->clear();
	}
	
	function total() {
		return count($this->get_model());
	}
}
?>