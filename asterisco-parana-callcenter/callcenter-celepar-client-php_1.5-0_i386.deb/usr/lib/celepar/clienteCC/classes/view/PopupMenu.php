<?php
class PopupMenu extends GtkMenu
{
	function PopupMenu($menuDef, $acao) {
		parent::__construct();
	    foreach($menuDef as $menuItemTxt) {
	        if($menuItemTxt == '<hr>') {
	            $this->append(new GtkSeparatorMenuItem());
	        } else {
	            $menuItem = new GtkMenuItem($menuItemTxt);
	            $menuItem->connect('activate', $acao);
	            $this->append($menuItem);
	        }
	    }
	}
	
	function mostra() {
	    $this->show_all();
	    $this->popup();
	}
}
?>