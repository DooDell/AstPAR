<?php
class JanelaSupervisor extends GtkWindow
{
	private /* List<Fila>    */ $filas;
	private /* List<Usuario> */ $usuarios;
	private /* List<Status>  */ $status;
	private /* Usuario       */ $agente;
	private /* int           */ $linhaAgSel;
	
	// Widgets
	private $btnUsuarios, /* List */ $btnFila, $btnSair;
	private $listaUsuarios;
	private $statusBar;
	
	public function JanelaSupervisor() {
		parent::__construct();
		
		$this->connect_simple('destroy', array($this, 'on_Sair_clicked'), true);
		$this->set_title(".: Call Center CELEPAR :.");
		$this->set_position(Gtk::WIN_POS_CENTER);
		$this->set_default_size(800, 600);
		$this->set_icon(GdkPixbuf::new_from_file("gfx/telefonista.png"));

		$this->initDados();		
		$this->add($this->criaInterface());
		$this->show_all();
		
		Gtk::timeout_add(1500, array($this, "funcTimer"));
	}
	
	function initDados() {
		$this->linhaAgSel = -1;
		
		$this->filas      = bdFacil::todos('Fila');
		
		$this->status     = bdFacil::todos('Status');
		$this->status[0]  = new Status();
		$this->status[0]->nome = 'Deslogado';
	}
	
	function funcTimer() {
		global $usuario, $MOSTRA_SQL;
$MOSTRA_SQL = false;
		$this->usuarios = bdFacil::todos('Usuario');
		$this->listaUsuarios->limpa();
		foreach($this->usuarios as $usu) {
			$nomeStatus = $this->status[$usu->codstatus]->nome;
			if($usu->emligacao > 0) {
				if($usu->sainte == 't') $gfxStatus = "status_sainte.png";
				else                    $gfxStatus = "status_entrante.png";
			} else {
				if($usu->codstatus == 0)        $gfxStatus = "status_deslogado.png";
				else if($usu->codstatus == 1)   $gfxStatus = "status_disponivel.png";
				else if($usu->codstatus == 200) $gfxStatus = "status_indisponivel.png";
				else                            $gfxStatus = "status_pausa.png";
			}
			$timer = $usu->tempostatus;
			$this->listaUsuarios->addLinha("$gfxStatus,$usu->nome,$usu->ramal,$nomeStatus,$timer,$usu->id");
		}
		// TODO setar linha selecionada = $this->linhaAgSel
$MOSTRA_SQL = true;
		return true;
	}
	
	function on_Fila_clicked($btn) {
		$nomeFila = $btn->get_label();
	}
	
	function on_Sair_clicked() {
		$conn = new Conexao();
		$conn->fecha(true);
		gtk::main_quit();
	}
	
	function on_LinhaUsuario_clicked($view, $event) {
	    if ($event->button==1) return false; // let php-gtk2 handles this
	    if ($event->button==2) return true; // do nothing
	    if ($event->button==3) {
	        $pathArray = $view->get_path_at_pos($event->x, $event->y);
	        $this->linhaAgSel = $pathArray[0][0];
	        $store = $view->get_model();
			$iter = $store->get_iter($this->linhaAgSel);
			
			$nomeAg = $store->get_value($iter, 1);
			$agenteAux = bdFacil::carregarPor("Usuario", "nome = '$nomeAg'", "", "1");
			$this->agente = $agenteAux[0];
			$conn = new Conexao();
			$filasAgente = $conn->arrayDeInteiros("SELECT codfila FROM cc_usuariofila WHERE codusu = " . $this->agente->id);
			$conn->fecha();
			
			$optPopupAg = array($this->agente->nome, "<hr>");
			// Adicionar em filas que o agente NAO esteja
			$addAddFila = false;
			foreach($this->filas as $fila) {
				if(!in_array($fila->id, $filasAgente)) {
					$optPopupAg[] = "Adicionar a fila [$fila->nome]";
					$addAddFila = true;
				}
			}
			// Remover de fila que o agente esteja
			$addRemFila = false;
			foreach($this->filas as $fila) {
				if(in_array($fila->id, $filasAgente)) {
					if($addAddFila) {
						$optPopupAg[] = "<hr>";
						$addAddFila = false;
					}
					$optPopupAg[] = "Remover da fila [$fila->nome]";
					$addRemFila = true;
				}
			}
			if($this->agente->codstatus != 0) {
				if($addRemFila) $optPopupAg[] = "<hr>";
				$optPopupAg[] = "Status: Deslogar";
				if($this->agente->codstatus != 1) $optPopupAg[] = "Status: Dispon�vel";
				if($this->agente->codstatus < 100 || $this->agente->codstatus > 199) $optPopupAg[] = "Status: Pausa";
				if($this->agente->codstatus != 200) $optPopupAg[] = "Status: Indispon�vel";
			}
			
			$popup = new PopupMenu($optPopupAg, array($this, 'on_PopupAgente_clicked'));
			$popup->mostra();
			
	        return true;
	    }
	}
	
	function on_PopupAgente_clicked($menuItem) {
	    $txtMenu = $menuItem->child->get_label();
	    $idAgenteSel = $this->agente->id;
	    if(Util::comecaCom($txtMenu, "Adicionar a fila") || Util::comecaCom($txtMenu, "Remover da fila")) {
	    	$cmd = (Util::comecaCom($txtMenu, "Adicionar a fila")) ? "addFila" : "remFila";
	    	list($d, $nomeFila) = explode("[", $txtMenu);
	    	$nomeFila = substr($nomeFila, 0, strlen($nomeFila)-1);
	    	$fila = bdFacil::carregarPor("Fila", "nome = '$nomeFila'", "", "1");
			$fila = $fila[0];
	    	ClienteCC::enviaComando("$cmd:$idAgenteSel:$fila->id:$fila->nome");
	    } else if(Util::comecaCom($txtMenu, "Status")) {
	    	switch($txtMenu) {
	    		case "Status: Deslogar":     $status = 0;   break;
	    		case "Status: Dispon�vel":   $status = 1;   break;
	    		case "Status: Pausa":        $status = 100; break;
	    		case "Status: Indispon�vel": $status = 200; break;
	    	}
	    	$codStatus = $this->agente->codstatus;
	    	ClienteCC::enviaComando("mudaStatus:$idAgenteSel:$codStatus:$status");
	    }
	}
		
	function criaInterface() {
		global $usuario;
		
		$linhas = new GtkVBox();
		
		$colLin1BtnAcoes = new GtkHBox();
		foreach($this->filas as $fila) {
			$this->btnFila[$fila->id] = new GtkButton($fila->nome);
			$this->btnFila[$fila->id]->set_image(GtkImage::new_from_file("gfx/fila.png"));
			$this->btnFila[$fila->id]->connect('clicked', array($this, 'on_Fila_clicked'));
			$colLin1BtnAcoes->pack_start($this->btnFila[$fila->id]);
		}
		
		$this->btnSair = new GtkButton("Sair");
		$this->btnSair->set_image(GtkImage::new_from_file("gfx/sair.png"));
		$this->btnSair->connect('clicked', array($this, 'on_Sair_clicked'));
		$colLin1BtnAcoes->pack_start($this->btnSair);
		
		$colLin1BtnAcoes->pack_start(GtkImage::new_from_file("gfx/logoCelepar.png"));
		$linhas->pack_start($colLin1BtnAcoes, false, false);
		
		$this->listaUsuarios = new Lista("Estado&P,Nome,Ramal,Estado,Tempo no Estado,ID");
		$this->listaUsuarios->connect('button-press-event', array($this, 'on_LinhaUsuario_clicked'));
		$linhas->pack_start($this->listaUsuarios);
		
		$this->statusBar = new GtkStatusbar();
		$context_id = $this->statusBar->get_context_id('msg1');
		$this->statusBar->push($context_id, "$usuario->nome - Ramal: $usuario->ramal - Tel: $usuario->telefone");
		$linhas->pack_start($this->statusBar, false, false);
		
		return $linhas;
	}
}
?>