<?php
define("LOG_CRITICO",  5);
define("LOG_AVISO",   10);
define("LOG_NORMAL",  20);
define("LOG_DEBUG0",  25);
define("LOG_DEBUG1",  30);
define("LOG_DEBUG2",  40);

define("NIVEL_DEBUG", LOG_DEBUG0);

/* Usuario */ $usuario = null;
/* Config */  $config  = null;
/* boolean */ $MOSTRA_SQL = true;

/*
 * Fun��o especial do PHP5 que permite utilizar classes sem fazer a importa��o pr�via
 * do arquivo PHP. Esta fun��o procura por classes a serem inclu�das nos diret�rios
 * listados de classes do sistema.
 * @param nomeDaClasse Nome daclasse a ser inclu�da (autom�tico)
 */
function __autoload($nomeDaClasse) {
	foreach(array("control", "model", "view") as $pasta) {
		if(file_exists("classes/$pasta/$nomeDaClasse.php")) {
			require_once("classes/$pasta/$nomeDaClasse.php");
			return true;
		}
	}
	return false;
}
?>