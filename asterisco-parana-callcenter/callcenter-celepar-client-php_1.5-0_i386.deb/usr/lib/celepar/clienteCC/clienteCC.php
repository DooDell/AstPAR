<?php
if( !class_exists('gtk')) {
	die('Please load the php-gtk2 module in your php.ini' . "\r\n");
}

include("includePrincipal.php");

class ClienteCC
{
	private $janelaLogin, $janela;

	public function ClienteCC() {
		global $config;
		$config = new Config();
		
		$this->janelaLogin = new JanelaLogin();
		$this->janelaLogin->connect('hide', array($this, 'init'));
		$this->janelaLogin->show_all();
	}
	
	public function init() {
		global $usuario;
		if($usuario->tipo == 1) $janela = new JanelaAgente();
		else                    $janela = new JanelaSupervisor();
	}
	
	static function enviaComando($comando) {
		global $usuario;
		$sql = "INSERT INTO cc_acaoagente(codusu, executaacao) VALUES($usuario->id, '$comando')";
		$conn = new Conexao();
		$err = $conn->executa($sql);
		$conn->fecha();
		if($err !== true) Logger::loga(LOG_CRITICO, "Erro ao executar SQL: $sql: $err");
		return $err;
	}
}

$clienteCC = new ClienteCC();
Gtk::main();
?>