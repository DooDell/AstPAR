<?php
	/**
	 * 
	 */
	define("LOG_CRITICO",  5);
	define("LOG_AVISO",   10);
	define("LOG_NORMAL",  20);
	define("LOG_DEBUG0",  25);
	define("LOG_DEBUG1",  30);
	define("LOG_DEBUG2",  40);
	define("NIVEL_DEBUG", LOG_DEBUG0);
	
	/**
	 * 
	 */
	define("EVENTO_LOGIN",    1); //(1, 'Login', 'C�digo do Usu�rio', 'Ramal', 'Telefone', '');
	define("EVENTO_LOGOFF",   2); //(2, 'Logoff', 'C�digo do Usu�rio', 'Ramal', '', '');
	define("EVENTO_STATUS",   3); //(3, 'Status', 'C�digo do Agente', 'Status Anterior', 'Status Novo', 'C�digo do usu�rio');
	define("EVENTO_ENTRACH",  4); //(4, 'Entra na Chamada', 'C�digo do Usu�rio Ouvinte', 'Ramal do Ouvinte', 'C�digo', '');
	define("EVENTO_ESCUTACH", 5); //
	define("EVENTO_", 6);
?>