<?php
include("includePrincipal.php");
include("classes/amiLib.php");
include("classes/conexao.php");
include("classes/util.php");

$saiLoopPrincipal = false;
$modoChecaFila = "AMI";

$MOSTRA_SQL = true;
$console = null;
$listaIdChamadaFila = null;

class ControleCC {
	public static $conf;
	private $connCC, $astLoginOK = false, $dbCCLoginOK = false;
	
	public function ControleCC() {
		global $console;
		
		$console = new Logger(false);
		$console->loga(LOG_AVISO, "Lendo arquivo de configuracao.");
		ControleCC::$conf = new Conf();
		$err = ControleCC::$conf->init();
		if(!$err) {
			$console->loga(LOG_AVISO, "Arquivo de configuracao [".
				ControleCC::$conf->arq."] nao encontrado. Assumindo valores padrao");
		}
		$console->loga(LOG_AVISO, "Conectando com o banco CC.");
		$this->connCC = new Conexao();
		if(!$this->connCC->loginOK) {
			$console->loga(LOG_CRITICO, "Problemas ao conectar no banco do CC!");
			$this->shut(8);
		}
		$console->loga(LOG_DEBUG0, "Limpando acoes antigas do banco.");
		$this->connCC->executa("DELETE FROM cc_acaoagente");
		$console->loga(LOG_AVISO, "Efetuando login no Asterisk [".ControleCC::$conf->ami->host."].");
		$tries = 0;
		while($tries++ < 10) {
			if($this->initAMI()) {
				$this->astLoginOK = true;
				break;
			}
			sleep(3);
		}
		if(!$this->astLoginOK) {
			$console->loga(LOG_CRITICO, "Falha ao logar no AMI!");
			$this->shut(16);
		}
		$console->loga(LOG_DEBUG0, "Inicializando lista [idCahamda]x[nomeFila].");
		$listaIdChamadaFila = array();
	}
	
	function initAMI() {
		$this->AMI = new AMI();
		if(!($pacote = $this->AMI->login(ControleCC::$conf->ami))) {
			$this->AMI->disconnect();
			return false;
		}
		$this->checaEventos($pacote);
		return true;
	}

	function shut($ret=0)
	{
		global $console;
		if($this->astLoginOK) {
			$console->loga(LOG_AVISO, "Efetuando logoff no Asterisk.");
			$this->AMI->disconnect();
		}
		
		if($this->dbCCLoginOK) {
			$console->loga(LOG_AVISO, "Efetuando logoff do banco.");
			$this->connCC->fecha(true);
		}
	    $console->fecha();
	    exit($ret);
	}
	
	function run() {
		global $console, $MOSTRA_SQL, $saiLoopPrincipal;
		$timer = 0;
		$console->loga(LOG_AVISO, "Loop de espera por pacotes:");
		while(!$saiLoopPrincipal) {
			// Checa por eventos vindos do AMI
			$pacoteRecebido = $this->AMI->receive(0.5);
			if(!$pacoteRecebido->vazio()) { // Trata os eventos recebidos
				if(NIVEL_DEBUG >= LOG_DEBUG1) $pacoteRecebido->mostra();
				$this->checaEventos($pacoteRecebido);
				// regula o timer caso receba pacote
				if($timer > 0) $timer--;
			}

			// Usa o delay do recebimento de pacotes para temporizar
			// O acesso ao banco a cada aprox. 1.5s
			$timer++;		
			if($timer == 3 || $timer == 6) {
				$MOSTRA_SQL = false;
				if($timer == 6) {
					$timer = 0;
					$this->atualizaFilas();
				}
				$this->checaAcoesAExecutar();
				$this->verificaArquivoSaida();
			}
		}
	}
	
	function verificaArquivoSaida() {
		global $console, $saiLoopPrincipal;
		if(file_exists("/etc/asterisk/parana/cc/SAIA")) {
			unlink("/etc/asterisk/parana/cc/SAIA");
			$console->loga(LOG_NORMAL, "Pedido de saida! Saindo!");
			$saiLoopPrincipal = true;
		}
	}
	
	function logaEvento($tipoEvento, $c1="", $c2="", $c3="", $c4="")
	{
		$dtHr = date("y-m-d H:i:s");
		$sql = "INSERT INTO cc_historico(tipoEvento, dataHora, campo1, campo2, campo3, campo4) " . 
				"VALUES($tipoEvento, '$dtHr', '$c1', '$c2', '$c3', '$c4')";
		return $this->connCC->executa($sql);
	}
	
	function enviaComando($cmd, $params = array()) {
		$pacote = $this->AMI->send_command($cmd, $params);
		$this->checaEventos($pacote);
		return $pacote;
	}
	
	function verificaStatus($pacote) {
		$ret = 0;
		$this->msgAster = $pacote->getAtr('Message');
		return ($pacote->getAtr('Response') == "Success");
	}
	
	/**
	 * Procura o canal da liga��o de um agente
	 * retorno: (string canal) = achou, (null) = agente n�o tem canal (n�o est� em liga��o)
	 */
	function procuraCanalDoAgente($idAgente, $telefone)
	{
		$pacote = $this->enviaComando("Status");
		$aux =& $pacote;
		while($aux) {
			if($aux->getAtr('Event') == "Status" && 
					($aux->getAtr('Channel') == "Agent/$idAgente" ||
					 Util::comecaCom($aux->getAtr('Channel'), "SIP/$telefone") ||
					 $aux->getAtr('CallerIDName') == "Liga-Agent/$idAgente")) {
				return $aux->getAtr('Link');
			}
			$aux = $aux->prox;
		}
		return null;
	}
	
	function dbAst_AgentesFilas($addOuDel, $ifaceAg, $fila) {
		$connAst = new Conexao("asterisk");
		$sql = ($addOuDel == "ADD") ?
					"INSERT INTO membrosfila(queue_name, interface, penalty) VALUES('$fila', 'Agent/$ifaceAg', 0)" :
					"DELETE FROM membrosfila WHERE queue_name = '$fila' AND interface = 'Agent/$ifaceAg'";
		$connAst->executa($sql);
		$ret = $connAst->qtdAff;
		$connAst->fecha(true);
		return $ret;
	}
	
	function dbAst_SetaTelAtual($codUsu, $telAtual) {
		$connAst = new Conexao("asterisk");
		$sql = "UPDATE usuario SET telAtual = '$telAtual' WHERE id = $codUsu";
		$connAst->executa($sql);
		$ret = $connAst->qtdAff;
		$connAst->fecha(true);
		return $ret;
	}
	
	function dbAst_registraMac($codUsu, $tel, $mac) {
		$connAst = new Conexao("asterisk");
		$connAst->executa("SELECT mac FROM telefone WHERE login = '$tel'");
		if($connAst->qtdSel > 0) {
			if($connAst->qtdSel > 1) $console->loga(LOG_AVISO, "Duplicidade na tabela Telefone!!!!");
			$macDB = $connAst->temMaisDados("mac");
			if(empty($macDB)) {
				$msg = $connAst->executa("UPDATE telefone SET mac = '$mac' WHERE login = '$tel'");
				if($msg === true)
					$msg = "OK";
			} else {
				if($mac == $macDB) $msg = "OK";
				else               $msg = "PA em uso por outro computador. Verifique as configura��es.";
			}
		} else
			$msg = "Telefone n�o cadastrado no servidor Asterisk. Verifique as configura��es.";
		$connAst->fecha(true);
		$this->connCC->executa("UPDATE cc_usuario SET msg = '$msg' WHERE id = $codUsu");
		return ($msg == "OK");
	}

/**
 * checaEAtualizaBanco: Func executada a aprox. cada 2 segundos.
 * 1. Verifica se no existem aes a serem executadas, checando
 * os dados na tabel cc_acaoagente.
 * 2. Atualiza os dados vindos do * nas respectivas tabelas.
 */
	function checaAcoesAExecutar() {
		global $console, $MOSTRA_SQL;
		$console->loga(LOG_DEBUG2, "Checando tabelas de comandos:");
		
		$acoes = array();
		$this->connCC->executa("SELECT executaacao,codusu FROM cc_acaoagente");
		$MOSTRA_SQL = true;
		if($this->connCC->qtdSel > 0) {
			while($this->connCC->temMaisDados())
				$acoes[] = $this->connCC->data['codusu'] . "|" . $this->connCC->data['executaacao'];
			
			foreach($acoes as $act) {
				list($codUsu, $executaAcao) = explode("|", $act);
				$console->loga(LOG_DEBUG0, "*********************** AcaoAgente.ExecutaAcao: [$executaAcao]");
				$params = explode(":", $executaAcao);
				$acao = $params[0];
				switch($acao) {
					case "login":
						$ramal    = $params[1];
						$telefone = $params[2];
						$senha    = $params[3];
						$console->loga(LOG_NORMAL, ">>>> Efetuar login do Agente(ID: $codUsu, ramal: $ramal).");
						$pacote = $this->enviaComando("AgentCallBackLogin", array(
									"Agent" => $codUsu,
									"Exten" => $ramal,
									"Context" => "agentes",
									"AckCall" => "false",
									"WrapupTime" => "10" // TODO WrapupTime Dinamico
									));
						$sucesso = $this->verificaStatus($pacote);
						$console->loga(LOG_AVISO, ($sucesso ? "Login efetuado com sucesso" : "Erro ao efetuar login") . ". msgAsterisk: $this->msgAster");
						if($sucesso) {
							if(!$this->connCC->executa("UPDATE cc_usuario SET ramal = $ramal, telefone = '$telefone', codstatus = 1, tempoStatus = '".date("H:i:s")."' WHERE id = $codUsu"))
								$console->loga(LOG_AVISO, "ERRO[30]!! Ao setar cc_usuario.ramal");
							
							//$this->dbAst_SetaTelAtual($codUsu, $telefone);
							exec("/usr/sbin/pabxastprctl nAGI registra $ramal $senha $telefone");
							
							$this->logaEvento(EVENTO_LOGIN, $codUsu, $ramal, $telefone);
							
							$pacote = $this->enviaComando("Originate", array(
									"Channel" => "SIP/$telefone",
									"Priority" => "0",
									"Application" => "Playback",
									"Data" => "cc_agenteRegistrado",
									"Timeout" => "30000",
									"Async" => "1"
									));
						}
						break;
					
					case "logoff":
						$tipoAg = $params[1];
						$ramal  = $params[2];
						$senha  = $params[3];
						$console->loga(LOG_NORMAL, ">>>> Efetuar logoff do Agente(ID: $codUsu).");
						$pacote = $this->enviaComando("AgentLogoff", array(
									"Agent" => $codUsu,
									"Soft" => "1"
									));
						$sucesso = $this->verificaStatus($pacote);
						$console->loga(LOG_AVISO, ($sucesso ? "Logoff efetuado com sucesso" : "Erro ao efetuar logoff").". msgAsterisk: $this->msgAster");
						if($sucesso) {
							$sql = "UPDATE cc_usuario SET chamando = FALSE, sainte = FALSE, numSai = '', numEntra = '', emLigacao = 0, telefone = '', codStatus = 0, tempoStatus = '".date("H:i:s")."' WHERE id = $codUsu";
							if(!$this->connCC->executa($sql))
								$console->loga(LOG_AVISO, "ERRO[40]!! Ao setar cc_usuario.codStatus");
							
							if($tipoAg == 1) {
								//$this->dbAst_SetaTelAtual($codUsu, "");
								exec("/usr/sbin/pabxastprctl nAGI desregistra $ramal $senha");
							}
							
							$this->logaEvento(EVENTO_LOGOFF, $codUsu, $ramal);
						}
						break;
					
					case "mudaStatus":
						$idAgente = $params[1];
						$stsAnt   = $params[2];
						$stsNovo  = $params[3];
						$console->loga(LOG_NORMAL, ">>>> Alterar status do Agente/$idAgente de [$stsAnt] para [$stsNovo].");
						
						if(($stsAnt == 1 && $stsNovo != 0) || $stsNovo == 1) {
							$pausado = ($stsNovo == 1) ? 0 : 1;
							$pacote = $this->enviaComando("QueuePause", array(
									"Interface" => "Agent/$idAgente",
									"Paused" => $pausado
									));
							$sucesso = $this->verificaStatus($pacote);
							$console->loga(LOG_AVISO, ($sucesso ? "Status alterado com sucesso" : "Erro ao efetuar mudanca de status").". msgAsterisk: $this->msgAster");
						} else $sucesso = true;
						if($sucesso) {
							// Mudar o status no banco para refletir na appJava:
							if(!$this->connCC->executa("UPDATE cc_usuario SET codStatus = $stsNovo, tempoStatus = '".date("H:i:s")."' WHERE id = $idAgente"))
								$console->loga(LOG_CRITICO, "ERRO[10]!! Ao alterar cc_usuario.codStatus");
							$this->logaEvento(EVENTO_STATUS, $idAgente, $stsAnt, $stsNovo, $codUsu);
						}
						break;
					
					case "entraChamada":
					case "escutaChamada":
						$telSup = $params[1];
						$telAg  = $params[2];
						$idAg   = $params[3];
						$entra = ($acao == "entraChamada") ? 'w' : 0;
						$evento= ($acao == "entraChamada") ? EVENTO_ENTRACH : EVENTO_ESCUTACH;
						$pacote = $this->enviaComando("Originate", array(
									"Channel" => "SIP/$telSup",
									"Priority" => "0",
									"Application" => "ChanSpy",
									"Data" => "SIP/$telAg|q$entra",
									"Timeout" => "30000",
									"Async" => "1"
									));
						$sucesso = $this->verificaStatus($pacote);
						$console->loga(LOG_AVISO, ($sucesso ? "Espiando!" : "Erro ao espiar").". msgAsterisk: $this->msgAster");
						if($sucesso)
							$this->logaEvento($evento, $codUsu, $telSup, $idAg, $telAg);
						break;
						
					case "conferencia":
						
						break;
					
					case "addFila":
						$idAgente = $params[1];
						$idFila   = $params[2];
						$nomeFila = $params[3];
						$console->loga(LOG_NORMAL, ">>>> Adicionar Agente/$idAgente a fila $nomeFila"."[$idFila]");
						if(!$this->connCC->executa("INSERT INTO cc_usuariofila(codUsu, codFila) VALUES($idAgente, $idFila)"))
							$console->loga(LOG_CRITICO, "ERRO[20]!! Ao inserir [$idAgente] na fila [$nomeFila]");
						else $this->dbAst_AgentesFilas("ADD", $idAgente, $nomeFila);
						break;
						
					case "remFila":
						$idAgente = $params[1];
						$idFila   = $params[2];
						$nomeFila = $params[3];
						$console->loga(LOG_NORMAL, ">>>> Remover Agente/$idAgente a fila $nomeFila"."[$idFila]");
						if(!$this->connCC->executa("DELETE FROM cc_usuariofila WHERE codUsu = $idAgente AND codFila = $idFila"))
							$console->loga(LOG_CRITICO, "ERRO[20]!! Ao remover [$idAgente] da fila [$nomeFila]");
						else $this->dbAst_AgentesFilas("DEL", $idAgente, $nomeFila);
						break;
	
					case "disca":
						$tel = $params[1];
						$num = $params[2];
						$console->loga(LOG_NORMAL, ">>>> Telefone $tel ligando para $num.");
						$pacote = $this->enviaComando("Originate", array(
									"Channel" => "SIP/$tel",
									"Context" => "agentes",
									"Exten" => $num,
									"Priority" => "1",
									"Callerid" => "$tel",
									"Timeout" => "30000",
									"Async" => "1"
									));
						$sucesso = $this->verificaStatus($pacote);
						$console->loga(LOG_AVISO, ($sucesso ? "Chamada efetuada com sucesso" : "Erro ao efetuar chamada") . ". msgAsterisk: $this->msgAster");
						break;
						
					case "transferir":
						$numTransf = $params[1];
						$telefone  = $params[2];
						$console->loga(LOG_NORMAL, ">>>> Transferir chamada do Agente/$codUsu para numero [$numTransf].");
						if(($canal = $this->procuraCanalDoAgente($codUsu, $telefone)) != null) {
							$pacote = $this->enviaComando("Redirect", array(
									"Channel" => $canal,
									"Context" => "ramais-internos",
									"Exten" => $numTransf,
									"Priority" => "1",
									));
							$sucesso = $this->verificaStatus($pacote);
							$console->loga(LOG_AVISO, ($sucesso ? "Chamada transferida com sucesso" : "Erro ao transferir chamada") . ". msgAsterisk: $this->msgAster");
						} else
							$console->loga(LOG_AVISO, ">>> Erro ao transferir chamada do Agent/$codUsu. Nao esta em chamada?");
						break;
						
					case "espera":
						$telefone  = $params[1];
						$console->loga(LOG_NORMAL, ">>>> Colocar em espera chamada do Agente/$codUsu");
						if(($canal = $this->procuraCanalDoAgente($codUsu, $telefone)) != null) {
							$pacote = $this->enviaComando("Redirect", array(
									"Channel" => $canal,
									"Context" => "agentes",
									"Exten" => "6999",
									"Priority" => "1",
									));
							$sucesso = $this->verificaStatus($pacote);
							$console->loga(LOG_AVISO, ($sucesso ? "Chamada colocada em espera com sucesso" : "Erro ao colocar a chamada em espera") . ". msgAsterisk: $this->msgAster");
						} else
							$console->loga(LOG_AVISO, ">>> Erro ao achar canal do Agent/$codUsu. Nao esta em chamada?");
						break;
						
					case "desespera":
						$tel = $params[1];
						$salaEspera = null;
						$console->loga(LOG_NORMAL, ">>>> Retornar chamada em espera do Agente/$codUsu no telefone [$tel]");
						// Buscar o n�mero onde a chamada foi estacionada
						$pacote = $this->enviaComando("ParkedCalls");
						$aux =& $pacote;
						while($aux) {
							if($aux->getAtr('Event') == "ParkedCall") {
								$console->loga(LOG_NORMAL, "DEBUG_ORTIZ:::::::::" . $aux);
								if($aux->getAtr('CallerIDName') == "SIP/$tel") {
									$salaEspera = $aux->getAtr('Exten');
									if($salaEspera) break;
								}
							}
							$aux = $aux->prox;
						}
						if($salaEspera) {
							$pacote = $this->enviaComando("Originate", array(
									"Channel" => "SIP/$tel",
									"Context" => "ramais-internos",
									"Exten" => $salaEspera,
									"Priority" => "1",
									"Callerid" => "CallCenter",
									"Timeout" => "30000",
									"Async" => "1"
									));
							$sucesso = $this->verificaStatus($pacote);
						}
						$console->loga(LOG_AVISO, ($sucesso ? "Chamada recuperada da sala $salaEspera" : "Erro ao buscar sala") . ". msgAsterisk: $this->msgAster");
						break;
					
					case "registraMac":
						$tel = $params[1];
						$mac = $params[2];
						$console->loga(LOG_NORMAL, ">>>> Autenticar registro do MAC[$mac] para o telefone[$tel]");
						$this->dbAst_registraMac($codUsu, $tel, $mac);
						break;
				}
			}
			$this->connCC->executa("DELETE FROM cc_acaoagente");
		}
	}

/**
 * atualizaFilas: Func executada a aprox. cada 2 segundos.
 * Requisita o status das filas no *, para posterior atualiza��o dos dados no BD
 */
	function atualizaFilas() {
		global $console, $modoChecaFila;
		$console->loga(LOG_DEBUG2, "Checando status das filas no *");
		if($modoChecaFila = "AMI") {
			$this->enviaComando("QueueStatus");
		} else {
			$astRet = "";
			exec('asterisk -rx "queue show"', $astRet);
	/* Ex. RETORNO:
	
	celepar      has 0 calls (max unlimited) in 'fewestcalls' strategy (0s holdtime), W:10, C:0, A:1, SL:0.0% within 0s
	   Members:
	      Agent/16 (realtime) (Not in use) has taken no calls yet
	      Agent/14 (realtime) (Unavailable) has taken no calls yet
	   No Callers
	
	sefa         has 1 calls (max unlimited) in 'fewestcalls' strategy (50s holdtime), W:10, C:5, A:2, SL:0.0% within 0s
	   Members:
	      Agent/16 (realtime) (Not in use) has taken 3 calls (last was 10 secs ago)
	      Agent/14 (realtime) (Unavailable) has taken 2 calls (last was 709 secs ago)
	      Agent/17 (realtime) (paused) (Not in use) has taken no calls yet
	   Callers:
	      1. SIP/cac04-082bb230 (wait: 0:01, prio: 0)
	
	 */
	 		$numInfo = 0;
	 		$nomeFila = "";
	 		$tempoMedioEspera = $tempoEspera = 0;
	 		$qtdChamRecebida = $qtdChamAtendida = $qtdChamAbandonada = $qtdChamEspera = 0;
			foreach($astRet as $lin) {
				if(empty($lin)) {
					if(empty($tempoEspera)) $tempoEspera = "0:00";
					else $tempoEspera = substr($tempoEspera, 0, strlen($tempoEspera)-1); // trans "0:10," em "0:10"
					$tempoMedioEspera = substr($tempoMedioEspera, 1, strlen($tempoMedioEspera)-2); // trans "(10s" em "10"
					list($d, $qtdChamAtendida)   = explode(":", $qtdChamAtendida);
					$qtdChamAtendida = substr($qtdChamAtendida, 0, strlen($qtdChamAtendida)-1); // trans "1," em "1"
					list($d, $qtdChamAbandonada) = explode(":", $qtdChamAbandonada); 
					$qtdChamRecebida = $qtdChamAtendida + $qtdChamAbandonada;
					
					$tempoEspera = Util::formataSegundos($tempoEspera);
					$tempoMedioEspera = Util::formataSegundos($tempoMedioEspera);
					$sql = "UPDATE cc_fila SET qtdChamEspera = '$qtdChamEspera', tempoMedioEspera = '$tempoMedioEspera', " .
							"tempoEspera = '$tempoEspera', qtdChamRecebida = '$qtdChamRecebida', qtdChamAtendida = '$qtdChamAtendida' " .
							"WHERE nome = '$nomeFila'";
					$insOK = $this->connCC->executa($sql);
					if(!$insOK || $this->connCC->qtdAff != 1) {
						$console->loga(LOG_AVISO, "ERRO[50]!! Ao atualizar iforma��es da fila [$nomeFila]");
					} else {
						$console->loga(LOG_DEBUG2, ">>EV: QueueParams. Setado qtdChamEspera($emEspera), tempoMedioEspera($tempoEsp)" .
							"qtdChamRecebida($totRecv), qtdChamAtendida($completed) para a fila($nomeFila)");
					}
	
					$numInfo = 0;	// Nova fila
					$nomeFila = "";
	 				$tempoMedioEspera = $tempoEspera = 0;
	 				$qtdChamRecebida = $qtdChamAtendida = $qtdChamAbandonada = $qtdChamEspera = 0;
				} else {
					$palavras = explode(" ", Util::tiraEspacosDuplicados($lin));
					switch($numInfo) {
						case 0: // l� a 1a linha
							$nomeFila = $palavras[0];
							$qtdChamEspera     = Util::pegaPalavraAnterior($palavras, "calls");
							$tempoMedioEspera  = Util::pegaPalavraAnterior($palavras, "holdtime");
							$qtdChamAtendida   = Util::pegaPalavraPorPrefixo($palavras, "C:");
							$qtdChamAbandonada = Util::pegaPalavraPorPrefixo($palavras, "A:");
							$numInfo = 1;
							break;
							
						case 1: // procura a linha "Callers:"
							if($palavras[0] == "Callers:") $numInfo = 2;
							break;
						
						case 2:
							$tempoEspera = Util::pegaPalavraAnterior($palavras, "prio:");
							break;
					}
				}
			}
		}
	}
	
	function checaEventos($pacote) {
		global $console, $saiLoopPrincipal;
		$aux =& $pacote;
		while($aux) {
			$evento = $aux->getAtr('Event');
			if(!empty($evento)) {
				switch(strtolower($evento)) {
					case "newexten":
						if($aux->getAtr('Application') == "NoOp") {
							if($aux->getAtr('AppData')) {
								list($appChave, $nomeFila) = explode("=", $aux->getAtr('AppData'));
								if($appChave == "CCCfila" && !empty($nomeFila)) {
									$canal = $aux->getAtr('Channel');
									$nomeCanalLimpo = Util::limpaNomeCanal($canal);
									$console->loga(LOG_NORMAL, ">>EV: Newexten(NoOp): guardando nomeFila: $nomeFila para o Canal: $nomeCanalLimpo");
									$listaIdChamadaFila[$nomeCanalLimpo] = $nomeFila;
								}
							}
						} else if($aux->getAtr('Extension') == "0") {
							$console->loga(LOG_DEBUG0, "Evento Tratado: NewExten-Extension-0 => SAINDO");
							// Se alguem ligar p/ 0 sai...
							$saiLoopPrincipal = true;
						}
						break;
					
					case "dial":
						$src = $aux->getAtr('Source');
						$nomeCanalLimpo = Util::limpaNomeCanal($src);
						$console->loga(LOG_DEBUG0, "Evento Tratado: Dial [$nomeCanalLimpo]");
						// Tenta buscar o CallerID da melhor forma
						$cid = $aux->getAtr('CallerID');
						if(empty($cid) || $cid == "<unknown>" || $cid == "<Unknown>") {
							$cid = $aux->getAtr('CallerIDname');
							if(empty($cid) || $cid == "<unknown>" || $cid == "<Unknown>") {
								if(Util::comecaCom($src, "SIP/")) {
									$cid = Util::pegaSipDoPacote($aux, "Source");
									list($d, $cid) = explode("/", $cid);
								} else
									$cid = "?";
							}
						}
						$sip = Util::pegaSipDoPacote($aux, "Destination");
						list($d, $tel) = explode("/", $sip);
						
						$nomeCanalLimpo = Util::limpaNomeCanal($src);
						$chFila = $listaIdChamadaFila[$nomeCanalLimpo];
						unset($listaIdChamadaFila[$nomeCanalLimpo]);
						
						$sql = "UPDATE cc_usuario SET idFila = '$chFila'," .
								" chamando = TRUE, tempoStatus = '".date("H:i:s")."'," .
								" numEntra = '$cid' WHERE telefone = '$tel'";
						$this->connCC->executa($sql);
						if($this->connCC->qtdAff > 1) {
							$qtd = $this->connCC->qtdAff;
							$console->loga(LOG_AVISO, "++++++++++ Inconsistencia[4]! $qtd linhas atualizada em [cc_usuario]!");
						} else if($this->connCC->qtdAff == 1)
							$console->loga(LOG_NORMAL, ">>EV: Dial. Setado idFila($chFila), chamando=1, tempoStatus e numEntra($cid) para o telefone($tel)");
						break;
					
					case "originateresponse":
						$console->loga(LOG_DEBUG0, "Evento Tratado: OriginateResponse");
						$sip = Util::pegaSipDoPacote($aux);
						if(Util::comecaCom($sip, "SIP")) {
							list($d, $tel) = explode("/", $sip);
							$resp = $aux->getAtr('Response');
							if($resp == "Success") {
								$num = $aux->getAtr('Exten');
								$sql = "UPDATE cc_usuario SET sainte = TRUE, tempoStatus = '".date("H:i:s")."'," .
										" numSai = '$num' WHERE telefone = '$tel'";
								$this->connCC->executa($sql);
								if($this->connCC->qtdAff > 1) {
									$qtd = $this->connCC->qtdAff;
									$console->loga(LOG_AVISO, "++++++++++ Inconsistencia[1]! $qtd linhas atualizada em [cc_usuario]!");
								} else if($this->connCC->qtdAff == 1)
									$console->loga(LOG_NORMAL, ">>EV: OriginateResponse. Setado numSai($num) para o telefone($tel)", num, tel);
							} else if($resp == "Failure") {
								$this->connCC->executa("UPDATE cc_usuario SET sainte = FALSE, numSai = '' WHERE telefone = '$tel'");
								$console->loga(LOG_NORMAL, ">>EV: OriginateResponse. Failure Setado numSai(0) para o telefone($tel)");
							}
						}
						break;
					
					case "hangup": // Alguem desligou
						$console->loga(LOG_DEBUG0, "Evento Tratado: Hangup");
						$chan = $aux->getAtr('Channel');
						$nomeCanalLimpo = Util::limpaNomeCanal($chan);
						if(isset($listaIdChamadaFila[$nomeCanalLimpo])) {
							$console->loga(LOG_NORMAL, ">>EV: Hangup. Descartando o nome da fila [".$listaIdChamadaFila[$nomeCanalLimpo]."] para o canal [$nomeCanalLimpo]");
							unset($listaIdChamadaFila[$nomeCanalLimpo]);
						}
						$sip  = Util::pegaSipDoPacote($aux);
						if(Util::comecaCom($sip, "SIP")) {
							list($d, $tel) = explode("/", $sip);
							if(strlen($tel) > 0) {
								$sql = "UPDATE cc_usuario SET  tempoStatus = '".date("H:i:s")."'," .
										" emLigacao = 0, chamando = FALSE, sainte = FALSE, numSai = '' WHERE telefone = '$tel'";
								$this->connCC->executa($sql);
								if($this->connCC->qtdAff > 1) {
									$qtd = $this->connCC->qtdAff;
									$console->loga(LOG_AVISO, "++++++++++++ Inconsistencia[2]! $qtd linhas atualizada em [cc_usuario]!!!");
								} else if($this->connCC->qtdAff == 1)
									$console->loga(LOG_NORMAL, ">>EV: Hangup. Setado numSai(0) para o telefone($tel)");
							}
						}
						break;
					
					case "link":
						$console->loga(LOG_DEBUG0, "Evento Tratado: Link");
						$canal = Util::pegaSipDoPacote($aux, "Channel2");
						if(Util::comecaCom($canal, "Agent"))   list($d, $codUsu) = explode("/", $canal);
						else if(Util::comecaCom($canal, "SIP"))	list($d, $tel1)   = explode("/", $canal);
						if(strlen($tel1) > 0 || $codUsu > 0) {
							$check = 1;
							if(strlen($tel1) > 0) {
								$canal = Util::pegaSipDoPacote($aux, "Channel1");
								if(Util::comecaCom($canal, "SIP"))
									list($d, $tel2) = explode("/", $canal);
								$sql = "UPDATE cc_usuario SET chamando = FALSE, emLigacao = 2 WHERE telefone = '$tel1'";
								if(!empty($tel2)) {
									$sql .= " OR telefone = '$tel2'";
									$check = 2;
								}
								$this->connCC->executa($sql);
							} else if($codUsu > 0)
								$this->connCC->executa("UPDATE cc_usuario SET emLigacao = 2 WHERE id = $codUsu");
							
							if($this->connCC->qtdAff > $check) {
								$qtdAff = $this->connCC->qtdAff;
								$console->loga(LOG_AVISO, "+++++++++++ Inconsistencia[3]! $qtdAff linhas atualizada em [cc_usuario]!!!");
							} else if($this->connCC->qtdAff > 0)
								$console->loga(LOG_NORMAL, ">>EV: Link. Setado emLigacao(2) para o ramal($tel1 e $tel2)");
						}
						break;

					case "queueparams": // Evento gerado pela requisi��o do status das filas a cada 2s
						$nomeFila  = $aux->getAtr('Queue');
						if(!empty($nomeFila)) {
							$console->loga(LOG_DEBUG2, "Evento Tratado: QueueParams");
							$emEspera  = $aux->getAtr('Calls');
							$tempoEsp  = $aux->getAtr('Holdtime');
							$completed = $aux->getAtr('Completed');
							$abandoned = $aux->getAtr('Abandoned');
							
							$emEspera  = (empty($emEspera)  || !is_numeric($emEspera))  ? "0" : $emEspera;
							$tempoEsp  = (empty($tempoEsp)  || !is_numeric($tempoEsp))  ? "0" : $tempoEsp;
							$completed = (empty($completed) || !is_numeric($completed)) ? "0" : $completed;
							$abandoned = (empty($abandoned) || !is_numeric($abandoned)) ? "0" : $abandoned;
							$totRecv   = (($completed - $abandoned) > 0) ? ($completed - $abandoned) : 0;
							
							if($emEspera == 0) $sqlTempoEsp = ", tempoEspera='0:00' ";
							
							$tempoEsp = Util::formataSegundos($tempoEsp);
							
							$sql = "UPDATE cc_fila SET qtdChamEspera = '$emEspera', tempoMedioEspera = '$tempoEsp', " .
								"qtdChamRecebida = '$totRecv', qtdChamAtendida = '$completed'$sqlTempoEsp WHERE nome = '$nomeFila'";
							$insOK = $this->connCC->executa($sql);
							if(!$insOK || $this->connCC->qtdAff != 1)
								$console->loga(LOG_AVISO, "ERRO[50]!! Ao atualizar informa��es da fila [$nomeFila]");
							else
								$console->loga(LOG_DEBUG2, ">>EV: QueueParams. Setado qtdChamEspera($emEspera), tempoMedioEspera($tempoEsp)" .
									"qtdChamRecebida($totRecv), qtdChamAtendida($completed) para a fila($nomeFila)");
						}
						break;
					
					case "queueentry":
						$nomeFila  = $aux->getAtr('Queue');
						if($aux->getAtr('Position') == "1" && !empty($nomeFila)) {
							$console->loga(LOG_DEBUG2, "Evento Tratado: QueueEntry");
							$tempoEspera = $tempoEspera = Util::formataSegundos($aux->getAtr('Wait'));
							
							$sql = "UPDATE cc_fila SET tempoEspera = '$tempoEspera' WHERE nome = '$nomeFila'";
							$insOK = $this->connCC->executa($sql);
							if(!$insOK || $this->connCC->qtdAff != 1)
								$console->loga(LOG_AVISO, "ERRO[51]!! Ao atualizar informa��es da fila [$nomeFila]");
							else
								$console->loga(LOG_DEBUG2, ">>EV: QueueEntry. Setado tempoEspera($tempoEspera) para a fila($nomeFila)");
						}
						break;

					case "channelreload":
						if($aux->getAtr('Channel') == "SIP")
							$console->loga(LOG_AVISO, "SIP RELOAD");
						break;
				
					case "shutdown":
						$console->loga(LOG_NORMAL, "Asterisk desligou. Saindo!");
						$saiLoopPrincipal = true;
						break;
				}
			}
			$aux = $aux->prox;
		}
		return true;
	}
}

$daemon = new ControleCC();
$daemon->run();
$daemon->shut();
?>
