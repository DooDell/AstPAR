<?php
class InfoHost {
	public $host, $port, $user, $pass, $db;
}
class Conf {
	public $arq, $ami, $cc, $ast;
	
	public function init($arq = "/etc/controleCC.conf") {
		$this->arq = $arq;
		if(!$this->ler()) {
			$this->ami = new InfoHost();
			$this->ami->host = "localhost";
			$this->ami->port = 5038;
			$this->ami->user = "admin";
			$this->ami->pass = "sapo";
			
			$this->cc = new InfoHost();
			$this->cc->host = "localhost";
			$this->cc->port = 3306;
			$this->cc->user = "sa_cc";
			$this->cc->pass = "sapo";
			$this->cc->db   = "cc";
			
			$this->ast = new InfoHost();
			$this->ast->host = "localhost";
			$this->ast->port = 3306;
			$this->ast->user = "sa_asterisk";
			$this->ast->pass = "sapo";
			$this->ast->db   = "asterisk";
			
			$this->salvar();
			return false;
		}
		return true;
	}
	
	function salvar() {
		$txt = 
'// Arquivo de configuracao do Controle do CallCenter Celepar
$amiHost = "' .$this->ami->host. '";
$amiPort = '  .$this->ami->port. ';
$amiUser = "' .$this->ami->user. '";
$amiPass = "' .$this->ami->pass. '";

$ccHost  = "' .$this->cc->host. '";
$ccPort  = '  .$this->cc->port. ';
$ccUser  = "' .$this->cc->user. '";
$ccPass  = "' .$this->cc->pass. '";
$ccDB    = "' .$this->cc->db.   '";

$astHost = "' .$this->ast->host. '";
$astPort = '  .$this->ast->port. ';
$astUser = "' .$this->ast->user. '";
$astPass = "' .$this->ast->pass. '";
$astDB   = "' .$this->ast->db.   '";
';
		file_put_contents($this->arq, $txt);
	}
	
	function ler() {
		if(!file_exists($this->arq)) return false;
		$txt = file_get_contents($this->arq);
		if(strstr($txt, "// Arquivo de configuracao do Controle do CallCenter Celepar")) {
			$amiHost = $amiPort = $amiUser = $amiPass = null;
			$ccHost = $ccPort = $ccUser = $ccPass = $ccDB = null;
			$astHost = $astPort = $astUser = $astPass = $astDB = null;
			eval($txt);
			$this->ami = new InfoHost();
			$this->ami->host = $amiHost;
			$this->ami->port = $amiPort;
			$this->ami->user = $amiUser;
			$this->ami->pass = $amiPass;
			
			$this->cc = new InfoHost();
			$this->cc->host  = $ccHost;
			$this->cc->port  = $ccPort;
			$this->cc->user  = $ccUser;
			$this->cc->pass  = $ccPass;
			$this->cc->db    = $ccDB;
			
			$this->ast = new InfoHost();
			$this->ast->host  = $astHost;
			$this->ast->port  = $astPort;
			$this->ast->user  = $astUser;
			$this->ast->pass  = $astPass;
			$this->ast->db    = $astDB;
			return true;
		}
	}
}

class Logger
{
	private $arqLoga;
	public  $emTela;
	
	public function Logger($emTela=true) {
		$this->emTela = $emTela;
	}
	
	function loga($nivelDebug, $texto)
	{
		if($nivelDebug <= NIVEL_DEBUG) {
			$data = date("d/m/y");
			$hora = date("H:i:s");
			
			if(!is_resource($this->arqLoga)) {
				$this->arqLoga = fopen("/var/log/controleCallCenter.log", "a");
				if(!$this->arqLoga) {
					echo("Erro ao abrir arquivo de log [/var/log/controleCallCenter.log]. Saindo!\n");
					exit(1);
				}
				fprintf($this->arqLoga, "\n\n=== controleCC Ver:".VERSAO." - Arquivo de LOG aberto dia [$data] ===\n\n");
				if($this->emTela)
					echo("\n\n=== controleCC Ver:".VERSAO." - Arquivo de LOG aberto dia [$data] ===\n\n");
			}
			fprintf($this->arqLoga, "[$data $hora] > $texto\n");
			
			if($this->emTela)
				echo("[$data $hora] > $texto\n");
		}
	}
	
	function fecha()
	{
		if(is_resource($this->arqLoga)) {
			$this->loga(LOG_AVISO, "Fechando arquivo de log.");
			fclose($this->arqLoga);
		}
	}
}

class Util
{
	/**
	 * Procura o nome da fila segundo um canal
	 * Serve para
	// TODO : Serve para...
	 */
	static function procuraNomeFilaPorCanal($canal)
	{
		global $listaIdChamadaFila;
		$aux =& $listaIdChamadaFila;
		while($aux) {
			if($aux->canal == $canal) break;
			$aux =& $aux->prox;
		}
		return $aux;
	}

	static function pegaSipDoPacote($pacote, $tipo='Channel') {
		list($sip, $d) = explode("-", $pacote->getAtr($tipo));
		return $sip;
	}
	
	static function comecaCom($str, $comeco) {
		return(substr($str, 0, strlen($comeco)) == $comeco);
	}
	
	static function tiraEspacosDuplicados($str) {
		$ret = "";
		foreach(explode(" ", $str) as $pal) {
			if(strlen($pal)) {
				if(!empty($ret)) $ret .= " ";
				$ret .= $pal;
			}
		}
		return $ret;
	}
	
	static function pegaPalavraAnterior($palavras, $procura) {
		$ret = false;
		for($c=1; $c<count($palavras); $c++) {
			if(Util::comecaCom($palavras[$c], $procura)) {
				$ret = $palavras[$c - 1];
				break;
			}
		}
		return $ret;
	}
	
	static function pegaPalavraPorPrefixo($palavras, $prefixo) {
		$ret = false;
		for($c=1; $c<count($palavras); $c++) {
			if(Util::comecaCom($palavras[$c], $prefixo)) {
				$ret = $palavras[$c];
				break;
			}
		}
		return $ret;
	}
	
	static function formataSegundos($segundos) {
		$minutos = floor($segundos / 60);
		if($minutos > 0) {
			$segundos -= ($minutos * 60);
			if($segundos < 10) $segundos = "0$segundos";
			$horas = floor($minutos / 60);
			if($horas > 0) {
				$minutos -= ($horas * 60);
				if($minutos < 10) $minutos = "0$minutos";
				return "$horas:$minutos:$segundos";
			} else {
				return "$minutos:$segundos";
			}
		} else {
			return ($segundos < 10) ? "0:0$segundos" : "0:$segundos";
		}
	}
	
	static function limpaNomeCanal($nomeCanal) {
		return str_replace(array("/", ",", "-"), "", $nomeCanal);
	}
}
?>