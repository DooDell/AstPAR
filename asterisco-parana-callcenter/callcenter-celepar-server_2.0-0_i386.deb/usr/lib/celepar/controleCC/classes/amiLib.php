<?php
/**
 * AMI
 *
 * Classe para trabalhar com AMI no Asterisk com PHP 5.x
 *
 * Detalhes:
 *
 * Lembre-se de configurar corretamente o usuario, senha
 * e as permissoes no arquivo /etc/asterisk/manager.conf
 *
 * Exemplo:
 *
 * <code>
 * [admin]
 * secret = senha123
 * read = system,call,log,verbose,command,agent,user,config
 * write = system,call,log,verbose,command,agent,user,config
 * </code>
 * 
 * @since 22/03/2008
 * @author Carlos Alberto Cesario <carloscesario@gmail.com>
 * @package AMI
 * @license http://www.gnu.org/copyleft/gpl.html GPL
 * @filesource
*/

class pacote {
	private $atributos;
	public  $prox, $dados;
	
	public function __construct() {
		$this->atributos = array();
		$this->prox = NULL;
		$this->dados = NULL;
	}
	
	function vazio() {
		return (count($this->atributos) == 0) ? true : false;
	}
	
	function setAtr($chave, $valor=null) {
		if(is_array($chave)) {
			foreach($chave as $c => $v)
				$this->atributos[$c] = $v;
		} else
			$this->atributos[$chave] = $valor;
	}
	
	function getAtr($chave) {
		return $this->atributos[$chave];
	}
	
	function mostra() {
		$ret = "";
		$aux =& $this;
		while($aux) {
			$str = "" . $aux;
			if(strlen($str)) $ret .= "$str \n";
			$aux = $aux->prox;
		}
		return $ret;
	}
	
	function __toString() {
		if(!count($this->atributos)) return "";
		
		foreach($this->atributos as $chave => $valor)
			$ret .= "$chave = $valor\n";
		if($this->dados)
			$ret .= "Dados: $this->dados\n";
		return $ret . "\n";
	}
}
 
class AMI
{
	private $SOCKET = null, $DEBUG, $actID = 1000, $conectado = false;

	public function __construct($ev="On") {
		$this->DEBUG = false;
		$this->eventos = $ev;
	}

	public function debugMsg($msg)
	{
		if($this->DEBUG)
			echo "AMI> " . date("M  d") . " " . date("H:i:s") . " -- debug: " .preg_replace("/(\r\n|\r|\n)/", ' ', $msg). "\n";
    }
 
    public function login($conf) {
    	if(!is_a($conf, "InfoHost")) {
    		$this->debugMsg("Parametro inv�lido para AMI->login");
    		return false;
    	}
        $buffer = "";
 
		if(($this->SOCKET = socket_create(AF_INET, SOCK_STREAM, SOL_TCP)) < 0) {
			$this->debugMsg("Impossivel criar socket");
			return false;
		}

		if(!@socket_connect($this->SOCKET, $conf->host, $conf->port)) {
			$this->debugMsg("Impossivel conectar ao Asterisk");
			return false;
		}
			
        if ($this->SOCKET == false) {
			$this->debugMsg("Impossivel conectar ao asterisk manager");
			return false;
		} else {
            while(!$this->temDadosNoSocket()) {}
            while($this->temDadosNoSocket())
            	$buffer .= socket_read($this->SOCKET, 2048);
            
            if (!stristr($buffer, "Asterisk Call Manager")) {
				$this->debugMsg("Asterisk Manager nao esta rodando nesta porta");
                return false;
            } else {
                $pacote = $this->send_command('Login', array('Username' => $conf->user, 'Secret' => $conf->pass, "Events" => $this->eventos));
				$this->debugMsg("Resposta: [" . $pacote->getAtr('Message') . "]");
				
                if (!stristr($pacote->getAtr('Response'), "Success")) {
					$this->debugMsg("Falha no login. O usuario ou senha estao incorrretos.");
                    return false;
                } else {
                	$this->conectado = true;
					$this->debugMsg("Conexao bem sucedida.");
                }
			}
		}
		return $pacote;
	}
 
    public function disconnect()
    {
    	$ret = true;
    	if($this->conectado) {
        	$ret = $this->send_command('Logoff');
        	socket_close($this->SOCKET);
    	}
        return $ret;
    }
    
    public function send_command($acao, $params = array())
    {
        $ret = array();
        
        $cmd = "Action: $acao\r\n";
        foreach($params as $chave => $valor)
            $cmd .= "$chave: $valor\r\n";
        
        $cmd .= "ActionID: " .$this->actID++. "\r\n\r\n";
        if(NIVEL_DEBUG >= LOG_DEBUG2) $this->debugMsg("Comando: $cmd");
 
        $TO = 0.2;
        if(     $acao == 'Login')  $TO = 0.8;
        else if($acao == 'Logoff') $TO = 0;
        
        socket_write($this->SOCKET, $cmd);
        $pacote = $this->receive($TO);
        
        return $pacote;
    }
 
    function receive($timeout = 0.1) {
    	$ret = new pacote();
    	
    	$rbuff = "";
    	while($this->temDadosNoSocket($timeout))
			$rbuff .= socket_read($this->SOCKET, 2048);

    	if(strlen($rbuff) > 0) {
    		$utlSL = 10;
    		$aux =& $ret;
    		$temDados = false;
    		foreach(explode("\r\n", $rbuff) as $lin) {
				$len = strlen($lin);
				if($len == 0 && $utlSL == 0) break;
    			if($len < 1) {
    				$aux->prox = new pacote();
					$aux =& $aux->prox;			
    			} else {
    				list($chave, $valor) = explode(": ", $lin);
    				if($chave == "Response" && $valor == "Follows")
    					$temDados = true;
    				
    				if($temDados && strstr($chave, " "))
    					$aux->dados = $lin;
    				else if($chave != "Privilege")
    					$aux->setAtr($chave, $valor);
	   			}
    			$utlSL = $len;
    		}
    	}
    	$aux->prox = null;
		return $ret;
	}
	
	function temDadosNoSocket($timeout = 0.1) {
		$read = array($this->SOCKET);
		return socket_select($read, $write = NULL, $except = NULL, floor($timeout), ceil($timeout*1000000));
	}
}
?>