<?php
/**
 * Conex�o com o banco de dados PostgreSQL
 * @author Gabriel Ortiz - ortiz@celepar.pr.gov.br
 * @version 1.0, 22/05/2006
 */
class Conexao {
	private $id, $res, $bd;
	public $qtdSel, $qtdAff, $data, $erro, $loginOK;
	
	/**
	 * Faz a conex�o com o BD
	 */
	function Conexao($banco="cc") {
		$this->loginOK = false;
		$this->bd = $banco;
		$conf = ($this->bd == "cc") ? ControleCC::$conf->cc : ControleCC::$conf->ast;
		if($this->bd == "cc") {
			if(!is_resource($GLOBALS['idBD']))
				$GLOBALS['idBD'] = pg_connect("host=$conf->host dbname=cc user=$conf->user password=$conf->pass");
			$this->id = $GLOBALS['idBD'];
		} else {
			$this->id = pg_connect("host=$conf->host dbname=$banco user=$conf->user password=$conf->pass");
		}
		$this->loginOK = true;
	}
	
	/**
	 * Retorna um array de inteiros conforme o SQL, que deve estar
	 * estruturado de forma a prover um... array de ints!
	 * @param String sql - SQL na forma "SELECT id FROM ....", id ou outro campo int
	 */
	function arrayDeInteiros($sql) {
		$ret = array();
		$err = $this->executa($sql);
		if(is_string($err)) return $err;
		while($this->temMaisDados())
			$ret[] = $this->data[0];
		return $ret;
	}

	/**
	 * Executa uma query no BD e retorna os dados.
	 * @param String sql - SQL a ser executado
	 * @return true para OK, ou MSG de erro
	 */
	function executa($sql) {
		if ($sql=="")	{
			$this->res = 0;
			$this->qtd = 0;
		} else {
			global $console, $MOSTRA_SQL;
			
			$this->res = pg_query($this->id, $sql);
			if($MOSTRA_SQL)
				$console->loga(LOG_DEBUG0, "***** Exec SQL: $sql");
			if ($this->res) {
				$this->qtdSel = @pg_num_rows($this->res);		// Num para SELECT
				$this->qtdAff = @pg_affected_rows($this->res);	// Num para INSERT, UPDATE, DELETE
				return true;
			} else {
				$err = "Erro SQL[$sql][" . pg_last_error($this->id) . "]";
				$console->loga(LOG_AVISO, "Erro del SQL:" . $err);
				return $err;
			}
		}
	}

	/**
	 * Busca os dados de uma linha do resultado e posiciona o ponteiro na prxima.
	 * Para listar os dados no cdigo basta utilizar por exemplo:
	 *                while ($conn->temMaisDados())  {
	 *                   echo $conn->data["nome"];
	 *                }
	 * Caso o parametro no seja vazio j retorna o valor do campo pedido. Exemplo:
	 * 								$conn->executa("SELECT a FROM b WHERE c=1")
	 * 								echo $conn->temMaisDados("a")
	 */
	function temMaisDados($campo="") {
		global $console;
		if($this->qtdSel <= 0) return false;
		$this->data = pg_fetch_array($this->res);
		if($this->data) {
			if(!empty($campo)) return $this->data[$campo];
			return true;
		}
		return false;
	}

	/**
	 * Encerra a conexo com o banco de dados.
	 */
	function fecha($deVerdade = false) {
		if($deVerdade || $this->bd != "cc")
			pg_close($this->id);
		$this->id = "";
		$this->res = 0;
		$this->qtd = 0;
		$this->data = "";
	}
}
?>