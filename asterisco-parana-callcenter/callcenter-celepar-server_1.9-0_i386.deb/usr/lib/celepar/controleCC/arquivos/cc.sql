--
-- PostgreSQL database dump
--

SET client_encoding = 'UTF8';
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'Standard public schema';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: cc_acaoagente; Type: TABLE; Schema: public; Owner: sa_cc; Tablespace: 
--

CREATE TABLE cc_acaoagente (
    id serial NOT NULL,
    executaacao character varying(60),
    codusu integer NOT NULL
);


ALTER TABLE public.cc_acaoagente OWNER TO sa_cc;

--
-- Name: cc_acaoagente_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa_cc
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('cc_acaoagente', 'id'), 52, true);


--
-- Name: cc_fila; Type: TABLE; Schema: public; Owner: sa_cc; Tablespace: 
--

CREATE TABLE cc_fila (
    id integer NOT NULL,
    nome character varying(20),
    qtdchamespera integer,
    tempomedioespera character varying(25) NOT NULL,
    tempoespera character varying(25) NOT NULL,
    qtdchamrecebida integer NOT NULL,
    qtdchamatendida integer NOT NULL,
    tempomedioatend character varying(25) NOT NULL,
    tempomedioabandono character varying(25) NOT NULL
);


ALTER TABLE public.cc_fila OWNER TO sa_cc;

--
-- Name: cc_historico; Type: TABLE; Schema: public; Owner: sa_cc; Tablespace: 
--

CREATE TABLE cc_historico (
    id serial NOT NULL,
    tipoevento integer NOT NULL,
    datahora timestamp without time zone NOT NULL,
    campo1 character varying(64),
    campo2 character varying(64),
    campo3 character varying(64),
    campo4 character varying(64)
);


ALTER TABLE public.cc_historico OWNER TO sa_cc;

--
-- Name: cc_historico_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa_cc
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('cc_historico', 'id'), 493, true);


--
-- Name: cc_status; Type: TABLE; Schema: public; Owner: sa_cc; Tablespace: 
--

CREATE TABLE cc_status (
    id integer NOT NULL,
    nome character varying(32),
    nomestatus character varying(255)
);


ALTER TABLE public.cc_status OWNER TO sa_cc;

--
-- Name: cc_tipoevento; Type: TABLE; Schema: public; Owner: sa_cc; Tablespace: 
--

CREATE TABLE cc_tipoevento (
    id integer NOT NULL,
    nome character varying(32),
    campo1 character varying(32),
    campo2 character varying(32),
    campo3 character varying(32),
    campo4 character varying(32)
);


ALTER TABLE public.cc_tipoevento OWNER TO sa_cc;

--
-- Name: cc_usuario; Type: TABLE; Schema: public; Owner: sa_cc; Tablespace: 
--

CREATE TABLE cc_usuario (
    id integer NOT NULL,
    "login" character varying(32) NOT NULL,
    telefone character varying(32),
    nome character varying(32) NOT NULL,
    ramal integer NOT NULL,
    senha integer NOT NULL,
    tipo integer NOT NULL,
    codstatus integer NOT NULL,
    tempostatus character varying(32) NOT NULL,
    numsai character varying(32),
    numentra character varying(32),
    emligacao boolean NOT NULL,
    chamando boolean NOT NULL,
    sainte boolean NOT NULL,
    idfila character varying(32),
    msg character varying(128),
    nomefone character varying(255)
);


ALTER TABLE public.cc_usuario OWNER TO sa_cc;

--
-- Name: cc_usuariofila; Type: TABLE; Schema: public; Owner: sa_cc; Tablespace: 
--

CREATE TABLE cc_usuariofila (
    id serial NOT NULL,
    codusu integer NOT NULL,
    codfila integer NOT NULL
);


ALTER TABLE public.cc_usuariofila OWNER TO sa_cc;

--
-- Name: cc_usuariofila_id_seq; Type: SEQUENCE SET; Schema: public; Owner: sa_cc
--

SELECT pg_catalog.setval(pg_catalog.pg_get_serial_sequence('cc_usuariofila', 'id'), 261, true);


--
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: public; Owner: sa_cc
--

CREATE SEQUENCE hibernate_sequence
    INCREMENT BY 1
    NO MAXVALUE
    NO MINVALUE
    CACHE 1;


ALTER TABLE public.hibernate_sequence OWNER TO sa_cc;

--
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: public; Owner: sa_cc
--

SELECT pg_catalog.setval('hibernate_sequence', 633, true);


--
-- Data for Name: cc_acaoagente; Type: TABLE DATA; Schema: public; Owner: sa_cc
--



--
-- Data for Name: cc_fila; Type: TABLE DATA; Schema: public; Owner: sa_cc
--



--
-- Data for Name: cc_historico; Type: TABLE DATA; Schema: public; Owner: sa_cc
--



--
-- Data for Name: cc_status; Type: TABLE DATA; Schema: public; Owner: sa_cc
--

INSERT INTO cc_status VALUES (0, 'Deslogado', NULL);
INSERT INTO cc_status VALUES (1, 'Disponivel', NULL);
INSERT INTO cc_status VALUES (200, 'Indisponivel', NULL);
INSERT INTO cc_status VALUES (100, 'Pausa', NULL);
INSERT INTO cc_status VALUES (102, 'CLT', NULL);
INSERT INTO cc_status VALUES (101, 'Laboral', NULL);
INSERT INTO cc_status VALUES (104, 'Lanche/Particular', NULL);
INSERT INTO cc_status VALUES (105, 'Treinamento', NULL);
INSERT INTO cc_status VALUES (103, 'Trabalho', NULL);


--
-- Data for Name: cc_tipoevento; Type: TABLE DATA; Schema: public; Owner: sa_cc
--

INSERT INTO cc_tipoevento VALUES (1, 'Login', 'Código do Usuário', 'Ramal', 'Telefone', '');
INSERT INTO cc_tipoevento VALUES (2, 'Logoff', 'Código do Usuário', '', '', '');
INSERT INTO cc_tipoevento VALUES (3, 'Status', 'Código do Agente', 'Status Anterior', 'Status Novo', 'Código do usuário');
INSERT INTO cc_tipoevento VALUES (4, 'Entra na Chamada', 'Código do Usuário Ouvinte', 'Ramal do Ouvinte', 'Código', '');
INSERT INTO cc_tipoevento VALUES (5, 'Escuta Chamada', 'Código do Usuário Ouvinte', 'Ramal do Ouvinte', 'Código', '');

--
-- Data for Name: cc_usuario; Type: TABLE DATA; Schema: public; Owner: sa_cc
--


--
-- Data for Name: cc_usuariofila; Type: TABLE DATA; Schema: public; Owner: sa_cc
--


--
-- Name: cc_acaoagente_pkey; Type: CONSTRAINT; Schema: public; Owner: sa_cc; Tablespace: 
--

ALTER TABLE ONLY cc_acaoagente
    ADD CONSTRAINT cc_acaoagente_pkey PRIMARY KEY (id);


--
-- Name: cc_fila_pkey; Type: CONSTRAINT; Schema: public; Owner: sa_cc; Tablespace: 
--

ALTER TABLE ONLY cc_fila
    ADD CONSTRAINT cc_fila_pkey PRIMARY KEY (id);


--
-- Name: cc_historico_pkey; Type: CONSTRAINT; Schema: public; Owner: sa_cc; Tablespace: 
--

ALTER TABLE ONLY cc_historico
    ADD CONSTRAINT cc_historico_pkey PRIMARY KEY (id);


--
-- Name: cc_status_pkey; Type: CONSTRAINT; Schema: public; Owner: sa_cc; Tablespace: 
--

ALTER TABLE ONLY cc_status
    ADD CONSTRAINT cc_status_pkey PRIMARY KEY (id);


--
-- Name: cc_tipoevento_pkey; Type: CONSTRAINT; Schema: public; Owner: sa_cc; Tablespace: 
--

ALTER TABLE ONLY cc_tipoevento
    ADD CONSTRAINT cc_tipoevento_pkey PRIMARY KEY (id);


--
-- Name: cc_usuario_login_key; Type: CONSTRAINT; Schema: public; Owner: sa_cc; Tablespace: 
--

ALTER TABLE ONLY cc_usuario
    ADD CONSTRAINT cc_usuario_login_key UNIQUE ("login");


--
-- Name: cc_usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: sa_cc; Tablespace: 
--

ALTER TABLE ONLY cc_usuario
    ADD CONSTRAINT cc_usuario_pkey PRIMARY KEY (id);


--
-- Name: cc_usuariofila_pkey; Type: CONSTRAINT; Schema: public; Owner: sa_cc; Tablespace: 
--

ALTER TABLE ONLY cc_usuariofila
    ADD CONSTRAINT cc_usuariofila_pkey PRIMARY KEY (id);


--
-- Name: acaoag_usuFK; Type: FK CONSTRAINT; Schema: public; Owner: sa_cc
--

ALTER TABLE ONLY cc_acaoagente
    ADD CONSTRAINT "acaoag_usuFK" FOREIGN KEY (codusu) REFERENCES cc_usuario(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fk5382464ff3dacb07; Type: FK CONSTRAINT; Schema: public; Owner: sa_cc
--

ALTER TABLE ONLY cc_usuario
    ADD CONSTRAINT fk5382464ff3dacb07 FOREIGN KEY (codstatus) REFERENCES cc_status(id);


--
-- Name: fk550e670fbaedf602; Type: FK CONSTRAINT; Schema: public; Owner: sa_cc
--

ALTER TABLE ONLY cc_acaoagente
    ADD CONSTRAINT fk550e670fbaedf602 FOREIGN KEY (codusu) REFERENCES cc_usuario(id);


--
-- Name: fka1787c4799a582d3; Type: FK CONSTRAINT; Schema: public; Owner: sa_cc
--

ALTER TABLE ONLY cc_usuariofila
    ADD CONSTRAINT fka1787c4799a582d3 FOREIGN KEY (codfila) REFERENCES cc_fila(id);


--
-- Name: fka1787c47baedf602; Type: FK CONSTRAINT; Schema: public; Owner: sa_cc
--

ALTER TABLE ONLY cc_usuariofila
    ADD CONSTRAINT fka1787c47baedf602 FOREIGN KEY (codusu) REFERENCES cc_usuario(id);


--
-- Name: historico_tipoevFK; Type: FK CONSTRAINT; Schema: public; Owner: sa_cc
--

ALTER TABLE ONLY cc_historico
    ADD CONSTRAINT "historico_tipoevFK" FOREIGN KEY (tipoevento) REFERENCES cc_tipoevento(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: usuario_statusFK; Type: FK CONSTRAINT; Schema: public; Owner: sa_cc
--

ALTER TABLE ONLY cc_usuario
    ADD CONSTRAINT "usuario_statusFK" FOREIGN KEY (codstatus) REFERENCES cc_status(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: usufila_filaFK; Type: FK CONSTRAINT; Schema: public; Owner: sa_cc
--

ALTER TABLE ONLY cc_usuariofila
    ADD CONSTRAINT "usufila_filaFK" FOREIGN KEY (codfila) REFERENCES cc_fila(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: usufila_usuFK; Type: FK CONSTRAINT; Schema: public; Owner: sa_cc
--

ALTER TABLE ONLY cc_usuariofila
    ADD CONSTRAINT "usufila_usuFK" FOREIGN KEY (codusu) REFERENCES cc_usuario(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

