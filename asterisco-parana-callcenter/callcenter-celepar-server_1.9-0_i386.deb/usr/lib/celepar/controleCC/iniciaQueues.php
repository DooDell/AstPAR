<?php
include("classes/amiLib.php");
include("classes/util.php");
include("classes/conexao.php");

$AMI = null;

// chuncho! (referenciado em conexao.php)
class ControleCC {
	public static $conf;
}

ControleCC::$conf = new Conf();
$err = ControleCC::$conf->init();
if(!$err) {
	echo("Arquivo de configuracao [".
		ControleCC::$conf->arq."] nao encontrado. Assumindo valores padrao\n");
}
	
function initAMI() {
	global $AMI;
	$AMI = new AMI("Off");
	if(!($pacote = $AMI->login(ControleCC::$conf->ami))) {
		$AMI->disconnect();
		return false;
	}
	return true;
}

echo("Efetuando login no Asterisk [".ControleCC::$conf->ami->host."].\n");
$tries = 0;
$astLoginOK = false;
while($tries++ < 10) {
	if(initAMI()) {
		$astLoginOK = true;
		break;
	}
	sleep(3);
}
if(!$astLoginOK) {
	echo("Falha ao logar no AMI!\n");
} else {
	$conn = new Conexao("asterisk");
	$conn->executa("SELECT name,ramal FROM fila");
	while($conn->temMaisDados()) {
		$pacote = $AMI->send_command("Originate", array(
				"Channel" => "Local/" . $conn->data['ramal'],
				"Context" => "ramais-internos",
				"Application" => "Playback",
				"Data" => "cc_agenteRegistrado",
				"Priority" => "1",
				"Callerid" => "CallCenter",
				"Timeout" => "30000",
				"Async" => "1"
			));
		echo $pacote->mostra() . "\n\n";
	}
	$conn->fecha(true);
	$AMI->disconnect();
}
?>