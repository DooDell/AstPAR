
SELECT setval('tronco_id_seq', max(id)) FROM tronco;
SELECT setval('troncovoip_id_seq', max(id)) FROM troncovoip;

--
-- Inserir o tronco STP
--
INSERT INTO troncovoip(servidor,usuario,senha,porta)
	VALUES ('corevoip.pr.gov.br', 'pabx01', '123456', 5060);
INSERT INTO tronco(nome,descricao,direcao,tipo,modelo,tiporotaentrada,contexto,ramal,detalhes,idfilho)
	VALUES ('CORE STP', 'Core de Telefonia IP do Estado do Paran�', 3, 2, 'generica', 1, 'ramais-internos', '0', '', (SELECT currval('troncovoip_id_seq')));


--
-- Configurar o tronco STP como Padrao e o que estava padrao como Backup
--
UPDATE parametro SET valor = (SELECT valor FROM parametro WHERE nomeparam = 'troncoPadrao') WHERE nomeparam = 'troncoBackup';
UPDATE parametro SET valor = (SELECT id FROM tronco WHERE nome = 'CORE STP') WHERE nomeparam = 'troncoPadrao';


--
-- Sinalizar que este PABX foi configurado para o STP
--
SELECT setval('parametro_id_seq', max(id)) FROM parametro;
INSERT INTO parametro(nome, valor, nomeparam, flags, info)
	VALUES ('Configurado para o STP', '1', 'configstp', 0, 'Este PABX foi configurado para o STP');

