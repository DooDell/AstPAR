#!/bin/bash 
#----------------------------------------------------------------------
# worker.sh
# Utilizado para "subir" e "descer" os n�s do cluster HA
#----------------------------------------------------------------------

MODULO="WORKER.SH"
source /usr/lib/telefoniaip/modulos/Ferramentas/telipHA/clusterConfig.sh

DIRINIT=/usr/lib/telefoniaip/modulos/Ferramentas/telipHA/init.d

up()
{
	MSG="UP: Ativando IP(s) virtuais ($IP_VIRTUAL):";grava_log
	for IPIF in $IP_VIRTUAL; do
		IP=`echo $IPIF | cut -d : -f 1`
		IF=`echo $IPIF | cut -d : -f 2`
		MSG="++ UP: Adicionando IP $IP na interface $IF";grava_log
		ip addr add $IP$REDE dev $IF
	done
	
	ping -c 1 $GW > /dev/null
	MSG="UP: PING com gateway realizado";grava_log

	#-----------------------------------------------------
	#    INICIALIZACAO DOS SERVICOS
	#-----------------------------------------------------
	if [ -d $DIRINIT ]; then
		MSG="UP: Inicializando Servicos em $DIRINIT";grava_log
		run-parts --report --arg=start $DIRINIT >> $ARQ_LOG
	fi
}

down()
{
    MSG="DOWN: Removendo IP(s) vituais ($IP_VIRTUAL):";grava_log
    for IPIF in $IP_VIRTUAL; do
    	IP=`echo $IPIF | cut -d : -f 1`
		IF=`echo $IPIF | cut -d : -f 2`
    	MSG="++ DOWN: Removendo IP $IP da $IF";grava_log
    	ip addr | grep -v grep | grep $IP$REDE > /dev/null
    	if [ $? -eq 0 ]; then
    		ip addr del $IP$REDE dev $IF
    	fi
    done

    #-----------------------------------------------------
    #    ENCERRANDO OS SERVICOS
    #-----------------------------------------------------
    if [ -d $DIRINIT ]; then
	    MSG="DOWN: Encerrando Servicos em $DIRINIT";grava_log
		run-parts --report --reverse --arg=stop $DIRINIT >> $ARQ_LOG
	fi
}

case "$1" in
	up)   up
	;;

	down) down
	;;

	*)    MSG="Parametro Invalido";grava_log
	;;
esac
