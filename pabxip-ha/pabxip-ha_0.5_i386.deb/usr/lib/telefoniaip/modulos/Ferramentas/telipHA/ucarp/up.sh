#!/bin/bash

/usr/lib/telefoniaip/modulos/Ferramentas/telipHA/worker.sh up
