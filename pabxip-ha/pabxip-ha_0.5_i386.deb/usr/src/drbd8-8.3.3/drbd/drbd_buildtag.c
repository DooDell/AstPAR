/* automatically generated. DO NOT EDIT. */
#include <linux/drbd.h>
const char *drbd_buildtag(void)
{
	return "GIT-hash: 49bfeeaf3690ad0b9afd5376feda9e9eb34a30f3"
		" build by phil@fat-tyre, 2009-10-05 14:52:58";
}
