#!/bin/bash 

#------------------------------------------------------------------
# MODULO - UCARP.SH
#
# DATA DE MODIFICA��O:
# DESCRI�AO DA ALTERA��O:
#------------------------------------------------------------------

grava_log()
{
    echo -e "$(date '+%F %T') $MODULO - $MSG" >> $ARQ_LOG
}

start()
{
      #--------------------------------------------------------------
      #     ESTE PROCEDIMENTO DEVE SER EXECUTADO PARA VERIFICAR SE 
      #     PLACA DE REDE JA ESTA CONFIGURADA.
      #     SE A PLACA DE REDE N�O ESTIVER DISPONIVEL, OCORRERA UM
      #     ERRO COM A INICIALIZACAO DO UCARP
      #---------------------------------------------------------------

      if [ $LOCALHOST == $HOST_MASTER ]
      then
            IP=$IP_HOSTMASTER
      else
            IP=$IP_HOSTSLAVE
      fi

      while true
      do
            MSG="PROCURANDO $IP EM INTERFACE $INTERFACE";grava_log
            ifconfig $INTERFACE | grep $IP > /dev/null
            if [ $? -eq 0 ]
            then
                   break
            fi
	    sleep 1
      done

      MSG="INICIANDO EXECUCAO DO MODULO UCARP.SH";grava_log
      MSG="VERIFICANDO HOSTNAME E ENDERECAMENTO IP";grava_log

      if [ $LOCALHOST == $HOST_MASTER ]
      then
             IP_LOCAL=$IP_HOSTMASTER
             PREFERENCE="-P"
             PESO="1" 
      else
             IP_LOCAL=$IP_HOSTSLAVE
             PREFERENCE=" "
             PESO="3"
      fi

      MSG="EXECUTANDO UCARP ";grava_log

      #----------------------------------------------------
      #    PARAMETROS DO UCARP
      #---------------------------------------------------
      #    i - Interface de escuta de multicast
      #    s - Endereco IP real da interface
      #    v - Identificacao de grupo
      #    p - Senha de autenticacao de grupo
      #    a - Endereco IP Virtual
      #    u - Script a ser executado em modo UP
      #    d - Script a ser executado em modo DOWN
      #    B - Execucao em modo Background
      #    b - Intervalo de envio de mensagem keepalive
      #    r - Tempo de espera para considerar "morto" um noh do cluster
      #    k - Preferencia para assumir o papel de MASTER
      #        Quanto menor o valor melhor a preferencia
      #----------------------------------------------------
      $UCARP -i $INTERFACE $PREFERENCE -s $IP_LOCAL -v $VID \
              -p $PWD -a $IP_VIRTUAL -u $UP -d $DOWN -B -b $INTERVAL_ADVERTISE -r $TRYING_NUMBER -k $PESO
}

stop()
{
	/aplic/scripts/ucarp/down.sh
	killall -9 ucarp
}

#-----------------------------------------------------
#        ROTINA PRINCIPAL
#-----------------------------------------------------

MODULO="UCARP.SH"
ARQ_LOG="/var/log/cluster.log"
LOCALHOST=$(uname -n)

HOST_MASTER="Master"
HOST_SLAVE="Slave"
IP_VIRTUAL="192.168.254.237"
IP_HOSTMASTER="192.168.254.235"
IP_HOSTSLAVE="192.168.254.236"

UCARP="/usr/local/sbin/ucarp"
VID="50"
PWD="PWD50"
INTERFACE="eth0"
TRYING_NUMBER="4"
INTERVAL_ADVERTISE="3"
UP="/aplic/scripts/ucarp/up.sh"
DOWN="/aplic/scripts/ucarp/down.sh"

case "$1" in
    start) start
	        ;;
    stop) stop
	        ;;
     *) MSG="Parametro Invalido";grava_log
            ;;
esac

