#!/bin/bash

/aplic/scripts/ucarp/vip.sh up &

