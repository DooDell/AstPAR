#!/bin/bash 

#----------------------------------------------------------------------
# MODULO - VIP.SH
#----------------------------------------------------------------------
# PROCEDIMENTO PARA GERENCIAMENTO DE INTERFACE - UCARP
#----------------------------------------------------------------------
#           GERENCIAMENTO DO IP VIRTUAL -  10.15.190.50
#
# DATA DE ALTERA��O:
# DESCRI��O DA ALTERA��O:
#----------------------------------------------------------------------


grava_log()
{
    echo -e "$(date '+%F %T') $MODULO - $MSG" >> $ARQ_LOG
}


drbd_primary()
{
       MSG="DRBD_PRIMARY: CHAMANDO ROTINA DRBD.SH PRIMARY";grava_log
       /aplic/scripts/drbd/drbd.sh primary 

       if [ $? -ne 0 ]
       then
              MSG="ROTINA DRBD.SH PRIMARY TERMINOU DE FORMA ANORMAL";grava_log
              exit
       fi
}

drbd_secondary()
{
    MSG="DRBD_SECONDARY INICIANDO CHAMADA DE STOP DO ASTERISK";grava_log
    /aplic/scripts/drbd/drbd.sh secondary
}

asterisk_up()
{
    MSG="UP: EXECUTANDO TELIP START";grava_log

	sh /opt/asterisk2/start.sh

    sh /etc/init.d/postgresql-8.1 start
    sh /etc/init.d/apache2 start
    sh /etc/init.d/telip start
    /usr/lib/telefoniaip/arquivos/scripts/healthCheck.sh ARQS
}

asterisk_down()
{
    MSG="DOWN: EXECUTANDO TELIP STOP";grava_log

	sh /opt/asterisk2/stop.sh

    sh /etc/init.d/telip stop
    sh /etc/init.d/apache2 stop
    sh /etc/init.d/postgresql-8.1 stop
}


up()
{

    #-----------------------------------------------------
    # ADICIONAR ENDERECO VIRTUAL NA INTEFACE ETH0
    #-----------------------------------------------------
    MSG="UP: Adicionando endereco VIRTUAL na interface ETH0";grava_log
    ip addr add $IP_VIRTUAL dev $INTERFACE
    ip addr add $IP_VIRTUAL2 dev $INTERFACE
    ping -c 1 -I $IPV $GW > /dev/null
    MSG="UP: PING com gateway realizado";grava_log

    #-----------------------------------------------------
    # ESCREVER O CODIGO DO PROCEDIMENTO A PARTIR DAQUI
    #-----------------------------------------------------
    #-----------------------------------------------------
    # ATIVAR DRBD
    #-----------------------------------------------------
    MSG="UP: Inicializando Procedimento";grava_log
    MSG="UP: INICIANDO DRBD_PRIMARY";grava_log
    drbd_primary

    #-----------------------------------------------------
    # ATIVAR ASTERISK
    #-----------------------------------------------------
    MSG="UP: INICIANDO ASTERISK";grava_log
    asterisk_up
    sleep 2
    #/aplic/scripts/sipsak/sipsak_ast.sh > /dev/null
    #if [ $? -eq 0 ]
    #then
    #       MSG="UP: ASTERISK INICIOU CORRETAMENTE";grava_log
    #else
    #       MSG="UP: PROBLEMAS NA INICIALIZACAO DO ASTERISK !!!";grava_log
    #fi

    #-----------------------------------------------------
    #  ENVIA EMAIL PARA ORTIZ
    #-----------------------------------------------------
    MSG="UP: ENVIANDO EMAIL";grava_log
    if [ "x$EMAILADMIN" != "x" ]; then
       echo "[$DESC]" > /tmp/mail.out
       echo '-' >> /tmp/mail.out
       echo "$(time) - O Cluster migrou o endereco principal para o host: $LOCALHOST" >> /tmp/mail.out
       mail -a "From: CLUSTER" -s "MIGRACAO DO CLUSTER" $EMAILADMIN < /tmp/mail.out
   fi


}


down()
{

    MSG="DOWN: Removendo Endereco IP na ETH0";grava_log

    ip addr | grep -v grep | grep $IP_VIRTUAL > /dev/null

    if [ $? -eq 0 ]
    then
            ip addr del $IP_VIRTUAL dev $INTERFACE
            ip addr del $IP_VIRTUAL2 dev $INTERFACE
            MSG="DOWN: Endereco IP Virtual $IP_VIRTUAL foi removido da interface";grava_log
    else
            MSG="DOWN: Endereco IP Virtual $IP_VIRTUAL nao esta configurado na interface ETH0";grava_log
    fi

    #-----------------------------------------------------
    # ESCREVER O CODIGO DO PROCEDIMENTO A PARTIR DAQUI
    #-----------------------------------------------------
	        
    MSG="DOWN: Encerrando Procedimento";grava_log
    MSG="DOWN: Encerrando Asterisk";grava_log
    asterisk_down 
    MSG="DOWN: Chamando drbd para entrar em modo secondary";grava_log
    drbd_secondary
}


#---------------------------------------------------------
#             Rotina Principal
#---------------------------------------------------------

MODULO="VIP.SH"
ARQ_LOG="/var/log/cluster.log"
LOCALHOST=$(uname -n)

HOST_MASTER="Master"
HOST_SLAVE="Slave"
IP_VIRTUAL="192.168.254.237"
IP_MASTER="192.168.254.235/24"
IP_SLAVE="192.168.254.236/24"

GW="192.168.1.1"
IPV="192.168.254.237"
INTERFACE="eth0"

IP_VIRTUAL2="192.168.1.237"

case "$1" in
    up) up
           ;;
    down) down
           ;;
    *) MSG="Parametro Invalido";grava_log
       ;;
esac

