#!/bin/bash 

#------------------------------------------------------------------
# MODULO - DRBD.SH
#
# OBJETIVO: GERENCIAMENTO DOS SERVICOS COM DRBD
#
# DATA DE MODIFICAO:
# DESCRICAO DA ALTERACAO:
#
#------------------------------------------------------------------
# FLAGS - cat /proc/drbd
#------------------------------------------------------------------
#cs (connection state). Status of the network connection. 
#ds (disk states). State of the hard disks. Prior to the slash the state of the local node is displayed, after the slash the state of the hard disk of the partner node is shown
#ns (network send).  Volume of net data sent to the partner via the network connection; in Kibyte.
#nr (network receive).  Volume of net data received by the partner via the network connection; in Kibyte.
#dw (disk write). Net data written on local hard disk; in Kibyte.
#dr (disk read). Net data read from local hard disk; in Kibyte.
#al (activity log). Number of updates of the activity log area of the meta data.
#bm (bit map).  Number of updates of the bitmap area of the meta data. 
#lo (local count). Number of open requests to the local I/O sub-system issued by DRBD.
#pe (pending). Number of requests sent to the partner, but that have not yet been answered by the latter.
#ua (unacknowledged). Number of requests received by the partner via the network connection, but that have not yet been answered.
#ap (application pending). Number of block I/O requests forwarded to DRBD, but not yet answered by DRBD.
#ep (epochs). Number of epoch objects. Usually 1. Might increase under I/O load when using either the barrier or the none write ordering method. Since 8.2.7.
#wo (write order). Currently used write ordering method: b (barrier), f (flush), d (drain) or n (none). Since 8.2.7.
#oos (out of sync). Amount of storage currently out of sync; in Kibibytes. Since 8.2.6.
#
#------------------------------------------------------------------
# CONECTION STATE (CS) - drbdadm cstate resource
#------------------------------------------------------------------
# StandAlone. No network configuration available. The resource has not yet been connected, or has been administratively disconnected (using drbdadm disconnect), 
#             or has dropped its connection due to failed authentication or split brain.
#Disconnecting.  Temporary state during disconnection. The next state is StandAlone.
#Unconnected.  Temporary state, prior to a connection attempt. Possible next states: WFConnection and WFReportParams.
#Timeout. Temporary state following a timeout in the communication with the peer. Next state: Unconnected.
#BrokenPipe. Temporary state after the connection to the peer was lost. Next state: Unconnected.
#NetworkFailure. Temporary state after the connection to the partner was lost. Next state: Unconnected.
#ProtocolError. Temporary state after the connection to the partner was lost. Next state: Unconnected.
#TearDown. Temporary state. The peer is closing the connection. Next state: Unconnected.
#WFConnection. This node is waiting until the peer node becomes visible on the network. 
#WFReportParams. TCP connection has been established, this node waits for the first network packet from the peer.
#Connected. A DRBD connection has been established, data mirroring is now active. This is the normal state.
#StartingSyncS. Full synchronization, initiated by the administrator, is just starting. The next possible states are: SyncSource or PausedSyncS.
#StartingSyncT. Full synchronization, initiated by the administrator, is just starting. Next state: WFSyncUUID.
#WFBitMapS. Partial synchronization is just starting. Next possible states: SyncSource or PausedSyncS.
#WFBitMapT. Partial synchronization is just starting. Next possible state: WFSyncUUID.
#WFSyncUUID. Synchronization is about to begin. Next possible states: SyncTarget or PausedSyncT.
#SyncSource. Synchronization is currently running, with the local node being the source of synchronization.
#SyncTarget. Synchronization is currently running, with the local node being the target of synchronization.
#PausedSyncS. The local node is the source of an ongoing synchronization, but synchronization is currently paused. 
#             This may be due to a dependency on the completion of another synchronization process, or due to synchronization having been i
#			 manually interrupted by drbdadm pause-sync.
#PausedSyncT. The local node is the target of an ongoing synchronization, but synchronization is currently paused. 
#             This may be due to a dependency on the completion of another synchronization process, or due to synchronization having been manually interrupted 
#			 by drbdadm pause-sync.
#VerifyS. On-line device verification is currently running, with the local node being the source of verification.
#VerifyT. On-line device verification is currently running, with the local node being the target of verification.
#
#---------------------------------------------------------------------
# HIERARQUIA - ROLE (RO) - drbdadm role resource
#--------------------------------------------------------------------
#Primary. The resource is currently in the primary role, and may be read from and written to. 
#         This role only occurs on one of the two nodes, unless dual-primary node  is enabled
#Secondary. The resource is currently in the secondary role. It normally receives updates from its peer (unless running in disconnected mode), 
#           but may neither be read from nor written to. This role may occur on one node or both nodes.
#Unknown. The resource's role is currently unknown. The local resource role never has this status. 
#         It is only displayed for the peer's resource role, and only in disconnected mode.
#
#------------------------------------------------------------------
# ESTADO DO DISCO - DISK STATE (DS) - drbdadm dstate resource
#------------------------------------------------------------------
#Diskless. No local block device has been assigned to the DRBD driver. 
#           This may mean that the resource has never attached to its backing device, that it has been manually detached using drbdadm detach, 
#		   or that it automatically detached after a lower-level I/O error.
#Attaching. Transient state while reading meta data.
#Failed. Transient state following an I/O failure report by the local block device. Next state: Diskless.
#Negotiating. Transient state when an Attach is carried out on an already-connected DRBD device.
#Inconsistent. The data is inconsistent. This status occurs immediately upon creation of a new resource, on both nodes (before the initial full sync). 
#              Also, this status is found in one node (the synchronization target) during synchronization. 
#DUnknown. This state is used for the peer disk if no network connection is available.
#Consistent. Consistent data of a node without connection. When the connection is established, it is decided whether the data are UpToDate or Outdated.
#UpToDate. Consistent, up-to-date state of the data. This is the normal state.
#

#==================================================================
#   FUNCAO - GRAVA_LOG
#
#   OBJETIVO - GRAVACAO DE LOG NO ARQUIVO /VAR/LOG/CLUSTER.LOG
#==================================================================
grava_log()
{
    echo -e "$(date '+%F %T') $MODULO - $MSG" >> $ARQ_LOG
}

#==================================================================
#   FUNCAO - START
#
#   OBJETIVO - CARREGA O MODULO DRDB E ATIVA A EXECUCAO DO SERVICO
#              DEIXANDO O NOH NO ESTADO SECUNDARIO
#==================================================================
start()
{

#--------------------------------------------
#             Cabecalho de LOG
#-------------------------------------------- 

    MGS="\n\n";grava_log
    MSG="$(uname -n) - $(date) - START - ### INICIANDO START DO DRBD  ###";grava_log
    MSG="\n\n";grava_log

#--------------------------------------------
#            Carga do modulo - DRBD
#-------------------------------------------- 

    MSG="$(uname -n) - $(date) - START - Carregando modulos DRBD";grava_log

    lsmod | grep -v grep | grep drbd > /dev/null

    if [ $? -eq 1 ]
    then
           /sbin/modprobe drbd > /dev/null
           lsmod | grep -v grep | grep drbd > /dev/null
           if [ $? -eq 1 ]
           then
                   MSG="$(uname -n) - $(date) - START - ERRO DE CARGA DO MODULO DRBD";grava_log
                   exit 1
		   else
                   MSG="$(uname -n) - $(date) - START - Modulo DRBD Carregado com Sucesso";grava_log
           fi
    else
           MSG="$(uname -n) - $(date) - START - Modulos do DRBD jah estao carregados";grava_log
    fi

#-----------------------------------------------
#              Inicializa o DRBD
#----------------------------------------------- 

    MSG="$(uname -n) - $(date) - START - Inicializando os servico DRBD";grava_log

    #-------------------------------------------
    #    Executa tres tentativa de iniciar
    #    o DRBD com intervalo de um segundo
    #    entre cada tentativa, apos exceder
    #    o numero maximo, o script e encerrado 
    #    com erro
    #-------------------------------------------
    cont=0
    while true
    do
		 cat /proc/drbd | grep -v grep | grep cs: > /dev/null

		 if [ $? -eq 1 ]
		 then
                         /sbin/drbdadm up all > /dev/null
                         if [ $? -eq 0 ]
                         then
                                   MSG="$(uname -n) - $(date) - START - Servico DRBD inicializado com sucesso !!!!";grava_log
                                   break
                         else
	                           if [ $cont -gt 3 ]
                                   then
                                             MSG="$(uname -n) - $(date) - START - Falha geral na inicializado do servico DRBD";grava_log
                                             exit 1
                                   else
                                             MSG="$(uname -n) - $(date) - START - DRBD FALHA INICIALIZACAO - $cont";grava_log
                                             cont=$(expr $cont + 1)
                                             MSG="$(uname -n) - $(date) - START - CAT /PROC/DRBD";grava_log
		                             MSG="$(cat /proc/drbd)";grava_log
                                             sleep 1
                                   fi
                         fi
		 else
                          MSG="$(uname -n) - $(date) - START - DRBD JAH estah inicializado !!!!";grava_log
			  break
                 fi
    done

    MSG="\n\n";grava_log
           
}

#==================================================================
#   FUNCAO - STOP
#
#   OBJETIVO - ENCERRAMENTO DO SERVICO DRDB
#              1-ENCERRA A EXECUCAO DO BANCO DE DADOS
#              2-DESMONTA SISTEMA DE ARQUIVOS
#              3-COLOCA O NOH COMO SECUNDARIO
#              4-ENCERRA O SERVICO DRBD
#              5-REMOVE O MODULO DA MEMORIA
#==================================================================
stop()
{
    #--------------------------------------------
    #             Cabecalho de LOG
    #-------------------------------------------- 

    MSG="\n\n";grava_log
    MSG="$(uname -n) - $(date) - STOP - ### STOP DO DRBD  ###";grava_log
    MSG="\n\n";grava_log

    #-----------------------------------------------------
    #      DESMONTANDO SISTEMA DE ARQUIVOS /DEV/DRBD0
    #-----------------------------------------------------
    MSG="$(uname -n) - $(date) - STOP - Desmontando Sistema de Arquivo /dev/drbd0";grava_log
    mount | grep -v grep | grep $DEVICE_DRBD > /dev/null

    if  [ $? -eq 0 ]
    then
          umount $DEVICE_DRBD > /dev/null
          if  [ $? -eq 0 ]
          then
                  MSG="$(uname -n) - $(date) - STOP -Sistema de Arquivo $DEVICE_DRBD foi desmontado com sucesso";grava_log
	  else
                  MSG="$(uname -n) - $(date) - STOP - Problemas na Desmontagem do Sistema de Arquivo $DEVICE_DRBD";grava_log
	  fi
    fi

    #-----------------------------------------------------
    #      Encerranento do DRBD
    #-----------------------------------------------------
    MSG="$(uname -n) - $(date) - STOP - Finalizando execucao do DRBD";grava_log
    
    if [ -f /proc/drbd ]
    then
          MSG="$(uname -n) - $(date) - STOP - Colocando cluster em modo secundario";grava_log
          drbdadm secondary all
          if  [ $? -eq 0 ]
          then
                  MSG="$(uname -n) - $(date) - STOP - O Sistema foi colocado em modo SECONDARY";grava_log
	  else
                  MSG="$(uname -n) - $(date) - STOP - Nao foi possivel colocar o sistema em modo SECONDARY";grava_log
	  fi
          MSG="$(uname -n) - $(date) - STOP - Desabilitando DRBD";grava_log
          drbdadm down all
          if  [ $? -eq 0 ]
          then
                  MSG="$(uname -n) - $(date) - STOP - DRBD foi desabilitado com sucesso";grava_log
	  else
                  MSG="$(uname -n) - $(date) - STOP - NAO foi possivel desabilitar o DRBD";grava_log
	  fi
          MSG="$(uname -n) - $(date) - STOP - Removendo modulos do DRBD";grava_log
          rmmod drbd
          if  [ $? -eq 0 ]
          then
                  MSG="$(uname -n) - $(date) - STOP - Os modulos do DRBD foram removidos com sucesso";grava_log
	  else
                  MSG="$(uname -n) - $(date) - STOP - Os modulos do DRBD NAO foram removidos";grava_log
	  fi
    fi
   
}

#==================================================================
#   FUNCAO - PRIMARY
#
#   OBJETIVO - COLOCA O NOH EM MODO PRIMARY
#
#              1-ENTRA EM MODO PRIMARY
#              2-MONTA SISTEMAS DE ARQUIVOS
#              3-COLOCA O POSTGRES EM EXECUCAO
#
#==================================================================
primary()
{

    #--------------------------------------------
    #             Cabecalho de LOG
    #-------------------------------------------- 

    MSG="\n\n";grava_log
    MSG="$(uname -n) - $(date) - PRIMARY - ### ENTRANDO EM MODO PRIMARY  ###";grava_log
    MSG="\n\n";grava_log

    #--------------------------------------------------------
    #        Verifica se o modulo DRBD esta carregado
    #--------------------------------------------------------
    lsmod | grep -v grep | grep drbd > /dev/null

    if [ $? -eq 1 ]
    then
          MSG="$(uname -n) - $(date) - PRIMARY - Modulo DRBD nao esta carregado";grava_log 
          MSG="$(uname -n) - $(date) - PRIMARY - Carregando Modulo";grava_log 
          start
    fi

    #-----------------------------------------------------------------
    #     Antes de entrar em modo "Primary" eh necessario que 
    #     que o estado do DRBD esteja seguro.
    #     O estado seguro eh caracterizado pela seguintes condicoes:
    #     - duas maquinas em execucao
    #     - Estado da Conexao do Cluster- "Connected" (CS)
    #     - Situacao dos discos - "UpToDate/UpToDate" (DS)
    #     - Hierarquia dos noh do Cluster - "Secondary/Secondary" (RO)
    #    
    #     Se existir apenas uma maquina em execucao, esta pode entrar
    #     diretamente no estado Primary
    #------------------------------------------------------------------
    #    
    #     O software de disponibilidade UCARP pode produzir algumas 
    #     instabilidades no ambiente no momento que ele esta 
    #     entrando em execucao, assim, antes de entrar em modo Primary
    #     sera realizado um laco infinito para verificar a condicao de seguranca.
    #     Se obtivermos 3 verificacoes sucessivas com sucesso com intervalo de 
    #     1 segundo, eh considerado um estado seguro. Se nao ocorrer um estado seguro
    #     com 50 tentativa, a operacao de entrada em modo Primary sera cancelado
    #----------------------------------------------------------------------------------
    MSG="$(uname -n) - $(date) - PRIMARY - INICIANDO LOOP PARA ENCONTRAR ESTADO SEGURO PARA ENTRAR EM MODO PRIMARY";grava_log 
    cont=0
    cont1=0
    while true 
    do
           MSG="$(uname -n) - $(date) - PRIMARY - PROCURANDO ESTADO SEGURO ANTES DE INICIAR MIGRACAO";grava_log 
           if [ $LOCALHOST = $HOST_MASTER ]
           then
                  ping -c 2 -w 2 $IP_HOSTSLAVE > /dev/null
           else
                  ping -c 2 -w 2 $IP_HOSTMASTER > /dev/null
           fi

           ST_PING=$?
           STATEDS_LOCAL=$(drbdadm dstate all | cut -d \/ -f 1)   #Estado Local (DS)
           STATEDS_REMOTO=$(drbdadm dstate all | cut -d \/ -f 2)  #Estado Remoto (DS)
           STATECS_CONEXAO=$(drbdadm cstate all )  #Estado da conexao (CS)
           STATERO_LOCAL=$(drbdadm state all | cut -d \/ -f 1)   #Estado Local (RO)
           STATERO_REMOTO=$(drbdadm state all | cut -d \/ -f 2)  #Estado Remoto (RO)


           if [ $STATECS_CONEXAO = "StandAlone" ]
           then
                   MSG="$(uname -n) - $(date) - PRIMARY - NOH EM MODO STANDALONE, NECESSIDADE DE INTERVENCAO MANUAL ";grava_log
                   MSG="$(uname -n) - $(date) - PRIMARY - PROCESSO INTERROMPIDO";grava_log
		   exit 1
	   fi

           MSG="$(uname -n) - $(date) - $STATECS_CONEXAO = Connected? - $STATEDS_LOCAL = UpToDate? - $STATEDS_REMOTO = UpToDate? - $STATERO_REMOTO = Secondary?";grava_log

           if [ $ST_PING -eq 0 -a $STATECS_CONEXAO = "Connected" ] #---> Os dois hosts estao em execucao e drbd ativo nos hosts
           then
                   if [ $STATEDS_LOCAL = "UpToDate" -a $STATEDS_REMOTO = "UpToDate" -a $STATERO_REMOTO = "Secondary" ] #--> Situacao Ideal de Conexao
                   then
                           cont=$(expr $cont + 1)
                           if [ $cont -gt 3 ] #--> Foi verificado tres vezes consecutivas, entao o estado eh estavel
                           then
                                   MSG="$(uname -n) - $(date) - PRIMARY - SITUACAO IDEAL ESTAVEL E REALIZANDO CHAVEAMENTO";grava_log
                                   break
                           fi
                           MSG="$(uname -n) - $(date) - PRIMARY - SITUACAO IDEAL ENCONTRADO - $cont";grava_log
                           cont1=0
                           sleep 1
                   else
                           MSG="$(uname -n) - $(date) - PRIMARY - ESPERANDO SITUACAO IDEAL CONNECTED/UPDATE/UPDATE .. $cont1";grava_log
                           sleep 1
                           cont=0
                           cont1=$(expr $cont1 + 1)
                           if [ $cont1 -gt $MAX_TIMEOUT ] #--> Tempo maximo de espera foi esgotado,provalvelmente remoto estah em modo primary
                           then
                                  MSG="===========================================================";grava_log
                                  MSG="$(uname -n) - $(date) - PRIMARY - RESUMO";grava_log
                                  MSG="$(uname -n) - $(date) - PRIMARY - TIMEOUT - OPERACAO PRIMARY CANCELADO";grava_log
                                  MSG="$(uname -n) - $(date) - PRIMARY - NAO FOI ENCONTRADO A SITUACAO IDEAL PARA ENTRAR EM MODO PRIMARY";grava_log
                                  MSG="$(uname -n) - $(date) - PRIMARY - ESTADO DA CONEXAO: $STATECS_CONEXAO";grava_log
                                  MSG="$(uname -n) - $(date) - PRIMARY - POSICAO HIERARQUIA LOCAL: $STATERO_LOCAL";grava_log
                                  MSG="$(uname -n) - $(date) - PRIMARY - POSICAO HIERARQUIA REMOTA: $STATERO_REMOTO";grava_log
                                  MSG="$(uname -n) - $(date) - PRIMARY - ESTADO DO DISCO LOCAL: $STATEDS_LOCAL";grava_log
                                  MSG="$(uname -n) - $(date) - PRIMARY - ESTADO DO DISCO REMOTO: $STATEDS_REMOTO";grava_log
                                  exit 1
                         fi
                   fi
           else
                   MSG="$(uname -n) - $(date) - PRIMARY - HOST REMOTO ESTA INATINGIVEL ATRAVES DO PING OU O ESTADO DA CONEXAO NAO EH CONNECTED";grava_log
                   if [ $ST_PING -ne 0  -a $STATECS_CONEXAO = "WFConnection" ] #--> host remoto nao estah em execucao
                   then
                          MSG="$(uname -n) - $(date) - PRIMARY - CONEXAO NO ESTADO: $STATECS_CONEXAO";grava_log
                          MSG="$(uname -n) - $(date) - PRIMARY - ESTADO DO DISCO: $STATEDS_LOCAL";grava_log
                          MSG="$(uname -n) - $(date) - PRIMARY - ENCERRANDO LOOP";grava_log
                          break
                   else
                          if [ $STATECS_CONEXAO = "SyncSource" -o $STATECS_CONEXAO = "SyncTarget" ] #--> Sincronizacao ocorrendo
                          then
                                 if [ $ST_PING -ne 0 -a $STATERO_REMOTO = "Unknown" ]
                                 then
                                        MSG="$(uname -n) - $(date) - PRIMARY - CONEXAO EM MODO DE SINCRONIZACAO: $STATECS_CONEXAO";grava_log
                                        MSG="$(uname -n) - $(date) - PRIMARY - CONEXAO NO ESTADO: $STATECS_CONEXAO";grava_log
                                        MSG="$(uname -n) - $(date) - PRIMARY - ESTADO HIERARQUICO DO REMOTO: $STATERO_REMOTO";grava_log
                                        MSG="$(uname -n) - $(date) - PRIMARY - ENCERRANDO LOOP";grava_log
                                        break
                                 fi
                                 if [ $ST_PING -eq 0 -a $STATERO_REMOTO = "Secondary" ]
                                 then
                                        MSG="$(uname -n) - $(date) - PRIMARY - CONEXAO EM MODO DE SINCRONIZACAO: $STATECS_CONEXAO";grava_log
                                        MSG="$(uname -n) - $(date) - PRIMARY - CONEXAO NO ESTADO: $STATECS_CONEXAO";grava_log
                                        MSG="$(uname -n) - $(date) - PRIMARY - ESTADO HIERARQUICO DO REMOTO: $STATERO_REMOTO";grava_log
                                        MSG="$(uname -n) - $(date) - PRIMARY - ENCERRANDO LOOP";grava_log
                                        break
				fi
                                MSG="$(uname -n) - $(date) - PRIMARY - CONEXAO EM MODO DE SINCRONIZACAO COM SITUACAO INDEFINIDA !!!";grava_log
			  else
                                MSG="$(uname -n) - $(date) - PRIMARY - ESPERANDO SITUACAO IDEAL ATUALMENTE: $STATECS_CONEXAO.. $cont1";grava_log
                                MSG="$(uname -n) - $(date) - PRIMARY - POSICAO HIERARQUIA LOCAL: $STATERO_LOCAL";grava_log
                                MSG="$(uname -n) - $(date) - PRIMARY - POSICAO HIERARQUIA REMOTA: $STATERO_REMOTO";grava_log
                                MSG="$(uname -n) - $(date) - PRIMARY - ESTADO DO DISCO LOCAL: $STATEDS_LOCAL";grava_log
                                MSG="$(uname -n) - $(date) - PRIMARY - ESTADO DO DISCO REMOTO: $STATEDS_REMOTO";grava_log
                                MSG="$(uname -n) - $(date) - PRIMARY - AGUARDANDO MAIS $(expr $MAX_TIMEOUT - $cont1) segundos";grava_log
                                sleep 1
                                cont=0
                                cont1=$(expr $cont1 + 1)
                                if [ $cont1 -gt $MAX_TIMEOUT ]
                                then
                                       MSG="$(uname -n) - $(date) - PRIMARY - TIMEOUT - OPERACAO PRIMARY CANCELADO";grava_log
                                       MSG="$(uname -n) - $(date) - PRIMARY - NAO FOI ENCONTRADO A SITUACAO IDEAL PARA ENTRAR EM MODO PRIMARY";grava_log
                                       MSG="$(uname -n) - $(date) - PRIMARY - ESTADO DA CONEXAO: $STATECS_CONEXAO";grava_log
                                       MSG="$(uname -n) - $(date) - PRIMARY - POSICAO HIERARQUIA LOCAL: $STATERO_LOCAL";grava_log
                                       MSG="$(uname -n) - $(date) - PRIMARY - POSICAO HIERARQUIA REMOTA: $STATERO_REMOTO";grava_log
                                       MSG="$(uname -n) - $(date) - PRIMARY - ESTADO DO DISCO LOCAL: $STATEDS_LOCAL";grava_log
                                       MSG="$(uname -n) - $(date) - PRIMARY - ESTADO DO DISCO REMOTO: $STATEDS_REMOTO";grava_log
                                       exit 1
                                fi
                         fi
		   fi
           fi
    done

    #-------------------------------------------------------
    #        Verifica o estado atual de cada NO
    #-------------------------------------------------------

    STATERO_LOCAL=$(drbdadm state all | cut -d \/ -f 1)   #Estado Local
    STATERO_REMOTO=$(drbdadm state all | cut -d \/ -f 2)  #Estado Remoto
    STATECS_CONEXAO=$(drbdadm cstate all | cut -d \/ -f 2)  #Estado Remoto
    STATEDS_LOCAL=$(drbdadm dstate all | cut -d \/ -f 1)   #Estado Local (DS)
    STATEDS_REMOTO=$(drbdadm dstate all | cut -d \/ -f 2)  #Estado Remoto (DS)

    if [ $STATERO_LOCAL == "Primary" ]
    then
          MSG="$(uname -n) - $(date) - PRIMARY - O Servidor atual ja atua como PRIMARY";grava_log
    else
          MSG="$(uname -n) - $(date) - PRIMARY - O Servidor entrando em modo  PRIMARY";grava_log
           #--------------------------------#
	       #   Entrando em modo Primary     #
	       #--------------------------------#
            /sbin/drbdadm primary all
            if [ $? -ne 0 ]
            then
                    x=$(cat /proc/drbd)
                    MSG="$(uname -n) - $(date) - PRIMARY - O Servidor nao conseguiu entrar em modo PRIMARY - $x";grava_log
                    exit 1	        
	    else
                    MSG="$(uname -n) - $(date) - PRIMARY - O Servidor entrou em modo PRIMARY com SUCESSO";grava_log
            fi
    fi
           #--------------------------------------------------------
           #     Montagem do sistema de arquivos
           #--------------------------------------------------------
           count=0
           while true
           do
                 #------------------------------------------------------------
                 #   Verifica se o sistema de arquivos ja esta montado
                 #------------------------------------------------------------
                 mount | grep -v grep | grep $DEVICE_DRBD > /dev/null
                 if  [ $? -eq 0 ]
                 then
                        MSG="$(uname -n) - $(date) - PRIMARY - Sistemas de arquivo /dev/drbd0 ja esta montado ...";grava_log
                        break
		 fi

                 x=$(cat /proc/drbd)
                 mount $DEVICE_DRBD $MOUNT_DRBD > /dev/null 2>&1
                 mount | grep -v grep | grep $DEVICE_DRBD > /dev/null
                 if  [ $? -eq 0 ]
                 then
                        MSG="$(uname -n) - $(date) - PRIMARY - Sistemas de arquivo $DEVICE_DRBD montado com sucesso ...";grava_log
                        break
                 else
                        MSG="$(uname -n) - $(date) - PRIMARY - PROBLEMAS NA MONTAGEM DO SISTEMAS DE ARQUIVO /DEV/DRBD0 - $count, $x";grava_log
                        sleep 1
                 fi
                 count=$(expr $count + 1)
                 STATE=$(drbdadm state all | cut -d \/ -f 1)   #Estado Local
                 if [ $count -gt 180 -a $STATE == "Primary" ]
                 then
                       MSG="$(uname -n) - $(date) - PRIMARY - ESGOTADO O NUMERO DE TENTATIVA DE MONTAGEM DO FILESYSTEM, PROCEDIMENTO ENCERRADO";grava_log
                       exit 1
                 fi
           done

           #------------------------------------------------------
           #     MOSTRA RESUMO DA OPERACAO
           #------------------------------------------------------
	   STATECS_CONEXAO=$(drbdadm cstate all | cut -d \/ -f 2)  #Estado Remoto 
	   STATERO_LOCAL=$( drbdadm state all | cut -d \/ -f 1)
	   STATERO_REMOTO=$( drbdadm state all | cut -d \/ -f 2)
	   STATEDS_LOCAL=$(drbdadm dstate all | cut -d \/ -f 1)   #Estado Local (DS)
	   STATEDS_REMOTO=$(drbdadm dstate all | cut -d \/ -f 2)  #Estado Remoto (DS)
	   MSG="$(uname -n) - $(date) - PRIMARY - SITUACAO FINAL DE PROCEDIMENTO";grava_log
	   MSG="$(uname -n) - $(date) - PRIMARY - HIERARQUIA DO NOH LOCAL: $STATERO_LOCAL";grava_log
	   MSG="$(uname -n) - $(date) - PRIMARY - HIERARQUIA DO NOH REMOTO: $STATERO_REMOTO";grava_log
	   MSG="$(uname -n) - $(date) - PRIMARY - ESTADO DO DISCO LOCAL: $STATEDS_LOCAL";grava_log
	   MSG="$(uname -n) - $(date) - PRIMARY - ESTADO DO DISCO REMOTO: $STATEDS_REMOTO";grava_log		
	   MSG="$(uname -n) - $(date) - PRIMARY - ESTADO DA CONEXAO: $STATECS_CONEXAO";grava_log
}


#==================================================================
#   FUNCAO - SECONDARY
#
#   OBJETIVO - COLOCA O NOH EM MODO SECONDARY
#
#              1-ENCERRA EXECUCAO DO POSTGRES
#              2-DESMONTA SISTEMAS DE ARQUIVOS
#              3-COLOCA EM MODO SECONDARY
#
#==================================================================
secondary()
{

    #--------------------------------------------
    #             Cabecalho de LOG
    #-------------------------------------------- 

    MSG="\n\n";grava_log
    MSG="###### ENTRANDO EM MODO SECONDARY  ###";grava_log
    MSG="\n\n";grava_log

    #--------------------------------------------------------------------------
    #        Verifica se a opcao PRIMARY esta executando de forma concorrente
    #--------------------------------------------------------------------------
    ps aux | grep -v grep | grep primary
	if [ $? -eq 0 ]
	then
            ID_PRIMARY=$(ps aux | grep -v grep | grep -v ucarp | grep primary | awk '{print $2}')
            MSG="$(uname -n) - $(date) - SECONDARY - A opcao PRIMARY esta executando de forma concorrente com a opcao SECONDARY";grava_log
            MSG="$(uname -n) - $(date) - SECONDARY - A opcao PRIMARY esta sera encerrada de na forca bruta";grava_log
            MSG="$(uname -n) - $(date) - SECONDARY - Identificacao do processo PRIMARY: $ID_PRIMARY";grava_log
            kill -9 $ID_PRIMARY
	fi

    #--------------------------------------------------------
    #        Verifica se o modulo DRBD esta carregado
    #--------------------------------------------------------
    lsmod | grep -v grep | grep $DEVICE_DRBD > /dev/null
		    
    if [ $? -eq 1 ]
    then
          MSG="$(uname -n) - $(date) - SECONDARY - Modulo DRBD nao esta carregado";grava_log
          MSG="$(uname -n) - $(date) - SECONDARY - Carregando Modulo DRBD";grava_log
          start
    fi

    #---------------------------------------------------------
    #       Verifica o estado atual do NOH local
    #---------------------------------------------------------

    MSG="$(uname -n) - $(date) - SECONDARY - Verificando Posicao Hierarquica do NOH local";grava_log
    STATE_RO=$( drbdadm state all | cut -d \/ -f 1)
    MSG="$(uname -n) - $(date) - SECONDARY - A posicao do NOH eh: $STATE_RO";grava_log

    #-----------------------------------------------------
    #      Encerramento do OPENSIPS
    #-----------------------------------------------------
    MSG="$(uname -n) - $(date) - SECONDARY - Encerrando OPENSIPS";grava_log

    ps aux | grep -v grep | grep opensips
    if [ $? -eq 0 ]
    then
           /usr/local/sbin/opensipsctl stop
           sleep 2
    fi
    
    #-----------------------------------------------------
    #      DESMONTANDO SISTEMA DE ARQUIVOS /DEV/DRBD0
    #-----------------------------------------------------
    MSG="$(uname -n) - $(date) - SECONDARY - Verificando Sistemas de Arquivos";grava_log
    mount | grep -v grep | grep $DEVICE_DRBD > /dev/null

    if  [ $? -eq 0 ]
    then
          MSG="$(uname -n) - $(date) - SECONDARY - Desmontando Sistema de Arquivo $DEVICE_DRBD";grava_log
          umount $DEVICE_DRBD
          if  [ $? -eq 0 ]
          then
                  MSG="$(uname -n) - $(date) - SECONDARY - Sistema de Arquivo $DEVICE_DRBD foi desmontado com sucesso";grava_log
	  else
                  MSG="$(uname -n) - $(date) - SECONDARY - PROBLEMAS na desmontagem do sistemas de arquivo $DEVICE_DRBD";grava_log
	  fi
    else
          MSG="$(uname -n) - $(date) - SECONDARY - Sistema de Arquivos  $DEVICE_DRBD nao esta montado";grava_log
    fi

    #----------------------------------------------------
    #        COLOCA O NOH ATUAL COMO SECUNDARIO
    #----------------------------------------------------
    MSG="$(uname -n) - $(date) - SECONDARY - Verificando posicao hierarquica do Noh Local";grava_log
    if [ $STATE_RO == "Secondary" ]
    then
           MSG="$(uname -n) - $(date) - SECONDARY - O Servidor atual ja atua como SECONDARY";grava_log
    else
           MSG="$(uname -n) - $(date) - SECONDARY - Colocando NOH em modo Secondary";grava_log
           /sbin/drbdadm secondary all
           if  [ $? -eq 0 ]
           then
                    MSG="$(uname -n) - $(date) - SECONDARY - O NOH local foi colocado em modo SECONDARY";grava_log
	   else
                    MSG="$(uname -n) - $(date) - SECONDARY - Problemas ... O NOH local NAO foi colocado em modo SECONDARY";grava_log
	   fi
     fi

     #------------------------------------------------------
     #     MOSTRA RESUMO DA OPERACAO
     #------------------------------------------------------
    STATECS_CONEXAO=$(drbdadm cstate all | cut -d \/ -f 2)  #Estado Remoto 
    STATERO_LOCAL=$( drbdadm state all | cut -d \/ -f 1)
    STATERO_REMOTO=$( drbdadm state all | cut -d \/ -f 2)
    STATEDS_LOCAL=$(drbdadm dstate all | cut -d \/ -f 1)   #Estado Local (DS)
    STATEDS_REMOTO=$(drbdadm dstate all | cut -d \/ -f 2)  #Estado Remoto (DS)
    MSG="$(uname -n) - $(date) - SECONDARY - SITUACAO FINAL DE PROCEDIMENTO";grava_log
    MSG="$(uname -n) - $(date) - SECONDARY - HIERARQUIA DO NOH LOCAL: $STATERO_LOCAL";grava_log
    MSG="$(uname -n) - $(date) - SECONDARY - HIERARQUIA DO NOH REMOTO: $STATERO_REMOTO";grava_log
    MSG="$(uname -n) - $(date) - SECONDARY - ESTADO DO DISCO LOCAL: $STATEDS_LOCAL";grava_log
    MSG="$(uname -n) - $(date) - SECONDARY - ESTADO DO DISCO REMOTO: $STATEDS_REMOTO";grava_log
    MSG="$(uname -n) - $(date) - SECONDARY - ESTADO DA CONEXAO: $STATECS_CONEXAO";grava_log
}

#==================================================================
#   FUNCAO - SYNC
#
#   OBJETIVO - MOSTRA O STATUS DO CLUSTER ATRAVES DO ARQUIVO
#              /PROC/DRBD
#==================================================================
sync()
{
      clear

      if [ -f /proc/drbd ]
      then
	        echo "Pressione CTRL+C para encerrar o monitoramento"
            watch -n 2 cat /proc/drbd 
      else
            MSG="O SISTEMA DRBD NO ESTA ATIVO NO MOMENTO";grava_log
      fi
}

#==================================================================
#   FUNCAO - CREATE_DEVICE
#
#   OBJETIVO - CRIACAO DO DEVICE /DEV/DRBD0
#
#==================================================================
create_device()
{
      clear

      echo "ATENCAO ... ATENCAO ... ATENCAO ... ATENCAO .... ATENCAO ..."
      echo "PERIGO ...  PERIGO ...  PERIGO ...  PERIGO ...   PERIGO ..."
      echo -e "\n\n"
      echo "ESTE PROCEDIMENTO IRA CRIAR UM NOVO DEVICE PARA O CLUSTER"
      echo "TODOS OS DADOS PRESENTES NO DISCO DESTE HOSTS SERA PERDIDO"
      echo "NAO EXECUTE ESTA FUNCAO, A NAO SER QUE SAIBA REALMENTE O QUE ESTA FAZENDO !!!!!"
      echo -e "\n"
      echo "OBSERVACOES E PROCEDIMENTO MANUAIS NECESSARIOS"
	  echo "APOS A CRIACAO DO DEVICE DRBD0, O ESTADO DO DISCO FICARA EM DS:Inconsistent"
      echo "A SINCRONIZACAO OCORRERA AUTOMATICAMENTE SE O ESTADO COM O NOH REMOTO ESTIVER CS=CONNECTED"
      echo "SE O NOH REMOTO ESTIVER EM MODO CS=STANDALONE ENTAO SERA NECESSARIO EMITIR NO NOH REMOTO O SEGUINTE COMANDO: drbdadm connect all"
      echo "A PARTIR DESTE MOMENTO, OS DOIS NOHS ENTRARAO NO MODO CS=CONNECTED E A SINCRONIZACAO COMECARA A OCORRER"
      echo -e "\n\n"
      echo -n "VOCE DESEJA PROSSEGUIR REALMENTE ? (S/N) "
      read resp

      if [ $resp == "s" -o $resp == "S" ]
      then
           echo -e "\n\n"
           echo "INICIANDO PROCEDIMENTO ..."
           echo -e "\n\n"
      else
           echo -e "\n\n"
           echo "PROCEDIMENTO ENCERRADO ..."
		   exit 1
      fi

      #---------------------------------------------------------
      #    REMOVENDO DRBD PARA CRIAR O NOVO DEVICE
      #---------------------------------------------------------
      if [ -f /proc/drbd ]
      then
            stop 
            MSG="ENCERRANDO DRBD .....";grava_log
      fi

      #---------------------------------------------------------
      #    GERA ARQUIVO DE RESPOSTA AUTOMATICA PARA DRBDADM
      #---------------------------------------------------------
      echo "yes" > /tmp/yes.txt
	  echo "yes" >> /tmp/yes.txt

      #---------------------------------------------------------
      #    CRIA O DEVICE DRBD0
      #---------------------------------------------------------
      drbdadm create-md drbd0 < /tmp/yes.txt

      #---------------------------------------------------------
      #    INICIA NOVAMENTE O DRBD
      #---------------------------------------------------------
      start
}

#==================================================================
#   FUNCAO - INITIALIZE_HD
#
#   OBJETIVO - GRAVACAO DE ZEROS BINARIOS EM UMA PARTICAO DO HD
#
#==================================================================
initialize_hd()
{
    #-------------------------------------------------------
    #    Inicializa uma particao com zero binario
    #
    #    $2 = /dev/sdb1
    #    $3 = 2000000 (2 GB)
	#   
    #-------------------------------------------------------
      clear

      echo "ATENCAO ... ATENCAO ... ATENCAO ... ATENCAO .... ATENCAO ..."
      echo "PERIGO ...  PERIGO ...  PERIGO ...  PERIGO ...   PERIGO ..."
      echo -e "\n\n"
      echo "ESTE PROCEDIMENTO IRA GRAVAR ZEROS BINARIO NO DEVICE $DEVICE"
      echo "TODOS OS DADOS PRESENTES NO DEVICE $DEVICE SERA PERDIDO"
      echo "NAO EXECUTE ESTA FUNCAO, A NAO SER QUE SAIBA REALMENTE O QUE ESTA FAZENDO"
      echo -e "\n\n"
      echo -n "VOCE DESEJA PROSSEGUIR REALMENTE ? (S/N) "
      read resp

      if [ $resp == "s" -o $resp == "S" ]
      then
           echo -e "\n\n"
           echo "INICIANDO PROCEDIMENTO ..."
           echo -e "\n\n"
      else
           echo -e "\n\n"
           echo "PROCEDIMENTO ENCERRADO ..."
		   exit 1
      fi

      mount | grep -v grep | grep drbd0 > /dev/null

      if [ $? -eq -0 ]
      then
            stop 
            MSG="ENCERRANDO DRBD .....";grava_log
      fi

    #-------------------------------------------------------
    #    Inicializa uma particao com zero binario
    #-------------------------------------------------------
      dd if=/dev/zero of=$DEVICE bs=1024 count=$TAMANHO
}

#==================================================================
#   FUNCAO - INITIAL_DEVICE_SINCRONIZATION
#
#   OBJETIVO - EXECUTAR A SINCRONIZACAO INICIAL DE UM DISCO EM CLUSTER
#
#==================================================================
initial_device_sincronization()
{
      clear

      echo "ATENCAO ... ATENCAO ... ATENCAO ... ATENCAO .... ATENCAO ..."
      echo "PERIGO ...  PERIGO ...  PERIGO ...  PERIGO ...   PERIGO ..."
      echo -e "\n\n"
      echo "ESTE PROCEDIMENTO IRA INICIAR A SINCRONIZACAO DO CLUSTER E DEVE SER EXECUTADO NA PRIMEIRA INICIALIZACAO DO CLUSTER"
      echo "O ESTADO DA CONEXAO DEVE ESTAR CS:CONNECT, RO:SECONDARY/SECONDARY E DS:INCONSISTENT/INCONSISTENT"
      echo "A FONTE DE SINCRONIZACAO SERA O HOST LOCAL - $(uname -n | tr 'a-z' 'A-Z')"
      echo "NAO EXECUTE ESTA FUNCAO, A NAO SER QUE SAIBA REALMENTE O QUE ESTA FAZENDO !!!"
      echo -e "\n\n"
      echo -n "VOCE DESEJA PROSSEGUIR REALMENTE ? (S/N) "
      read resp

      if [ $resp == "s" -o $resp == "S" ]
      then
           echo -e "\n\n"
           echo "INICIANDO PROCEDIMENTO ..."
           echo -e "\n\n"
      else
           echo -e "\n\n"
           echo "PROCEDIMENTO ENCERRADO ..."
		   exit 1
      fi

    if [ ! -f /proc/drbd ]
    then
	      start
		  sleep 2
	fi

    STATERO_LOCAL=$(drbdadm state all | cut -d \/ -f 1)   #Estado Local Primary/Secondary
    STATERO_REMOTO=$(drbdadm state all | cut -d \/ -f 2)  #Estado Remoto Primary/Secondary
    STATECS_CONEXAO=$(drbdadm cstate all | cut -d \/ -f 2)  #Estado Remoto Connected
    STATEDS_LOCAL=$(drbdadm dstate all | cut -d \/ -f 1)   #Estado Local Inconsistent/Inconsistent
    STATEDS_REMOTO=$(drbdadm dstate all | cut -d \/ -f 2)  #Estado Remoto Inconsistent/Inconsistent

    if [ $STATERO_LOCAL = "Secondary" -a $STATERO_REMOTO = "Secondary" -a $STATECS_CONEXAO = "Connected" -a $STATEDS_LOCAL = "Inconsistent" -a $STATEDS_REMOTO = "Inconsistent" ]
    then
	       echo "Iniciando processo de sincronizacao ..."
	       drbdadm -- --overwrite-data-of-peer primary drbd0
               sync
    else
		   echo "O cluster nao encontra-se em estado para iniciar a sincronizacao"
		   echo "Estado da conexao do Cluster: $STATECS"
		   echo "Posicao Hierarquica do No Local: $STATERO1"
		   echo "Posicao Hierarquica do No Remoto: $STATERO2"
		   echo "Atualizacao do Disco Local: $STATEDS1"
		   echo "Atualizacao do Disco Remoto: $STATEDS2"
		   exit 1
    fi
}

#==================================================================
#   FUNCAO - CONNECT_DRBD
#
#   OBJETIVO - CONECTAR UM DEVICE A UM CLUSTER
#
#==================================================================
connect_drbd()
{
    STATECS_CONEXAO=$(drbdadm cstate all | cut -d \/ -f 2)  #Estado Remoto Connected
	if [ $STATECS_CONEXAO = "StandAlone" ]
    then
          drbdadm connect all
	else
          MSG="$(uname -n) - $(date) - CONNECT_DRBD - OPERACAO DE CONEXAO NAO FOI REALIZADA";grava_log
          MSG="$(uname -n) - $(date) - CONNECT_DRBD - A CONEXAO ESTAH NO MODO $STATECS_CONEXAO";grava_log
          echo "OPERACAO DE CONEXAO NAO FOI REALIZADA"
          echo "CONEXAO ESTAH NO MODO $STATECS_CONEXAO"
	fi
}

#==================================================================
#   FUNCAO - DISCONNECT_DRBD
#   OBJETIVO - DESCONECTAR UM DEVICE A UM CLUSTER
#
#==================================================================
disconnect_drbd()
{
    STATECS_CONEXAO=$(drbdadm cstate all | cut -d \/ -f 2)  #Estado Remoto Connected
	if [ $STATECS_CONEXAO = "Connected" ]
    then
          drbdadm disconnect all
	else
          MSG="$(uname -n) - $(date) - DISCONNECT_DRBD - OPERACAO DE DESCONEXAO NAO FOI REALIZADA";grava_log
          MSG="$(uname -n) - $(date) - DISCONNECT_DRBD - A CONEXAO ESTAH NO MODO $STATECS_CONEXAO";grava_log
          echo "OPERACAO DE DESCONEXAO NAO FOI REALIZADA"
          echo "CONEXAO ESTAH NO MODO $STATECS_CONEXAO"
	fi
}

#==================================================================
#   FUNCAO - SPLIT_BRAIN_MANUAL_RECOVERY
#   OBJETIVO - REALIZAR TRATAMENTO DE SPLIT BRAIN MANUALMENTE
#
#==================================================================
split_brain_manual_recovery()
{
	mount | grep -v grep | grep drbd
	if [ $? -eq 0 ]
	then
           MSG="$(uname -n) - $(date) - SPLIT_BRAIN_MANUAL_RECOVERY - DESMONTANDO SISTEMAS DE ARQUIVOS";grava_log
	fi

    MSG="$(uname -n) - $(date) - SPLIT_BRAIN_MANUAL_RECOVERY - DESCARTANDO MODIFICACOES E CONECTANDO COM NOH REMOTO";grava_log
	drbdadm secondary all
	drbdadm -- --discard-my-data connect all
    sleep 3
     #------------------------------------------------------
     #     MOSTRA RESUMO DA OPERACAO
     #------------------------------------------------------
    STATECS_CONEXAO=$(drbdadm cstate all | cut -d \/ -f 2)  #Estado Remoto 
    STATERO_LOCAL=$( drbdadm state all | cut -d \/ -f 1)
    STATERO_REMOTO=$( drbdadm state all | cut -d \/ -f 2)
    STATEDS_LOCAL=$(drbdadm dstate all | cut -d \/ -f 1)   #Estado Local (DS)
    STATEDS_REMOTO=$(drbdadm dstate all | cut -d \/ -f 2)  #Estado Remoto (DS)
    MSG="$(uname -n) - $(date) - SPLIT_BRAIN_MANUAL_RECOVERY - SITUACAO FINAL DE PROCEDIMENTO";grava_log
    MSG="$(uname -n) - $(date) - SPLIT_BRAIN_MANUAL_RECOVERY - HIERARQUIA DO NOH LOCAL: $STATERO_LOCAL";grava_log
    MSG="$(uname -n) - $(date) - SPLIT_BRAIN_MANUAL_RECOVERY - HIERARQUIA DO NOH REMOTO: $STATERO_REMOTO";grava_log
    MSG="$(uname -n) - $(date) - SPLIT_BRAIN_MANUAL_RECOVERY - ESTADO DO DISCO LOCAL: $STATEDS_LOCAL";grava_log
    MSG="$(uname -n) - $(date) - SPLIT_BRAIN_MANUAL_RECOVERY - ESTADO DO DISCO REMOTO: $STATEDS_REMOTO";grava_log
    MSG="$(uname -n) - $(date) - SPLIT_BRAIN_MANUAL_RECOVERY - ESTADO DA CONEXAO: $STATECS_CONEXAO";grava_log
}

#==================================================================
#   FUNCAO - SPLIT_BRAIN
#   OBJETIVO - REALIZAR TRATAMENTO DE SPLIT BRAIN
#
#==================================================================
split_brain_procedure()
{
          MSG="$(uname -n) - $(date) - SPLIT_BRAIN - OCORREU SPLIT_BRAIN";grava_log
          MSG="$(uname -n) - $(date) - SPLIT_BRAIN - OCORREU SPLIT_BRAIN";grava_log
          MSG="$(uname -n) - $(date) - SPLIT_BRAIN - OCORREU SPLIT_BRAIN";grava_log
          MSG="$(uname -n) - $(date) - SPLIT_BRAIN - OCORREU SPLIT_BRAIN";grava_log
          MSG="$(uname -n) - $(date) - SPLIT_BRAIN - OCORREU SPLIT_BRAIN";grava_log
          MSG="$(uname -n) - $(date) - SPLIT_BRAIN - OCORREU SPLIT_BRAIN";grava_log
          MSG="$(uname -n) - $(date) - SPLIT_BRAIN - OCORREU SPLIT_BRAIN";grava_log
          MSG="$(uname -n) - $(date) - SPLIT_BRAIN - OCORREU SPLIT_BRAIN";grava_log
		  
          if [ $HOST_MASTER = $LOCALHOST ]
		  then
                 MSG="$(uname -n) - $(date) - SPLIT_BRAIN - TRATANDO SPLIT_BRAIN COMO MASTER";grava_log
		  else
                 MSG="$(uname -n) - $(date) - SPLIT_BRAIN - TRATANDO SPLIT_BRAIN COMO SLAVE";grava_log
		  fi
}

#==================================================================
#   FUNCAO - DRBD_ADJUST
#   OBJETIVO - RECONFIGURAR OS RECURSOS. 
#              DEVE SER EXECUTADO TODA VEZ QUE O ARQUIVO DRBD.CONF 
#              FOR ALTERADO
#
#==================================================================
drbd_adjust()
{
	drbdadm adjust all
}


#======================================
#        Inicio do modulo principal
#======================================

LOCALHOST=$(uname -n)
MODULO="DRBD.SH"
ARQ_LOG="/var/log/cluster.log"

HOST_MASTER="Master"
HOST_SLAVE="Slave"
IP_VIRTUAL="192.168.254.237"
IP_HOSTMASTER="192.168.254.235"
IP_HOSTSLAVE="192.168.254.236"

MAX_TIMEOUT="180"
DEVICE_DRBD=/dev/drbd0
MOUNT_DRBD=/drbd0

case "$1" in
    start) start
           ;;
    stop) stop
           ;;
    restart) stop
             sleep 2
             start
           ;;
    primary) primary
           ;;
    secondary) secondary
           ;;
    sync) sync
           ;;
    stat) sync
           ;;
    create_drbd) create_device
           ;;
    init_disk)  DEVICE=$2  #ex: /dev/sdb1
	             TAMANHO=$3 #ex: 2000000 que corresponde a 2 GB
	             initialize_hd
           ;;
    init_sync)   initial_device_sincronization
           ;;
    split_brain)   split_brain_procedure
           ;;
    connect)   connect_drbd
           ;;
    adjust)   drbd_adjust 
           ;;
    disconnect)   disconnect_drbd
           ;;
    sb_manual)   split_brain_manual_recovery
           ;;
    *) echo "Opcao Invalida (start/stop/restart/primary/secondary/sync/stat/create_drbd/init_disk/init_sync/connect/disconnect/split_brain/adjust/sb_manual)"
esac


