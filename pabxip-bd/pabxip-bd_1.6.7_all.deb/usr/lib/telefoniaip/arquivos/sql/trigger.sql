

SET client_encoding = 'ISO-8859-1';
SET check_function_bodies = false;
SET client_min_messages = warning;

COMMENT ON SCHEMA public IS 'Standard public schema';

SET search_path = public, pg_catalog;
SET default_tablespace = '';
SET default_with_oids = false;

-- Triggers e Functions
CREATE LANGUAGE plpgsql;

CREATE FUNCTION tarifacdr() RETURNS "trigger" AS
$BODY$
DECLARE
	-- Para o funcionamento da trigger as rotas que serao tarifadas devem:
	-- Comecar com 1 zero  e ter o numero nos ultimos 8 digitos para chamadas locais
	-- Comecar com 2 zeros e ter o DDD+numero nos ultimos 10 digitos para chamadas DDD
	tarifa     RECORD;
	tarifaOK   INTEGER;
	valSec     FLOAT;
	result     FLOAT;
	
	lenNumDisc INTEGER;
	lensrc     INTEGER;
	horarios   RECORD;
	
	dddLocal   VARCHAR;
	dddDest    VARCHAR;
	prefLocal  VARCHAR;
	deg        INTEGER;
	vc         INTEGER;
	dest       VARCHAR;
	origem     VARCHAR;
	numero     VARCHAR;
	
	userOrig   RECORD;
	novoSaldo  FLOAT;
BEGIN
	-- buscar o DDD local
	SELECT valor INTO dddLocal FROM parametro WHERE nomeparam = 'DDDLocal';
	IF dddLocal = '' THEN
		RAISE WARNING 'DDD Local nao configurado!!! Trigger de tarifacao cancelada.';
		NEW.valor := '-1';
		return NEW;
	END IF;

--RAISE WARNING 'SRC: %', NEW.src;
	--Verifico se � chamada ENTRANTE
	IF (NEW.direcao = '1') THEN
		lensrc:= char_length(NEW.src); 
		IF lensrc = 4 THEN
			NEW.localidade := '-ENT. INTERNA-';
			NEW.tarifa     := '0';
			NEW.valor      := '0';
			return NEW;
		ELSEIF lensrc = 8 THEN   
			origem := dddLocal || substr(NEW.src, 1, 4);
 		ELSEIF lensrc = 10 THEN   
			origem := substr(NEW.src, 1, 6);
		ELSEIF lensrc=12 THEN
			IF  substr(NEW.src, 1, 2)= '55' THEN	
				origem := substr(NEW.src, 3, 6);	
			ELSE
				NEW.localidade := 'INTERNACIONAL';
				NEW.tarifa     := '0';
				NEW.valor      := '0';
				return NEW;
			END IF;
		ELSE 
			RAISE WARNING 'ORIGEM de tamanho desconhecido: %', NEW.src;
			NEW.localidade := 'DESCONHECIDO';
			NEW.tarifa     := '0';
			NEW.valor      := '0';
			return NEW;
		END IF;

		IF cast(substr(origem, 3, 1) as integer) > 5 THEN
			-- 3o digito > 5 = Celular
			NEW.localidade := 'M�VEL';
		ELSE
			-- Busca a localidade
			SELECT m.nome INTO NEW.localidade FROM prefixo p, municipio m, localidade_prefixo lp, localidade l WHERE p.prefixo = origem AND p.prefixo = cast(lp.prefixo as varchar) AND lp.codigo_cnl = l.codigo_cnl AND l.id_municipio = m.id;
		END IF;
		NEW.tarifa     := '0';
		NEW.valor      := '0';
		return NEW;
	END IF;

--RAISE WARNING 'DST: %', NEW.dst;
	-- Ajustar o numero discado para o formato XXXXXXXX (local) ou DDXXXXXXXX (DDD)
	lenNumDisc := char_length(NEW.dst);
        
	IF substr(NEW.dst, 1, 3) = '000' THEN
		-- Nao tarifa DDI
		NEW.localidade := 'DDI';
		NEW.numdisc    := substr(NEW.dst, 2, lenNumDisc - 1);
		NEW.tarifa     := '0';
		NEW.valor      := '0';
		return NEW;
	ELSEIF substr(NEW.dst, 1, 2) = '00' THEN
		IF substr(NEW.dst, 1, 5) = '00800' THEN
			NEW.localidade := '0800';
			NEW.numdisc    := substr(NEW.dst, 2, lenNumDisc - 1);
			NEW.tarifa     := '0';
			NEW.valor      := '0';
			return NEW;			
		ELSE
			numero := substr(NEW.dst, (lenNumDisc - 9), 10);
		END IF;
	ELSEIF substr(NEW.dst, 1, 1) = '0' THEN
		numero := substr(NEW.dst, (lenNumDisc - 7), 8);
	ELSEIF lenNumDisc = 10 AND substr(NEW.dst, 1, 1) != '0' THEN
		-- Caso especial, para mascara de discagem DDXXXXXXXX (para o redial)
		numero := NEW.dst;
	END IF;

	-- Pr� calcular o tamanho do numero discado
	lenNumDisc := char_length(numero);

	-- Chamadas internas nao sao tarifadas
	IF lenNumDisc IS NULL OR lenNumDisc < 8 OR NEW.direcao = '3' THEN
		NEW.localidade := '-CH. INTERNA-';
		NEW.numdisc    := NEW.dst;
		NEW.tarifa     := '0';
		NEW.valor      := '0';
		return NEW;
	END IF;
		
	IF lenNumDisc = 8 THEN
		-- Chamada Local, concaternar o DDD local
		numero := dddLocal || numero;
	END IF;
	-- Setar DDD+Prefixo de destino
	dest := substr(numero, 1, 6);
	-- Setar numdisc
	NEW.numdisc = numero;
	
	-- Buscar a tarifa
	tarifaOK := 0;
	IF NEW.tarifa != '' AND NEW.tarifa != '0' THEN
		SELECT * INTO tarifa FROM valortarifa WHERE num = cast(NEW.tarifa as integer) AND datafinal > NEW.calldate ORDER BY datafinal ASC LIMIT 1;
		IF tarifa.tipo != '' AND tarifa.tipo != '0' THEN
			tarifaOK := tarifa.id;
		END IF;
	END IF;

	-- Buscar a Localidade
	IF NEW.localidade IS NULL THEN
		IF cast(substr(dest, 3, 1) as integer) > 5 THEN
			-- 3o digito > 5 = Celular
			NEW.localidade := 'M�VEL';
		ELSE
			-- Busca a localidade
			SELECT m.nome INTO NEW.localidade FROM prefixo p, municipio m, localidade_prefixo lp, localidade l WHERE p.prefixo = dest AND p.prefixo = cast(lp.prefixo as varchar) AND lp.codigo_cnl = l.codigo_cnl AND l.id_municipio = m.id;
		END IF;	
	END IF;
	
	-- Sem tarifa
	IF tarifaOK = 0 OR NEW.billsec < 4 THEN
		result := '0';
	ELSE
		-- Calculo valor sem taxas 
		valSec := tarifa.vm / 60;
		IF NEW.billsec < tarifa.tempo1 THEN
			-- Valor minimo
			result := valSec * tarifa.tempo1;
		ELSE
			result := valSec * (CEIL(NEW.billsec::float / tarifa.tempo2::float) * tarifa.tempo2); -- arredonda billsec para multp sup de tempo2
		END IF;
--RAISE WARNING 'tempo: %s - valSec: % - ValM: % - T1: % - T2: % - result: % - MOD: %', NEW.billsec, valSec, tarifa.vm, tarifa.tempo1, tarifa.tempo2, result, NEW.billsec % tarifa.tempo2;

		--Verificar o tipo da tarifa para aplicar as taxas
		IF tarifa.ignorataxas = '0' THEN -- Varificar se devemos ignorar as taxas
			-- Achar os tipos de hor�rio para fixo e m�vel
			SELECT horariofixo,horariocelular INTO horarios FROM tipohorario WHERE diasemana = EXTRACT(DOW FROM NEW.calldate) AND hora = date_part('hour', NEW.calldate);
				
			IF tarifa.tipo = '2' THEN
				-- CELULAR
				dddDest := substr(dest, 1, 2);
				IF dddLocal != dddDest THEN
					IF substr(dddLocal, 1, 1) = substr(dddDest, 1, 1) THEN
						--Taxa VC2
						vc := 2;
						result := (result * tarifa.taxavc2);
					ELSE
						--Taxa VC3
						vc := 3;
						result := (result * tarifa.taxavc3);
					END IF;
				ELSE
					vc := 1;
				END IF;
			
				--Taxa HORARIO
				IF horarios.horariocelular = 2 THEN
					NEW.valor := (result * tarifa.taxah2);
				END IF;
			
				--RAISE WARNING 'Chamada Celular, destino: %, vc: %, horario: %', dest, vc, horarios.horariocelular;
			ELSE
				-- FIXO -- Buscar o prefixo local	
				SELECT valor INTO prefLocal FROM parametro where nomeparam = 'prefixoLocal';
				-- Achar o DEGRAU
				SELECT degrau INTO deg FROM matriztarifacao WHERE cnlorigem = (SELECT codigo_area FROM prefixo WHERE prefixo = dddLocal || prefLocal) AND cnldestino = (SELECT codigo_area FROM prefixo WHERE prefixo = dest);
				--Taxa DEGRAU 
				IF     deg = 1 THEN result := (result * 1.3);  -- +30%
				ELSEIF deg = 2 THEN result := (result * 1.5);  -- +50%
				ELSEIF deg = 3 THEN result := (result * 1.75); -- +75%
				ELSEIF deg = 4 THEN result := (result * 2);    -- +100%
				END IF;
		
				--Taxa HORARIO
				IF     horarios.horariofixo = 2 THEN result := (result * 2);    -- +100%
				ELSEIF horarios.horariofixo = 3 THEN result := (result * 0.5);  -- -50%
				ELSEIF horarios.horariofixo = 4 THEN result := (result * 0.25); -- -75%
				END IF;
				
				--RAISE WARNING 'Chamada DDD, destino: %, degrau: %, horario: %', dest, deg, horarios.horariofixo;
			END IF;
		END IF;
	
		IF result > 0 THEN
			SELECT id,nome,tipocobranca,saldo INTO userOrig FROM usuario WHERE CAST(id as varchar) = NEW.accountcode LIMIT 1;
			IF userOrig.tipocobranca = 'E' THEN
				novoSaldo := userOrig.saldo - result;
				IF novoSaldo < 0.015 THEN
					novoSaldo := 0;
				END IF;
				UPDATE usuario SET saldo = novoSaldo WHERE id = userOrig.id;
				--RAISE WARNING 'Usuario % -> saldo atualizado: % -> %', userOrig.nome, userOrig.saldo, novoSaldo;
			END IF;
		END IF;
	END IF;
		
	NEW.valor := result;
	--RAISE WARNING 'Discado: % - Dest: % - Localidade: %, IDtarifa: % - BillSec: % - Valor: %', NEW.dst, dest, NEW.localidade, tarifaOK, NEW.billsec, NEW.valor;
	return NEW;
	
	EXCEPTION
        WHEN others THEN
            RAISE WARNING 'Trigger de tarifacao(ID: % - UID: %) -> Erro! NUM:%, DETAILS:%', NEW.id, NEW.uniqueid, SQLSTATE, SQLERRM;
            return NEW;
END
$BODY$
LANGUAGE 'plpgsql';
ALTER FUNCTION tarifacdr() OWNER TO sa_asterisk;

CREATE TRIGGER tarifacdr_trigger BEFORE INSERT OR UPDATE ON cdr FOR EACH ROW EXECUTE PROCEDURE tarifacdr();
