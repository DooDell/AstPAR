<?php
	header("Location:telefoniaip/index.php");
?>
<!--
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
	"http://www.w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta http-equiv="Content-Language" content="en" />
		<meta name="GENERATOR" content="PHPEclipse 1.2.0" />
		<style type="text/css">
body {
 background: #FFFFFF;
}

a { font-weight: bold; }
a:link { text-decoration: none; color:#333; }
a:visited { text-decoration: none; color:#333; }
a:hover { text-decoration: underline ; color:#000; }

.box { 
  background: #FFFFFF;
  text-align: center;
}
.boxtop { 
  background: url(ne.gif) no-repeat top right; 
}
.boxtop div { 
  font-size: 0;
  height: 15px; 
  background: url(nw.gif) no-repeat top left; 
}
.boxbottom { 
  background: url(se.gif) no-repeat bottom right; 
}
.boxbottom div { 
  font-size: 0;
  height: 15px; 
  background: url(sw.gif) no-repeat bottom left; 
}
.boxcontent {
  padding: 0px 15px 0px 15px;
}

.box2 { 
  background: #FF9000;
  font-family: Arial;
}
.boxtop2 { 
  background: url(ne2.gif) no-repeat top right; 
}
.boxtop2 div { 
  font-size: 0;
  height: 15px; 
  background: url(nw2.gif) no-repeat top left; 
}
.boxbottom2 { 
  background: url(se2.gif) no-repeat bottom right; 
}
.boxbottom2 div { 
  font-size: 0;
  height: 15px; 
  background: url(sw2.gif) no-repeat bottom left; 
}
		</style>
		<title>.: Asterisco Paran� :.</title>
	</head>
	<body>
		<div class='box2'>
			<div class='boxtop2'><div></div></div>
			<div class='boxcontent'>
				<h1>.: Asterisco Paran� 3.5 :.</h1>
				<div class='box'>
					<div class='boxtop'><div></div></div>
					<div class='boxcontent'>
						Acesso ao portal: <a href='http://www.asteriscoparana.pr.gov.br'>http://www.asteriscoparana.pr.gov.br</a>
					</div>
					<div class='boxbottom'><div></div></div>
				</div>
				<br>
				<div class='box'>
					<div class='boxtop'><div></div></div>
					<div class='boxcontent'>
						Acesso a interface do PABX: <a href='telefoniaip/'>PABXIP asteriscoParana</a><br>
					</div>
					<div class='boxbottom'><div></div></div>
				</div>
			</div>
			<div class='boxbottom2'><div></div></div>
		</div>
	</body>
</html>-->